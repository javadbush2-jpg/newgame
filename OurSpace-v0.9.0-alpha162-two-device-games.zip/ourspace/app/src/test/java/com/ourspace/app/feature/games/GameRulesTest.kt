package com.ourspace.app.feature.games

import com.ourspace.app.core.sync.GameEvent
import com.ourspace.app.core.sync.GameMessageProtocol
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class GameRulesTest {
    private val sessionId = "session-123"
    private val host = "phone-host"
    private val guest = "phone-guest"
    private var nextId = 0

    private fun event(
        action: String,
        sender: String,
        vararg args: String,
        gameId: String = "tic_tac_toe",
        at: Long = nextId.toLong()
    ): GameEvent = GameEvent(
        sessionId = sessionId,
        gameId = gameId,
        action = action,
        arguments = args.toList(),
        senderDeviceId = sender,
        messageId = "event-${nextId++}",
        createdAt = at
    )

    private fun pairedStart(gameId: String = "tic_tac_toe") = listOf(
        event("start", host, gameId = gameId, at = 1L),
        event("join", guest, gameId = gameId, at = 2L)
    )

    @Test
    fun ticTacToeRejectsOutOfTurnAndFinishesOnWin() {
        val events = pairedStart() + listOf(
            event("move", host, "0", "0", at = 3L),
            event("move", host, "1", "8", at = 4L), // rejected: guest owns this turn
            event("move", guest, "1", "1", at = 5L),
            event("move", host, "2", "3", at = 6L),
            event("move", guest, "3", "2", at = 7L),
            event("move", host, "4", "6", at = 8L)
        )

        val snapshot = buildOnlineGameSessions(events).single().snapshot

        assertEquals(listOf(1, 2, 0, 1, 0, 0, 1, 0, 2), snapshot.board)
        assertEquals(host, snapshot.winnerDeviceId)
        assertTrue(snapshot.isFinished)
        assertFalse(snapshot.isDraw)
        assertNull(snapshot.currentPlayerDeviceId)
    }

    @Test
    fun nimAlternatesPhonesAndRejectsIllegalTake() {
        val events = pairedStart("nim") + listOf(
            event("move", host, "0", "3", gameId = "nim", at = 3L),
            event("move", host, "1", "2", gameId = "nim", at = 4L), // out of turn
            event("move", guest, "1", "2", gameId = "nim", at = 5L)
        )

        val session = buildOnlineGameSessions(events).single()

        assertEquals(10, session.snapshot.remainingTokens)
        assertEquals(host, session.snapshot.currentPlayerDeviceId)
        assertFalse(session.snapshot.isFinished)
    }

    @Test
    fun reversiStartsWithFourLegalMovesAndFlipsCapturedDisc() {
        val events = pairedStart("reversi") + event("move", host, "0", "19", gameId = "reversi", at = 3L)
        val snapshot = buildOnlineGameSessions(events).single().snapshot

        assertEquals(setOf(19, 26, 37, 44), reversiLegalMoves(initialReversiBoard(), 1))
        assertEquals(1, snapshot.board[19])
        assertEquals(1, snapshot.board[27])
        assertEquals(guest, snapshot.currentPlayerDeviceId)
        assertEquals(setOf(18, 20, 34), snapshot.legalMoves)
    }

    @Test
    fun rockPaperScissorsCommitRevealAwardsScoreWithoutPublishingChoiceEarly() {
        val choiceHost = "paper"
        val choiceGuest = "rock"
        val nonceHost = "salt-host"
        val nonceGuest = "salt-guest"
        val hashHost = GameMessageProtocol.rockPaperScissorsCommitment(sessionId, 1, host, choiceHost, nonceHost)
        val hashGuest = GameMessageProtocol.rockPaperScissorsCommitment(sessionId, 1, guest, choiceGuest, nonceGuest)
        val events = pairedStart("rock_paper_scissors") + listOf(
            event("commit", host, "1", hashHost, gameId = "rock_paper_scissors", at = 3L),
            event("commit", guest, "1", hashGuest, gameId = "rock_paper_scissors", at = 4L)
        )
        val beforeReveal = buildOnlineGameSessions(events).single().snapshot
        assertEquals(setOf(host, guest), beforeReveal.committedDeviceIds)
        assertTrue(beforeReveal.revealedChoices.isEmpty())

        val completedEvents = events + listOf(
            event("reveal", host, "1", choiceHost, nonceHost, gameId = "rock_paper_scissors", at = 5L),
            event("reveal", guest, "1", choiceGuest, nonceGuest, gameId = "rock_paper_scissors", at = 6L)
        )
        val completed = buildOnlineGameSessions(completedEvents).single().snapshot
        assertEquals(1, completed.hostScore)
        assertEquals(0, completed.guestScore)
        assertEquals(2, completed.rpsRound)
        assertEquals(host, completed.lastCompletedRpsRound?.winnerDeviceId)
    }

    @Test
    fun protocolRoundTripsMachineEventsAndRejectsOrdinaryChat() {
        val encoded = GameMessageProtocol.encode(sessionId, "nim", "move", "3")
        val decoded = GameMessageProtocol.decode(encoded, host, "message-1", 42L)

        assertTrue(GameMessageProtocol.isProtocolMessage(encoded))
        assertEquals("nim", decoded?.gameId)
        assertEquals("move", decoded?.action)
        assertEquals(listOf("3"), decoded?.arguments)
        assertNull(GameMessageProtocol.decode("سلام", host, "message-2", 43L))
    }

    @Test
    fun aGameSessionAppearsOnlyAfterAValidStartEvent() {
        val invalid = event("move", host, "1")
        assertTrue(buildOnlineGameSessions(listOf(invalid)).isEmpty())
    }
}
