package com.ourspace.app.core.sync

import java.nio.charset.StandardCharsets
import java.security.MessageDigest

/**
 * Small, versioned game-event envelope carried by the existing paired-device message sync.
 * These messages are intentionally machine-only and are filtered out of the human chat UI.
 */
object GameMessageProtocol {
    const val PREFIX = "[[OSGAME1]]|"
    const val SQLITE_CHAT_EXCLUSION_PATTERN = "[[OSGAME1]]|%"

    fun isProtocolMessage(text: String): Boolean = text.startsWith(PREFIX)

    fun encode(
        sessionId: String,
        gameId: String,
        action: String,
        vararg arguments: String
    ): String {
        require(isSafeToken(sessionId, 80)) { "Invalid game session id" }
        require(isSafeToken(gameId, 32)) { "Invalid game id" }
        require(isSafeToken(action, 24)) { "Invalid game action" }
        require(arguments.size <= 4) { "Too many game event arguments" }
        require(arguments.all { isSafeArgument(it) }) { "Invalid game event argument" }
        return PREFIX + (listOf(sessionId, gameId, action) + arguments).joinToString("|")
    }

    fun decode(
        text: String,
        senderDeviceId: String,
        messageId: String,
        createdAt: Long
    ): GameEvent? {
        if (!isProtocolMessage(text) || senderDeviceId.isBlank() || messageId.isBlank()) return null
        val fields = text.removePrefix(PREFIX).split('|')
        if (fields.size !in 3..7) return null
        val sessionId = fields[0]
        val gameId = fields[1]
        val action = fields[2]
        val arguments = fields.drop(3)
        if (!isSafeToken(sessionId, 80) || !isSafeToken(gameId, 32) || !isSafeToken(action, 24)) return null
        if (arguments.any { !isSafeArgument(it) }) return null
        return GameEvent(
            sessionId = sessionId,
            gameId = gameId,
            action = action,
            arguments = arguments,
            senderDeviceId = senderDeviceId,
            messageId = messageId,
            createdAt = createdAt
        )
    }

    fun rockPaperScissorsCommitment(
        sessionId: String,
        round: Int,
        deviceId: String,
        choice: String,
        nonce: String
    ): String {
        require(round > 0)
        require(choice in setOf("rock", "paper", "scissors"))
        require(deviceId.isNotBlank() && nonce.isNotBlank())
        val material = "$sessionId|$round|$deviceId|$choice|$nonce"
        val digest = MessageDigest.getInstance("SHA-256")
            .digest(material.toByteArray(StandardCharsets.UTF_8))
        return digest.joinToString(separator = "") { byte -> (byte.toInt() and 0xff).toString(16).padStart(2, '0') }
    }

    private fun isSafeToken(value: String, maxLength: Int): Boolean =
        value.length in 1..maxLength && value.all { it.isLetterOrDigit() || it == '-' || it == '_' }

    private fun isSafeArgument(value: String): Boolean =
        value.length in 1..128 && value.all { it != '|' && !it.isISOControl() }
}

data class GameEvent(
    val sessionId: String,
    val gameId: String,
    val action: String,
    val arguments: List<String>,
    val senderDeviceId: String,
    val messageId: String,
    val createdAt: Long
)
