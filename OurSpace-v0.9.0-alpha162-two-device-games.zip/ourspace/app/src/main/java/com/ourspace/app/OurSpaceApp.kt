package com.ourspace.app

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.platform.LocalContext
import androidx.compose.runtime.setValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.ourspace.app.feature.home.MainShell
import com.ourspace.app.ui.components.HeartbeatOverlay
import com.ourspace.app.feature.onboarding.OnboardingScreen
import com.ourspace.app.model.DeviceRole
import com.ourspace.app.ui.AppViewModel
import com.ourspace.app.ui.components.AmbientBackground
import com.ourspace.app.ui.components.FloatingMotion

@Composable
fun OurSpaceApp(viewModel: AppViewModel = viewModel()) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val pairingAction by viewModel.pairingAction.collectAsStateWithLifecycle()

    LaunchedEffect(state.role) {
        viewModel.ensureHostService(state.role)
    }

    when {
        state.isLoading || state.deviceIdentity == null -> {
            AmbientBackground {
                Column(
                    Modifier.fillMaxSize(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = androidx.compose.foundation.layout.Arrangement.Center
                ) {
                    FloatingMotion {
                        Box(
                            Modifier.size(86.dp).background(MaterialTheme.colorScheme.primaryContainer, RoundedCornerShape(28.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Outlined.FavoriteBorder, null, modifier = Modifier.size(44.dp), tint = MaterialTheme.colorScheme.primary)
                        }
                    }
                    Spacer(Modifier.height(20.dp))
                    Text("OurSpace", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Black)
                    Text("در حال آماده‌سازی فضای امن شما…", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.height(14.dp))
                    CircularProgressIndicator(Modifier.size(26.dp))
                }
            }
        }
        state.role == null -> {
            OnboardingScreen(
                pairingInProgress = pairingAction.isLoading,
                pairingMessage = pairingAction.message,
                pairingError = pairingAction.error,
                onSaveServer = viewModel::saveOnboardingRelay,
                onHostReady = viewModel::completeHostSetup,
                onCompanionReady = viewModel::completeCompanionSetup
            )
        }
        else -> AuthenticatedApp(viewModel, state.role!!, state.deviceIdentity!!)
    }
}

@Composable
private fun AuthenticatedApp(
    viewModel: AppViewModel,
    role: DeviceRole,
    identity: com.ourspace.app.core.security.DeviceIdentityManager.DeviceIdentity
) {
    val tasks by viewModel.tasks.collectAsStateWithLifecycle()
    val events by viewModel.events.collectAsStateWithLifecycle()
    val shoppingItems by viewModel.shoppingItems.collectAsStateWithLifecycle()
    val messages by viewModel.messages.collectAsStateWithLifecycle()
    val gameMessages by viewModel.gameMessages.collectAsStateWithLifecycle()
    val attachments by viewModel.attachments.collectAsStateWithLifecycle()
    val financialAccounts by viewModel.financialAccounts.collectAsStateWithLifecycle()
    val financeTransactions by viewModel.financeTransactions.collectAsStateWithLifecycle()
    val financeBudgets by viewModel.financeBudgets.collectAsStateWithLifecycle()
    val sharedDebts by viewModel.sharedDebts.collectAsStateWithLifecycle()
    val recurringTransactions by viewModel.recurringTransactions.collectAsStateWithLifecycle()
    val memories by viewModel.memories.collectAsStateWithLifecycle()
    val moodCheckIns by viewModel.moodCheckIns.collectAsStateWithLifecycle()
    val specialDates by viewModel.specialDates.collectAsStateWithLifecycle()
    val cycleLogs by viewModel.cycleLogs.collectAsStateWithLifecycle()
    val cycleSettings by viewModel.cycleSettings.collectAsStateWithLifecycle()
    val coupleProfile by viewModel.coupleProfile.collectAsStateWithLifecycle()
    val palette by viewModel.palette.collectAsStateWithLifecycle()
    val themeMode by viewModel.themeMode.collectAsStateWithLifecycle()
    val telegramBotToken by viewModel.telegramBotToken.collectAsStateWithLifecycle()
    val telegramStickerPacks by viewModel.telegramStickerPacks.collectAsStateWithLifecycle()
    val stickerImportAction by viewModel.stickerImportAction.collectAsStateWithLifecycle()
    val pairingSnapshot by viewModel.pairingSnapshot.collectAsStateWithLifecycle()
    val pairingAction by viewModel.pairingAction.collectAsStateWithLifecycle()
    val syncState by viewModel.syncState.collectAsStateWithLifecycle()
    val relayConfig by viewModel.relayConfig.collectAsStateWithLifecycle()
    val diagnostics by viewModel.diagnostics.collectAsStateWithLifecycle()
    val syncHealth by viewModel.syncHealth.collectAsStateWithLifecycle()
    val relayAction by viewModel.relayAction.collectAsStateWithLifecycle()
    val backupAction by viewModel.backupAction.collectAsStateWithLifecycle()
    val attachmentAction by viewModel.attachmentAction.collectAsStateWithLifecycle()
    val chatAction by viewModel.chatAction.collectAsStateWithLifecycle()
    val peerTyping by viewModel.peerTyping.collectAsStateWithLifecycle()
    val pendingSendIds by viewModel.pendingSendIds.collectAsStateWithLifecycle()
    val pendingSyncChanges by viewModel.pendingSyncChanges.collectAsStateWithLifecycle()
    val pendingSyncUnsent by viewModel.pendingSyncUnsent.collectAsStateWithLifecycle()
    val pendingSyncAwaitingAck by viewModel.pendingSyncAwaitingAck.collectAsStateWithLifecycle()
    val locationShares by viewModel.locationShares.collectAsStateWithLifecycle()
    val locationSharingEnabled by viewModel.locationSharingEnabled.collectAsStateWithLifecycle()
    val locationAction by viewModel.locationAction.collectAsStateWithLifecycle()
    val heartAction by viewModel.heartAction.collectAsStateWithLifecycle()
    val heartAnimation by viewModel.incomingHeartAnimation.collectAsStateWithLifecycle()
    val sharedPlaces by viewModel.sharedPlaces.collectAsStateWithLifecycle()
    val habits by viewModel.habits.collectAsStateWithLifecycle()
    val watchlistItems by viewModel.watchlistItems.collectAsStateWithLifecycle()

    val context = LocalContext.current
    var hasLocationPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
                ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        )
    }
    val locationPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { result ->
        hasLocationPermission = result.values.any { it }
        if (hasLocationPermission) {
            // Enabling sharing schedules the first publish after persisting the preference.
            viewModel.setLocationSharingEnabled(true)
        }
    }

    MainShell(
        role = role,
        identity = identity,
        pairingSnapshot = pairingSnapshot,
        pairingAction = pairingAction,
        syncState = syncState,
        relayConfig = relayConfig,
        relayAction = relayAction,
        backupAction = backupAction,
        onBackupNow = viewModel::backupNow,
        onRestoreBackup = viewModel::restoreBackup,
        pendingSyncChanges = pendingSyncChanges,
        pendingSyncUnsent = pendingSyncUnsent,
        pendingSyncAwaitingAck = pendingSyncAwaitingAck,
        tasks = tasks,
        events = events,
        shoppingItems = shoppingItems,
        messages = messages,
        gameMessages = gameMessages,
        attachments = attachments,
        attachmentAction = attachmentAction,
        chatAction = chatAction,
        stickerImportAction = stickerImportAction,
        telegramStickerPacks = telegramStickerPacks,
        onImportTelegramPack = viewModel::importTelegramStickerPack,
        onDeleteTelegramPack = viewModel::deleteTelegramStickerPack,
        onObserveTelegramStickers = viewModel::observeTelegramStickers,
        onSendTelegramSticker = viewModel::sendTelegramSticker,
        peerTyping = peerTyping,
        pendingSendIds = pendingSendIds,
        financialAccounts = financialAccounts,
        financeTransactions = financeTransactions,
        financeBudgets = financeBudgets,
        sharedDebts = sharedDebts,
        recurringTransactions = recurringTransactions,
        memories = memories,
        moodCheckIns = moodCheckIns,
        specialDates = specialDates,
        cycleLogs = cycleLogs,
        cycleSettings = cycleSettings,
        locationShares = locationShares,
        locationSharingEnabled = locationSharingEnabled,
        locationAction = locationAction,
        coupleProfile = coupleProfile,
        palette = palette,
        themeMode = themeMode,
        onAddTask = viewModel::addTask,
        onAddTimedTask = viewModel::addTimedTask,
        onToggleTask = viewModel::toggleTask,
        onUpdateTaskSchedule = viewModel::updateTaskSchedule,
        onDeleteTask = viewModel::deleteTask,
        onAddEvent = viewModel::addEvent,
        onAddTimedEvent = viewModel::addTimedEvent,
        onAddWorkScheduleEvents = viewModel::addWorkScheduleEvents,
        onUpdateEvent = viewModel::updateEvent,
        onUpdateEventSchedule = viewModel::updateEventSchedule,
        onDeleteEvent = viewModel::deleteEvent,
        onAddShopping = viewModel::addShoppingItem,
        onToggleShopping = viewModel::toggleShoppingItem,
        onDeleteShopping = viewModel::deleteShoppingItem,
        onClearCheckedShopping = viewModel::clearCheckedShopping,
        heartAction = heartAction,
        onSendHeartPulse = viewModel::sendHeartPulse,
        onSendMessage = viewModel::sendMessage,
        onSendGameMessage = viewModel::sendGameEvent,
        onSendAttachment = viewModel::sendMessageAttachment,
        onSaveAttachment = viewModel::saveAttachmentCopy,
        onLoadAttachment = viewModel::loadAttachmentContent,
        onDeleteAttachment = viewModel::deleteAttachment,
        onEditMessage = viewModel::editMessage,
        onDeleteMessage = viewModel::deleteMessage,
        onReactMessage = viewModel::reactToMessage,
        onMarkVisibleChatMessagesRead = viewModel::markVisibleChatMessagesRead,
        onTyping = viewModel::notifyTyping,
        onStampDeliveries = viewModel::stampIncomingDeliveries,
        onShareTaskToChat = viewModel::shareTaskToChat,
        onShareEventToChat = viewModel::shareEventToChat,
        onShareDebtToChat = viewModel::shareDebtToChat,
        onShareMemoryToChat = viewModel::shareMemoryToChat,
        onShareLocationToChat = viewModel::shareLocationToChat,
        onSearchChatMessages = viewModel::searchChatMessages,
        onFindChatMessage = viewModel::findChatMessage,
        onLoadOlderChatMessages = viewModel::loadOlderChatMessages,
        onAddFinancialAccount = viewModel::addFinancialAccount,
        onCorrectFinancialAccountBalance = viewModel::correctFinancialAccountBalance,
        onAddFinanceTransaction = viewModel::addFinanceTransaction,
        onAddFinanceTransactionAt = viewModel::addFinanceTransactionAt,
        onDeleteFinanceTransaction = viewModel::deleteFinanceTransaction,
        onSetFinanceBudget = viewModel::setFinanceBudget,
        onAddSharedDebt = viewModel::addSharedDebt,
        onToggleDebtSettled = viewModel::toggleDebtSettled,
        onDeleteSharedDebt = viewModel::deleteSharedDebt,
        onAddRecurringTransaction = viewModel::addRecurringTransaction,
        onToggleRecurringTransaction = viewModel::toggleRecurringTransaction,
        onDeleteRecurringTransaction = viewModel::deleteRecurringTransaction,
        onAddMemory = viewModel::addMemory,
        onUpdateMemory = viewModel::updateMemory,
        onAddMemoryAttachment = { memoryId, uri, rotation -> viewModel.addMemoryAttachment(memoryId, uri, rotation) },
        onRotateMemoryAttachment = viewModel::rotateMemoryAttachment,
        onToggleMemoryFavorite = viewModel::toggleMemoryFavorite,
        onDeleteMemory = viewModel::deleteMemory,
        onSetDailyMood = viewModel::setDailyMood,
        onSetMoodForDay = viewModel::setMoodForDay,
        onAddSpecialDate = viewModel::addSpecialDate,
        onUpdateSpecialDate = viewModel::updateSpecialDate,
        onDeleteSpecialDate = viewModel::deleteSpecialDate,
        onStartPeriod = viewModel::startPeriod,
        onEndPeriod = viewModel::endPeriod,
        onDeleteCycleLog = viewModel::deleteCycleLog,
        onUpdateCycleSettings = viewModel::updateCycleSettings,
        onToggleLocationSharing = viewModel::setLocationSharingEnabled,
        onRefreshLocation = { viewModel.publishLocationNow() },
        onRefreshPartnerLocation = viewModel::refreshPartnerLocation,
        onRequestLocationPermission = {
            locationPermissionLauncher.launch(
                arrayOf(
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION
                )
            )
        },
        hasLocationPermission = hasLocationPermission,
        onSaveCoupleProfile = viewModel::saveCoupleProfile,
        onSetPalette = viewModel::setPalette,
        onSetThemeMode = viewModel::setThemeMode,
        telegramBotToken = telegramBotToken,
        onSetTelegramBotToken = viewModel::setTelegramBotToken,
        onApprovePairing = viewModel::approveIncomingPairing,
        onRejectPairing = viewModel::rejectIncomingPairing,
        onCheckPairing = viewModel::checkPairingStatus,
        onCancelPairing = viewModel::cancelOutgoingPairing,
        onRevokeTrust = viewModel::revokeTrustedDevice,
        onSync = viewModel::syncNow,
        onSaveRelayConfig = viewModel::saveRelayConfig,
        diagnostics = diagnostics,
        syncHealth = syncHealth,
        onRunConnectionTest = viewModel::runConnectionTest,
        onClearDiagnostics = viewModel::clearDiagnostics,
        onPairPayload = viewModel::completeCompanionSetup,
        onScanCompanionReply = viewModel::applyCompanionReplyQr,
                onScanApproval = viewModel::applyApprovalQr,
        onPairWithPin = viewModel::pairWithPin,
        onGenerateHostPin = viewModel::generateHostPin,
        onReset = viewModel::resetApp,
        sharedPlaces = sharedPlaces,
        habits = habits,
        watchlistItems = watchlistItems,
        onAddSharedPlace = viewModel::addSharedPlace,
        onAddHabit = viewModel::addHabit,
        onToggleHabitDoneToday = viewModel::toggleHabitDoneToday,
        onDeleteHabit = viewModel::deleteHabit,
        onAddWatchlistItem = viewModel::addWatchlistItem,
        onCycleWatchlistStatus = viewModel::cycleWatchlistStatus,
        onDeleteWatchlistItem = viewModel::deleteWatchlistItem,
        onDeleteSharedPlace = viewModel::deleteSharedPlace
    )
    HeartbeatOverlay(
        visible = heartAnimation,
        onAcknowledge = viewModel::acknowledgeLatestHeartPulse,
        onDismiss = viewModel::clearHeartAnimation
    )
}

