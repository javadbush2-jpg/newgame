"""Static integration contracts for two-device game events and chat isolation."""

from pathlib import Path
import re
import unittest

ROOT = Path(__file__).resolve().parents[1]


class TwoDeviceGamesContractTest(unittest.TestCase):
    def read(self, relative: str) -> str:
        return (ROOT / relative).read_text(encoding="utf-8")

    def test_version_and_catalog_have_five_two_device_games(self):
        gradle = self.read("app/build.gradle.kts")
        rules = self.read("app/src/main/java/com/ourspace/app/feature/games/GameRules.kt")
        self.assertIn('versionCode = 162', gradle)
        self.assertIn('versionName = "0.9.0-alpha162-two-device-games"', gradle)
        for game in ("tic_tac_toe", "connect_four", "rock_paper_scissors", "nim", "reversi"):
            self.assertIn(f'("{game}"', rules)

    def test_game_events_use_the_existing_message_sync_path(self):
        view_model = self.read("app/src/main/java/com/ourspace/app/ui/AppViewModel.kt")
        game_protocol = self.read("app/src/main/java/com/ourspace/app/core/sync/GameMessageProtocol.kt")
        self.assertIn("repository.sendMessage(deviceId, text, replyToId = null)", view_model)
        self.assertRegex(view_model, re.compile(r"sendGameEvent\(text: String\).*?autoSync\(\)", re.S))
        self.assertIn('const val PREFIX = "[[OSGAME1]]|"', game_protocol)
        self.assertIn("fun observeGameMessages(gamePrefixPattern: String)", self.read("app/src/main/java/com/ourspace/app/core/database/OurSpaceDao.kt"))

    def test_game_events_are_excluded_from_chat_and_chat_notifications(self):
        dao = self.read("app/src/main/java/com/ourspace/app/core/database/OurSpaceDao.kt")
        self.assertIn("text NOT LIKE '[[OSGAME1]]|%'", dao)
        self.assertIn("text LIKE :gamePrefixPattern", dao)
        self.assertIn("unreadCountOnce", dao)
        chat = self.read("app/src/main/java/com/ourspace/app/feature/chat/ChatScreen.kt")
        self.assertIn("GameMessageProtocol.isProtocolMessage(it.text)", chat)
        host_sync = self.read("app/src/main/java/com/ourspace/app/core/sync/HostSyncExchangeProcessor.kt")
        relay = self.read("app/src/main/java/com/ourspace/app/core/relay/RelayDuplexPoller.kt")
        self.assertIn("!incomingGameEventsOnly", host_sync)
        self.assertIn("!gameEventsOnly", relay)

    def test_turn_messages_carry_ply_and_jvm_rules_tests_exist(self):
        rules = self.read("app/src/main/java/com/ourspace/app/feature/games/GameRules.kt")
        screen = self.read("app/src/main/java/com/ourspace/app/feature/games/GamesScreen.kt")
        tests = self.read("app/src/test/java/com/ourspace/app/feature/games/GameRulesTest.kt")
        self.assertIn("orderedTurnMoves(events)", rules)
        self.assertGreaterEqual(screen.count("snapshot.moveCount.toString()"), 3)
        self.assertIn("protocolRoundTripsMachineEventsAndRejectsOrdinaryChat", tests)
        self.assertIn("rockPaperScissorsCommitRevealAwardsScoreWithoutPublishingChoiceEarly", tests)


if __name__ == "__main__":
    unittest.main()
