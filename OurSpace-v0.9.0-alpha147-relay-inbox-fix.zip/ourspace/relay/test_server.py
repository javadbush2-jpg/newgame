import os
import shutil
import sqlite3
import tempfile
import time
import unittest
import json
import threading
from http.server import ThreadingHTTPServer
from urllib.request import Request, urlopen
from urllib.error import HTTPError

from server import RelayStore, mailbox_for_token, validate_acknowledgements, validate_message


class RelayServerTest(unittest.TestCase):
    def setUp(self):
        # ignore_cleanup_errors helps on Windows when SQLite briefly holds the file.
        self.temp = tempfile.TemporaryDirectory(ignore_cleanup_errors=True)
        self.db_path = os.path.join(self.temp.name, "relay.sqlite3")
        self.store = RelayStore(self.db_path)
        self.now = int(time.time() * 1000)
        self.message = {
            "messageId": "550e8400-e29b-41d4-a716-446655440000",
            "correlationId": None,
            "createdAt": self.now,
            "expiresAt": self.now + 60_000,
            "envelope": {
                "type": "incremental_exchange",
                "requestId": "550e8400-e29b-41d4-a716-446655440000",
                "sentAt": self.now,
                "delta": {},
            },
        }

    def tearDown(self):
        # Windows keeps SQLite WAL handles open unless we switch journal mode and close.
        try:
            if os.path.exists(self.db_path):
                conn = sqlite3.connect(self.db_path, timeout=5)
                try:
                    conn.execute("PRAGMA journal_mode=DELETE")
                    conn.execute("PRAGMA wal_checkpoint(TRUNCATE)")
                    conn.commit()
                finally:
                    conn.close()
        except Exception:
            pass
        self.store = None
        self.temp.cleanup()

    def test_database_path_is_resolved_to_absolute_path(self):
        self.assertTrue(os.path.isabs(self.store.path))

    def test_health_returns_503_when_database_directory_disappears(self):
        import server as relay_server
        db_dir = os.path.join(self.temp.name, "vanishing-db-dir")
        store = RelayStore(os.path.join(db_dir, "relay.sqlite3"))
        shutil.rmtree(db_dir)
        httpd = ThreadingHTTPServer(("127.0.0.1", 0), relay_server.RelayHandler)
        httpd.store = store
        httpd.limiter = relay_server.RateLimiter()
        thread = threading.Thread(target=httpd.serve_forever, daemon=True)
        thread.start()
        try:
            url = f"http://127.0.0.1:{httpd.server_address[1]}/health"
            with self.assertRaises(HTTPError) as error:
                urlopen(url, timeout=3)
            self.assertEqual(503, error.exception.code)
            payload = json.loads(error.exception.read())
            self.assertEqual("degraded", payload["status"])
            self.assertEqual("database_unavailable", payload["error"])
        finally:
            httpd.shutdown()
            httpd.server_close()
            thread.join(timeout=2)

    def test_health_stats_ignore_expired_rows_without_deleting_them(self):
        now_ms = int(time.time() * 1000)
        with self.store.transaction() as database:
            database.execute(
                """INSERT INTO relay_messages(
                    mailbox_id, direction, message_id, correlation_id,
                    created_at, expires_at, envelope_json
                ) VALUES (?, ?, ?, ?, ?, ?, ?)""",
                ("M" * 43, "to-host", "ExpiredMessage12345", None,
                 now_ms - 10_000, now_ms - 1, "{}"),
            )
        snapshot = self.store.stats_snapshot()
        self.assertEqual(0, snapshot["pendingMessages"])
        with self.store.transaction() as database:
            remaining = database.execute(
                "SELECT COUNT(*) FROM relay_messages WHERE message_id=?",
                ("ExpiredMessage12345",),
            ).fetchone()[0]
        self.assertEqual(1, remaining)

    def test_household_token_matches_android_default(self):
        from server import DEFAULT_HOUSEHOLD_TOKEN, load_or_create_household_token
        token_path = os.path.join(self.temp.name, "household.json")
        with open(token_path, "w", encoding="utf-8") as fh:
            fh.write('{"token":"old-random-token-that-does-not-match"}')
        token, mailbox = load_or_create_household_token(token_path)
        self.assertEqual(DEFAULT_HOUSEHOLD_TOKEN, token)
        self.assertEqual(mailbox_for_token(DEFAULT_HOUSEHOLD_TOKEN), mailbox)
        with open(token_path, "r", encoding="utf-8") as fh:
            self.assertEqual(DEFAULT_HOUSEHOLD_TOKEN, __import__("json").load(fh)["token"])

    def test_pin_pairing_endpoints_register_and_validate(self):
        import server as relay_server
        old_values = (
            relay_server.HOUSEHOLD_TOKEN,
            relay_server.HOUSEHOLD_MAILBOX,
            relay_server.HOST_PIN_HASH,
            relay_server.HOST_PIN_EXPIRES_AT,
        )
        httpd = ThreadingHTTPServer(("127.0.0.1", 0), relay_server.RelayHandler)
        httpd.store = self.store
        httpd.limiter = relay_server.RateLimiter()
        relay_server.HOUSEHOLD_TOKEN = relay_server.DEFAULT_HOUSEHOLD_TOKEN
        relay_server.HOUSEHOLD_MAILBOX = relay_server.mailbox_for_token(relay_server.DEFAULT_HOUSEHOLD_TOKEN)
        relay_server.HOST_PIN_HASH = None
        relay_server.HOST_PIN_EXPIRES_AT = 0.0
        thread = threading.Thread(target=httpd.serve_forever, daemon=True)
        thread.start()
        base = f"http://127.0.0.1:{httpd.server_address[1]}"
        headers = {
            "Authorization": f"Bearer {relay_server.DEFAULT_HOUSEHOLD_TOKEN}",
            "Content-Type": "application/json",
        }
        try:
            request = Request(base + "/pairing/host-pin", data=json.dumps({"pin": "4821"}).encode(), headers=headers, method="POST")
            with urlopen(request, timeout=3) as response:
                self.assertTrue(json.loads(response.read())["registered"])

            valid = Request(base + "/pairing/verify-pin", data=json.dumps({"pin": "4821"}).encode(), headers=headers, method="POST")
            with urlopen(valid, timeout=3) as response:
                self.assertTrue(json.loads(response.read())["valid"])

            wrong = Request(base + "/pairing/verify-pin", data=json.dumps({"pin": "1111"}).encode(), headers=headers, method="POST")
            with self.assertRaises(HTTPError) as error:
                urlopen(wrong, timeout=3)
            self.assertEqual(403, error.exception.code)
        finally:
            httpd.shutdown()
            httpd.server_close()
            thread.join(timeout=2)
            (relay_server.HOUSEHOLD_TOKEN, relay_server.HOUSEHOLD_MAILBOX,
             relay_server.HOST_PIN_HASH, relay_server.HOST_PIN_EXPIRES_AT) = old_values

    def test_encrypted_backup_store_round_trip(self):
        backup = {"v": 1, "nonce": "dGVzdG5vbmNl", "ciphertext": "Y2lwaGVydGV4dA"}
        mailbox = mailbox_for_token("A" * 43)
        self.store.save_backup(mailbox, self.now, backup)
        restored = self.store.get_backup(mailbox)
        self.assertEqual((self.now, backup), restored)
        # Older uploads must not replace a newer snapshot.
        self.store.save_backup(mailbox, self.now - 1, {"v": 1, "nonce": "old", "ciphertext": "old"})
        self.assertEqual((self.now, backup), self.store.get_backup(mailbox))

    def test_backup_http_endpoints_require_token_and_round_trip(self):
        import server as relay_server
        old_values = (relay_server.HOUSEHOLD_TOKEN, relay_server.HOUSEHOLD_MAILBOX)
        relay_server.HOUSEHOLD_TOKEN = relay_server.DEFAULT_HOUSEHOLD_TOKEN
        relay_server.HOUSEHOLD_MAILBOX = relay_server.mailbox_for_token(relay_server.DEFAULT_HOUSEHOLD_TOKEN)
        httpd = ThreadingHTTPServer(("127.0.0.1", 0), relay_server.RelayHandler)
        httpd.store = self.store
        httpd.limiter = relay_server.RateLimiter()
        thread = threading.Thread(target=httpd.serve_forever, daemon=True)
        thread.start()
        base = f"http://127.0.0.1:{httpd.server_address[1]}"
        headers = {"Authorization": f"Bearer {relay_server.DEFAULT_HOUSEHOLD_TOKEN}", "Content-Type": "application/json"}
        backup = {"v": 1, "nonce": "dGVzdG5vbmNl", "ciphertext": "Y2lwaGVydGV4dA"}
        try:
            request = Request(base + "/v1/backup", data=json.dumps({"updatedAt": self.now, "backup": backup}).encode(), headers=headers, method="POST")
            with urlopen(request, timeout=3) as response:
                self.assertTrue(json.loads(response.read())["stored"])
            request = Request(base + "/v1/backup", headers={"Authorization": headers["Authorization"]}, method="GET")
            with urlopen(request, timeout=3) as response:
                payload = json.loads(response.read())
                self.assertEqual(self.now, payload["updatedAt"])
                self.assertEqual(backup, payload["backup"])
        finally:
            httpd.shutdown()
            httpd.server_close()
            thread.join(timeout=2)
            relay_server.HOUSEHOLD_TOKEN, relay_server.HOUSEHOLD_MAILBOX = old_values

    def test_mailbox_is_hash_of_bearer_token(self):
        token = "A" * 43
        self.assertEqual(43, len(mailbox_for_token(token)))
        self.assertNotEqual(mailbox_for_token(token), mailbox_for_token("B" * 43))

    def test_publish_is_idempotent_but_conflict_is_rejected(self):
        message = validate_message(dict(self.message))
        self.assertTrue(self.store.publish("M" * 43, "to-host", message))
        self.assertFalse(self.store.publish("M" * 43, "to-host", message))
        changed = dict(message)
        changed["envelope"] = {"type": "changed"}
        # Reusing a transport ID with a newer body is an intentional replace operation;
        # it avoids multiplying queue rows when an ACK list changes during retry.
        self.assertTrue(self.store.publish("M" * 43, "to-host", changed))
        queued = self.store.receive("M" * 43, "to-host", 20)
        self.assertEqual(1, len(queued))
        self.assertEqual("changed", queued[0]["envelope"]["type"])

    def test_full_mailbox_applies_backpressure_without_evicting_unacknowledged_messages(self):
        import server as relay_server
        old_limit = relay_server.MAX_MESSAGES_PER_MAILBOX
        old_total = relay_server.MAX_TOTAL_MESSAGES
        relay_server.MAX_MESSAGES_PER_MAILBOX = 1
        relay_server.MAX_TOTAL_MESSAGES = 100
        mailbox = "M" * 43
        first = validate_message(dict(self.message))
        try:
            self.assertTrue(self.store.publish(mailbox, "to-host", first))
            second = dict(self.message)
            second["messageId"] = "650e8400-e29b-41d4-a716-446655440001"
            second["createdAt"] = self.now + 1
            second["envelope"] = {"type": "incremental_exchange", "requestId": second["messageId"], "delta": {"x": 1}}
            with self.assertRaises(OverflowError):
                self.store.publish(mailbox, "to-host", validate_message(second))
            queued = self.store.receive(mailbox, "to-host", 20)
            self.assertEqual(1, len(queued))
            self.assertEqual(first["messageId"], queued[0]["messageId"])
        finally:
            relay_server.MAX_MESSAGES_PER_MAILBOX = old_limit
            relay_server.MAX_TOTAL_MESSAGES = old_total

    def test_receive_requires_acknowledgement_before_delete(self):
        import server as relay_server
        before = dict(relay_server.STATS)
        self.store.publish("M" * 43, "to-host", validate_message(dict(self.message)))
        first = self.store.receive("M" * 43, "to-host", 20)
        second = self.store.receive("M" * 43, "to-host", 20)
        self.assertEqual(1, len(first))
        self.assertEqual(first, second)
        self.assertEqual(1, self.store.acknowledge("M" * 43, "to-host", [self.message["messageId"]]))
        self.assertEqual([], self.store.receive("M" * 43, "to-host", 20))
        self.assertEqual(before["receive"] + 3, relay_server.STATS["receive"])
        self.assertEqual(before["receive_to_host"] + 3, relay_server.STATS["receive_to_host"])
        self.assertEqual(before["receive_messages_to_host"] + 2, relay_server.STATS["receive_messages_to_host"])
        self.assertEqual(before["ack"] + 1, relay_server.STATS["ack"])
        self.assertEqual(before["ack_to_host"] + 1, relay_server.STATS["ack_to_host"])
        self.assertEqual(before["ack_deleted_to_host"] + 1, relay_server.STATS["ack_deleted_to_host"])

    def test_authenticated_mailbox_get_returns_server_time_and_receive_stats(self):
        import server as relay_server
        old_values = (relay_server.HOUSEHOLD_TOKEN, relay_server.HOUSEHOLD_MAILBOX)
        relay_server.HOUSEHOLD_TOKEN = relay_server.DEFAULT_HOUSEHOLD_TOKEN
        relay_server.HOUSEHOLD_MAILBOX = mailbox_for_token(relay_server.DEFAULT_HOUSEHOLD_TOKEN)
        httpd = ThreadingHTTPServer(("127.0.0.1", 0), relay_server.RelayHandler)
        httpd.store = self.store
        httpd.limiter = relay_server.RateLimiter()
        thread = threading.Thread(target=httpd.serve_forever, daemon=True)
        thread.start()
        mailbox = relay_server.HOUSEHOLD_MAILBOX
        self.store.publish(mailbox, "to-companion", validate_message(dict(self.message)))
        before = int(time.time() * 1000)
        try:
            request = Request(
                f"http://127.0.0.1:{httpd.server_address[1]}/v1/mailboxes/{mailbox}/to-companion/messages?limit=20&wait=0",
                headers={"Authorization": f"Bearer {relay_server.DEFAULT_HOUSEHOLD_TOKEN}"},
                method="GET",
            )
            with urlopen(request, timeout=3) as response:
                payload = json.loads(response.read())
            after = int(time.time() * 1000)
            self.assertEqual(1, len(payload["messages"]))
            self.assertGreaterEqual(payload["serverTimeMs"], before)
            self.assertLessEqual(payload["serverTimeMs"], after)
            self.assertGreaterEqual(relay_server.STATS["receive_to_companion"], 1)
            self.assertGreaterEqual(relay_server.STATS["receive_messages_to_companion"], 1)
        finally:
            httpd.shutdown()
            httpd.server_close()
            thread.join(timeout=2)
            relay_server.HOUSEHOLD_TOKEN, relay_server.HOUSEHOLD_MAILBOX = old_values

    def test_acknowledgement_input_is_bounded_and_deduplicated(self):
        value = self.message["messageId"]
        self.assertEqual([value], validate_acknowledgements({"messageIds": [value, value]}))
        with self.assertRaises(ValueError):
            validate_acknowledgements({"messageIds": ["unsafe/path"]})


    def test_archive_survives_acknowledgement(self):
        token = "archive-test-token-1234567890"
        mailbox = mailbox_for_token(token)
        message = {
            "messageId": "ArchiveMessage123456",
            "correlationId": None,
            "createdAt": int(time.time() * 1000),
            "expiresAt": int(time.time() * 1000) + 60_000,
            "envelope": {"type": "incremental_exchange", "delta": {"changes": [{"entityType": "messages", "entityId": "msg-1", "payload": {"text": "durable"}}]}},
        }
        self.store.publish(mailbox, "to-host", message)
        self.assertEqual(self.store.acknowledge(mailbox, "to-host", [message["messageId"]]), 1)
        with self.store.transaction() as db:
            row = db.execute(
                "SELECT envelope_json FROM relay_archive WHERE mailbox_id=? AND direction=? AND message_id=?",
                (mailbox, "to-host", message["messageId"]),
            ).fetchone()
        self.assertIsNotNone(row)
        self.assertIn("incremental_exchange", row[0])


if __name__ == "__main__":
    unittest.main()
