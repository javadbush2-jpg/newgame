# OurSpace Alpha118 — فاز ۵ زیبایی (یکدست‌سازی صفحات فیچر)

## فاز ۵ — هماهنگی بصری در همه بخش‌ها

### Chat
- حباب پیام: گوشه‌های نرم‌تر (۲۴dp) و نوک ظریف‌تر
- رنگ پیام خودی: `primaryContainer` (خواناتر و گرم‌تر)
- رنگ پیام طرف مقابل: `surfaceContainerHigh`
- نقل‌قول داخل حباب و فیلد نوشتن پیام هماهنگ‌تر شد

### Relationship / Planner / Finance
- کارت‌های `surfaceVariant` به سلسله‌مراتب `surfaceContainer*` مهاجرت کردند
- شعاع گوشه‌ها یک پله نرم‌تر و یکدست‌تر شد

### Settings / Pairing / Diagnostics / Private Server
- کارت‌ها روی `surfaceContainerLow` با گوشه ۲۶–۲۸dp

### ConnectionStatusBar
- پس‌زمینه و گوشه مدرن‌تر در حالت کامل

## نسخه
- `0.9.0-alpha118` (versionCode 118)

## نکته
هیچ تغییری در منطق داده، همگام‌سازی یا پروتکل ایجاد نشده است.
