# پروتکل Relay رمزگذاری‌شده OurSpace — پیش‌نویس نسخه ۱

> این پوشه یک پیاده‌سازی مرجع است و به معنی Deploy شدن Relay عمومی نیست. برنامه تا زمانی که Endpoint معتبر HTTPS پیکربندی و اتصال میزبان/همراه به آن متصل نشود، همچنان از مسیر LAN استفاده می‌کند.

## هدف

Relay فقط یک صندوق پستی موقت برای پاکت‌های از قبل رمزگذاری‌شده است. کلید مشترک، Snapshot آشکار، متن پیام، داده مالی، خاطره یا اطلاعات رابطه هرگز به API این Relay تحویل داده نمی‌شود.

Relay می‌تواند موارد زیر را ببیند:

- زمان و اندازه تقریبی پاکت
- جهت ارسال: به میزبان یا به همراه
- شناسه تصادفی پیام و Correlation
- شناسه غیرقابل‌حدس صندوق پستی

Relay نباید بتواند محتوای برنامه را رمزگشایی یا یک پاکت AES-GCM معتبر جعل کند. بااین‌حال Relay مخرب همچنان می‌تواند پیام را حذف، تکرار یا تحویل را به تأخیر بیندازد؛ کلاینت باید تکرار را تحمل و انقضا/زمان را بررسی کند.

## مشتق‌سازی صندوق پستی

هر دو گوشی پس از Pairing یک Secret مشترک ۲۵۶ بیتی دارند:

1. `authToken = Base64URL(HMAC-SHA256(sharedSecret, "ourspace-relay-v1:authentication"))`
2. `mailboxId = Base64URL(SHA-256(UTF8(authToken)))`

سرور با Hash کردن Bearer Token بررسی می‌کند که Token مربوط به Mailbox داخل URL است. Token یا Shared Secret داخل دیتابیس Relay ذخیره نمی‌شود. Token فقط باید روی HTTPS ارسال شود.

در مسیر جدید، گوشی میزبان یک PIN چهاررقمی را در endpointهای `/pairing/host-pin` ثبت می‌کند و گوشی همراه آن را با `/pairing/verify-pin` اعتبارسنجی می‌کند. PIN پس از ۱۰ دقیقه منقضی می‌شود و تلاش‌های ناموفق محدود هستند. کلید Relay از پیش در نسخه خصوصی اپ تعریف شده و باید با مقدار `DEFAULT_HOUSEHOLD_TOKEN` در `relay/server.py` یکسان بماند. این کلید ثابت در APK قابل استخراج است؛ از این الگو برای سرویس عمومی چندکاربره استفاده نکنید.

## مسیرها

### سلامت عمومی

```http
GET /health
```

### انتشار پاکت

```http
POST /v1/mailboxes/{mailboxId}/{to-host|to-companion}/messages
Authorization: Bearer {authToken}
Content-Type: application/json
```

بدنه:

```json
{
  "messageId": "opaque-random-id",
  "correlationId": null,
  "createdAt": 0,
  "expiresAt": 0,
  "envelope": {
    "v": 1,
    "nonce": "base64url",
    "ciphertext": "base64url"
  }
}
```

`envelope` خروجی مستقیم `SecureEnvelope.encrypt` است. برای پاسخ میزبان، `correlationId` برابر `messageId` درخواست همراه خواهد بود.

### دریافت

```http
GET /v1/mailboxes/{mailboxId}/{direction}/messages?limit=20
Authorization: Bearer {authToken}
```

سرور پیام‌ها را حذف نمی‌کند؛ حذف فقط پس از تأیید کلاینت انجام می‌شود.

### تأیید و حذف

```http
POST /v1/mailboxes/{mailboxId}/{direction}/acknowledgements
Authorization: Bearer {authToken}
Content-Type: application/json

{"messageIds":["opaque-random-id"]}
```

## محدودیت‌های مرجع

- TTL حداکثر ۷ روز و پیش‌فرض کلاینت ۲۴ ساعت
- حداکثر ۵۰ پیام در هر Fetch
- حداکثر ۱۰۰ شناسه در هر Acknowledgement
- حداکثر ۲۰۰۰ پیام منتظر برای هر Mailbox و ۱۰۰٬۰۰۰ پیام در کل نمونه مرجع
- حداکثر ۱۲۰ درخواست در دقیقه برای هر Mailbox و سقف کلی ۳۰۰۰ درخواست در دقیقه
- عدم دنبال‌کردن Redirect در کلاینت برای جلوگیری از افشای Bearer Token
- HTTPS اجباری؛ HTTP فقط برای `localhost`، `127.0.0.1` یا Emulator با `10.0.2.2`
- عدم Log کردن Token، Mailbox، Query یا بدنه

## مسیر ادغام برنامه

این مرحله فقط لایه پروتکل، کلاینت Ciphertext و سرور مرجع را اضافه کرده است. مراحل بعدی چرخه توسعه باید این موارد را تکمیل کنند:

1. ~~استخراج پردازش مشترک درخواست Sync از `LocalHostServer`~~ — انجام شد.
2. ~~Poll کردن `to-host` توسط سرویس میزبان و تولید پاسخ رمز‌شده~~ — انجام شد.
3. ~~Fallback همراه از LAN به Relay و دریافت `to-companion`~~ — انجام شد.
4. ~~رابط فارسی تنظیم Endpoint و نمایش وضعیت مسیر~~ — انجام شد.
5. آزمون Replay، Rate limit، TTL، Duplicate و قطع اتصال
6. Deploy واقعی پشت HTTPS و تنظیم Endpoint پیش‌فرض فقط پس از آماده‌شدن زیرساخت

## اجرای محلی سرور مرجع

```bash
python3 relay/server.py --host 0.0.0.0 --port 8787 --database relay-data/relay.sqlite3
```

برای محیط واقعی باید Reverse Proxy با TLS، محدودیت بدنه، پایش سلامت، پشتیبان‌گیری و سیاست حذف داده تنظیم شود. اجرای محلی بالا به‌تنهایی اتصال اینترنتی آماده استفاده ایجاد نمی‌کند.


## پشتیبان کامل و بازیابی (Alpha85)

- Relay علاوه بر آرشیو پاکت‌های همگام‌سازی، یک آخرین Snapshot کامل از پایگاه داده خانوار در جدول `household_backups` نگه می‌دارد.
- گوشی میزبان هر ۶۰ ثانیه، هنگام اتصال فعال، Snapshot را به‌روزرسانی می‌کند؛ از تنظیمات نیز می‌توان پشتیبان‌گیری دستی را اجرا کرد.
- Snapshot قبل از ارسال در گوشی با AES-GCM و کلید مشتق‌شده از کلید مشترک خانوار رمزگذاری می‌شود؛ سرور فقط `nonce` و `ciphertext` را ذخیره می‌کند.
- `POST /v1/backup` برای ذخیره و `GET /v1/backup` برای دریافت آخرین نسخه است؛ هر دو به Bearer Token خانوار نیاز دارند.
- گزینه بازیابی در تنظیمات داده‌ها را با دیتابیس محلی ادغام می‌کند و رکوردهای محلی را حذف نمی‌کند. برای جلوگیری از پاک‌شدن تصادفی نسخه کامل‌تر، کلاینت از جایگزینی پشتیبان بزرگ‌تر با Snapshot کوچک‌تر خودداری می‌کند.
- این Snapshot شامل رکوردهای Room و پیوست‌های ثبت‌شده در دیتابیس است، نه کلیدهای pairing، شناسه دستگاه، تنظیمات ظاهری یا تنظیمات سیستم‌عامل. پس از نصب مجدد ممکن است لازم باشد آدرس سرور را تنظیم و دستگاه را دوباره جفت کنید.
- دیتابیس سرور را نیز جداگانه بکاپ بگیرید؛ فایل SQLite سرور در صورت از بین رفتن دیسک همچنان نقطه حیاتی بازیابی است.

## کانال WebSocket بیدارباش (پروتکل ۳)

```http
GET /v1/push?token={authToken}
Upgrade: websocket
Connection: Upgrade
Sec-WebSocket-Key: ...
Authorization: Bearer {authToken}   # اختیاری اگر token در query باشد
```

پس از handshake، سرور فریم‌های متنی JSON می‌فرستد:

- `{"type":"hello","protocol":3,"push":"websocket"}` — اتصال موفق
- `{"type":"ping","at":...}` — نگه‌داری؛ کلاینت `{"type":"pong"}` می‌فرستد
- `{"type":"mail","direction":"to-host"|"to-companion","at":...}` — صندوق ورودی پر شد

**محتوای پیام هرگز روی WebSocket ارسال نمی‌شود.** کلاینت باید با همان API قبلی `GET .../messages` پاکت رمزشده را بردارد.
