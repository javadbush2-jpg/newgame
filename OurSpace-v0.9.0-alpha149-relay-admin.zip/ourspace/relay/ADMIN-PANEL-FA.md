# پنل مدیریت سرور OurSpace Relay

## آدرس
بعد از اجرای سرور:

```
http://IP-SERVER:8787/admin
```

مثال: `http://ourspace.iddns.ir:8787/admin`

## ورود
توکن یکی از این‌ها:
1. **کلید مشترک خانه** (همان `DEFAULT_ACCESS_TOKEN` / توکن اپ)
2. یا متغیر محیطی `OURSPACE_ADMIN_TOKEN` روی سرور

توکن فقط در `localStorage` مرورگر ذخیره می‌شود.

## بخش‌ها

### نمای کلی
- وضعیت سرویس، uptime
- تعداد پیام pending / آرشیو
- شمارنده‌های publish / receive / ack / error
- اتصال‌های WebSocket
- تفکیک صف بر اساس `to-host` و `to-companion`
- وضعیت DDNS و FCM

### دیتابیس
جداول:
- `relay_messages` — صف تحویل موقت
- `relay_archive` — آرشیو دائم تبادل‌ها
- `push_tokens` — توکن‌های FCM
- `household_backups` — پشتیبان رمزشده خانه

قابلیت‌ها: فیلتر mailbox، جهت، جستجو، صفحه‌بندی، جزئیات envelope (نوع، تعداد changes/acks، پیش‌نمایش JSON)

### لاگ‌ها
- لاگ زنده از حافظه سرور + فایل `relay.log`
- فیلتر سطح INFO / WARNING / ERROR
- بروزرسانی خودکار هر ۳ ثانیه

### عملیات
- حذف پیام‌های منقضی از صف
- خالی کردن صف pending (با فیلتر اختیاری)

## امنیت
- بدون توکن معتبر APIهای `/admin/api/*` پاسخ `401` می‌دهند
- توکن کامل FCM و بدنه کامل backup در UI نمایش داده نمی‌شود
- برای تولید، ترجیحاً `OURSPACE_ADMIN_TOKEN` جدا از توکن اپ تنظیم کنید و پنل را پشت reverse proxy/HTTPS بگذارید

## فایل‌ها
- `relay/admin.html` — رابط کاربری
- `relay/admin_ui.py` — منطق دیتابیس و لاگ
- مسیرها در `relay/server.py`
