#!/usr/bin/env bash
# One-shot installer for the OurSpace private sync server (Ubuntu/Debian VPS).
#   sudo bash install.sh sync.example.com
set -euo pipefail

DOMAIN="${1:-}"
if [[ -z "$DOMAIN" ]]; then
  echo "usage: sudo bash install.sh <your-domain>" >&2
  exit 1
fi

if ! command -v docker >/dev/null 2>&1; then
  echo "==> installing docker"
  curl -fsSL https://get.docker.com | sh
fi

cd "$(dirname "$0")"
echo "OURSPACE_DOMAIN=$DOMAIN" > .env

echo "==> opening ports 80/443"
if command -v ufw >/dev/null 2>&1; then
  ufw allow 80/tcp  || true
  ufw allow 443/tcp || true
fi

echo "==> starting services"
docker compose --env-file .env up -d --build

echo
echo "Done. Point the app at:  https://$DOMAIN"
echo "Health check:            curl https://$DOMAIN/health"
