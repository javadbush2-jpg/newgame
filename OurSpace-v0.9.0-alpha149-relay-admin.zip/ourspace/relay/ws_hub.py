"""Minimal stdlib WebSocket hub for OurSpace relay push.

Clients connect to GET /v1/push with Upgrade: websocket and ?token=HOUSEHOLD_TOKEN
(or Authorization: Bearer). After auth, the server pushes JSON text frames when
new mail is published for that mailbox — content stays on the HTTP mailbox API.

This is intentionally small (no third-party deps) so the personal relay stays
easy to run with plain python3.
"""

from __future__ import annotations

import base64
import hashlib
import json
import logging
import struct
import threading
import time
from typing import Callable

LOG = logging.getLogger("ourspace.relay.ws")

GUID = "258EAFA5-E914-47DA-95CA-C5AB0DC85B11"


def accept_key(sec_key: str) -> str:
    digest = hashlib.sha1((sec_key + GUID).encode("ascii")).digest()
    return base64.b64encode(digest).decode("ascii")


def encode_text(payload: str) -> bytes:
    data = payload.encode("utf-8")
    n = len(data)
    if n < 126:
        header = bytes([0x81, n])
    elif n < 65536:
        header = bytes([0x81, 126]) + struct.pack("!H", n)
    else:
        header = bytes([0x81, 127]) + struct.pack("!Q", n)
    return header + data


def encode_pong(payload: bytes = b"") -> bytes:
    n = len(payload)
    if n < 126:
        header = bytes([0x8A, n])
    else:
        header = bytes([0x8A, 126]) + struct.pack("!H", n)
    return header + payload


def encode_close(code: int = 1000) -> bytes:
    return bytes([0x88, 0x02]) + struct.pack("!H", code)


def decode_frames(buffer: bytearray) -> tuple[list[tuple[int, bytes]], bytearray]:
    """Return list of (opcode, payload) and remaining buffer."""
    out: list[tuple[int, bytes]] = []
    while True:
        if len(buffer) < 2:
            break
        b0, b1 = buffer[0], buffer[1]
        opcode = b0 & 0x0F
        masked = (b1 & 0x80) != 0
        length = b1 & 0x7F
        idx = 2
        if length == 126:
            if len(buffer) < 4:
                break
            length = struct.unpack("!H", buffer[2:4])[0]
            idx = 4
        elif length == 127:
            if len(buffer) < 10:
                break
            length = struct.unpack("!Q", buffer[2:10])[0]
            idx = 10
        mask = b""
        if masked:
            if len(buffer) < idx + 4:
                break
            mask = bytes(buffer[idx : idx + 4])
            idx += 4
        if len(buffer) < idx + length:
            break
        payload = bytes(buffer[idx : idx + length])
        if masked:
            payload = bytes(b ^ mask[i % 4] for i, b in enumerate(payload))
        del buffer[: idx + length]
        out.append((opcode, payload))
    return out, buffer


class WsClient:
    def __init__(self, sock, mailbox: str, addr) -> None:
        self.sock = sock
        self.mailbox = mailbox
        self.addr = addr
        self.alive = True
        self.lock = threading.Lock()
        self.connected_at = time.time()

    def send_json(self, obj: dict) -> bool:
        return self.send_raw(encode_text(json.dumps(obj, separators=(",", ":"))))

    def send_raw(self, data: bytes) -> bool:
        if not self.alive:
            return False
        try:
            with self.lock:
                self.sock.sendall(data)
            return True
        except OSError:
            self.alive = False
            return False

    def close(self) -> None:
        self.alive = False
        try:
            self.sock.sendall(encode_close())
        except OSError:
            pass
        try:
            self.sock.close()
        except OSError:
            pass


class PushHub:
    """mailbox -> set[WsClient]"""

    def __init__(self) -> None:
        self._clients: dict[str, set[WsClient]] = {}
        self._lock = threading.Lock()
        self._total = 0

    def register(self, client: WsClient) -> None:
        with self._lock:
            self._clients.setdefault(client.mailbox, set()).add(client)
            self._total += 1
        LOG.info("ws connected mailbox=%s from=%s total=%s", client.mailbox[:12], client.addr, self._total)

    def unregister(self, client: WsClient) -> None:
        with self._lock:
            bucket = self._clients.get(client.mailbox)
            if not bucket:
                return
            bucket.discard(client)
            if not bucket:
                self._clients.pop(client.mailbox, None)
            self._total = max(0, self._total - 1)
        LOG.info("ws disconnected mailbox=%s total=%s", client.mailbox[:12], self._total)

    def count(self) -> int:
        with self._lock:
            return self._total

    def notify(self, mailbox: str, direction: str) -> int:
        payload = {
            "type": "mail",
            "direction": direction,
            "at": int(time.time() * 1000),
        }
        with self._lock:
            clients = list(self._clients.get(mailbox, ()))
        sent = 0
        for client in clients:
            if client.send_json(payload):
                sent += 1
            else:
                self.unregister(client)
        return sent


HUB = PushHub()


def handle_websocket(
    handler,
    mailbox: str,
    sec_key: str,
    token_ok: bool,
) -> None:
    """Complete WS handshake on this BaseHTTPRequestHandler and run the socket loop.

    Call only after auth succeeded. This method takes ownership of the connection
    and does not return until the client disconnects.
    """
    if not token_ok:
        handler.send_error(401, "unauthorized")
        return

    sock = handler.connection
    addr = handler.client_address
    accept = accept_key(sec_key)
    response = (
        "HTTP/1.1 101 Switching Protocols\r\n"
        "Upgrade: websocket\r\n"
        "Connection: Upgrade\r\n"
        f"Sec-WebSocket-Accept: {accept}\r\n"
        "Sec-WebSocket-Protocol: ourspace-push\r\n"
        "\r\n"
    ).encode("ascii")
    try:
        sock.sendall(response)
    except OSError:
        return

    # Prevent BaseHTTPRequestHandler from touching the socket further.
    handler.close_connection = True

    # TCP keepalive helps detect dead mobile networks faster than app-level ping alone.
    try:
        import socket as _socket
        sock.setsockopt(_socket.SOL_SOCKET, _socket.SO_KEEPALIVE, 1)
        if hasattr(_socket, "TCP_KEEPIDLE"):
            sock.setsockopt(_socket.IPPROTO_TCP, _socket.TCP_KEEPIDLE, 30)
            sock.setsockopt(_socket.IPPROTO_TCP, _socket.TCP_KEEPINTVL, 10)
            sock.setsockopt(_socket.IPPROTO_TCP, _socket.TCP_KEEPCNT, 3)
    except OSError:
        pass

    client = WsClient(sock, mailbox, addr)
    HUB.register(client)
    try:
        client.send_json({"type": "hello", "protocol": 3, "push": "websocket", "at": int(time.time() * 1000)})
        buffer = bytearray()
        sock.settimeout(45.0)
        last_ping = time.monotonic()
        while client.alive:
            # Server-initiated keepalive text ping every 25s
            if time.monotonic() - last_ping >= 25:
                if not client.send_json({"type": "ping", "at": int(time.time() * 1000)}):
                    break
                last_ping = time.monotonic()
            try:
                chunk = sock.recv(4096)
            except TimeoutError:
                continue
            except OSError:
                break
            if not chunk:
                break
            buffer.extend(chunk)
            frames, buffer = decode_frames(buffer)
            for opcode, payload in frames:
                if opcode == 0x8:  # close
                    client.alive = False
                    break
                if opcode == 0x9:  # ping
                    client.send_raw(encode_pong(payload))
                elif opcode == 0xA:  # pong
                    pass
                elif opcode == 0x1:  # text — client may send {"type":"pong"} or subscribe ack
                    try:
                        msg = json.loads(payload.decode("utf-8"))
                        if isinstance(msg, dict) and msg.get("type") == "pong":
                            pass
                    except (UnicodeDecodeError, json.JSONDecodeError):
                        pass
    finally:
        HUB.unregister(client)
        client.close()
