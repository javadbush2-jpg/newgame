#!/usr/bin/env bash
# OurSpace Relay — one-command start (no Firebase required)
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p relay-data
HOST="${OURSPACE_HOST:-0.0.0.0}"
PORT="${OURSPACE_PORT:-8787}"
DB="${OURSPACE_DB:-relay-data/relay.sqlite3}"

if [[ -f relay-data/fcm-server-key.txt ]]; then
  echo "[OurSpace] FCM key file found — Google wake enabled"
else
  echo "[OurSpace] FCM optional (not configured) — WebSocket + long-poll active"
fi

echo "[OurSpace] Listening on http://${HOST}:${PORT}"
echo "[OurSpace] Health: curl http://127.0.0.1:${PORT}/health"
exec python3 server.py --host "$HOST" --port "$PORT" --database "$DB"
