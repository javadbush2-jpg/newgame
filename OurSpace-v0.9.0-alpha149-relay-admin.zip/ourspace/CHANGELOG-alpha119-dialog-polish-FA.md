# Alpha 119 — Dialog & Form UI Polish (کامل)

## هدف
یکدست‌سازی و زیباتر کردن **تمام دیالوگ‌های تأیید و فرم** در OurSpace با سیستم طراحی مشترک (couple-first، نرم، گرم).

## سیستم دیالوگ (`ui/design/OSDialogs.kt`)

| کامپوننت | کاربرد |
|----------|--------|
| `OSAlertDialog` | پوسته پایه: گوشه xl، سایه رنگی ملایم، border گرادیانی |
| `OSConfirmDialog` | تأیید/انصراف + destructive + emoji/icon |
| `OSFormDialog` | فرم با عنوان، زیرعنوان، محتوا، `showDismissButton` |
| `OSDialogPrimaryButton` / `Secondary` / `Destructive` | دکمه‌های یکدست |

## مهاجرت کامل (۰ باقی‌مانده `AlertDialog` خام در featureها)

### Main
- اجازه اعلان‌ها → `OSConfirmDialog` + 🔔

### Components
- `PersianDatePickerDialog` → `OSFormDialog` + تقویم زیباتر

### Planner
- حذف الگو / نوبت / کار / کالا / عادت → `OSConfirmDialog` destructive
- `WorkScheduleDialog` → `OSFormDialog` + 👷
- `InputDialog` → `OSFormDialog` + ✏️
- جزئیات روز تقویم → `OSFormDialog` + 📅
- `AddHabitDialog` → `OSFormDialog` + 💊

### Finance
- اصلاح موجودی → `OSFormDialog` + 💰
- بدهی دونفره → `OSFormDialog` + 🤝
- تراکنش تکرارشونده → `OSFormDialog` + 🔄
- حساب جدید → `OSFormDialog` + 🏦
- تراکنش جدید → `OSFormDialog` + 💳
- بودجه ماهانه → `OSFormDialog` + 📊

### Chat
- حذف پیام → `OSConfirmDialog`
- گزینه‌های پیام → `OSFormDialog` + 💬
- ویرایش پیام → `OSFormDialog` + ✏️
- پیش‌نمایش پیوست → `OSFormDialog` + 📎

### Relationship
- تأیید حذف عمومی / تصویر خاطره → `OSConfirmDialog`
- فیلم/سریال → `OSFormDialog` + 🎬
- پروفایل دونفره → `OSFormDialog` + 💑
- خاطره / مناسبت → `OSFormDialog` + 📷 / 🎉
- تنظیمات چرخه / شروع دوره → `OSFormDialog` + 🌙 / 🌸
- گالری تصویر خاطره → `OSFormDialog` + 🖼️

### Calendar (Home)
- انتخاب نوع ثبت → `OSFormDialog` + ✨
- فرم ثبت (کار، قرار، عادت، خاطره، مناسبت، مالی، حال) → `OSFormDialog` + 📝

## الگوی استفاده

```kotlin
OSConfirmDialog(
    title = "حذف؟",
    message = "…",
    confirmLabel = "حذف",
    destructive = true,
    emoji = "🗑️",
    onConfirm = { … },
    onDismiss = { … }
)

OSFormDialog(
    title = "…",
    emoji = "💰",
    onDismiss = { … },
    onConfirm = { … },
    confirmEnabled = fieldsValid,
    showDismissButton = true
) {
    OutlinedTextField(…)
}
```
