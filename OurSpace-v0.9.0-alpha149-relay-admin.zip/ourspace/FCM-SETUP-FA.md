# FCM اختیاری (برای بیدارباش بعد از Force Stop)

**برای استفاده عادی لازم نیست.** با `./start.sh` همه‌چیز بدون Google کار می‌کند.

## فعال‌سازی اختیاری
1. Firebase → Cloud Messaging → Server key
2. ذخیره در: `relay/relay-data/fcm-server-key.txt`
3. (اختیاری) `app/google-services.json` واقعی
4. Restart سرور + یک‌بار باز کردن اپ برای ثبت توکن

بدون FCM: WebSocket + long-poll + WorkManager فعال‌اند.

## بیلد بدون Firebase
از Alpha118 به بعد، اگر `app/google-services.json` نباشد، پلاگین Google Services اعمال نمی‌شود و `assembleDebug` خطا نمی‌دهد.
یک فایل placeholder داخل `app/google-services.json` هست؛ برای FCM واقعی آن را با فایل پروژه Firebase خودت جایگزین کن.

