# OurSpace Alpha114 — Visual Polish v2 (عمق و ظرافت)

نسخه بهبود ظاهری پیشرفته بر پایه Alpha113.

## تغییرات اصلی

### Design System
- **OSRadius**: گوشه‌ها نرم‌تر و مدرن‌تر (xs=12 → xxl=40)
- **OSElevation**: عمق بیشتر برای کارت و ناوبری شناور
- **OSGlow**: آلفاهای متعادل‌تر برای خوانایی بهتر محتوا
- **OSSpacing.bottomNavClearance**: افزایش به ۱۰۰dp برای فاصله بهتر

### Theme
- پس‌زمینه روشن گرم‌تر (`#F9F6FA`) و Surface تمیزتر
- Dark Mode با کنتراست و عمق سطح بهتر
- Outline نرم‌تر در هر دو حالت
- Shapes Material بزرگ‌تر و هماهنگ‌تر با توکن‌های جدید
- Typography با line-height مناسب‌تر برای متن فارسی

### Components
- **GradientHero**: گرادیان چهارمرحله‌ای، سه orb تزئینی، گوشه ۳۲dp، padding بهتر
- **GlassPanel**: border نرم‌تر و opacity بالاتر
- **SoftCard**: شعاع پیش‌فرض ۲۰dp
- Floating Bottom Nav: ارتفاع و elevation بیشتر، border glow قوی‌تر، scale آیکون ۱.۱۲
- FAB: شکل و elevation بهبود یافته

### Home / MainShell
- WelcomeHero: سلسله‌مراتب متن و فاصله عمودی دقیق‌تر
- نوار شناور پایین با حس premium‌تر

این نسخه **هیچ تغییری در مدل داده، همگام‌سازی یا منطق کسب‌وکار** ندارد و فقط ظاهر و حس را ارتقا می‌دهد.
