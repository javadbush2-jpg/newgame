# Alpha 121 — Transport Phase 1+2

## فاز ۱ — سرعت و مسیر فوری
1. **WebRTC fast-path برای delta**
   - همان `incremental_exchange` که به رله می‌رود، وقتی DataChannel باز است همزمان روی WebRTC هم فرستاده می‌شود
   - گیرنده با `processMessage` اعمال می‌کند و `incremental_exchange_result` را فوری برمی‌گرداند
   - رله همچنان مسیر دوام‌دار است (offline-safe)

2. **اولویت پیام چت در outbox**
   - `messages` و `heartPulses` قبل از بقیه entityها claim/ارسال می‌شوند
   - پیوست‌ها در lane جدا (chunk) می‌مانند و صف متن را بند نمی‌آورند

3. **Wake فوری بعد از ارسال**
   - `autoSync()` → `WebRtcSession.sendNudge()` + `HostServerService.requestImmediateSync`

4. **نوار وضعیت در چت**
   - برچسب اتصال از `ConnectionDiagnostics` + نشان «لینک مستقیم» وقتی WebRTC باز است

## فاز ۲ — پایداری پس‌زمینه
1. **IN_FLIGHT کوتاه‌تر** — ۴۵s → ۱۲s (بازپس‌گیری سریع‌تر SENDING)
2. **Retry تهاجمی‌تر** — base/max delay کمتر؛ ticker outbox هر ۲s
3. **Long-poll هوشمند**
   - outbox پر: ۳s
   - WS وصل و بیکار: ۲۲s
   - WS قطع: ۶s
4. **FCM**
   - ثبت توکن هنگام شروع duplex و HostServerService
   - دکمه «ثبت مجدد توکن اعلان سرور» در تنظیمات
5. **باتری**
   - بخش «پس‌زمینه و باتری» با درخواست `IGNORE_BATTERY_OPTIMIZATIONS`

## فایل‌های اصلی
- `core/webrtc/WebRtcSession.kt`
- `core/relay/RelayDuplexPoller.kt`
- `core/sync/IncrementalSyncCodec.kt`
- `core/server/HostServerService.kt`
- `ui/AppViewModel.kt`
- `feature/chat/ChatScreen.kt`
- `feature/settings/SettingsScreen.kt`
