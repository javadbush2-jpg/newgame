# OurSpace Alpha115 — فاز ۱ و ۲ زیبایی (عمق + میکرو-اینتراکشن)

## فاز ۱ — عمق و کیفیت بصری پایه

### Surface Hierarchy (Material 3)
- اضافه شدن کامل `surfaceContainerLowest / Low / High / Highest` در Light و Dark
- کارت‌ها و نوار شناور حالا روی لایه‌های سطح درست قرار می‌گیرند (نه فقط elevation)

### Shadow رنگی و ظریف
- `OSCard` جدید با colored ambient/spot shadow از رنگ primary
- Empty State با سایه نرم دایره‌ای

### Typography
- line-height و letter-spacing بهتر برای تیترهای فارسی
- خوانایی متن‌های بلند بهبود یافت

## فاز ۲ — میکرو-اینتراکشن و حس زندگی

### Press Feedback یکدست
- `Modifier.osPressable()` برای scale + alpha نرم هنگام فشار
- `OSCard` با انیمیشن press داخلی
- استفاده از `OSMotion.pressSpring` و توکن‌های `OSPress`

### Empty State لوکس‌تر
- آیکون بزرگ‌تر + سایه رنگی
- دکمه اکشن با `OSPrimaryButton`
- فاصله‌گذاری گرم‌تر

### Loading / Skeleton
- `OSShimmer` با گرادیان متحرک هماهنگ با پالت
- `OSSkeletonRow` آماده برای لیست‌ها

### Ambient Mesh
- شدت پیش‌فرض کمی کاهش یافت تا محتوا خواناتر بماند

## نکات
- هیچ تغییری در منطق داده، همگام‌سازی یا Relay ایجاد نشده.
- نسخه: `0.9.0-alpha115` (versionCode 115)
