# کاهش حجم OurSpace

## چه کارهایی در این نسخه اعمال شد؟

1. **فقط ABI گوشی واقعی** (`armeabi-v7a` + `arm64-v8a`)
   - کتابخانه‌های native مربوط به WebRTC و SQLCipher برای x86/x86_64 دیگر داخل APK نمی‌آیند.
   - معمولاً بزرگ‌ترین کاهش حجم از همین‌جاست (چند مگابایت تا بیش از ۱۰MB بسته به نسخهٔ WebRTC).

2. **Resource Shrinking در release**
   - `isShrinkResources = true` همراه با minify، منابع استفاده‌نشده را حذف می‌کند.

3. **محدود کردن زبان‌ها**
   - فقط `en` و `fa` داخل APK می‌مانند.

4. **قوانین ProGuard/R8 کامل‌تر**
   - حذف لاگ‌های verbose در release + keepهای لازم برای SQLCipher و WebRTC تا برنامه نشکند.

5. **تنظیمات Bundle**
   - اگر با `bundleRelease` بسازی و در Play منتشر کنی، هر کاربر فقط ABI و زبان خودش را می‌گیرد (حجم نصب کمتر از APK یکپارچه).

6. **R8 fullMode**
   - فشرده‌سازی قوی‌تر کد در `gradle.properties`.

## چطور بیلد بگیری؟

```bash
# APK سبک‌تر برای نصب مستقیم روی گوشی واقعی:
./gradlew assembleRelease

# بهترین حالت برای انتشار (Play Store):
./gradlew bundleRelease
```

خروجی APK:
`app/build/outputs/apk/release/app-release.apk`

خروجی AAB:
`app/build/outputs/bundle/release/app-release.aab`

## نکته مهم برای امولاتور

اگر روی امولاتور x86 توسعه می‌دهی، موقتاً بلوک `ndk { abiFilters ... }` را در `app/build.gradle.kts` کامنت کن؛ وگرنه APK روی امولاتور نصب نمی‌شود.

## منابع اصلی حجم (تقریبی)

| بخش | نقش در حجم |
|-----|------------|
| WebRTC (native) | خیلی زیاد |
| SQLCipher (native) | زیاد |
| Compose + Material | متوسط |
| material-icons-extended | کم تا متوسط (در release با R8 کم می‌شود) |
| کد خود اپ | نسبتاً کم |

## کاهش بیشتر (اختیاری، نیاز به تصمیم تو)

- اگر P2P/WebRTC برای همه کاربران ضروری نیست، می‌توان آن را به ماژول داینامیک یا build flavor جدا منتقل کرد.
- جایگزینی `material-icons-extended` با فقط آیکون‌های استفاده‌شده (کار دستی بیشتر).
- انتشار فقط به‌صورت AAB به‌جای APK universal.
