# OurSpace Alpha116 — فاز ۳ زیبایی (Bottom Nav پیشرفته + Gradient + Dark Premium)

## فاز ۳ — جزئیات سطح بالا

### Bottom Navigation سطح بعدی
- **آیکون Filled/Outlined**: تب فعال از آیکون filled استفاده می‌کند، تب‌های غیرفعال outlined می‌مانند (morph بصری)
- **Pill انتخاب‌شده**: پس‌زمینه گرادیانی قوی‌تر + گوشه ۲۰dp
- **Indicator درخشان**: خط زیر تب فعال با گرادیان افقی نرم (glow)
- **Scale با Spring**: انیمیشن آیکون از tween به `OSMotion.navIndicator` (spring) تغییر کرد و به ۱.۱۴ رسید

### Gradient & Mesh
- GradientHero در نسخه‌های قبلی به ۴ مرحله + ۳ orb ارتقا یافته بود و حفظ شد
- NavPillIndicator کمی عریض‌تر و بلندتر شد
- شدت Ambient Mesh از قبل متعادل شده بود

### Dark Mode Premium
- لایه‌های `surfaceContainer*` در حالت تاریک با عمق و تمایز بیشتر تنظیم شدند تا کارت‌ها طبیعی‌تر شناور شوند

## نسخه
- `0.9.0-alpha116` (versionCode 116)

## نکته
هیچ تغییری در مدل داده، همگام‌سازی یا منطق کسب‌وکار ایجاد نشده است.
