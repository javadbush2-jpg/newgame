# Alpha 120 — Chat: Typing, Delivery status, Share cards

## ۱) نشانگر «در حال نوشتن» (Typing)
- فریم سبک WebRTC: `{"t":"ourspace-typing","on":true/false}`
- `WebRtcSession.sendTyping` / `setTypingListener`
- در چت: هنگام تایپ به طرف مقابل اعلام می‌شود؛ بعد از ۱.۶s سکوت قطع می‌شود
- UI: متن «در حال نوشتن…» بالای composer

## ۲) وضعیت ارسال دقیق‌تر
- فیلد جدید `MessageEntity.deliveredAt` + migration `19 → 20`
- وضعیت روی پیام‌های خودی:
  - `…` در حال ارسال (pendingSendIds)
  - `✓` ذخیره محلی / در صف همگام‌سازی
  - `✓✓` خاکستری = تحویل به گوشی مقابل (`deliveredAt`)
  - `✓✓` رنگی = خوانده‌شده (`readAt`)
- `stampIncomingDelivered` روی پیام‌های دریافتی؛ بعد از مشاهده چت / ارسال / mark-read همگام می‌شود

## ۳) اشتراک کارت از بخش‌های دیگر به چت
- فرمت: `OS_CARD|v1|<TYPE>|<json>` + خط خوانای فارسی برای جستجو
- انواع: TASK / EVENT / DEBT / MEMORY / LOCATION
- دکمه اشتراک (آیکون Share):
  - Planner: کارها و قرارها
  - Finance: بدهی‌ها
  - Relationship: خاطرات
  - Map: موقعیت من / شریک
- بعد از اشتراک، تب چت باز می‌شود و کارت به‌صورت حباب ساختاریافته نمایش داده می‌شود

## فایل‌های کلیدی
- `core/webrtc/WebRtcSession.kt`
- `core/database/Entities.kt` + `OurSpaceDatabase.kt` (v20)
- `core/sync/SyncSnapshotCodec.kt`
- `feature/chat/ChatShareCard.kt` + `ChatScreen.kt`
- `ui/AppViewModel.kt` + `MainShell` / `OurSpaceApp`
