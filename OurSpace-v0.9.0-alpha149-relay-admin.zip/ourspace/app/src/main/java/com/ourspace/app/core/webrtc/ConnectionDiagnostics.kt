package com.ourspace.app.core.webrtc

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/** Lightweight in-app sync health telemetry for the personal relay server. */
object ConnectionDiagnostics {
    enum class ConnectionState {
        DISCONNECTED, CONNECTING, CONNECTED, DEGRADED, RECONNECTING
    }

    data class Health(
        val state: ConnectionState = ConnectionState.DISCONNECTED,
        val lastSentAt: Long = 0L,
        val lastReceivedAt: Long = 0L,
        val lastAckAt: Long = 0L,
        val lastActivityAt: Long = 0L,
        val sentCount: Long = 0L,
        val receivedCount: Long = 0L,
        val inboundPollCount: Long = 0L,
        val lastInboundPollAt: Long = 0L,
        val lastInboundDirection: String = "",
        val lastInboundBatchSize: Int = 0,
        val ackCount: Long = 0L,
        val failedCount: Long = 0L,
        val lastLatencyMs: Long = -1L,
        val pushConnected: Boolean = false
    )

    private val _lines = MutableStateFlow<List<String>>(emptyList())
    val lines: StateFlow<List<String>> = _lines
    private val _health = MutableStateFlow(Health())
    val health: StateFlow<Health> = _health
    private val clock = SimpleDateFormat("HH:mm:ss", Locale.US)
    private val sentAtByMessage = LinkedHashMap<String, Long>()

    fun setState(state: ConnectionState) {
        _health.value = _health.value.copy(state = state)
    }

    fun setPushConnected(connected: Boolean) {
        // A WebSocket handshake proves only the wake channel, not that authenticated mailbox
        // reads work. Keep it as a separate signal; inbox health is set by inboxPollSucceeded.
        _health.value = _health.value.copy(pushConnected = connected)
    }

    fun touchActivity() {
        val now = System.currentTimeMillis()
        // Activity (for example an FCM wake or an outbound publish) must not imply that the
        // receiver has successfully read its authenticated mailbox.
        _health.value = _health.value.copy(lastActivityAt = now)
    }

    @Synchronized
    fun inboxPollSucceeded(direction: String, batchSize: Int) {
        val now = System.currentTimeMillis()
        val current = _health.value
        _health.value = current.copy(
            state = ConnectionState.CONNECTED,
            lastActivityAt = now,
            lastInboundPollAt = now,
            inboundPollCount = current.inboundPollCount + 1,
            lastInboundDirection = direction,
            lastInboundBatchSize = batchSize.coerceAtLeast(0)
        )
    }

    fun statusLabelFa(h: Health = _health.value): String {
        // Only a successful authenticated mailbox GET proves the receive lane is alive.
        // Health checks, WebSocket handshakes and successful sends are shown separately.
        val inboxRecent = h.lastInboundPollAt > 0L &&
            System.currentTimeMillis() - h.lastInboundPollAt < INBOX_STALE_AFTER_MS
        val effective = when {
            h.state == ConnectionState.RECONNECTING -> ConnectionState.RECONNECTING
            h.state == ConnectionState.DEGRADED -> ConnectionState.DEGRADED
            h.state == ConnectionState.CONNECTING -> ConnectionState.CONNECTING
            inboxRecent -> ConnectionState.CONNECTED
            h.pushConnected -> ConnectionState.CONNECTING
            h.state == ConnectionState.CONNECTED -> ConnectionState.CONNECTING
            else -> h.state
        }
        return when (effective) {
            ConnectionState.CONNECTED ->
                if (h.pushConnected) "دریافت صندوق فعال • کانال فوری" else "دریافت صندوق فعال"
            ConnectionState.CONNECTING ->
                if (h.pushConnected) "کانال فوری وصل؛ دریافت صندوق تأیید نشده" else "در حال بررسی صندوق دریافت…"
            ConnectionState.RECONNECTING -> "در حال اتصال مجدد…"
            ConnectionState.DEGRADED -> "دریافت صندوق ناپایدار است"
            ConnectionState.DISCONNECTED -> "سرور در دسترس نیست"
        }
    }

    fun detailLabelFa(h: Health = _health.value): String {
        val activity = listOf(h.lastActivityAt, h.lastReceivedAt, h.lastSentAt, h.lastAckAt).maxOrNull() ?: 0L
        val ago = if (activity > 0L) "آخرین فعالیت ${formatRelativeFa(activity)}" else "هنوز همگام‌سازی نشده"
        val inbox = if (h.lastInboundPollAt > 0L) {
            " • صندوق ${h.lastInboundDirection}: ${formatRelativeFa(h.lastInboundPollAt)}، ${h.lastInboundBatchSize} پیام/${h.inboundPollCount} بررسی"
        } else {
            " • دریافت صندوق هنوز تأیید نشده"
        }
        val queue = if (h.failedCount > 0) " • خطا: ${h.failedCount}" else ""
        val lat = if (h.lastLatencyMs >= 0) " • تأخیر ${h.lastLatencyMs}ms" else ""
        return ago + inbox + queue + lat
    }

    private fun formatRelativeFa(at: Long): String {
        val sec = ((System.currentTimeMillis() - at) / 1000L).coerceAtLeast(0)
        return when {
            sec < 15 -> "همین الان"
            sec < 60 -> "${sec} ثانیه پیش"
            sec < 3600 -> "${sec / 60} دقیقه پیش"
            sec < 86400 -> "${sec / 3600} ساعت پیش"
            else -> clock.format(Date(at))
        }
    }

    @Synchronized
    fun sent(messageId: String? = null) {
        val now = System.currentTimeMillis()
        messageId?.let { sentAtByMessage[it] = now }
        trimIds(now)
        val current = _health.value
        _health.value = current.copy(
            lastSentAt = now,
            lastActivityAt = now,
            sentCount = current.sentCount + 1
        )
    }

    @Synchronized
    fun received(messageId: String? = null) {
        val now = System.currentTimeMillis()
        val current = _health.value
        val latency = messageId?.let { sentAtByMessage.remove(it)?.let { stamp -> now - stamp } }
            ?: current.lastLatencyMs
        _health.value = current.copy(
            lastReceivedAt = now,
            lastActivityAt = now,
            receivedCount = current.receivedCount + 1,
            lastLatencyMs = latency,
            state = ConnectionState.CONNECTED
        )
    }

    fun ack(messageId: String? = null) {
        val now = System.currentTimeMillis()
        val current = _health.value
        val latency = messageId?.let { sentAtByMessage.remove(it)?.let { stamp -> now - stamp } }
            ?: current.lastLatencyMs
        _health.value = current.copy(
            lastAckAt = now,
            lastActivityAt = now,
            ackCount = current.ackCount + 1,
            lastLatencyMs = latency
        )
    }

    fun failed() {
        _health.value = _health.value.copy(failedCount = _health.value.failedCount + 1)
    }

    @Synchronized
    fun log(message: String) {
        val line = "${clock.format(Date())} $message"
        _lines.value = (_lines.value + line).takeLast(80)
    }

    fun clear() {
        _lines.value = emptyList()
        _health.value = Health()
        synchronized(this) { sentAtByMessage.clear() }
    }

    private fun trimIds(now: Long) {
        val iterator = sentAtByMessage.entries.iterator()
        while (iterator.hasNext()) {
            if (now - iterator.next().value > 120_000L) iterator.remove()
        }
        while (sentAtByMessage.size > 200) {
            val first = sentAtByMessage.keys.firstOrNull() ?: break
            sentAtByMessage.remove(first)
        }
    }

    private const val INBOX_STALE_AFTER_MS = 90_000L
}
