package com.ourspace.app.core.push

import android.util.Log
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import com.ourspace.app.core.server.HostServerService
import com.ourspace.app.core.sync.CompanionSyncWorker
import com.ourspace.app.core.webrtc.ConnectionDiagnostics

/**
 * Data-only FCM wake. Safe no-op path when Firebase project is not configured.
 * Message bodies are never expected in [RemoteMessage.getData].
 */
class OurSpaceFirebaseMessagingService : FirebaseMessagingService() {

    override fun onNewToken(token: String) {
        Log.i(TAG, "FCM token refreshed")
        FcmTokenRegistrar.onNewToken(applicationContext, token)
    }

    override fun onMessageReceived(message: RemoteMessage) {
        val type = message.data["type"].orEmpty()
        if (type.isNotEmpty() && type != "ourspace_mail") {
            Log.i(TAG, "Ignoring non-OurSpace push type=$type")
            return
        }
        Log.i(TAG, "FCM data wake dir=${message.data["direction"]}")
        ConnectionDiagnostics.log("بیدارباش FCM دریافت شد")
        ConnectionDiagnostics.touchActivity()
        runCatching { CompanionSyncWorker.runSoon(applicationContext) }
        runCatching { HostServerService.requestImmediateSync(applicationContext) }
        runCatching { HostServerService.start(applicationContext) }
    }

    companion object {
        private const val TAG = "OurSpaceFCM"
    }
}
