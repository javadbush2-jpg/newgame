package com.ourspace.app.core.reminder

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.ourspace.app.OurSpaceApplication
import com.ourspace.app.core.cycle.CycleInsights
import com.ourspace.app.core.notification.OurSpaceNotificationCenter
import com.ourspace.app.core.security.DeviceIdentityManager
import com.ourspace.app.core.time.PersianDateFormatter
import java.util.Calendar
import java.util.concurrent.TimeUnit

/** Local reminder sweep. Every logical reminder is de-duplicated for its relevant day/occurrence. */
class DailyReminderWorker(
    appContext: Context,
    params: WorkerParameters
) : CoroutineWorker(appContext, params) {

    override suspend fun doWork(): Result {
        val app = applicationContext as? OurSpaceApplication ?: return Result.success()
        val db = app.database
        val notifications = OurSpaceNotificationCenter(applicationContext)
        if (!notifications.canPostReminders()) return Result.success()
        val now = System.currentTimeMillis()
        val todayKey = PersianDateFormatter.currentJalaliDayKey()
        val deviceId = runCatching { DeviceIdentityManager().getOrCreateIdentity().deviceId }.getOrNull()

        val openTasks = db.taskDao().getAllOnce().filter { !it.isDeleted && !it.isCompleted }
        val overdue = openTasks.count { it.dueAt != null && it.dueAt!! < now }
        if (openTasks.isNotEmpty()) notifyOnce("open-tasks", todayKey) { notifications.showTaskReminder(openTasks.size) }
        if (overdue > 0) notifyOnce("overdue-tasks", todayKey) { notifications.showOverdueTasks(overdue) }

        // Notify upcoming appointments in start-time order; work schedule markers are not appointments.
        val soonEvents = db.eventDao().getAllOnce()
            .filter { !it.isDeleted && !it.details.orEmpty().startsWith("OS_WORK|") && it.startAt in now..(now + DAY_MS) }
            .sortedBy { it.startAt }
        soonEvents.forEach { event ->
            // A rescheduled appointment is a new occurrence and should be eligible for a reminder.
            notifyOnce("event:${event.id}", event.startAt.toString()) {
                notifications.showUpcomingEvent(event.title, event.id)
            }
        }

        // Yearly anniversaries follow the Jalali calendar, matching the calendar UI.
        val specialDates = db.specialDateDao().getAllOnce().filter { !it.isDeleted }
        specialDates.forEach { date ->
            val occurrence = PersianDateFormatter.nextSpecialDateOccurrence(date.occurredAt, date.repeatYearly, now)
                ?: return@forEach
            val days = occurrence.daysUntil
            if (days !in 0..3) return@forEach
            notifyOnce("special:${date.id}:${occurrence.jalaliYear}", "sent") {
                notifications.showUpcomingSpecialDate(date.title, days, date.id)
            }
        }

        if (deviceId != null) {
            val hasMood = db.moodCheckInDao().getAllOnce().any {
                !it.isDeleted && it.deviceId == deviceId && it.dayKey == todayKey
            }
            if (!hasMood) notifyOnce("mood", todayKey) { notifications.showMoodReminder() }
        }

        val logs = db.cycleLogDao().getAllOnce()
        val settings = db.cycleSettingsDao().getOnce()
        if (settings?.trackingEnabled != false) {
            val insight = CycleInsights.snapshot(logs, settings, now)
            val until = insight.daysUntilNext
            if (until != null && until in 0..2) {
                val targetAt = Calendar.getInstance().apply {
                    timeInMillis = now
                    add(Calendar.DAY_OF_YEAR, until)
                }.timeInMillis
                val targetDay = dayKey(targetAt)
                notifyOnce("cycle:$targetDay", "sent") { notifications.showCycleReminder(until) }
            }
        }

        val shoppingOpen = db.shoppingDao().getAllOnce().count { !it.isDeleted && !it.isChecked }
        if (shoppingOpen >= 5) notifyOnce("shopping", todayKey) { notifications.showShoppingReminder(shoppingOpen) }
        return Result.success()
    }

    private inline fun notifyOnce(key: String, occurrence: String, action: () -> Unit) {
        val prefs = applicationContext.getSharedPreferences(DEDUP_PREFS, Context.MODE_PRIVATE)
        if (prefs.getString(key, null) == occurrence) return
        action()
        prefs.edit().putString(key, occurrence).apply()
    }

    private fun dayKey(timestamp: Long): String {
        val c = Calendar.getInstance().apply { timeInMillis = timestamp }
        return "${c.get(Calendar.YEAR)}-${c.get(Calendar.DAY_OF_YEAR)}"
    }


    companion object {
        private const val UNIQUE = "ourspace_daily_reminders"
        private const val DEDUP_PREFS = "ourspace_notification_dedupe"
        private const val DAY_MS = 24L * 60 * 60 * 1000

        fun schedule(context: Context) {
            val request = PeriodicWorkRequestBuilder<DailyReminderWorker>(12, TimeUnit.HOURS)
                .build()
            WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                UNIQUE,
                ExistingPeriodicWorkPolicy.UPDATE,
                request
            )
        }
    }
}
