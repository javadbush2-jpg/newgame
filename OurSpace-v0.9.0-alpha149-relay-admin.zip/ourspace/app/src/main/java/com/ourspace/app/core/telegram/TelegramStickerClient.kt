package com.ourspace.app.core.telegram

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.util.concurrent.TimeUnit
import java.util.zip.GZIPInputStream
import java.io.ByteArrayInputStream

/**
 * Minimal Telegram Bot API client for fetching public sticker sets.
 * Requires a bot token from @BotFather. Does not read user chats.
 */
class TelegramStickerClient(
    private val botToken: String,
    private val http: OkHttpClient = defaultClient
) {
    data class RemoteSticker(
        val fileId: String,
        val fileUniqueId: String,
        val emoji: String,
        val isAnimated: Boolean,
        val isVideo: Boolean,
        val width: Int,
        val height: Int
    )

    data class RemoteStickerSet(
        val name: String,
        val title: String,
        val isAnimated: Boolean,
        val isVideo: Boolean,
        val stickers: List<RemoteSticker>
    )

    data class DownloadedSticker(
        val meta: RemoteSticker,
        val bytes: ByteArray,
        val mimeType: String,
        val fileName: String
    )

    fun isConfigured(): Boolean = botToken.trim().length >= 20

    suspend fun getStickerSet(nameOrLink: String): RemoteStickerSet = withContext(Dispatchers.IO) {
        require(isConfigured()) { "توکن ربات تلگرام تنظیم نشده است" }
        val name = normalizePackName(nameOrLink)
        require(name.isNotBlank()) { "نام پک استیکر نامعتبر است" }
        val url = "https://api.telegram.org/bot${botToken.trim()}/getStickerSet?name=${java.net.URLEncoder.encode(name, "UTF-8")}"
        val body = httpGet(url)
        val root = JSONObject(body)
        if (!root.optBoolean("ok", false)) {
            val desc = root.optString("description", "خطای ناشناخته از تلگرام")
            throw IllegalStateException(desc)
        }
        val result = root.getJSONObject("result")
        val stickersJson = result.getJSONArray("stickers")
        val list = ArrayList<RemoteSticker>(stickersJson.length())
        for (i in 0 until stickersJson.length()) {
            val s = stickersJson.getJSONObject(i)
            // Skip video stickers for now (need ExoPlayer); keep static + animated TGS
            if (s.optBoolean("is_video", false)) continue
            list.add(
                RemoteSticker(
                    fileId = s.getString("file_id"),
                    fileUniqueId = s.getString("file_unique_id"),
                    emoji = s.optString("emoji", "⭐"),
                    isAnimated = s.optBoolean("is_animated", false),
                    isVideo = false,
                    width = s.optInt("width", 512),
                    height = s.optInt("height", 512)
                )
            )
        }
        require(list.isNotEmpty()) { "این پک استیکر قابل‌استفاده‌ای ندارد (یا فقط ویدیویی است)" }
        RemoteStickerSet(
            name = result.getString("name"),
            title = result.optString("title", name),
            isAnimated = result.optBoolean("is_animated", false) || list.any { it.isAnimated },
            isVideo = false,
            stickers = list
        )
    }

    suspend fun downloadSticker(sticker: RemoteSticker): DownloadedSticker = withContext(Dispatchers.IO) {
        require(isConfigured()) { "توکن ربات تلگرام تنظیم نشده است" }
        val fileUrl = "https://api.telegram.org/bot${botToken.trim()}/getFile?file_id=${java.net.URLEncoder.encode(sticker.fileId, "UTF-8")}"
        val fileBody = httpGet(fileUrl)
        val fileRoot = JSONObject(fileBody)
        if (!fileRoot.optBoolean("ok", false)) {
            throw IllegalStateException(fileRoot.optString("description", "دانلود فایل استیکر ناموفق"))
        }
        val path = fileRoot.getJSONObject("result").getString("file_path")
        val downloadUrl = "https://api.telegram.org/file/bot${botToken.trim()}/$path"
        val bytes = httpGetBytes(downloadUrl)
        require(bytes.isNotEmpty()) { "فایل استیکر خالی است" }
        require(bytes.size <= 2 * 1024 * 1024) { "حجم استیکر بیش از حد مجاز است" }
        val mime: String
        val ext: String
        when {
            sticker.isAnimated || path.endsWith(".tgs", ignoreCase = true) -> {
                mime = MIME_TGS
                ext = "tgs"
            }
            else -> {
                mime = "image/webp"
                ext = "webp"
            }
        }
        DownloadedSticker(
            meta = sticker,
            bytes = bytes,
            mimeType = mime,
            fileName = "tg_${sticker.fileUniqueId}.$ext"
        )
    }

    /**
     * TGS = gzip-compressed Lottie JSON. Returns raw JSON bytes for Lottie, or null if not TGS.
     */
    fun tgsToLottieJson(tgsBytes: ByteArray): ByteArray? {
        return runCatching {
            GZIPInputStream(ByteArrayInputStream(tgsBytes)).use { it.readBytes() }
        }.getOrNull()
    }

    private fun httpGet(url: String): String {
        val request = Request.Builder().url(url).get().build()
        http.newCall(request).execute().use { response ->
            val body = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                throw IllegalStateException("خطای شبکه تلگرام: HTTP ${response.code}")
            }
            return body
        }
    }

    private fun httpGetBytes(url: String): ByteArray {
        val request = Request.Builder().url(url).get().build()
        http.newCall(request).execute().use { response ->
            val body = response.body?.bytes() ?: ByteArray(0)
            if (!response.isSuccessful) {
                throw IllegalStateException("دانلود فایل ناموفق: HTTP ${response.code}")
            }
            return body
        }
    }

    companion object {
        const val MIME_TGS = "application/x-tgsticker"

        private val defaultClient: OkHttpClient = OkHttpClient.Builder()
            .connectTimeout(20, TimeUnit.SECONDS)
            .readTimeout(60, TimeUnit.SECONDS)
            .writeTimeout(30, TimeUnit.SECONDS)
            .callTimeout(90, TimeUnit.SECONDS)
            .build()

        fun normalizePackName(input: String): String {
            val t = input.trim()
            if (t.isEmpty()) return ""
            // https://t.me/addstickers/PackName or tg://addstickers?set=PackName
            val patterns = listOf(
                Regex("""(?:https?://)?t\.me/addstickers/([A-Za-z0-9_]+)""", RegexOption.IGNORE_CASE),
                Regex("""tg://addstickers\?set=([A-Za-z0-9_]+)""", RegexOption.IGNORE_CASE),
                Regex("""addstickers/([A-Za-z0-9_]+)""", RegexOption.IGNORE_CASE)
            )
            for (p in patterns) {
                val m = p.find(t)
                if (m != null) return m.groupValues[1]
            }
            // bare short name
            return t.removePrefix("@").filter { it.isLetterOrDigit() || it == '_' }
        }
    }
}
