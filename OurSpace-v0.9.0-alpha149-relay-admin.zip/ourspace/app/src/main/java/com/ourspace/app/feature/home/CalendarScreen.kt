package com.ourspace.app.feature.home

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import kotlin.math.roundToInt
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.CalendarMonth
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.Event
import androidx.compose.material.icons.outlined.ExpandLess
import androidx.compose.material.icons.outlined.ExpandMore
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material.icons.outlined.Favorite
import androidx.compose.material.icons.outlined.Mood
import androidx.compose.material.icons.outlined.Payments
import androidx.compose.material.icons.outlined.PhotoLibrary
import androidx.compose.material.icons.outlined.ShoppingCart
import androidx.compose.material.icons.outlined.Schedule
import androidx.compose.material.icons.outlined.TaskAlt
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.ourspace.app.core.database.*
import com.ourspace.app.core.time.PersianDateFormatter
import com.ourspace.app.ui.design.OSFormDialog
import java.util.Calendar

private enum class CalendarCreateType(val label: String) {
    TASK("کار جدید"),
    EVENT("قرار یا برنامه"),
    HABIT("عادت یا یادآور"),
    MEMORY("خاطره مشترک"),
    OCCASION("مناسبت"),
    FINANCE("تراکنش مالی"),
    MOOD("ثبت حال روز")
}


@Composable
private fun CalendarLegendItem(color: Color, label: String) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        Box(
            Modifier
                .width(12.dp)
                .height(6.dp)
                .clip(RoundedCornerShape(50))
                .background(color)
        )
        Text(label, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CalendarScreen(
    tasks: List<TaskEntity>, events: List<EventEntity>, shoppingItems: List<ShoppingItemEntity>,
    messages: List<MessageEntity>, attachments: List<AttachmentEntity>, financeTransactions: List<FinanceTransactionEntity>,
    financialAccounts: List<FinancialAccountEntity>, onAddFinanceTransactionAt: (String, String?, String, Long, String, String, Long) -> Unit,
    sharedDebts: List<SharedDebtEntity>, recurringTransactions: List<RecurringTransactionEntity>, habits: List<HabitEntity> = emptyList(), memories: List<MemoryEntity>,
    moodCheckIns: List<MoodCheckInEntity>, specialDates: List<SpecialDateEntity>, cycleLogs: List<CycleLogEntity>,
    cycleSettings: CycleSettingsEntity?, onAddTask: (String, Int, String, Long?) -> Unit,
    onAddTimedTask: (String, Int, String, Long?, Int) -> Unit = { title, priority, assignee, dueAt, _ -> onAddTask(title, priority, assignee, dueAt) },
    onToggleTask: (TaskEntity) -> Unit, onDeleteTask: (TaskEntity) -> Unit,
    onUpdateTaskSchedule: (TaskEntity, Long, Int) -> Unit = { _, _, _ -> },
    onAddEvent: (String, Long) -> Unit, onDeleteEvent: (EventEntity) -> Unit,
    onAddTimedEvent: (String, Long, Int) -> Unit = { title, at, _ -> onAddEvent(title, at) },
    onUpdateEventSchedule: (EventEntity, Long, Long) -> Unit = { _, _, _ -> },
    onAddHabit: (String, String, String, String) -> Unit = { _, _, _, _ -> },
    onAddMemory: (String, String, String, Long) -> Unit, onToggleMemoryFavorite: (MemoryEntity) -> Unit,
    onDeleteMemory: (MemoryEntity) -> Unit, onAddSpecialDate: (String, String, Long, Boolean) -> Unit,
    onSetDailyMood: (String, String, String) -> Unit, onToggleShopping: (ShoppingItemEntity) -> Unit,
    onOpenPlanner: () -> Unit = {}, onOpenFinance: () -> Unit = {}, onOpenChat: () -> Unit = {}, onOpenMemories: () -> Unit = {}
) {
    val todayJ = remember { PersianDateFormatter.jalaliDate(System.currentTimeMillis()) }
    var monthOffset by remember { mutableIntStateOf(0) }
    val shownMonth = remember(monthOffset, todayJ) {
        val absolute = todayJ.year * 12 + todayJ.month - 1 + monthOffset
        (Math.floorDiv(absolute, 12)) to (Math.floorMod(absolute, 12) + 1)
    }
    val year = shownMonth.first
    val month = shownMonth.second
    val days = PersianDateFormatter.daysInJalaliMonth(year, month)
    val firstDayEpoch = remember(year, month) { PersianDateFormatter.toEpochMillis(year, month, 1, 12) }
    val firstDow = remember(firstDayEpoch) { Calendar.getInstance().apply { timeInMillis = firstDayEpoch }.get(Calendar.DAY_OF_WEEK) % 7 } // Saturday-first: Sat=0 … Fri=6
    var selectedEpoch by remember { mutableLongStateOf(dayStart(System.currentTimeMillis())) }
    var createType by remember { mutableStateOf<CalendarCreateType?>(null) }
    var showCreatePicker by remember { mutableStateOf(false) }
    var showDayHours by remember { mutableStateOf(false) }
    var title by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var mood by remember { mutableStateOf("LOVE") }
    var repeatYearly by remember { mutableStateOf(true) }
    var financeAmount by remember { mutableStateOf("") }
    var financeCategory by remember { mutableStateOf("سایر") }
    var financeKind by remember { mutableStateOf("EXPENSE") }
    var selectedHour by remember { mutableIntStateOf(12) }
    var selectedMinute by remember { mutableIntStateOf(0) }
    var selectedDuration by remember { mutableIntStateOf(60) }
    var financeAccountId by remember(financialAccounts) { mutableStateOf(financialAccounts.firstOrNull { !it.isDeleted && !it.isArchived }?.id.orEmpty()) }
    val selectedJ = PersianDateFormatter.jalaliDate(selectedEpoch)
    val selectedKey = PersianDateFormatter.jalaliDayKey(selectedEpoch)
    val selectedEnd = dayEnd(selectedEpoch)
    val dayTasks = tasks.filter { !it.isDeleted && it.dueAt != null && it.dueAt!! in selectedEpoch..selectedEnd }.sortedBy { it.dueAt }
    val dayEvents = events.filter { !it.isDeleted && !it.details.orEmpty().startsWith("OS_WORK|") && it.startAt in selectedEpoch..selectedEnd }.sortedBy { it.startAt }
    // شیفت شب فقط روی روز شروع ثبت می‌شود (نه روز پایان که به روز بعد می‌رود)
    val dayWorkEvents = events.filter { event ->
        !event.isDeleted &&
            event.details.orEmpty().startsWith("OS_WORK|") &&
            event.startAt in selectedEpoch..selectedEnd
    }.sortedBy { it.startAt }
    val dayMemories = memories.filter { !it.isDeleted && it.occurredAt in selectedEpoch..selectedEnd }.sortedBy { it.occurredAt }
    val daySpecials = specialDates.filter { item ->
        if (item.isDeleted) false else {
            val j = PersianDateFormatter.jalaliDate(item.occurredAt)
            j.month == selectedJ.month && j.day == selectedJ.day && (item.repeatYearly || j.year == selectedJ.year)
        }
    }
    val dayFinance = financeTransactions.filter { !it.isDeleted && it.occurredAt in selectedEpoch..selectedEnd }.sortedBy { it.occurredAt }
    val dayDebts = sharedDebts.filter { !it.isDeleted && it.settledAt == null && it.dueAt != null && it.dueAt!! in selectedEpoch..selectedEnd }
    val dayRecurring = recurringTransactions.filter { !it.isDeleted && it.isActive && it.nextRunAt in selectedEpoch..selectedEnd }
    val dayMoods = moodCheckIns.filter { !it.isDeleted && it.dayKey == selectedKey }
    // فقط روزهای دورهٔ قاعدگی:
    // - اگر پایان ثبت شده: از شروع تا همان پایان
    // - اگر هنوز باز است: حداکثر averagePeriodDays روز از شروع (و نه بعد از امروز)
    fun periodDisplayEnd(log: CycleLogEntity): Long {
        val periodLength = (cycleSettings?.averagePeriodDays ?: 5).coerceIn(1, 15)
        val todayEnd = dayEnd(System.currentTimeMillis())
        val byLength = endOfDayAfterDays(log.startAt, periodLength - 1)
        return log.endAt?.let { minOf(it, todayEnd) } ?: minOf(byLength, todayEnd)
    }
    fun isPeriodVisible(log: CycleLogEntity, dayStart: Long, dayEnd: Long): Boolean =
        !log.isDeleted && log.startAt <= dayEnd && periodDisplayEnd(log) >= dayStart
    val dayPeriods = cycleLogs.filter { isPeriodVisible(it, selectedEpoch, selectedEnd) }
    val openShopping = shoppingItems.filter { !it.isDeleted && !it.isChecked }
    val dayCount = dayTasks.size + dayEvents.size + dayWorkEvents.size + dayMemories.size + daySpecials.size + dayFinance.size + dayDebts.size + dayRecurring.size + dayMoods.size + dayPeriods.size
    val monthCount = remember(tasks, events, memories, specialDates, financeTransactions, moodCheckIns, sharedDebts, recurringTransactions, cycleLogs, cycleSettings, year, month) {
        val matches = { timestamp: Long -> val d = PersianDateFormatter.jalaliDate(timestamp); d.year == year && d.month == month }
        tasks.count { !it.isDeleted && it.dueAt != null && matches(it.dueAt!!) } +
            events.count { !it.isDeleted && !it.details.orEmpty().startsWith("OS_WORK|") && matches(it.startAt) } + memories.count { !it.isDeleted && matches(it.occurredAt) } +
            specialDates.count { item -> !item.isDeleted && runCatching { val d = PersianDateFormatter.jalaliDate(item.occurredAt); d.month == month && (item.repeatYearly || d.year == year) }.getOrDefault(false) } +
            financeTransactions.count { !it.isDeleted && matches(it.occurredAt) } +
            moodCheckIns.count { !it.isDeleted && it.dayKey.startsWith("$year-${month.toString().padStart(2, '0')}") } +
            sharedDebts.count { !it.isDeleted && it.settledAt == null && it.dueAt != null && matches(it.dueAt!!) } +
            recurringTransactions.count { !it.isDeleted && it.isActive && matches(it.nextRunAt) } +
            (1..PersianDateFormatter.daysInJalaliMonth(year, month)).count { d ->
                val start = PersianDateFormatter.toEpochMillis(year, month, d, 0)
                isPeriodVisibleForMonth(cycleLogs, cycleSettings, start, dayEnd(start))
            }
    }

    Column(Modifier.fillMaxSize()) {
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 100.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item {
                Card(shape = RoundedCornerShape(30.dp), colors = CardDefaults.cardColors(containerColor = Color.Transparent), modifier = Modifier.fillMaxWidth()) {
                    Box(Modifier.background(Brush.linearGradient(listOf(MaterialTheme.colorScheme.primary, MaterialTheme.colorScheme.tertiary))).padding(20.dp)) {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                Icon(Icons.Outlined.CalendarMonth, null, tint = Color.White, modifier = Modifier.size(32.dp))
                                Column(Modifier.weight(1f)) {
                                    Text("تقویم مشترک ما", color = Color.White, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Black)
                                    Text("همه اتفاق‌های مهم، در یک نگاه", color = Color.White.copy(alpha = .9f), style = MaterialTheme.typography.bodyMedium)
                                }
                            }
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                HeroStat("رویدادهای ماه", PersianDateFormatter.toPersianDigits(monthCount), Modifier.weight(1f))
                                HeroStat("روز انتخابی", PersianDateFormatter.toPersianDigits(dayCount), Modifier.weight(1f))
                                HeroStat("خریدهای باز", PersianDateFormatter.toPersianDigits(openShopping.size), Modifier.weight(1f))
                            }
                        }
                    }
                }
            }
            item {
                Card(
                    shape = RoundedCornerShape(28.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.92f)
                    ),
                    elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
                    border = androidx.compose.foundation.BorderStroke(
                        1.dp,
                        Brush.linearGradient(
                            listOf(
                                MaterialTheme.colorScheme.primary.copy(alpha = 0.22f),
                                MaterialTheme.colorScheme.tertiary.copy(alpha = 0.10f),
                                MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.25f)
                            )
                        )
                    )
                ) {
                    Column(Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                            IconButton(onClick = { val nextOffset = monthOffset - 1; val absolute = todayJ.year * 12 + todayJ.month - 1 + nextOffset; val y = Math.floorDiv(absolute, 12); val m = Math.floorMod(absolute, 12) + 1; monthOffset = nextOffset; selectedEpoch = dayStart(PersianDateFormatter.toEpochMillis(y, m, 1, 12)) }) { Text("‹", style = MaterialTheme.typography.headlineMedium) }
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("${PersianDateFormatter.jalaliMonthName(month)} ${PersianDateFormatter.toPersianDigits(year)}", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Black)
                                TextButton(onClick = { monthOffset = 0; selectedEpoch = dayStart(System.currentTimeMillis()) }) { Text("رفتن به امروز") }
                            }
                            IconButton(onClick = { val nextOffset = monthOffset + 1; val absolute = todayJ.year * 12 + todayJ.month - 1 + nextOffset; val y = Math.floorDiv(absolute, 12); val m = Math.floorMod(absolute, 12) + 1; monthOffset = nextOffset; selectedEpoch = dayStart(PersianDateFormatter.toEpochMillis(y, m, 1, 12)) }) { Text("›", style = MaterialTheme.typography.headlineMedium) }
                        }
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            listOf("ش", "ی", "د", "س", "چ", "پ", "ج").forEach { Text(it, modifier = Modifier.weight(1f), color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold) }
                        }
                        Spacer(Modifier.height(8.dp))
                        repeat(6) { week ->
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                                repeat(7) { col ->
                                    val day = week * 7 + col - firstDow + 1
                                    if (day in 1..days) {
                                        val epoch = dayStart(PersianDateFormatter.toEpochMillis(year, month, day, 12))
                                        val end = dayEnd(epoch)
                                        val isToday = PersianDateFormatter.jalaliDayKey(epoch) == PersianDateFormatter.currentJalaliDayKey()
                                        val hasTask = tasks.any { !it.isDeleted && it.dueAt != null && it.dueAt!! in epoch..end }
                                        val hasEvent = events.any { !it.isDeleted && !it.details.orEmpty().startsWith("OS_WORK|") && it.startAt in epoch..end }
                                        // فقط روز شروع شیفت — شیفت شب روی دو روز پشت‌سرهم علامت نخورد
                                        val hasWork = events.any { e ->
                                            !e.isDeleted &&
                                                e.details.orEmpty().startsWith("OS_WORK|") &&
                                                e.startAt in epoch..end
                                        }
                                        val hasMemory = memories.any { !it.isDeleted && it.occurredAt in epoch..end }
                                        val hasSpecial = specialDates.any { sd -> !sd.isDeleted && runCatching { val j = PersianDateFormatter.jalaliDate(sd.occurredAt); j.month == month && j.day == day && (sd.repeatYearly || j.year == year) }.getOrDefault(false) }
                                        val hasFinance = financeTransactions.any { !it.isDeleted && it.occurredAt in epoch..end }
                                        val hasDebt = sharedDebts.any { !it.isDeleted && it.settledAt == null && it.dueAt != null && it.dueAt!! in epoch..end }
                                        val hasRecurring = recurringTransactions.any { !it.isDeleted && it.isActive && it.nextRunAt in epoch..end }
                                        val hasMood = moodCheckIns.any { !it.isDeleted && it.dayKey == PersianDateFormatter.jalaliDayKey(epoch) }
                                        val hasCycle = cycleLogs.any { log -> isPeriodVisible(log, epoch, end) }
                                        val active = PersianDateFormatter.jalaliDayKey(epoch) == selectedKey
                                        // Each category has its own stable color so the dots are distinguishable.
                                        val markers = buildList {
                                            if (hasTask) add(Color(0xFF3984F5))       // tasks: blue
                                            if (hasEvent) add(Color(0xFFFF9F43))      // events: orange
                                            if (hasWork) add(Color(0xFF5C6BC0))       // shift/work: indigo
                                            if (hasMemory) add(Color(0xFF9B59D0))     // memories: purple
                                            if (hasSpecial) add(Color(0xFFE84A8A))    // occasions: pink
                                            if (hasFinance) add(Color(0xFF21A675))    // finance: green
                                            if (hasDebt) add(Color(0xFFE04F5F))       // debts: red
                                            if (hasRecurring) add(Color(0xFF00A6A6)) // recurring: teal
                                            if (hasMood) add(Color(0xFFE0B323))      // mood: gold
                                            if (hasCycle) add(Color(0xFFDB6BC4))     // cycle: magenta
                                        }
                                        com.ourspace.app.ui.components.CalendarDayCell(
                                            dayNumber = PersianDateFormatter.toPersianDigits(day),
                                            isSelected = active,
                                            isToday = isToday,
                                            isCurrentMonth = true,
                                            markerColors = markers,
                                            modifier = Modifier.weight(1f).height(54.dp),
                                            onClick = { selectedEpoch = epoch }
                                        )
                                    } else Spacer(Modifier.weight(1f).height(54.dp))
                                }
                            }
                            Spacer(Modifier.height(5.dp))
                        }
                        Spacer(Modifier.height(4.dp))
                        Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
                            Text("راهنمای رنگ نشانگرها", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                CalendarLegendItem(Color(0xFF3984F5), "کارها")
                                CalendarLegendItem(Color(0xFFFF9F43), "قرارها")
                                CalendarLegendItem(Color(0xFF5C6BC0), "شیفت/کار")
                                CalendarLegendItem(Color(0xFF9B59D0), "خاطرات")
                                CalendarLegendItem(Color(0xFFE84A8A), "مناسبت‌ها")
                                CalendarLegendItem(Color(0xFF21A675), "مالی")
                            }
                            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                CalendarLegendItem(Color(0xFFE04F5F), "بدهی")
                                CalendarLegendItem(Color(0xFF00A6A6), "پرداخت دوره‌ای")
                                CalendarLegendItem(Color(0xFFE0B323), "حال‌وهوا")
                                CalendarLegendItem(Color(0xFFDB6BC4), "قاعدگی")
                            }
                        }
                    }
                }
            }
            item {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                    Column {
                        Text(PersianDateFormatter.formatDate(selectedEpoch), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Black)
                        Text(if (dayCount == 0) "برای این روز هنوز چیزی ثبت نشده" else "${PersianDateFormatter.toPersianDigits(dayCount)} مورد در این روز", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                    }
                    FilledTonalButton(onClick = { showCreatePicker = true }) { Icon(Icons.Outlined.Add, null); Spacer(Modifier.width(4.dp)); Text("ثبت مورد") }
                }
            }
            item {
                DayHourTimeline(
                    expanded = showDayHours,
                    onToggle = { showDayHours = !showDayHours },
                    selectedEpoch = selectedEpoch,
                    tasks = dayTasks,
                    // Show generated work shifts inside the hourly timeline as well as in the list below.
                    events = (dayEvents + dayWorkEvents).distinctBy { it.id }.sortedBy { it.startAt },
                    habits = habits.filter { !it.isDeleted },
                    onMoveTask = onUpdateTaskSchedule,
                    onMoveEvent = onUpdateEventSchedule,
                    onHourClick = { hour ->
                        selectedHour = hour
                        selectedMinute = 0
                        showCreatePicker = true
                    }
                )
            }
            if (dayTasks.isNotEmpty()) item { SectionHeading("کارها", Icons.Outlined.TaskAlt, dayTasks.size) }
            items(dayTasks, key = { "task-${it.id}" }) { task -> CalendarEntry(task.title, task.note.ifBlank { if (task.isCompleted) "انجام‌شده" else "شروع: ${task.dueAt?.let(PersianDateFormatter::formatTime) ?: "—"} · مدت: ${PersianDateFormatter.toPersianDigits(task.durationMinutes.toString())} دقیقه" }, Icons.Outlined.CheckCircle, MaterialTheme.colorScheme.primaryContainer, trailing = { Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(task.isCompleted, onCheckedChange = { onToggleTask(task) }); IconButton(onClick = { onDeleteTask(task) }) { Icon(Icons.Outlined.DeleteOutline, "حذف کار") } } }) }
            if (dayEvents.isNotEmpty()) item { SectionHeading("قرارها و برنامه‌ها", Icons.Outlined.Event, dayEvents.size) }
            if (dayWorkEvents.isNotEmpty()) item { SectionHeading("شیفت و ساعت کاری", Icons.Outlined.Schedule, dayWorkEvents.size) }
            items(dayWorkEvents, key = { "work-${it.id}" }) { event ->
                CalendarEntry(
                    event.title,
                    "${PersianDateFormatter.formatTime(event.startAt)} تا ${PersianDateFormatter.formatTime(event.endAt ?: (event.startAt + 60L * 60_000L))}",
                    Icons.Outlined.Schedule,
                    MaterialTheme.colorScheme.primaryContainer,
                    trailing = {
                        IconButton(onClick = { onDeleteEvent(event) }) {
                            Icon(Icons.Outlined.DeleteOutline, "حذف نوبت کاری")
                        }
                    }
                )
            }
            items(dayEvents, key = { "event-${it.id}" }) { event -> CalendarEntry(event.title, listOf("${PersianDateFormatter.formatTime(event.startAt)} تا ${PersianDateFormatter.formatTime(event.endAt ?: (event.startAt + 60L * 60_000L))}", event.details.orEmpty().takeUnless { it.startsWith("OS_WORK|") }).filterNotNull().filter { it.isNotBlank() }.joinToString(" · "), Icons.Outlined.Event, MaterialTheme.colorScheme.secondaryContainer, trailing = { IconButton(onClick = { onDeleteEvent(event) }) { Icon(Icons.Outlined.DeleteOutline, "حذف قرار") } }) }
            if (dayMemories.isNotEmpty()) item { SectionHeading("خاطرات مشترک", Icons.Outlined.PhotoLibrary, dayMemories.size) }
            items(dayMemories, key = { "memory-${it.id}" }) { memory -> CalendarEntry(memory.title, listOf(memory.note, attachments.count { !it.isDeleted && it.memoryId == memory.id }.let { if (it > 0) "${PersianDateFormatter.toPersianDigits(it)} پیوست" else "" }).filter { it.isNotBlank() }.joinToString(" · ").ifBlank { "خاطره ثبت‌شده در این روز" }, Icons.Outlined.Favorite, MaterialTheme.colorScheme.tertiaryContainer, trailing = { Row(verticalAlignment = Alignment.CenterVertically) { IconButton(onClick = { onToggleMemoryFavorite(memory) }) { Icon(Icons.Outlined.Favorite, "علاقه‌مندی", tint = if (memory.isFavorite) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant) }; IconButton(onClick = { onDeleteMemory(memory) }) { Icon(Icons.Outlined.DeleteOutline, "حذف خاطره") } } }) }
            if (daySpecials.isNotEmpty()) item { SectionHeading("مناسبت‌ها", Icons.Outlined.CalendarMonth, daySpecials.size) }
            items(daySpecials, key = { "special-${it.id}" }) { date -> CalendarEntry(date.title, date.note.orEmpty().ifBlank { if (date.repeatYearly) "تکرار سالانه" else "مناسبت ثبت‌شده" }, Icons.Outlined.CalendarMonth, MaterialTheme.colorScheme.primaryContainer) }
            if (dayFinance.isNotEmpty()) item { SectionHeading("امور مالی", Icons.Outlined.Payments, dayFinance.size) }
            items(dayFinance, key = { "finance-${it.id}" }) { tx -> CalendarEntry(tx.category, "${tx.kind} · ${PersianDateFormatter.formatMoney(tx.amount)}${if (tx.note.isBlank()) "" else " · ${tx.note}"}", Icons.Outlined.Payments, MaterialTheme.colorScheme.secondaryContainer) }
            if (dayDebts.isNotEmpty()) item { SectionHeading("سررسید بدهی‌ها", Icons.Outlined.Payments, dayDebts.size) }
            items(dayDebts, key = { "debt-${it.id}" }) { debt -> CalendarEntry(debt.title, "سررسید · ${PersianDateFormatter.formatMoney(debt.amount)}${if (debt.note.isBlank()) "" else " · ${debt.note}"}", Icons.Outlined.Payments, MaterialTheme.colorScheme.errorContainer) }
            if (dayRecurring.isNotEmpty()) item { SectionHeading("پرداخت‌های دوره‌ای", Icons.Outlined.Payments, dayRecurring.size) }
            items(dayRecurring, key = { "recurring-${it.id}" }) { item -> CalendarEntry(item.category, "پرداخت برنامه‌ریزی‌شده · ${PersianDateFormatter.formatMoney(item.amount)}${if (item.note.isBlank()) "" else " · ${item.note}"}", Icons.Outlined.Payments, MaterialTheme.colorScheme.secondaryContainer) }
            if (dayMoods.isNotEmpty()) item { SectionHeading("حال‌وهوای ثبت‌شده", Icons.Outlined.Mood, dayMoods.size) }
            items(dayMoods, key = { "mood-${it.id}" }) { item -> CalendarEntry(moodLabel(item.mood), item.note.ifBlank { "ثبت حال روزانه" }, Icons.Outlined.Mood, MaterialTheme.colorScheme.tertiaryContainer) }
            val activeHabits = habits.filter { !it.isDeleted }
            if (activeHabits.isNotEmpty()) item { SectionHeading("عادات و یادآورها", Icons.Outlined.CheckCircle, activeHabits.size) }
            items(activeHabits, key = { "habit-${it.id}" }) { habit -> CalendarEntry(habit.title, listOf(habit.scheduleNote, habit.note).filter { it.isNotBlank() }.joinToString(" · ").ifBlank { "برنامه تکرارشونده" } + if (selectedKey == PersianDateFormatter.currentJalaliDayKey() && habit.lastCompletedDayKey == selectedKey) " · امروز انجام شد" else "", Icons.Outlined.CheckCircle, MaterialTheme.colorScheme.surfaceVariant) }
            if (dayPeriods.isNotEmpty()) item { SectionHeading("قاعدگی", Icons.Outlined.Favorite, dayPeriods.size) }
            items(dayPeriods, key = { "cycle-${it.id}" }) { log -> CalendarEntry("دوره ثبت‌شده", log.note.ifBlank { "شدت: ${log.flowLevel}" }, Icons.Outlined.Favorite, MaterialTheme.colorScheme.errorContainer) }
            item {
                Card(shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = .55f))) {
                    Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("دسترسی سریع به بخش‌ها", fontWeight = FontWeight.Black)
                        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            AssistChip(onClick = onOpenPlanner, label = { Text("کارها و خرید") }, leadingIcon = { Icon(Icons.Outlined.ShoppingCart, null) })
                            AssistChip(onClick = onOpenFinance, label = { Text("مالی") }, leadingIcon = { Icon(Icons.Outlined.Payments, null) })
                            AssistChip(onClick = onOpenChat, label = { Text("گفتگو") }, leadingIcon = { Icon(Icons.Outlined.ChatBubbleOutline, null) })
                            AssistChip(onClick = onOpenMemories, label = { Text("ما و خاطرات") }, leadingIcon = { Icon(Icons.Outlined.Favorite, null) })
                        }
                        if (openShopping.isNotEmpty()) {
                            Text("خریدهای باز (بدون تاریخ مشخص)", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                            openShopping.take(5).forEach { item ->
                                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                    Checkbox(checked = item.isChecked, onCheckedChange = { onToggleShopping(item) })
                                    Text(item.title, modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
                                    Text(item.quantity, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.labelSmall)
                                }
                            }
                        }
                    }
                }
            }
        }
    }


    if (showCreatePicker) {
        OSFormDialog(
            title = "برای ${PersianDateFormatter.formatDate(selectedEpoch)} چه چیزی ثبت کنیم؟",
            emoji = "✨",
            onDismiss = { showCreatePicker = false },
            onConfirm = { showCreatePicker = false },
            confirmLabel = "بستن",
            showDismissButton = false
        ) {
                    CalendarCreateType.entries.forEach { type ->
                        OutlinedButton(
                            onClick = { createType = type; showCreatePicker = false; title = ""; note = ""; financeAmount = ""; selectedDuration = 60 },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(14.dp)
                        ) { Text(type.label, modifier = Modifier.fillMaxWidth()) }
                    }
        }
    }

    if (createType != null) {
        val type = createType!!
        OSFormDialog(
            title = type.label,
            emoji = "📝",
            onDismiss = { createType = null },
            onConfirm = {
                val timed = dayAtTime(selectedEpoch, selectedHour, selectedMinute)
            when (type) {
                CalendarCreateType.TASK -> if (title.isNotBlank()) onAddTimedTask(title.trim(), 1, "مشترک", timed, selectedDuration)
                CalendarCreateType.EVENT -> if (title.isNotBlank()) onAddTimedEvent(title.trim(), timed, selectedDuration)
                CalendarCreateType.HABIT -> if (title.isNotBlank()) {
                    val schedule = "ساعت ${selectedHour.toString().padStart(2, '0')}:${selectedMinute.toString().padStart(2, '0')}"
                    onAddHabit(title.trim(), "HABIT", schedule, note.trim())
                }
                CalendarCreateType.MEMORY -> if (title.isNotBlank()) onAddMemory(title.trim(), note.trim(), mood, selectedEpoch)
                CalendarCreateType.OCCASION -> if (title.isNotBlank()) onAddSpecialDate(title.trim(), note.trim(), selectedEpoch, repeatYearly)
                CalendarCreateType.FINANCE -> { val amount = financeAmount.toLongOrNull() ?: 0L; if (amount > 0 && financeAccountId.isNotBlank()) onAddFinanceTransactionAt(financeAccountId, null, financeKind, amount, financeCategory.ifBlank { "سایر" }, note.trim(), timed) }
                CalendarCreateType.MOOD -> onSetDailyMood(selectedKey, mood, note.trim())
            }
            createType = null
            },
            confirmLabel = "ثبت",
            confirmEnabled = when (type) { CalendarCreateType.TASK, CalendarCreateType.EVENT, CalendarCreateType.HABIT, CalendarCreateType.MEMORY, CalendarCreateType.OCCASION -> title.isNotBlank(); CalendarCreateType.FINANCE -> (financeAmount.toLongOrNull() ?: 0L) > 0 && financeAccountId.isNotBlank(); CalendarCreateType.MOOD -> true }
        ) {

                if (type == CalendarCreateType.FINANCE) {
                    if (financialAccounts.none { !it.isDeleted && !it.isArchived }) {
                        Text("ابتدا در بخش مالی یک حساب بساز.", color = MaterialTheme.colorScheme.error)
                    } else {
                        Text("حساب", fontWeight = FontWeight.Bold)
                        financialAccounts.filter { !it.isDeleted && !it.isArchived }.forEach { account ->
                            FilterChip(selected = financeAccountId == account.id, onClick = { financeAccountId = account.id }, label = { Text(account.name) })
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FilterChip(selected = financeKind == "EXPENSE", onClick = { financeKind = "EXPENSE" }, label = { Text("هزینه") })
                            FilterChip(selected = financeKind == "INCOME", onClick = { financeKind = "INCOME" }, label = { Text("درآمد") })
                        }
                        OutlinedTextField(value = financeAmount, onValueChange = { input -> financeAmount = input.map { c -> when (c) { in '۰'..'۹' -> ('0'.code + (c - '۰')).toChar(); in '٠'..'٩' -> ('0'.code + (c - '٠')).toChar(); else -> c } }.filter(Char::isDigit).joinToString("") }, label = { Text("مبلغ به تومان") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(value = financeCategory, onValueChange = { financeCategory = it }, label = { Text("دسته‌بندی") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(value = note, onValueChange = { note = it }, label = { Text("توضیحات") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
                    }
                } else if (type == CalendarCreateType.MOOD) {
                    Text("حال‌وهوای این روز را انتخاب کن")
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("LOVE" to "عاشقانه", "HAPPY" to "خوشحال", "CALM" to "آرام", "SAD" to "غمگین").forEach { (key, label) -> FilterChip(selected = mood == key, onClick = { mood = key }, label = { Text(label) }) }
                    }
                } else if (type != CalendarCreateType.FINANCE) OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("عنوان") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                if (type == CalendarCreateType.MEMORY || type == CalendarCreateType.OCCASION || type == CalendarCreateType.HABIT) OutlinedTextField(value = note, onValueChange = { note = it }, label = { Text("توضیحات") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
                if (type == CalendarCreateType.MOOD) OutlinedTextField(value = note, onValueChange = { note = it.take(80) }, label = { Text("توضیح کوتاه — چرا این حال؟ (اختیاری)") }, placeholder = { Text("مثلاً: امروز انرژی‌ام کم بود") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                if (type == CalendarCreateType.OCCASION) Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(repeatYearly, { repeatYearly = it }); Text("هر سال تکرار شود") }
                if (type == CalendarCreateType.TASK || type == CalendarCreateType.EVENT || type == CalendarCreateType.HABIT) {
                    Text("ساعت", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelLarge)
                    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        (0..23).forEach { h ->
                            FilterChip(
                                selected = selectedHour == h,
                                onClick = { selectedHour = h },
                                label = { Text(PersianDateFormatter.toPersianDigits(h.toString().padStart(2, '0'))) }
                            )
                        }
                    }
                    Text("دقیقه", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelLarge)
                    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf(0, 15, 30, 45).forEach { m ->
                            FilterChip(
                                selected = selectedMinute == m,
                                onClick = { selectedMinute = m },
                                label = { Text(PersianDateFormatter.toPersianDigits(m.toString().padStart(2, '0'))) }
                            )
                        }
                    }
                    if (type == CalendarCreateType.TASK || type == CalendarCreateType.EVENT) {
                        Text("مدت زمان", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelLarge)
                        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf(15, 30, 45, 60, 90, 120, 180).forEach { minutes ->
                                FilterChip(selected = selectedDuration == minutes, onClick = { selectedDuration = minutes }, label = {
                                    Text(if (minutes >= 60 && minutes % 60 == 0) "${minutes / 60} ساعت" else "$minutes دقیقه")
                                })
                            }
                        }
                    }
                    Text(
                        "زمان: ${PersianDateFormatter.toPersianDigits(selectedHour.toString().padStart(2, '0'))}:${PersianDateFormatter.toPersianDigits(selectedMinute.toString().padStart(2, '0'))}" + if (type == CalendarCreateType.TASK || type == CalendarCreateType.EVENT) " · مدت: ${PersianDateFormatter.toPersianDigits(selectedDuration.toString())} دقیقه" else "",
                        color = MaterialTheme.colorScheme.primary,
                        style = MaterialTheme.typography.bodySmall
                    )
                }
                Text("تاریخ انتخاب‌شده: ${PersianDateFormatter.formatDate(selectedEpoch)}", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodySmall)
        }
    }
    // A separate quick-action sheet keeps day creation one tap away without obscuring the calendar.
    // The primary action opens task creation; users can choose the precise record type from this dialog.
}

@Composable
private fun HeroStat(label: String, value: String, modifier: Modifier = Modifier) {
    Column(modifier.clip(RoundedCornerShape(16.dp)).background(Color.White.copy(alpha = .16f)).padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, color = Color.White, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Black)
        Text(label, color = Color.White.copy(alpha = .9f), style = MaterialTheme.typography.labelSmall)
    }
}

@Composable
private fun Dot(color: Color) { Box(Modifier.size(4.dp).background(color, CircleShape)) }

@Composable
private fun SectionHeading(title: String, icon: androidx.compose.ui.graphics.vector.ImageVector, count: Int) {
    Row(Modifier.fillMaxWidth().padding(top = 3.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
        Spacer(Modifier.width(8.dp))
        Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Black, modifier = Modifier.weight(1f))
        SuggestionChip(onClick = {}, label = { Text(PersianDateFormatter.toPersianDigits(count)) })
    }
}

@Composable
private fun CalendarEntry(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector, color: Color, trailing: (@Composable () -> Unit)? = null) {
    Card(shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), elevation = CardDefaults.cardElevation(1.dp)) {
        Row(Modifier.fillMaxWidth().padding(start = 12.dp, top = 10.dp, bottom = 10.dp, end = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(42.dp).clip(RoundedCornerShape(14.dp)).background(color), contentAlignment = Alignment.Center) { Icon(icon, null, tint = MaterialTheme.colorScheme.onSurface, modifier = Modifier.size(21.dp)) }
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(title.ifBlank { "بدون عنوان" }, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyLarge, maxLines = 2)
                if (subtitle.isNotBlank()) Text(subtitle, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall, maxLines = 3)
            }
            trailing?.invoke()
        }
    }
}

private fun dayStart(epoch: Long): Long = Calendar.getInstance().apply {
    timeInMillis = epoch
    set(Calendar.HOUR_OF_DAY, 0)
    set(Calendar.MINUTE, 0)
    set(Calendar.SECOND, 0)
    set(Calendar.MILLISECOND, 0)
}.timeInMillis

/** End of the local calendar day; unlike adding 24 hours, this handles DST transitions. */
private fun dayEnd(epoch: Long): Long = Calendar.getInstance().apply {
    timeInMillis = dayStart(epoch)
    add(Calendar.DAY_OF_YEAR, 1)
    add(Calendar.MILLISECOND, -1)
}.timeInMillis

private fun isPeriodVisibleForMonth(logs: List<CycleLogEntity>, settings: CycleSettingsEntity?, start: Long, end: Long): Boolean {
    val periodLength = (settings?.averagePeriodDays ?: 5).coerceIn(1, 15)
    val todayEnd = Calendar.getInstance().apply {
        set(Calendar.HOUR_OF_DAY, 23); set(Calendar.MINUTE, 59); set(Calendar.SECOND, 59); set(Calendar.MILLISECOND, 999)
    }.timeInMillis
    return logs.any { log ->
        if (log.isDeleted || log.startAt > end) false
        else {
            val byLength = endOfDayAfterDays(log.startAt, periodLength - 1)
            val displayEnd = log.endAt?.let { minOf(it, todayEnd) } ?: minOf(byLength, todayEnd)
            // روز فقط اگر داخل بازهٔ شروع..پایان دوره باشد
            log.startAt <= end && displayEnd >= start
        }
    }
}

private fun endOfDayAfterDays(epoch: Long, daysAfterStart: Int): Long = Calendar.getInstance().apply {
    timeInMillis = epoch
    add(Calendar.DAY_OF_YEAR, daysAfterStart.coerceAtLeast(0))
    set(Calendar.HOUR_OF_DAY, 23)
    set(Calendar.MINUTE, 59)
    set(Calendar.SECOND, 59)
    set(Calendar.MILLISECOND, 999)
}.timeInMillis
private fun dayNoon(epoch: Long): Long = Calendar.getInstance().apply { timeInMillis = epoch; set(Calendar.HOUR_OF_DAY, 12); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }.timeInMillis
private fun dayAtTime(epoch: Long, hour: Int, minute: Int = 0): Long = Calendar.getInstance().apply {
    timeInMillis = epoch
    set(Calendar.HOUR_OF_DAY, hour.coerceIn(0, 23))
    set(Calendar.MINUTE, minute.coerceIn(0, 59))
    set(Calendar.SECOND, 0)
    set(Calendar.MILLISECOND, 0)
}.timeInMillis
private fun hourOf(epoch: Long): Int = Calendar.getInstance().apply { timeInMillis = epoch }.get(Calendar.HOUR_OF_DAY)
private fun parseHabitHour(scheduleNote: String): Int? {
    val match = Regex("""(\d{1,2})\s*:\s*(\d{2})""").find(scheduleNote) ?: return null
    return match.groupValues[1].toIntOrNull()?.coerceIn(0, 23)
}
private fun moodLabel(value: String): String = when (value.uppercase()) { "LOVE" -> "عاشقانه"; "HAPPY" -> "خوشحال"; "CALM" -> "آرام"; "SAD" -> "غمگین"; "ANXIOUS" -> "نگران"; else -> value }

private data class HourSlotItem(val title: String, val kind: String, val color: Color)

@Composable
private fun DayHourTimeline(
    expanded: Boolean,
    onToggle: () -> Unit,
    selectedEpoch: Long,
    tasks: List<TaskEntity>,
    events: List<EventEntity>,
    habits: List<HabitEntity>,
    onHourClick: (Int) -> Unit,
    onMoveTask: (TaskEntity, Long, Int) -> Unit,
    onMoveEvent: (EventEntity, Long, Long) -> Unit
) {
    val density = LocalDensity.current.density
    val hourHeight = 60.dp
    val scrollState = rememberScrollState()
    var timelineNow by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        while (true) {
            kotlinx.coroutines.delay(60_000L)
            timelineNow = System.currentTimeMillis()
        }
    }
    val isToday = PersianDateFormatter.jalaliDayKey(selectedEpoch) == PersianDateFormatter.currentJalaliDayKey()
    val currentMinute = minuteOfDay(timelineNow)
    val timeFormatter = remember { java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault()) }
    Card(
        shape = RoundedCornerShape(26.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.72f)).clickable(onClick = onToggle).padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Box(Modifier.size(42.dp).clip(RoundedCornerShape(14.dp)).background(MaterialTheme.colorScheme.primary), contentAlignment = Alignment.Center) {
                        Icon(Icons.Outlined.Schedule, contentDescription = null, tint = MaterialTheme.colorScheme.onPrimary)
                    }
                    Column(Modifier.weight(1f)) {
                        Text("برنامه‌ریزی ساعتی", fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleMedium)
                        Text(if (expanded) "موردها را بکش تا زمانشان تغییر کند" else "نمای روزانه با بازهٔ زمانی هر مورد", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                if (isToday) {
                    Surface(shape = RoundedCornerShape(12.dp), color = MaterialTheme.colorScheme.surface, contentColor = MaterialTheme.colorScheme.primary) {
                        Text(PersianDateFormatter.toPersianDigits(timeFormatter.format(java.util.Date(timelineNow))), modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp), fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelLarge)
                    }
                    Icon(if (expanded) Icons.Outlined.ExpandLess else Icons.Outlined.ExpandMore, contentDescription = if (expanded) "بستن برنامه ساعتی" else "نمایش برنامه ساعتی", tint = MaterialTheme.colorScheme.primary)
                } else {
                    Text(if (expanded) "بستن" else "نمایش", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 8.dp))
                }
            }
            if (expanded) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    CalendarLegendItem(Color(0xFF3984F5), "کارها")
                    CalendarLegendItem(Color(0xFFFF9F43), "قرارها")
                    CalendarLegendItem(Color(0xFF5C6BC0), "شیفت شغلی")
                    CalendarLegendItem(Color(0xFF9B59D0), "عادات")
                    Spacer(Modifier.weight(1f))
                    Text("برای افزودن، روی ساعت بزن", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            AnimatedVisibility(visible = expanded) {
                Box(Modifier.fillMaxWidth().height(1440.dp).clip(RoundedCornerShape(16.dp)).background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.32f)).verticalScroll(scrollState)) {
                    // Hour grid and clickable empty slots.
                    Column(Modifier.fillMaxWidth()) {
                        (0..23).forEach { hour ->
                            Row(
                                Modifier.fillMaxWidth().height(hourHeight)
                                    .background(if (hour % 2 == 0) MaterialTheme.colorScheme.surface.copy(alpha = 0.52f) else Color.Transparent)
                                    .clickable { onHourClick(hour) },
                                verticalAlignment = Alignment.Top
                            ) {
                                Text(
                                    PersianDateFormatter.toPersianDigits(hour.toString().padStart(2, '0')) + ":۰۰",
                                    modifier = Modifier.width(54.dp).padding(top = 3.dp),
                                    fontWeight = FontWeight.Bold,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Column(Modifier.fillMaxWidth().weight(1f).padding(top = 9.dp)) {
                                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = .7f), thickness = 1.dp)
                                    Spacer(Modifier.height(29.dp))
                                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = .28f), thickness = 0.5.dp)
                                }
                            }
                        }
                    }
                    // Tasks are scheduled by dueAt; duration is stored in the task record.
                    tasks.forEach { task ->
                        val start = task.dueAt ?: return@forEach
                        val minute = minuteOfDay(start)
                        val duration = task.durationMinutes.coerceIn(15, 720)
                        Box(
                            Modifier.offset(y = minute.coerceIn(0, 1440 - duration).dp)
                                .fillMaxWidth()
                                .padding(start = 58.dp, end = 4.dp)
                                .height(duration.coerceAtLeast(34).dp)
                        ) {
                            Card(
                                modifier = Modifier.fillMaxSize(),
                                shape = RoundedCornerShape(10.dp),
                                colors = CardDefaults.cardColors(containerColor = Color(0xFF3984F5).copy(alpha = .94f))
                            ) {
                                Column(Modifier.fillMaxSize().padding(horizontal = 8.dp, vertical = 2.dp), verticalArrangement = Arrangement.spacedBy(0.dp)) {
                                    Box(Modifier.fillMaxWidth().height(5.dp).pointerInput(task.id, start, duration) {
                                        var total = 0f
                                        detectDragGestures(onDragEnd = {
                                            val delta = ((total / density).roundToInt() / 15) * 15
                                            if (delta != 0) {
                                                val endMinute = minute + duration
                                                val newStartMinute = (minute + delta).coerceIn(0, endMinute - 15)
                                                val newDuration = (endMinute - newStartMinute).coerceIn(15, 720)
                                                onMoveTask(task, dayAtTime(selectedEpoch, newStartMinute / 60, newStartMinute % 60), newDuration)
                                            }
                                        }) { change, amount -> change.consume(); total += amount.y }
                                    }.background(Color.White.copy(alpha = .65f)).fillMaxWidth())
                                    Text(task.title, color = Color.White, style = MaterialTheme.typography.labelMedium, maxLines = 1, fontWeight = FontWeight.Bold, modifier = Modifier.pointerInput(task.id, start, duration) {
                                        var total = 0f
                                        detectDragGestures(onDragEnd = {
                                            val delta = ((total / density).roundToInt() / 15) * 15
                                            if (delta != 0) {
                                                val newMinute = (minute + delta).coerceIn(0, 1440 - duration)
                                                onMoveTask(task, dayAtTime(selectedEpoch, newMinute / 60, newMinute % 60), duration)
                                            }
                                        }) { change, amount -> change.consume(); total += amount.y }
                                    })
                                    Text("${PersianDateFormatter.formatTime(start)} · ${PersianDateFormatter.toPersianDigits(duration.toString())} دقیقه", color = Color.White.copy(alpha = .92f), style = MaterialTheme.typography.labelSmall, maxLines = 1)
                                    Spacer(Modifier.weight(1f, fill = false))
                                    Box(Modifier.fillMaxWidth().height(5.dp).pointerInput(task.id, start, duration) {
                                        var total = 0f
                                        detectDragGestures(onDragEnd = {
                                            val delta = ((total / density).roundToInt() / 15) * 15
                                            if (delta != 0) onMoveTask(task, start, (duration + delta).coerceIn(15, 720))
                                        }) { change, amount -> change.consume(); total += amount.y }
                                    }.background(Color.White.copy(alpha = .65f)))
                                }
                            }
                        }
                    }
                    events.forEach { event ->
                        val start = event.startAt
                        val minute = minuteOfDay(start)
                        val end = event.endAt ?: (start + 60L * 60_000L)
                        val duration = ((end - start) / 60_000L).toInt().coerceIn(15, 720)
                        val isWorkShift = event.details.orEmpty().startsWith("OS_WORK|")
                        val eventColor = if (isWorkShift) Color(0xFF5C6BC0) else Color(0xFFFF9F43)
                        Box(
                            Modifier.offset(y = minute.coerceIn(0, 1439).dp)
                                .fillMaxWidth().padding(start = 58.dp, end = 4.dp).height(duration.coerceAtLeast(34).dp)
                        ) {
                            Card(Modifier.fillMaxSize(), shape = RoundedCornerShape(10.dp), colors = CardDefaults.cardColors(containerColor = eventColor)) {
                                Column(Modifier.fillMaxSize().padding(horizontal = 8.dp, vertical = 2.dp)) {
                                    Box(Modifier.fillMaxWidth().height(5.dp).pointerInput(event.id, start, end) {
                                        var total = 0f
                                        detectDragGestures(onDragEnd = {
                                            val delta = ((total / density).roundToInt() / 15) * 15
                                            if (delta != 0) {
                                                val endMinute = minute + duration
                                                val newStartMinute = (minute + delta).coerceIn(0, endMinute - 15)
                                                val newStart = dayAtTime(selectedEpoch, newStartMinute / 60, newStartMinute % 60)
                                                onMoveEvent(event, newStart, newStart + (endMinute - newStartMinute) * 60_000L)
                                            }
                                        }) { change, amount -> change.consume(); total += amount.y }
                                    }.background(Color.White.copy(alpha = .75f)))
                                    Text(event.title, color = Color.White, style = MaterialTheme.typography.labelMedium, maxLines = 1, fontWeight = FontWeight.Bold, modifier = Modifier.pointerInput(event.id, start, end) {
                                        var total = 0f
                                        detectDragGestures(onDragEnd = {
                                            val delta = ((total / density).roundToInt() / 15) * 15
                                            if (delta != 0) {
                                                val newMinute = (minute + delta).coerceIn(0, 1440 - duration)
                                                val newStart = dayAtTime(selectedEpoch, newMinute / 60, newMinute % 60)
                                                onMoveEvent(event, newStart, newStart + duration * 60_000L)
                                            }
                                        }) { change, amount -> change.consume(); total += amount.y }
                                    })
                                    Text("${PersianDateFormatter.formatTime(start)}–${PersianDateFormatter.formatTime(end)}", color = Color.White.copy(alpha = .95f), style = MaterialTheme.typography.labelSmall, maxLines = 1)
                                    Spacer(Modifier.weight(1f, fill = false))
                                    Box(Modifier.fillMaxWidth().height(5.dp).pointerInput(event.id, start, end) {
                                        var total = 0f
                                        detectDragGestures(onDragEnd = {
                                            val delta = ((total / density).roundToInt() / 15) * 15
                                            if (delta != 0) onMoveEvent(event, start, start + (duration + delta).coerceIn(15, 720) * 60_000L)
                                        }) { change, amount -> change.consume(); total += amount.y }
                                    }.background(Color.White.copy(alpha = .75f)))
                                }
                            }
                        }
                    }
                    habits.forEach { habit ->
                        val match = Regex("""(\d{1,2})\s*:\s*(\d{2})""").find(habit.scheduleNote) ?: return@forEach
                        val h = match.groupValues[1].toIntOrNull()?.coerceIn(0, 23) ?: return@forEach
                        val m = match.groupValues[2].toIntOrNull()?.coerceIn(0, 59) ?: 0
                        Row(Modifier.offset(y = (h * 60 + m).dp).fillMaxWidth().padding(start = 58.dp, end = 4.dp).height(34.dp).background(Color(0xFF9B59D0), RoundedCornerShape(8.dp)).padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(habit.title, color = Color.White, style = MaterialTheme.typography.labelMedium, maxLines = 1)
                        }
                    }
                    if (isToday) {
                        Row(
                            Modifier.offset(y = currentMinute.dp).fillMaxWidth().padding(start = 52.dp, end = 5.dp).height(2.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(Modifier.size(7.dp).clip(CircleShape).background(Color(0xFFE5484D)))
                            Spacer(Modifier.width(2.dp))
                            Box(Modifier.fillMaxWidth().height(2.dp).background(Color(0xFFE5484D)))
                        }
                    }
                }
            }
        }
    }
}

private fun minuteOfDay(epoch: Long): Int = Calendar.getInstance().apply { timeInMillis = epoch }.let {
    it.get(Calendar.HOUR_OF_DAY) * 60 + it.get(Calendar.MINUTE)
}

