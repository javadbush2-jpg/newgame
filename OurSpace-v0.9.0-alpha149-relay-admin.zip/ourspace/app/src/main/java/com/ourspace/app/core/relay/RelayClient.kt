package com.ourspace.app.core.relay

import java.io.ByteArrayOutputStream
import java.io.IOException
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import java.nio.charset.StandardCharsets
import java.util.UUID
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

class RelayClient(
    endpoint: String,
    private val credentials: RelayCredentials
) {
    private val baseUrl = RelayEndpointValidator.normalize(endpoint)

    data class HealthReport(
        val ok: Boolean,
        val protocol: Int = 0,
        val uptimeSec: Long = 0,
        val pendingMessages: Int = 0,
        val activeMailboxes: Int = 0,
        val raw: String = ""
    )

    suspend fun health(): Boolean = healthReport().ok

    suspend fun healthReport(): HealthReport = withContext(Dispatchers.IO) {
        runCatching {
            val body = request("GET", "/health", null, authenticated = false)
            val json = JSONObject(body)
            HealthReport(
                ok = json.optString("status") == "ok",
                protocol = json.optInt("protocol"),
                uptimeSec = json.optLong("uptimeSec"),
                pendingMessages = json.optInt("pendingMessages"),
                activeMailboxes = json.optInt("activeMailboxes"),
                raw = body
            )
        }.getOrElse { error ->
            val hint = when (error) {
                is java.net.UnknownHostException -> "DNS نام را پیدا نکرد (DDNS را چک کن)"
                is java.net.ConnectException -> "اتصال رد شد (سرور خاموش یا پورت بسته)"
                is java.net.SocketTimeoutException -> "زمان اتصال تمام شد (فایروال/مودم)"
                is javax.net.ssl.SSLException -> "خطای HTTPS/گواهی"
                else -> (error.message ?: error.javaClass.simpleName)
            }
            HealthReport(ok = false, raw = hint)
        }
    }

    suspend fun publish(
        direction: RelayDirection,
        envelope: JSONObject,
        correlationId: String? = null,
        ttlMillis: Long = RelayMessage.DEFAULT_TTL.toLong(),
        messageId: String = UUID.randomUUID().toString().replace("-", "").take(32).padEnd(16, '0')
    ): String = withContext(Dispatchers.IO) {
        require(RelayMessage.isSafeOpaqueId(messageId))
        require(correlationId == null || RelayMessage.isSafeOpaqueId(correlationId))
        require(ttlMillis in MIN_TTL..RelayMessage.MAX_TTL.toLong())
        require(envelope.toString().toByteArray(StandardCharsets.UTF_8).size <= RelayMessage.MAX_ENVELOPE_BYTES)
        val now = System.currentTimeMillis()
        val message = RelayMessage(
            messageId = messageId,
            correlationId = correlationId,
            createdAt = now,
            expiresAt = now + ttlMillis,
            envelope = envelope
        )
        val response = request(
            method = "POST",
            path = mailboxPath(direction) + "/messages",
            body = message.toJson().toString()
        )
        val returnedId = JSONObject(response).getString("messageId")
        require(returnedId == messageId) { "Relay changed message identity" }
        returnedId
    }

    /**
     * @param waitSeconds server long-poll (0 = immediate). Caps at server max (~25s).
     */
    suspend fun receive(
        direction: RelayDirection,
        limit: Int = 20,
        waitSeconds: Int = 0
    ): List<RelayMessage> = withContext(Dispatchers.IO) {
        val safeLimit = limit.coerceIn(1, MAX_FETCH_ITEMS)
        val wait = waitSeconds.coerceIn(0, 25)
        val path = buildString {
            append(mailboxPath(direction))
            append("/messages?limit=")
            append(safeLimit)
            if (wait > 0) {
                append("&wait=")
                append(wait)
            }
        }
        // Keep the timeout margin small enough that a dead network is detected promptly.
        // Android's NetworkCallback normally restarts the session even sooner.
        val response = request(
            method = "GET",
            path = path,
            body = null,
            readTimeoutMs = if (wait > 0) (wait + 5) * 1000 else READ_TIMEOUT
        )
        val payload = JSONObject(response)
        val array = payload.getJSONArray("messages")
        require(array.length() <= safeLimit)
        // Prefer the server clock when validating returned relay envelopes. A handset that
        // is several minutes behind can otherwise reject the entire batch as a future message
        // before the inbox processor gets a chance to ACK it. Old relay servers remain supported.
        val relayNow = payload.optLong("serverTimeMs")
            .takeIf { it > 0L }
            ?: System.currentTimeMillis()
        buildList {
            for (index in 0 until array.length()) {
                add(RelayMessage.fromJson(array.getJSONObject(index), now = relayNow))
            }
        }
    }

    /** Register FCM token for data-only wake signals (no message body on FCM). */
    suspend fun registerPushToken(token: String, platform: String = "android") = withContext(Dispatchers.IO) {
        require(token.length in 20..4096) { "invalid push token" }
        val body = JSONObject()
            .put("token", token)
            .put("platform", platform)
            .toString()
        request(
            method = "POST",
            path = "/v1/mailboxes/${credentials.mailboxId}/push-tokens",
            body = body
        )
    }

    suspend fun acknowledge(direction: RelayDirection, messageIds: Collection<String>) {
        if (messageIds.isEmpty()) return
        require(messageIds.size <= MAX_ACK_ITEMS)
        messageIds.forEach { require(RelayMessage.isSafeOpaqueId(it)) }
        withContext(Dispatchers.IO) {
            val ids = JSONArray().apply { messageIds.distinct().forEach { put(it) } }
            request(
                method = "POST",
                path = mailboxPath(direction) + "/acknowledgements",
                body = JSONObject().put("messageIds", ids).toString()
            )
        }
    }

    private fun mailboxPath(direction: RelayDirection): String =
        "/v1/mailboxes/${credentials.mailboxId}/${direction.wireName}"

    private fun request(
        method: String,
        path: String,
        body: String?,
        authenticated: Boolean = true,
        readTimeoutMs: Int = READ_TIMEOUT
    ): String {
        var lastError: IOException? = null
        repeat(3) { attempt ->
            try {
                return requestOnce(method, path, body, authenticated, readTimeoutMs)
            } catch (error: IOException) {
                lastError = error
                val msg = error.message.orEmpty().lowercase()
                val retryable = "unexpected end of stream" in msg ||
                    "connection reset" in msg ||
                    "broken pipe" in msg ||
                    "connection refused" in msg
                if (!retryable || attempt == 2) throw error
                try {
                    Thread.sleep(300L * (attempt + 1))
                } catch (_: InterruptedException) {
                    Thread.currentThread().interrupt()
                    throw error
                }
            }
        }
        throw lastError ?: IOException("Relay request failed")
    }

    private fun requestOnce(
        method: String,
        path: String,
        body: String?,
        authenticated: Boolean,
        readTimeoutMs: Int
    ): String {
        val bodyBytes = body?.toByteArray(StandardCharsets.UTF_8)
        require(bodyBytes == null || bodyBytes.size <= MAX_REQUEST_BYTES)
        // Prevent keep-alive reuse which breaks against simple Python HTTP servers.
        System.setProperty("http.keepAlive", "false")
        val connection = URL(baseUrl + path).openConnection() as HttpURLConnection
        return try {
            connection.requestMethod = method
            connection.connectTimeout = CONNECT_TIMEOUT
            connection.readTimeout = readTimeoutMs
            connection.instanceFollowRedirects = false
            connection.setRequestProperty("Accept", "application/json")
            connection.setRequestProperty("Cache-Control", "no-store")
            connection.setRequestProperty("Connection", "close")
            if (authenticated) {
                connection.setRequestProperty("Authorization", "Bearer ${credentials.authToken}")
            }
            if (bodyBytes != null) {
                connection.doOutput = true
                connection.setRequestProperty("Content-Type", "application/json; charset=utf-8")
                connection.setFixedLengthStreamingMode(bodyBytes.size)
                connection.outputStream.use { out ->
                    out.write(bodyBytes)
                    out.flush()
                }
            }
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val response = stream?.use { readBounded(it, MAX_RESPONSE_BYTES) }.orEmpty()
            if (code !in 200..299) {
                throw IOException("Relay request failed: HTTP $code ${response.take(120)}")
            }
            response
        } finally {
            bodyBytes?.fill(0)
            runCatching { connection.disconnect() }
        }
    }

    private fun readBounded(stream: InputStream, maxBytes: Int): String {
        val output = ByteArrayOutputStream()
        val buffer = ByteArray(8 * 1024)
        while (true) {
            val count = stream.read(buffer)
            if (count < 0) break
            if (output.size() + count > maxBytes) throw IOException("Relay response is too large")
            output.write(buffer, 0, count)
        }
        buffer.fill(0)
        return output.toString(StandardCharsets.UTF_8.name())
    }


    /**
     * Upload raw attachment bytes once (content-addressed by sha256).
     * Avoids Base64 inflation (~33%) and multi-chunk JSON overhead on the wire.
     */
    suspend fun putBlob(
        sha256: String,
        content: ByteArray,
        mimeType: String,
        fileName: String = ""
    ): Boolean = withContext(Dispatchers.IO) {
        val sha = sha256.lowercase().trim()
        require(sha.matches(Regex("^[a-f0-9]{64}$")))
        require(content.isNotEmpty() && content.size <= 48 * 1024 * 1024)
        val path = "/v1/mailboxes/${credentials.mailboxId}/blobs/$sha"
        System.setProperty("http.keepAlive", "false")
        val connection = URL(baseUrl + path).openConnection() as HttpURLConnection
        try {
            connection.requestMethod = "PUT"
            connection.connectTimeout = CONNECT_TIMEOUT
            connection.readTimeout = READ_TIMEOUT * 2
            connection.instanceFollowRedirects = false
            connection.setRequestProperty("Authorization", "Bearer ${credentials.authToken}")
            connection.setRequestProperty("Content-Type", mimeType.ifBlank { "application/octet-stream" })
            if (fileName.isNotBlank()) {
                connection.setRequestProperty("X-File-Name", fileName.take(180))
            }
            connection.setRequestProperty("Connection", "close")
            connection.doOutput = true
            connection.setFixedLengthStreamingMode(content.size)
            connection.outputStream.use { out ->
                out.write(content)
                out.flush()
            }
            val code = connection.responseCode
            if (code !in 200..299) {
                val err = connection.errorStream?.use { readBounded(it, 4096) }.orEmpty()
                throw IOException("Blob upload failed: HTTP $code ${err.take(120)}")
            }
            true
        } finally {
            runCatching { connection.disconnect() }
        }
    }

    suspend fun getBlob(sha256: String): ByteArray = withContext(Dispatchers.IO) {
        val sha = sha256.lowercase().trim()
        require(sha.matches(Regex("^[a-f0-9]{64}$")))
        val path = "/v1/mailboxes/${credentials.mailboxId}/blobs/$sha"
        System.setProperty("http.keepAlive", "false")
        val connection = URL(baseUrl + path).openConnection() as HttpURLConnection
        try {
            connection.requestMethod = "GET"
            connection.connectTimeout = CONNECT_TIMEOUT
            connection.readTimeout = READ_TIMEOUT * 3
            connection.instanceFollowRedirects = false
            connection.setRequestProperty("Authorization", "Bearer ${credentials.authToken}")
            connection.setRequestProperty("Connection", "close")
            val code = connection.responseCode
            if (code !in 200..299) {
                val err = connection.errorStream?.use { readBounded(it, 4096) }.orEmpty()
                throw IOException("Blob download failed: HTTP $code ${err.take(120)}")
            }
            connection.inputStream.use { input ->
                val output = ByteArrayOutputStream()
                val buffer = ByteArray(16 * 1024)
                var total = 0
                while (true) {
                    val n = input.read(buffer)
                    if (n < 0) break
                    total += n
                    if (total > 48 * 1024 * 1024) throw IOException("Blob too large")
                    output.write(buffer, 0, n)
                }
                output.toByteArray()
            }
        } finally {
            runCatching { connection.disconnect() }
        }
    }

    private companion object {
        const val MAX_FETCH_ITEMS = 50
        const val MAX_ACK_ITEMS = 100
        const val MAX_REQUEST_BYTES = RelayMessage.MAX_ENVELOPE_BYTES + 16 * 1024
        const val MAX_RESPONSE_BYTES = RelayMessage.MAX_ENVELOPE_BYTES + 512 * 1024
        const val MIN_TTL = 60_000L
        const val CONNECT_TIMEOUT = 7_000
        const val READ_TIMEOUT = 15_000
    }
}
