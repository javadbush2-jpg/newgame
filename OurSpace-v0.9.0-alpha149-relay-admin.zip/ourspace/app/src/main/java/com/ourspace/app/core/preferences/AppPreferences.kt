package com.ourspace.app.core.preferences

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.ourspace.app.core.relay.RelayConfig
import com.ourspace.app.core.relay.RelayEndpointValidator
import com.ourspace.app.core.webrtc.WebRtcConfig
import com.ourspace.app.model.DeviceRole
import com.ourspace.app.ui.theme.AppPalette
import com.ourspace.app.ui.theme.AppThemeMode
import com.ourspace.app.ui.theme.AppFontFamily
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.ourSpaceDataStore by preferencesDataStore(name = "ourspace_settings")

class AppPreferences(private val context: Context) {
    private object Keys {
        val role = stringPreferencesKey("device_role")
        val trustedHostPayload = stringPreferencesKey("trusted_host_payload")
        val palette = stringPreferencesKey("theme_palette")
        val themeMode = stringPreferencesKey("theme_mode")
        val fontScale = floatPreferencesKey("font_scale")
        val fontFamily = stringPreferencesKey("font_family")
        val compactUi = booleanPreferencesKey("compact_ui")
        val hapticsEnabled = booleanPreferencesKey("haptics_enabled")
        val reduceAnimations = booleanPreferencesKey("reduce_animations")
        val showCalendarWeekNumbers = booleanPreferencesKey("calendar_week_numbers")
        val relayEnabled = booleanPreferencesKey("relay_enabled")
        val relayEndpoint = stringPreferencesKey("relay_endpoint")
        val relayAccessToken = stringPreferencesKey("relay_access_token")
        val locationSharingEnabled = booleanPreferencesKey("location_sharing_enabled")
        val turnUrl = stringPreferencesKey("turn_url")
        val turnUsername = stringPreferencesKey("turn_username")
        val turnPassword = stringPreferencesKey("turn_password")
        val telegramBotToken = stringPreferencesKey("telegram_bot_token")
    }

    val role: Flow<DeviceRole?> = context.ourSpaceDataStore.data.map { preferences ->
        DeviceRole.fromPersistedName(preferences[Keys.role])
    }

    val trustedHostPayload: Flow<String?> = context.ourSpaceDataStore.data.map { preferences ->
        preferences[Keys.trustedHostPayload]
    }

    val palette: Flow<AppPalette> = context.ourSpaceDataStore.data.map { preferences ->
        AppPalette.fromPersistedName(preferences[Keys.palette])
    }

    val themeMode: Flow<AppThemeMode> = context.ourSpaceDataStore.data.map { preferences ->
        AppThemeMode.fromPersistedName(preferences[Keys.themeMode])
    }

    val fontScale: Flow<Float> = context.ourSpaceDataStore.data.map { preferences ->
        (preferences[Keys.fontScale] ?: 1.0f).coerceIn(0.85f, 1.35f)
    }

    val fontFamily: Flow<AppFontFamily> = context.ourSpaceDataStore.data.map { preferences ->
        AppFontFamily.fromPersistedName(preferences[Keys.fontFamily])
    }

    val compactUi: Flow<Boolean> = context.ourSpaceDataStore.data.map { it[Keys.compactUi] ?: false }
    val hapticsEnabled: Flow<Boolean> = context.ourSpaceDataStore.data.map { it[Keys.hapticsEnabled] ?: true }
    val reduceAnimations: Flow<Boolean> = context.ourSpaceDataStore.data.map { it[Keys.reduceAnimations] ?: false }
    val showCalendarWeekNumbers: Flow<Boolean> = context.ourSpaceDataStore.data.map { it[Keys.showCalendarWeekNumbers] ?: false }

    val locationSharingEnabled: Flow<Boolean> = context.ourSpaceDataStore.data.map { preferences ->
        preferences[Keys.locationSharingEnabled] ?: false
    }

    /** Optional self-hosted TURN relay; when set it is tried before the public ones. */
    val customTurn: Flow<WebRtcConfig.IceServerConfig?> = context.ourSpaceDataStore.data.map { preferences ->
        val url = preferences[Keys.turnUrl]?.trim().orEmpty()
        if (url.isBlank()) null else WebRtcConfig.IceServerConfig(
            url = url,
            username = preferences[Keys.turnUsername]?.takeIf { it.isNotBlank() },
            credential = preferences[Keys.turnPassword]?.takeIf { it.isNotBlank() }
        )
    }



    suspend fun currentCustomTurn(): WebRtcConfig.IceServerConfig? = customTurn.first()

    suspend fun setCustomTurn(url: String, username: String, password: String) {
        context.ourSpaceDataStore.edit { preferences ->
            preferences[Keys.turnUrl] = url.trim()
            preferences[Keys.turnUsername] = username.trim()
            preferences[Keys.turnPassword] = password.trim()
        }
    }

    val relayConfig: Flow<RelayConfig> = context.ourSpaceDataStore.data.map { preferences ->
        val endpoint = preferences[Keys.relayEndpoint]?.trim().orEmpty()
            .ifBlank { RelayConfig.DEFAULT_ENDPOINT }
        val token = preferences[Keys.relayAccessToken]?.trim().orEmpty()
            .ifBlank { RelayConfig.DEFAULT_ACCESS_TOKEN }
        RelayConfig(
            // Default ON so first launch connects to the household server without setup.
            enabled = preferences[Keys.relayEnabled] ?: true,
            endpoint = endpoint,
            accessToken = token
        )
    }

    suspend fun setRole(role: DeviceRole, hostPayload: String? = null) {
        context.ourSpaceDataStore.edit { preferences ->
            preferences[Keys.role] = role.persistedName
            if (hostPayload != null) {
                preferences[Keys.trustedHostPayload] = hostPayload
            }
        }
    }

    suspend fun currentRole(): DeviceRole? = role.first()

    suspend fun setPalette(palette: AppPalette) {
        context.ourSpaceDataStore.edit { it[Keys.palette] = palette.persistedName }
    }

    suspend fun setThemeMode(mode: AppThemeMode) {
        context.ourSpaceDataStore.edit { it[Keys.themeMode] = mode.persistedName }
    }

    suspend fun setFontScale(scale: Float) {
        context.ourSpaceDataStore.edit { it[Keys.fontScale] = scale.coerceIn(0.85f, 1.35f) }
    }
    suspend fun setFontFamily(family: AppFontFamily) {
        context.ourSpaceDataStore.edit { it[Keys.fontFamily] = family.persistedName }
    }
    suspend fun setCompactUi(enabled: Boolean) { context.ourSpaceDataStore.edit { it[Keys.compactUi] = enabled } }
    suspend fun setHapticsEnabled(enabled: Boolean) { context.ourSpaceDataStore.edit { it[Keys.hapticsEnabled] = enabled } }
    suspend fun setReduceAnimations(enabled: Boolean) { context.ourSpaceDataStore.edit { it[Keys.reduceAnimations] = enabled } }
    suspend fun setShowCalendarWeekNumbers(enabled: Boolean) { context.ourSpaceDataStore.edit { it[Keys.showCalendarWeekNumbers] = enabled } }

    suspend fun isLocationSharingEnabled(): Boolean = locationSharingEnabled.first()

    suspend fun setLocationSharingEnabled(enabled: Boolean) {
        context.ourSpaceDataStore.edit { it[Keys.locationSharingEnabled] = enabled }
    }

    suspend fun currentRelayConfig(): RelayConfig = relayConfig.first()


    val telegramBotToken: Flow<String> = context.ourSpaceDataStore.data.map { preferences ->
        preferences[Keys.telegramBotToken].orEmpty()
    }

    suspend fun currentTelegramBotToken(): String = telegramBotToken.first()

    suspend fun setTelegramBotToken(token: String) {
        context.ourSpaceDataStore.edit { preferences ->
            val cleaned = token.trim()
            if (cleaned.isEmpty()) preferences.remove(Keys.telegramBotToken)
            else preferences[Keys.telegramBotToken] = cleaned
        }
    }

    suspend fun setRelayConfig(enabled: Boolean, endpoint: String, accessToken: String = "") {
        val normalized = if (endpoint.isBlank()) "" else RelayEndpointValidator.normalize(endpoint)
        val token = accessToken.trim()
        require(!enabled || normalized.isNotBlank()) { "آدرس سرور لازم است" }
        if (enabled) require(token.length in 16..128) { "کلید مشترک خانه لازم است (از کنسول سرور کپی کن)" }
        context.ourSpaceDataStore.edit { preferences ->
            preferences[Keys.relayEnabled] = enabled
            preferences[Keys.relayEndpoint] = normalized
            preferences[Keys.relayAccessToken] = token
        }
    }

    suspend fun reset() {
        context.ourSpaceDataStore.edit { it.clear() }
    }

    companion object {
    }
}
