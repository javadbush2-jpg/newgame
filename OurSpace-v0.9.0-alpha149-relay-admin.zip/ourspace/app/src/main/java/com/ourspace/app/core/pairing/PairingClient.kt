package com.ourspace.app.core.pairing

import com.ourspace.app.core.security.DeviceIdentityManager
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.nio.charset.StandardCharsets
import java.util.UUID
import org.json.JSONObject

class PairingClient(private val identityManager: DeviceIdentityManager) {
    data class PairingRequestResult(
        val requestId: String,
        val hostDeviceId: String,
        val hostFingerprint: String,
        val host: String,
        val port: Int,
        val relayEndpoint: String?,
        val secret: ByteArray,
        /** QR that host must scan to receive the encrypted secret (offline path). */
        val replyQrPayload: String,
        val offline: Boolean
    )

    data class StatusResult(
        val status: PairingStore.RequestStatus,
        val proof: String? = null
    )

    data class CompanionReply(
        val requestId: String,
        val deviceId: String,
        val fingerprint: String,
        val publicKey: String,
        val encryptedSecret: String
    )

    data class ApprovalPayload(
        val requestId: String,
        val proof: String
    )

    /**
     * Start pairing from companion after scanning host invite QR.
     * Always uses offline QR reply path so internet-only phones work.
     * Optional LAN path is no longer required for pairing.
     */
    fun requestPairing(
        payload: String,
        ownIdentity: DeviceIdentityManager.DeviceIdentity
    ): PairingRequestResult {
        val parsed = identityManager.parsePairingPayload(payload)
            ?: throw IOException("QR میزبان معتبر نیست. از نسخه جدید اپ روی هر دو گوشی استفاده کنید.")
        val requestId = UUID.randomUUID().toString()
        val secret = identityManager.createPairingSecret()
        return try {
            val encryptedSecret = identityManager.encryptForPublicKey(parsed.publicKey, secret)
            val replyQr = buildCompanionReplyQr(
                requestId = requestId,
                ownIdentity = ownIdentity,
                encryptedSecret = encryptedSecret
            )
            PairingRequestResult(
                requestId = requestId,
                hostDeviceId = parsed.deviceId,
                hostFingerprint = identityManager.fingerprintForPublicKey(parsed.publicKey),
                host = parsed.host.orEmpty(),
                port = parsed.port ?: 0,
                relayEndpoint = null,
                secret = secret,
                replyQrPayload = replyQr,
                offline = true
            )
        } catch (error: Exception) {
            secret.fill(0)
            if (error is IOException) throw error
            throw IOException(error.message ?: "ساخت درخواست جفت‌سازی ناموفق بود.", error)
        }
    }

    fun parseCompanionReply(payload: String): CompanionReply {
        val cleaned = normalizeQrPayload(payload)
        require(cleaned.startsWith("ourspace://pair-reply")) {
            if (cleaned.startsWith("ourspace://pair-ok")) {
                "این QR تأیید میزبان است، نه پاسخ همراه. روی گوشی همراه گزینه «نمایش QR پاسخ» را باز کنید."
            } else if (cleaned.startsWith("ourspace://pair")) {
                "این QR دعوت میزبان است، نه پاسخ همراه. ابتدا همراه باید QR دعوت را اسکن کند و سپس QR پاسخ بسازد."
            } else {
                "QR همراه معتبر نیست. باید پاسخ جفت‌سازی (pair-reply) باشد."
            }
        }
        val map = queryMap(cleaned.substringAfter("?", ""))
        require(map["v"] == "3") { "نسخه QR پاسخ پشتیبانی نمی‌شود." }
        return CompanionReply(
            requestId = map["id"] ?: throw IOException("شناسه درخواست در QR نیست."),
            deviceId = map["device"] ?: throw IOException("شناسه دستگاه در QR نیست."),
            fingerprint = map["fp"] ?: throw IOException("اثرانگشت در QR نیست."),
            publicKey = map["key"].orEmpty(),
            encryptedSecret = map["enc"] ?: throw IOException("کلید رمز در QR نیست.")
        )
    }

    fun buildApprovalQr(requestId: String, proof: String): String {
        val id = URLEncoder.encode(requestId, StandardCharsets.UTF_8.name())
        val pr = URLEncoder.encode(proof, StandardCharsets.UTF_8.name())
        return "ourspace://pair-ok?v=3&id=$id&proof=$pr"
    }

    fun parseApproval(payload: String): ApprovalPayload {
        val cleaned = normalizeQrPayload(payload)
        require(cleaned.startsWith("ourspace://pair-ok")) {
            "QR تأیید معتبر نیست. باید pair-ok باشد."
        }
        val map = queryMap(cleaned.substringAfter("?", ""))
        require(map["v"] == "3") { "نسخه QR تأیید پشتیبانی نمی‌شود." }
        return ApprovalPayload(
            requestId = map["id"] ?: throw IOException("شناسه در QR تأیید نیست."),
            proof = map["proof"] ?: throw IOException("اثبات تأیید در QR نیست.")
        )
    }

    private fun buildCompanionReplyQr(
        requestId: String,
        ownIdentity: DeviceIdentityManager.DeviceIdentity,
        encryptedSecret: String
    ): String {
        fun enc(v: String) = URLEncoder.encode(v, StandardCharsets.UTF_8.name())
        // Keep QR small: host only needs encrypted secret + identity labels.
        return "ourspace://pair-reply?v=3" +
            "&id=${enc(requestId)}" +
            "&device=${enc(ownIdentity.deviceId)}" +
            "&fp=${enc(ownIdentity.fingerprint)}" +
            "&enc=${enc(encryptedSecret)}"
    }

    /** Scanners may add whitespace/newlines or change the scheme case; normalize both. */
    private fun normalizeQrPayload(raw: String): String {
        val trimmed = raw.trim().replace("\n", "").replace("\r", "")
        val schemeEnd = trimmed.indexOf("://")
        if (schemeEnd <= 0) return trimmed
        val queryStart = trimmed.indexOf('?')
        val headEnd = if (queryStart > 0) queryStart else trimmed.length
        return trimmed.substring(0, headEnd).lowercase() + trimmed.substring(headEnd)
    }

    private fun queryMap(raw: String): Map<String, String> {
        if (raw.isBlank()) return emptyMap()
        return raw.split('&').mapNotNull { part ->
            val split = part.split('=', limit = 2)
            if (split.size != 2) null
            else {
                java.net.URLDecoder.decode(split[0], StandardCharsets.UTF_8.name()) to
                    java.net.URLDecoder.decode(split[1], StandardCharsets.UTF_8.name())
            }
        }.toMap()
    }

    // Legacy LAN status poll kept for older hosts on same Wi-Fi; unused in offline flow.
    fun checkStatus(outgoing: PairingStore.OutgoingRequest): StatusResult {
        if (outgoing.host.isBlank() || outgoing.port <= 0) {
            return StatusResult(PairingStore.RequestStatus.PENDING)
        }
        return try {
            val response = execute(
                url = "http://${outgoing.host}:${outgoing.port}/pair/status?id=${outgoing.requestId}",
                method = "GET"
            )
            val json = JSONObject(response)
            val status = when (json.optString("status")) {
                "approved" -> PairingStore.RequestStatus.APPROVED
                "rejected" -> PairingStore.RequestStatus.REJECTED
                else -> PairingStore.RequestStatus.PENDING
            }
            StatusResult(status, json.optString("proof").takeIf { it.isNotBlank() })
        } catch (_: Exception) {
            StatusResult(PairingStore.RequestStatus.PENDING)
        }
    }

    private fun execute(url: String, method: String, body: String? = null): String {
        val connection = (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = method
            connectTimeout = 6_000
            readTimeout = 8_000
            if (body != null) {
                doOutput = true
                setRequestProperty("Content-Type", "application/json; charset=utf-8")
            }
        }
        try {
            if (body != null) {
                connection.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            }
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val text = stream?.bufferedReader()?.readText().orEmpty()
            if (code !in 200..299) throw IOException(text.ifBlank { "HTTP $code" })
            return text
        } finally {
            connection.disconnect()
        }
    }
}
