package com.ourspace.app.core.server

import android.content.Context
import android.util.Log
import com.ourspace.app.core.pairing.PairingStore
import com.ourspace.app.core.preferences.AppPreferences
import com.ourspace.app.core.security.DeviceIdentityManager
import com.ourspace.app.core.sync.HostSyncExchangeProcessor
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.InetAddress
import java.net.ServerSocket
import java.net.Socket
import java.net.URLDecoder
import java.nio.charset.StandardCharsets
import java.util.ArrayDeque
import java.util.concurrent.ArrayBlockingQueue
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.RejectedExecutionException
import java.util.concurrent.ThreadPoolExecutor
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.runBlocking
import org.json.JSONObject

class LocalHostServer(
    context: Context,
    private val port: Int = DEFAULT_PORT,
    private val syncProcessor: HostSyncExchangeProcessor = HostSyncExchangeProcessor(context)
) {
    private data class HttpRequest(
        val method: String,
        val path: String,
        val query: Map<String, String>,
        val body: String
    )

    private data class HttpResponse(val code: Int, val body: JSONObject)

    private class LocalRequestRateLimiter {
        private val requests = ConcurrentHashMap<String, ArrayDeque<Long>>()

        fun allow(clientAddress: String, now: Long = System.currentTimeMillis()): Boolean {
            val queue = requests.getOrPut(clientAddress) { ArrayDeque() }
            synchronized(queue) {
                val cutoff = now - RATE_WINDOW
                while (queue.peekFirst()?.let { it <= cutoff } == true) queue.removeFirst()
                if (queue.size >= MAX_REQUESTS_PER_WINDOW) return false
                queue.addLast(now)
                return true
            }
        }
    }

    private val running = AtomicBoolean(false)
    private val requestRateLimiter = LocalRequestRateLimiter()
    private val clientExecutor = ThreadPoolExecutor(
        MAX_CLIENT_THREADS,
        MAX_CLIENT_THREADS,
        0L,
        TimeUnit.MILLISECONDS,
        ArrayBlockingQueue(MAX_QUEUED_CLIENTS)
    )
    private val appContext = context.applicationContext
    private val pairingStore = PairingStore(appContext)
    private val preferences = AppPreferences(appContext)
    private val identityManager = DeviceIdentityManager()
    private var serverSocket: ServerSocket? = null
    private var acceptThread: Thread? = null

    fun start(): Boolean {
        if (!running.compareAndSet(false, true)) return true
        return try {
            serverSocket = ServerSocket(port, 16, InetAddress.getByName("0.0.0.0"))
            acceptThread = Thread(::acceptLoop, "ourspace-host-server").apply { start() }
            true
        } catch (error: Exception) {
            running.set(false)
            Log.e(TAG, "Unable to start local host server", error)
            false
        }
    }

    fun stop() {
        running.set(false)
        runCatching { serverSocket?.close() }
        acceptThread?.interrupt()
        clientExecutor.shutdownNow()
    }

    fun isRunning(): Boolean = running.get() && serverSocket?.isClosed == false

    private fun acceptLoop() {
        while (running.get()) {
            try {
                val socket = serverSocket?.accept() ?: break
                try {
                    clientExecutor.execute { handle(socket) }
                } catch (_: RejectedExecutionException) {
                    runCatching { socket.close() }
                }
            } catch (error: Exception) {
                if (running.get()) Log.w(TAG, "Host server accept failed", error)
            }
        }
    }

    private fun handle(socket: Socket) {
        socket.use { client ->
            client.soTimeout = 6_000
            val clientAddress = client.inetAddress?.hostAddress.orEmpty()
            if (!requestRateLimiter.allow(clientAddress)) {
                writeResponse(client, HttpResponse(429, JSONObject().put("error", "rate_limited")))
                return
            }
            val response = runCatching {
                route(readRequest(BufferedReader(InputStreamReader(client.getInputStream()))))
            }.getOrElse { error ->
                Log.w(TAG, "Invalid local request", error)
                HttpResponse(400, JSONObject().put("error", "bad_request").put("message", "درخواست معتبر نیست."))
            }
            writeResponse(client, response)
        }
    }

    private fun readRequest(reader: BufferedReader): HttpRequest {
        val requestLine = reader.readLine() ?: error("Missing request line")
        require(requestLine.length <= MAX_HEADER_LINE)
        val requestParts = requestLine.split(' ')
        require(requestParts.size >= 2)
        val method = requestParts[0].uppercase()
        val target = requestParts[1]
        require(target.length <= MAX_TARGET_LENGTH)
        val headers = mutableMapOf<String, String>()
        var headerCount = 0
        while (true) {
            val line = reader.readLine() ?: break
            require(line.length <= MAX_HEADER_LINE)
            if (line.isBlank()) break
            headerCount += 1
            require(headerCount <= MAX_HEADERS)
            val split = line.split(':', limit = 2)
            if (split.size == 2) headers[split[0].trim().lowercase()] = split[1].trim()
        }
        val contentLength = headers["content-length"]?.toIntOrNull() ?: 0
        require(contentLength in 0..MAX_BODY)
        val chars = CharArray(contentLength)
        var offset = 0
        while (offset < contentLength) {
            val count = reader.read(chars, offset, contentLength - offset)
            if (count <= 0) break
            offset += count
        }
        val targetParts = target.split('?', limit = 2)
        return HttpRequest(
            method = method,
            path = targetParts[0],
            query = parseQuery(targetParts.getOrNull(1).orEmpty()),
            body = String(chars, 0, offset)
        )
    }

    private fun route(request: HttpRequest): HttpResponse = when {
        request.method == "GET" && request.path == "/health" -> {
            HttpResponse(
                200,
                JSONObject()
                    .put("service", "OurSpace")
                    .put("status", "ok")
                    .put("protocol", 3)
            )
        }
        request.method == "POST" && request.path == "/pair/request" -> handlePairRequest(request)
        request.method == "GET" && request.path == "/pair/status" -> handlePairStatus(request)
        request.method == "POST" && request.path == "/sync/exchange" -> handleSyncExchange(request)
        else -> HttpResponse(404, JSONObject().put("error", "not_found"))
    }

    private fun handlePairRequest(request: HttpRequest): HttpResponse {
        val json = JSONObject(request.body)
        val requestId = json.getString("requestId").take(80)
        val deviceId = json.getString("deviceId").take(80)
        val fingerprint = json.getString("fingerprint").take(80)
        val publicKey = json.getString("publicKey")
        val encryptedSecret = json.getString("encryptedSecret")
        // Relay removed — ignore any legacy relayEndpoint field from older companions.
        val requestedRelay = null
        require(requestId.isNotBlank() && deviceId.isNotBlank() && encryptedSecret.length < 8_192)
        // no relay validation
        require(identityManager.deviceIdForPublicKey(publicKey) == deviceId)
        require(identityManager.fingerprintForPublicKey(publicKey) == fingerprint)
        val secret = identityManager.decryptPairingSecret(encryptedSecret)
        val status = try {
            require(secret.size == 32)
            pairingStore.receiveIncoming(requestId, deviceId, fingerprint, secret)
        } finally {
            secret.fill(0)
        }
        return when (status) {
            PairingStore.RequestStatus.REJECTED -> HttpResponse(
                409,
                JSONObject().put("status", "rejected").put("message", "یک دستگاه همراه دیگر قبلاً ثبت شده است.")
            )
            else -> HttpResponse(202, JSONObject().put("status", "pending").put("requestId", requestId))
        }
    }

    private fun handlePairStatus(request: HttpRequest): HttpResponse {
        val requestId = request.query["id"]?.take(80).orEmpty()
        if (requestId.isBlank()) return HttpResponse(400, JSONObject().put("error", "missing_id"))
        return when (pairingStore.incomingStatus(requestId)) {
            PairingStore.RequestStatus.PENDING -> HttpResponse(200, JSONObject().put("status", "pending"))
            PairingStore.RequestStatus.REJECTED -> HttpResponse(200, JSONObject().put("status", "rejected"))
            PairingStore.RequestStatus.APPROVED -> HttpResponse(
                200,
                JSONObject()
                    .put("status", "approved")
                    .put("proof", pairingStore.approvalProof(requestId))
            )
            null -> HttpResponse(404, JSONObject().put("status", "unknown"))
        }
    }

    private fun handleSyncExchange(request: HttpRequest): HttpResponse = try {
        val response = runBlocking(Dispatchers.IO) {
            syncProcessor.processEncryptedEnvelope(JSONObject(request.body))
        }
        HttpResponse(200, response)
    } catch (_: HostSyncExchangeProcessor.PairingRequiredException) {
        HttpResponse(401, JSONObject().put("error", "not_paired"))
    }

    private fun writeResponse(socket: Socket, response: HttpResponse) {
        val body = response.body.toString()
        val status = when (response.code) {
            200 -> "200 OK"
            202 -> "202 Accepted"
            400 -> "400 Bad Request"
            401 -> "401 Unauthorized"
            404 -> "404 Not Found"
            409 -> "409 Conflict"
            429 -> "429 Too Many Requests"
            else -> "500 Internal Server Error"
        }
        socket.getOutputStream().bufferedWriter().use { writer ->
            writer.write("HTTP/1.1 $status\r\n")
            writer.write("Content-Type: application/json; charset=utf-8\r\n")
            writer.write("Content-Length: ${body.toByteArray().size}\r\n")
            writer.write("Connection: close\r\n")
            writer.write("Cache-Control: no-store\r\n")
            writer.write("\r\n")
            writer.write(body)
            writer.flush()
        }
    }

    private fun parseQuery(raw: String): Map<String, String> = raw.split('&').mapNotNull { item ->
        val split = item.split('=', limit = 2)
        if (split.size != 2) null else {
            URLDecoder.decode(split[0], StandardCharsets.UTF_8.name()) to
                URLDecoder.decode(split[1], StandardCharsets.UTF_8.name())
        }
    }.toMap()

    companion object {
        const val DEFAULT_PORT = 8765
        private const val MAX_BODY = 34_000_000
        private const val MAX_HEADER_LINE = 8_192
        private const val MAX_TARGET_LENGTH = 2_048
        private const val MAX_HEADERS = 64
        private const val MAX_CLIENT_THREADS = 4
        private const val MAX_QUEUED_CLIENTS = 16
        private const val MAX_REQUESTS_PER_WINDOW = 120
        private const val RATE_WINDOW = 60_000L
        private const val TAG = "OurSpaceHostServer"
    }
}
