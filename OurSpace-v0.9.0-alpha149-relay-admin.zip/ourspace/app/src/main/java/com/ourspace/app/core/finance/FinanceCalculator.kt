package com.ourspace.app.core.finance

import com.ourspace.app.core.database.FinanceTransactionEntity
import com.ourspace.app.core.database.FinancialAccountEntity
import com.ourspace.app.core.time.PersianDateFormatter

object FinanceCalculator {
    data class PeriodTotals(val income: Long, val expense: Long)

    fun accountBalance(
        account: FinancialAccountEntity,
        transactions: List<FinanceTransactionEntity>
    ): Long = account.openingBalance + transactions.asSequence()
        .filter { !it.isDeleted && (it.accountId == account.id || it.targetAccountId == account.id) }
        .sumOf { transaction ->
            when {
                transaction.kind == "TRANSFER" && transaction.targetAccountId == account.id -> transaction.amount
                transaction.kind == "INCOME" && transaction.accountId == account.id -> transaction.amount
                transaction.accountId == account.id -> -transaction.amount
                else -> 0L
            }
        }

    fun totalBalance(
        accounts: List<FinancialAccountEntity>,
        transactions: List<FinanceTransactionEntity>
    ): Long = accounts.asSequence()
        .filter { !it.isDeleted && !it.isArchived }
        .sumOf { accountBalance(it, transactions) }

    fun periodTotals(
        transactions: List<FinanceTransactionEntity>,
        periodKey: String
    ): PeriodTotals {
        val periodTransactions = transactions.filter {
            !it.isDeleted && PersianDateFormatter.jalaliMonthKey(it.occurredAt) == periodKey
        }
        return PeriodTotals(
            income = periodTransactions.filter { it.kind == "INCOME" }.sumOf { it.amount },
            expense = periodTransactions.filter { it.kind == "EXPENSE" }.sumOf { it.amount }
        )
    }

    fun categoryExpense(
        transactions: List<FinanceTransactionEntity>,
        periodKey: String,
        category: String
    ): Long = transactions.asSequence()
        .filter {
            !it.isDeleted && it.kind == "EXPENSE" && it.category == category &&
                PersianDateFormatter.jalaliMonthKey(it.occurredAt) == periodKey
        }
        .sumOf { it.amount }
}
