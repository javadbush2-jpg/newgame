package com.ourspace.app.core.webrtc

import android.content.Context
import com.ourspace.app.core.sync.HostSyncExchangeProcessor
import com.ourspace.app.core.webrtc.ConnectionDiagnostics
import java.util.concurrent.atomic.AtomicReference
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import org.json.JSONObject

/**
 * Application-wide singleton holder for the active WebRTC peer session.
 *
 * Presence frames (nudge / typing) and optional realtime sync deltas travel as plain JSON
 * on the DataChannel. Durable delivery remains the encrypted relay mailbox; WebRTC is the
 * low-latency fast path when both phones are online.
 */
object WebRtcSession {
    private val managerRef = AtomicReference<WebRtcPeerManager?>(null)
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var hostProcessor: HostSyncExchangeProcessor? = null

    @Volatile
    private var nudgeListener: (() -> Unit)? = null

    @Volatile
    private var typingListener: ((Boolean, Long) -> Unit)? = null

    /**
     * Both roles may register this to apply incremental_exchange deltas arriving over WebRTC
     * without waiting for the relay long-poll.
     */
    @Volatile
    private var deltaListener: ((JSONObject) -> Unit)? = null

    private const val NUDGE_MESSAGE = "{\"t\":\"ourspace-nudge\"}"

    fun getOrCreate(context: Context): WebRtcPeerManager {
        managerRef.get()?.let { return it }
        synchronized(this) {
            managerRef.get()?.let { return it }
            val mgr = WebRtcPeerManager(context.applicationContext)
            mgr.addListener(object : WebRtcPeerManager.Listener {
                override fun onStateChanged(state: WebRtcPeerManager.State) {}
                override fun onError(message: String) {}
                override fun onMessage(text: String) {
                    handleInboundFrame(text)
                }
            })
            managerRef.set(mgr)
            return mgr
        }
    }

    private fun handleInboundFrame(text: String) {
        when {
            text.contains("ourspace-nudge") -> nudgeListener?.invoke()
            text.contains("ourspace-typing") -> {
                val frame = runCatching { JSONObject(text) }.getOrNull() ?: return
                val on = frame.optBoolean("on", false)
                val sentAt = frame.optLong("sentAt", System.currentTimeMillis())
                receiveTyping(on, sentAt)
            }
            else -> {
                val json = runCatching { JSONObject(text) }.getOrNull() ?: return
                val type = json.optString("type")
                if (type == "incremental_exchange" || type == "incremental_exchange_result") {
                    deltaListener?.invoke(json)
                }
                val processorLocal = hostProcessor ?: return
                if (!type.endsWith("exchange") || type == "incremental_exchange_result") return
                // Formal host exchange (non-delta push) still answered by host processor.
                if (json.has("delta") && type == "incremental_exchange") return
                scope.launch {
                    val mgr = managerRef.get() ?: return@launch
                    try {
                        val response = processorLocal.processMessage(json)
                        mgr.send(response.toString())
                    } catch (error: Exception) {
                        runCatching {
                            val err = JSONObject()
                                .put("error", true)
                                .put("message", error.message ?: "پردازش همگام‌سازی روی میزبان ناموفق بود.")
                            mgr.send(err.toString())
                        }
                    }
                }
            }
        }
    }

    fun setNudgeListener(listener: (() -> Unit)?) {
        nudgeListener = listener
    }

    fun setTypingListener(listener: ((Boolean, Long) -> Unit)?) {
        typingListener = listener
    }

    /** Deliver an ephemeral typing signal received through either WebRTC or the relay. */
    fun receiveTyping(isTyping: Boolean, sentAt: Long) {
        typingListener?.invoke(isTyping, sentAt)
    }

    fun setDeltaListener(listener: ((JSONObject) -> Unit)?) {
        deltaListener = listener
    }

    fun sendNudge() {
        val mgr = managerRef.get() ?: return
        if (!mgr.isOpen()) return
        scope.launch { runCatching { mgr.send(NUDGE_MESSAGE) } }
    }

    fun sendTyping(isTyping: Boolean, sentAt: Long = System.currentTimeMillis()) {
        val mgr = managerRef.get() ?: return
        if (!mgr.isOpen()) return
        val payload = JSONObject()
            .put("t", "ourspace-typing")
            .put("on", isTyping)
            .put("sentAt", sentAt)
            .toString()
        scope.launch { runCatching { mgr.send(payload) } }
    }

    /**
     * Fast-path: push the same incremental envelope that would go to the relay.
     * Returns false if the DataChannel is not open (caller should rely on relay only).
     */
    suspend fun sendRealtimeDelta(envelope: JSONObject): Boolean {
        val mgr = managerRef.get() ?: return false
        if (!mgr.isOpen()) return false
        // Return success only after DataChannel.send accepted the payload. The old
        // fire-and-forget implementation returned true before the coroutine ran, so
        // callers could log a false positive when the channel closed or send failed.
        return runCatching {
            mgr.send(envelope.toString())
            true
        }.getOrElse { error ->
            ConnectionDiagnostics.log("WebRTC ارسال فوری ناموفق بود؛ مسیر Relay ادامه می‌یابد: ${error.message ?: error.javaClass.simpleName}")
            false
        }
    }

    fun current(): WebRtcPeerManager? = managerRef.get()

    fun isOpen(): Boolean = managerRef.get()?.isOpen() == true

    fun attachHostProcessor(context: Context, processor: HostSyncExchangeProcessor) {
        hostProcessor = processor
        getOrCreate(context)
    }

    fun close() {
        managerRef.getAndSet(null)?.close()
        hostProcessor = null
        typingListener = null
        deltaListener = null
    }
}
