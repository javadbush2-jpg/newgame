package com.ourspace.app.feature.finance

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.outlined.DateRange
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.AccountBalanceWallet
import androidx.compose.material.icons.outlined.PieChart
import androidx.compose.material.icons.outlined.ReceiptLong
import androidx.compose.material.icons.outlined.Repeat
import androidx.compose.material.icons.outlined.SwapHoriz
import androidx.compose.material.icons.outlined.Star
import androidx.compose.material3.AlertDialog
import com.ourspace.app.ui.design.OSConfirmDialog
import com.ourspace.app.ui.design.OSFormDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.ourspace.app.core.database.FinanceBudgetEntity
import com.ourspace.app.core.database.FinanceTransactionEntity
import com.ourspace.app.core.finance.FinanceCalculator
import com.ourspace.app.core.database.FinancialAccountEntity
import com.ourspace.app.core.database.RecurringTransactionEntity
import com.ourspace.app.core.database.SharedDebtEntity
import com.ourspace.app.core.time.PersianDateFormatter
import com.ourspace.app.ui.components.FloatingMotion
import com.ourspace.app.ui.components.PersianDatePickerDialog
import com.ourspace.app.ui.components.MotionCard

private val expenseCategories = listOf("خوراک", "خانه", "رفت‌وآمد", "تفریح", "سلامت", "هدیه", "سایر")
private val incomeCategories = listOf("حقوق", "پاداش", "فروش", "هدیه", "سایر")

@Composable
fun FinanceScreen(
    ownDeviceId: String,
    accounts: List<FinancialAccountEntity>,
    transactions: List<FinanceTransactionEntity>,
    budgets: List<FinanceBudgetEntity>,
    debts: List<SharedDebtEntity>,
    recurringTransactions: List<RecurringTransactionEntity>,
    onAddAccount: (String, String, Long, Int) -> Unit,
    onCorrectAccountBalance: (FinancialAccountEntity, Long) -> Unit,
    onAddTransaction: (String, String?, String, Long, String, String) -> Unit,
    onDeleteTransaction: (FinanceTransactionEntity) -> Unit,
    onSetBudget: (String, String, Long) -> Unit,
    onAddDebt: (String, Long, String, String, Long?) -> Unit,
    onToggleDebtSettled: (SharedDebtEntity) -> Unit,
    onDeleteDebt: (SharedDebtEntity) -> Unit,
    onShareDebtToChat: (SharedDebtEntity) -> Unit = {},
    onAddRecurring: (String, String?, String, Long, String, String, String, Long) -> Unit,
    onToggleRecurring: (RecurringTransactionEntity) -> Unit,
    onDeleteRecurring: (RecurringTransactionEntity) -> Unit
) {
    val haptics = LocalHapticFeedback.current
    val currentPeriod = PersianDateFormatter.currentJalaliMonthKey()
    val totalBalance = remember(accounts, transactions) {
        FinanceCalculator.totalBalance(accounts, transactions)
    }
    val periodTotals = remember(transactions, currentPeriod) {
        FinanceCalculator.periodTotals(transactions, currentPeriod)
    }
    val monthIncome = periodTotals.income
    val monthExpense = periodTotals.expense
    val openDebts = debts.filter { it.settledAt == null }
    val owedToMe = openDebts.filter { it.creditorDeviceId == ownDeviceId }.sumOf { it.amount }
    val iOwe = openDebts.filter { it.debtorDeviceId == ownDeviceId }.sumOf { it.amount }
    var showAccountDialog by remember { mutableStateOf(false) }
    var showTransactionDialog by remember { mutableStateOf(false) }
    var showBudgetDialog by remember { mutableStateOf(false) }
    var showDebtDialog by remember { mutableStateOf(false) }
    var showRecurringDialog by remember { mutableStateOf(false) }

    Box(Modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 96.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                FinanceHero(
                    totalBalance = totalBalance,
                    income = monthIncome,
                    expense = monthExpense
                )
            }
            item {
                FinanceFlowChart(transactions = transactions)
            }
            item {
                CategoryBreakdownCard(transactions = transactions, periodKey = currentPeriod)
            }
            item {
                BudgetAlertBanner(
                    budgets = budgets.filter { it.periodKey == currentPeriod },
                    transactions = transactions,
                    periodKey = currentPeriod
                )
            }
            item {
                QuickFinanceActions(
                    onAccount = {
                        haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                        showAccountDialog = true
                    },
                    onTransaction = {
                        haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                        if (accounts.isEmpty()) showAccountDialog = true else showTransactionDialog = true
                    },
                    onBudget = {
                        haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                        showBudgetDialog = true
                    },
                    onDebt = {
                        haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                        showDebtDialog = true
                    },
                    onRecurring = {
                        haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                        if (accounts.isEmpty()) showAccountDialog = true else showRecurringDialog = true
                    }
                )
            }
            item {
                SectionHeader("حساب‌های مشترک", "${PersianDateFormatter.toPersianDigits(accounts.size)} حساب")
            }
            if (accounts.isEmpty()) {
                item { EmptyAccounts(onClick = { showAccountDialog = true }) }
            } else {
                item {
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        items(accounts, key = { it.id }) { account ->
                            val accountBalance = FinanceCalculator.accountBalance(account, transactions)
                            AccountCard(
                                account = account,
                                balance = accountBalance,
                                onCorrectBalance = { target -> onCorrectAccountBalance(account, target) }
                            )
                        }
                    }
                }
            }
            item {
                SectionHeader(
                    "حساب دونفره",
                    if (openDebts.isEmpty()) "بدهی بازی ندارید"
                    else "طلب من ${PersianDateFormatter.formatMoney(owedToMe)} • بدهی من ${PersianDateFormatter.formatMoney(iOwe)}"
                )
            }
            if (debts.isEmpty()) {
                item { EmptyFinanceFeature("هنوز بدهی دونفره‌ای ثبت نشده است.", "ثبت بدهی", onClick = { showDebtDialog = true }) }
            } else {
                items(debts.take(30), key = { "debt-${it.id}" }) { debt ->
                    DebtCard(
                        debt = debt,
                        ownDeviceId = ownDeviceId,
                        onToggleSettled = { onToggleDebtSettled(debt) },
                        onDelete = { onDeleteDebt(debt) },
                        onShare = { onShareDebtToChat(debt) }
                    )
                }
            }
            item {
                SectionHeader("تراکنش‌های تکرارشونده", if (recurringTransactions.isEmpty()) "پرداخت خودکار ثبت نشده" else "زمان‌بندی بر پایه تقویم شمسی")
            }
            if (recurringTransactions.isEmpty()) {
                item {
                    EmptyFinanceFeature(
                        "حقوق، اجاره یا هزینه‌های ثابت را زمان‌بندی کنید.",
                        "زمان‌بندی جدید",
                        onClick = { if (accounts.isEmpty()) showAccountDialog = true else showRecurringDialog = true }
                    )
                }
            } else {
                items(recurringTransactions.take(30), key = { "recurring-${it.id}" }) { rule ->
                    RecurringCard(
                        rule = rule,
                        accountName = accounts.firstOrNull { it.id == rule.accountId }?.name ?: "حساب حذف‌شده",
                        onToggle = { onToggleRecurring(rule) },
                        onDelete = { onDeleteRecurring(rule) }
                    )
                }
            }
            item {
                SectionHeader("بودجه این ماه", PersianDateFormatter.currentJalaliMonthLabel())
            }
            if (budgets.none { it.periodKey == currentPeriod }) {
                item { EmptyBudget(onClick = { showBudgetDialog = true }) }
            } else {
                items(budgets.filter { it.periodKey == currentPeriod }, key = { it.id }) { budget ->
                    val spent = FinanceCalculator.categoryExpense(transactions, currentPeriod, budget.category)
                    BudgetCard(budget, spent)
                }
            }
            item {
                SectionHeader("تراکنش‌های اخیر", if (transactions.isEmpty()) "بدون تراکنش" else "آخرین تغییرات")
            }
            if (transactions.isEmpty()) {
                item { EmptyTransactions(onClick = { if (accounts.isEmpty()) showAccountDialog = true else showTransactionDialog = true }) }
            } else {
                items(transactions.take(100), key = { it.id }) { transaction ->
                    TransactionCard(
                        transaction = transaction,
                        accountName = accounts.firstOrNull { it.id == transaction.accountId }?.name ?: "حساب حذف‌شده",
                        targetAccountName = transaction.targetAccountId?.let { targetId ->
                            accounts.firstOrNull { it.id == targetId }?.name
                        },
                        onDelete = { onDeleteTransaction(transaction) }
                    )
                }
            }
        }
        AnimatedVisibility(
            visible = accounts.isNotEmpty(),
            modifier = Modifier.align(Alignment.BottomStart).padding(20.dp),
            enter = scaleIn() + fadeIn(),
            exit = fadeOut()
        ) {
            FloatingActionButton(
                onClick = {
                    haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                    showTransactionDialog = true
                },
                containerColor = MaterialTheme.colorScheme.primary,
                shape = RoundedCornerShape(22.dp)
            ) { Icon(Icons.Default.Add, "تراکنش جدید", tint = MaterialTheme.colorScheme.onPrimary) }
        }
    }

    if (showAccountDialog) {
        AddAccountDialog(
            onDismiss = { showAccountDialog = false },
            onSave = { name, type, opening, color ->
                onAddAccount(name, type, opening, color)
                showAccountDialog = false
            }
        )
    }
    if (showTransactionDialog && accounts.isNotEmpty()) {
        AddTransactionDialog(
            accounts = accounts,
            onDismiss = { showTransactionDialog = false },
            onSave = { accountId, targetAccountId, kind, amount, category, note ->
                onAddTransaction(accountId, targetAccountId, kind, amount, category, note)
                showTransactionDialog = false
            }
        )
    }
    if (showBudgetDialog) {
        AddBudgetDialog(
            periodKey = currentPeriod,
            onDismiss = { showBudgetDialog = false },
            onSave = { category, amount ->
                onSetBudget(category, currentPeriod, amount)
                showBudgetDialog = false
            }
        )
    }
    if (showDebtDialog) {
        AddDebtDialog(
            onDismiss = { showDebtDialog = false },
            onSave = { title, amount, direction, note, dueAt ->
                onAddDebt(title, amount, direction, note, dueAt)
                showDebtDialog = false
            }
        )
    }
    if (showRecurringDialog && accounts.isNotEmpty()) {
        AddRecurringDialog(
            accounts = accounts,
            onDismiss = { showRecurringDialog = false },
            onSave = { accountId, targetId, kind, amount, category, note, interval, firstRunAt ->
                onAddRecurring(accountId, targetId, kind, amount, category, note, interval, firstRunAt)
                showRecurringDialog = false
            }
        )
    }
}

@Composable
private fun FinanceHero(totalBalance: Long, income: Long, expense: Long) {
    val dark = MaterialTheme.colorScheme.background.luminance() < 0.5f
    val gradient = Brush.linearGradient(
        if (dark) listOf(MaterialTheme.colorScheme.primaryContainer, MaterialTheme.colorScheme.tertiaryContainer)
        else listOf(MaterialTheme.colorScheme.primary, MaterialTheme.colorScheme.tertiary)
    )
    Box(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(32.dp)).background(gradient).padding(22.dp)
    ) {
        Box(
            Modifier.size(140.dp).align(Alignment.TopStart).background(Color.White.copy(alpha = .08f), CircleShape)
        )
        Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("دارایی مشترک", color = if (dark) MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = .90f) else Color.White.copy(alpha = .88f), style = MaterialTheme.typography.labelLarge)
                    AnimatedContent(
                        targetState = totalBalance,
                        transitionSpec = { (fadeIn() + scaleIn(initialScale = .92f)).togetherWith(fadeOut()) },
                        label = "balance"
                    ) { balance ->
                        Text(
                            PersianDateFormatter.formatMoney(balance),
                            color = if (dark) MaterialTheme.colorScheme.onPrimaryContainer else Color.White,
                            style = MaterialTheme.typography.headlineMedium,
                            fontWeight = FontWeight.Black,
                            modifier = Modifier.padding(top = 3.dp)
                        )
                    }
                }
                FloatingMotion {
                    Box(
                        Modifier.size(52.dp).background(Color.White.copy(alpha = .16f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) { Text("✦", color = if (dark) MaterialTheme.colorScheme.onPrimaryContainer else Color.White, style = MaterialTheme.typography.headlineSmall) }
                }
            }
            Row(Modifier.padding(top = 24.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                FinanceMetric("درآمد ماه", income, Color(0xFFB9F6CA), Modifier.weight(1f))
                FinanceMetric("هزینه ماه", expense, Color(0xFFFFCDD2), Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun FinanceMetric(title: String, amount: Long, accent: Color, modifier: Modifier) {
    Column(
        modifier.background(Color.Black.copy(alpha = .12f), RoundedCornerShape(18.dp)).padding(12.dp)
    ) {
        Text(title, color = if (MaterialTheme.colorScheme.background.luminance() < 0.5f) MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = .88f) else Color.White.copy(alpha = .80f), style = MaterialTheme.typography.labelSmall)
        Text(PersianDateFormatter.formatMoney(amount), color = if (MaterialTheme.colorScheme.background.luminance() < 0.5f) accent.copy(alpha = .98f) else accent, fontWeight = FontWeight.Bold, maxLines = 1)
    }
}

@Composable
private fun QuickFinanceActions(
    onAccount: () -> Unit,
    onTransaction: () -> Unit,
    onBudget: () -> Unit,
    onDebt: () -> Unit,
    onRecurring: () -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("دسترسی سریع", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            FinanceQuickAction("حساب", Icons.Outlined.AccountBalanceWallet, Modifier.weight(1f), onAccount)
            FinanceQuickAction("تراکنش", Icons.Outlined.ReceiptLong, Modifier.weight(1f), onTransaction)
            FinanceQuickAction("بودجه", Icons.Outlined.PieChart, Modifier.weight(1f), onBudget)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            FinanceQuickAction("بدهی دونفره", Icons.Outlined.SwapHoriz, Modifier.weight(1f), onDebt)
            FinanceQuickAction("تکرارشونده", Icons.Outlined.Repeat, Modifier.weight(1f), onRecurring)
            Spacer(Modifier.weight(1f))
        }
    }
}

@Composable
private fun FinanceQuickAction(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    modifier: Modifier,
    onClick: () -> Unit
) {
    Card(
        modifier = modifier.clickable(onClick = onClick),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow)
    ) {
        Column(
            Modifier.fillMaxWidth().padding(vertical = 14.dp, horizontal = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(7.dp)
        ) {
            Box(
                Modifier.size(42.dp).background(MaterialTheme.colorScheme.primaryContainer, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = title, tint = MaterialTheme.colorScheme.primary)
            }
            Text(title, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
private fun SectionHeader(title: String, caption: String) {
    Row(Modifier.fillMaxWidth().padding(top = 6.dp), verticalAlignment = Alignment.Bottom) {
        Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Black, modifier = Modifier.weight(1f))
        Text(caption, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
    }
}

@Composable
private fun AccountCard(
    account: FinancialAccountEntity,
    balance: Long,
    onCorrectBalance: (Long) -> Unit
) {
    val colors = listOf(
        Color(0xFF7B3F68), Color(0xFF006D77), Color(0xFF386A20),
        Color(0xFF9B4424), Color(0xFF4D5FAD), Color(0xFF6B5778)
    )
    val color = colors[account.colorSeed.coerceIn(colors.indices)]
    var showCorrectionDialog by remember(account.id) { mutableStateOf(false) }
    Card(
        modifier = Modifier.width(230.dp),
        shape = RoundedCornerShape(25.dp),
        colors = CardDefaults.cardColors(containerColor = color)
    ) {
        Column(Modifier.padding(18.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(38.dp).background(Color.White.copy(alpha = .16f), CircleShape), contentAlignment = Alignment.Center) {
                    Text(if (account.type == "CARD") "▣" else if (account.type == "SAVINGS") "◇" else "●", color = Color.White)
                }
                Text(account.name, color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 10.dp).weight(1f), maxLines = 1)
                IconButton(onClick = { showCorrectionDialog = true }) {
                    Icon(Icons.Outlined.Edit, contentDescription = "اصلاح موجودی", tint = Color.White)
                }
            }
            Text("موجودی", color = Color.White.copy(alpha = .7f), style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(top = 20.dp))
            Text(PersianDateFormatter.formatMoney(balance), color = Color.White, fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleLarge)
        }
    }
    if (showCorrectionDialog) {
        CorrectAccountBalanceDialog(
            accountName = account.name,
            currentBalance = balance,
            onDismiss = { showCorrectionDialog = false },
            onSave = onCorrectBalance
        )
    }

}

@Composable
private fun CorrectAccountBalanceDialog(
    accountName: String,
    currentBalance: Long,
    onDismiss: () -> Unit,
    onSave: (Long) -> Unit
) {
    var amount by remember(currentBalance) { mutableStateOf(currentBalance.toString()) }
    OSFormDialog(
        title = "اصلاح موجودی حساب",
        subtitle = "موجودی واقعی «$accountName» را وارد کنید. این اصلاح تراکنش جدید ایجاد نمی‌کند و فقط مانده حساب را با موجودی واقعی هماهنگ می‌کند.",
        emoji = "💰",
        onDismiss = onDismiss,
        onConfirm = { onSave(parseAmount(amount)); onDismiss() },
        confirmLabel = "ثبت اصلاح",
        confirmEnabled = amount.isNotBlank()
    ) {
        OutlinedTextField(
            value = amount,
            onValueChange = { amount = sanitizeAmountInput(it).take(18) },
            label = { Text("موجودی واقعی به تومان") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
        )
    }
}

@Composable
private fun BudgetCard(budget: FinanceBudgetEntity, spent: Long) {
    val progress = (spent.toFloat() / budget.monthlyLimit.coerceAtLeast(1)).coerceIn(0f, 1f)
    val animatedProgress by animateFloatAsState(progress, label = "budget-progress")
    Card(
        Modifier.fillMaxWidth().animateContentSize(),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow)
    ) {
        Column(Modifier.padding(17.dp)) {
            Row {
                Text(categoryEmoji(budget.category), modifier = Modifier.padding(end = 8.dp))
                Text(budget.category, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                Text(
                    "${PersianDateFormatter.formatMoney(spent)} از ${PersianDateFormatter.formatMoney(budget.monthlyLimit)}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            LinearProgressIndicator(
                progress = { animatedProgress },
                modifier = Modifier.fillMaxWidth().padding(top = 12.dp).height(8.dp).clip(CircleShape),
                color = if (progress >= .9f) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary,
                trackColor = MaterialTheme.colorScheme.surface
            )
        }
    }
}

@Composable
private fun TransactionCard(
    transaction: FinanceTransactionEntity,
    accountName: String,
    targetAccountName: String?,
    onDelete: () -> Unit
) {
    val isIncome = transaction.kind == "INCOME"
    val isTransfer = transaction.kind == "TRANSFER"
    Card(
        Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = .95f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(48.dp).background(
                    when {
                        isTransfer -> MaterialTheme.colorScheme.primaryContainer
                        isIncome -> Color(0xFFD8F5DF)
                        else -> MaterialTheme.colorScheme.errorContainer
                    },
                    RoundedCornerShape(18.dp)
                ),
                contentAlignment = Alignment.Center
            ) { Text(categoryEmoji(transaction.category), style = MaterialTheme.typography.titleLarge) }
            Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                Text(transaction.category, fontWeight = FontWeight.Bold)
                Text(
                    listOf(
                        if (isTransfer) "از $accountName به ${targetAccountName ?: "حساب مقصد"}" else accountName,
                        transaction.note
                    ).filter { it.isNotBlank() }.joinToString(" • "),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(PersianDateFormatter.formatDateTime(transaction.occurredAt), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline)
            }
            Column(horizontalAlignment = Alignment.End) {
                Text(
                    (when {
                        isTransfer -> "↔ "
                        isIncome -> "+"
                        else -> "−"
                    }) + PersianDateFormatter.formatMoney(transaction.amount),
                    color = when {
                        isTransfer -> MaterialTheme.colorScheme.primary
                        isIncome -> Color(0xFF237A3B)
                        else -> MaterialTheme.colorScheme.error
                    },
                    fontWeight = FontWeight.Black
                )
                IconButton(onClick = onDelete, modifier = Modifier.size(30.dp)) {
                    Icon(Icons.Outlined.Delete, "حذف تراکنش", modifier = Modifier.size(17.dp), tint = MaterialTheme.colorScheme.outline)
                }
            }
        }
    }
}

@Composable
private fun EmptyAccounts(onClick: () -> Unit) = EmptyFinanceCard(
    title = "اولین حساب را بسازید",
    body = "کارت بانکی، پول نقد یا پس‌انداز مشترک را اضافه کنید.",
    action = "افزودن حساب",
    onClick = onClick
)

@Composable
private fun EmptyBudget(onClick: () -> Unit) = EmptyFinanceCard(
    title = "بودجه‌ای برای این ماه ندارید",
    body = "برای هر دسته سقف مشخص کنید تا روند هزینه‌ها دیده شود.",
    action = "تنظیم بودجه",
    onClick = onClick
)

@Composable
private fun EmptyTransactions(onClick: () -> Unit) = EmptyFinanceCard(
    title = "هنوز تراکنشی ثبت نشده",
    body = "درآمد و هزینه‌های مشترک از اینجا قابل پیگیری هستند.",
    action = "ثبت اولین تراکنش",
    onClick = onClick
)

@Composable
private fun EmptyFinanceCard(title: String, body: String, action: String, onClick: () -> Unit) {
    Card(
        Modifier.fillMaxWidth().clickable(onClick = onClick),
        shape = RoundedCornerShape(26.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = .78f)
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(Modifier.padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(56.dp).background(
                    MaterialTheme.colorScheme.surface.copy(alpha = .85f),
                    CircleShape
                ),
                contentAlignment = Alignment.Center
            ) {
                Text("✦", style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.primary)
            }
            Column(Modifier.weight(1f).padding(horizontal = 14.dp)) {
                Text(title, fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleMedium)
                Text(
                    body,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }
            Text("‹", style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.primary)
        }
    }
}

@Composable
private fun EmptyFinanceFeature(body: String, action: String, onClick: () -> Unit) = EmptyFinanceCard(
    title = action,
    body = body,
    action = action,
    onClick = onClick
)

@Composable
private fun DebtCard(
    debt: SharedDebtEntity,
    ownDeviceId: String,
    onToggleSettled: () -> Unit,
    onDelete: () -> Unit,
    onShare: () -> Unit = {}
) {
    val isCreditor = debt.creditorDeviceId == ownDeviceId
    val settled = debt.settledAt != null
    Card(
        Modifier.fillMaxWidth().animateContentSize(),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (settled) MaterialTheme.colorScheme.surfaceVariant
            else MaterialTheme.colorScheme.secondaryContainer.copy(alpha = .68f)
        )
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(debt.title, fontWeight = FontWeight.Black)
                    Text(
                        if (settled) "تسویه‌شده" else if (isCreditor) "من طلبکارم" else "من بدهکارم",
                        color = if (settled) MaterialTheme.colorScheme.outline else MaterialTheme.colorScheme.primary,
                        style = MaterialTheme.typography.labelMedium
                    )
                }
                Text(PersianDateFormatter.formatMoney(debt.amount), fontWeight = FontWeight.Black)
                IconButton(onClick = onShare, modifier = Modifier.size(34.dp)) {
                    Icon(Icons.Outlined.Share, "اشتراک در چت", modifier = Modifier.size(18.dp))
                }
                IconButton(onClick = onDelete, modifier = Modifier.size(34.dp)) {
                    Icon(Icons.Outlined.Delete, "حذف بدهی", modifier = Modifier.size(18.dp))
                }
            }
            if (debt.note.isNotBlank()) Text(debt.note, style = MaterialTheme.typography.bodySmall)
            debt.dueAt?.let {
                Text("سررسید: ${PersianDateFormatter.formatDate(it)}", style = MaterialTheme.typography.labelSmall)
            }
            OutlinedButton(onClick = onToggleSettled, modifier = Modifier.fillMaxWidth()) {
                Text(if (settled) "بازگرداندن به بدهی باز" else "علامت‌گذاری به‌عنوان تسویه‌شده")
            }
        }
    }
}

@Composable
private fun RecurringCard(
    rule: RecurringTransactionEntity,
    accountName: String,
    onToggle: () -> Unit,
    onDelete: () -> Unit
) {
    val intervalLabel = when (rule.interval) {
        "WEEKLY" -> "هفتگی"
        "YEARLY" -> "سالانه"
        else -> "ماهانه شمسی"
    }
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(24.dp)) {
        Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(44.dp).background(MaterialTheme.colorScheme.primaryContainer, CircleShape),
                contentAlignment = Alignment.Center
            ) { Text("↻", style = MaterialTheme.typography.titleLarge) }
            Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                Text("${rule.category} • $accountName", fontWeight = FontWeight.Bold)
                Text(
                    "$intervalLabel • اجرای بعدی ${PersianDateFormatter.formatDate(rule.nextRunAt)}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(PersianDateFormatter.formatMoney(rule.amount), color = MaterialTheme.colorScheme.primary)
            }
            TextButton(onClick = onToggle) { Text(if (rule.isActive) "توقف" else "فعال‌سازی") }
            IconButton(onClick = onDelete, modifier = Modifier.size(34.dp)) {
                Icon(Icons.Outlined.Delete, "حذف زمان‌بندی", modifier = Modifier.size(18.dp))
            }
        }
    }
}

@Composable
private fun AddDebtDialog(
    onDismiss: () -> Unit,
    onSave: (String, Long, String, String, Long?) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    var direction by remember { mutableStateOf("OWED_TO_ME") }
    var note by remember { mutableStateOf("") }
    var dueAt by remember { mutableStateOf<Long?>(null) }
    var showDatePicker by remember { mutableStateOf(false) }
    OSFormDialog(
        title = "بدهی دونفره جدید",
        emoji = "🤝",
        onDismiss = onDismiss,
        onConfirm = { onSave(title, parseAmount(amount), direction, note, dueAt) },
        confirmLabel = "ثبت بدهی",
        confirmEnabled = title.isNotBlank() && parseAmount(amount) > 0
    ) {
        Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            FilterChip(direction == "OWED_TO_ME", { direction = "OWED_TO_ME" }, label = { Text("من طلبکارم") })
            FilterChip(direction == "I_OWE", { direction = "I_OWE" }, label = { Text("من بدهکارم") })
        }
        OutlinedTextField(title, { title = it.take(200) }, label = { Text("عنوان") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(
            amount,
            { amount = sanitizeAmountInput(it) },
            label = { Text("مبلغ به تومان") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(note, { note = it.take(1_000) }, label = { Text("یادداشت اختیاری") }, modifier = Modifier.fillMaxWidth())
        OutlinedButton(onClick = { showDatePicker = true }, modifier = Modifier.fillMaxWidth()) {
            Text(dueAt?.let { "سررسید: ${PersianDateFormatter.formatDate(it)}" } ?: "انتخاب سررسید اختیاری")
        }
        if (dueAt != null) TextButton(onClick = { dueAt = null }) { Text("حذف سررسید") }
    }
    if (showDatePicker) {
        PersianDatePickerDialog(
            title = "انتخاب سررسید شمسی",
            initialEpochMillis = dueAt ?: System.currentTimeMillis(),
            onDismiss = { showDatePicker = false },
            onConfirm = { dueAt = it; showDatePicker = false }
        )
    }
}

@Composable
private fun AddRecurringDialog(
    accounts: List<FinancialAccountEntity>,
    onDismiss: () -> Unit,
    onSave: (String, String?, String, Long, String, String, String, Long) -> Unit
) {
    var accountId by remember { mutableStateOf(accounts.first().id) }
    var kind by remember { mutableStateOf("EXPENSE") }
    var amount by remember { mutableStateOf("") }
    var category by remember { mutableStateOf(expenseCategories.first()) }
    var note by remember { mutableStateOf("") }
    var interval by remember { mutableStateOf("MONTHLY") }
    var firstRunAt by remember { mutableStateOf(System.currentTimeMillis()) }
    var showDatePicker by remember { mutableStateOf(false) }
    val categories = if (kind == "INCOME") incomeCategories else expenseCategories
    OSFormDialog(
        title = "تراکنش تکرارشونده",
        emoji = "🔄",
        onDismiss = onDismiss,
        onConfirm = { onSave(accountId, null, kind, parseAmount(amount), category, note, interval, firstRunAt) },
        confirmLabel = "ذخیره زمان‌بندی",
        confirmEnabled = parseAmount(amount) > 0
    ) {
LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth().heightIn(max = 420.dp)) {
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                        FilterChip(kind == "EXPENSE", { kind = "EXPENSE"; category = expenseCategories.first() }, label = { Text("هزینه") })
                        FilterChip(kind == "INCOME", { kind = "INCOME"; category = incomeCategories.first() }, label = { Text("درآمد") })
                    }
                }
                item {
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(accounts, key = { it.id }) { account ->
                            FilterChip(accountId == account.id, { accountId = account.id }, label = { Text(account.name) })
                        }
                    }
                }
                item {
                    OutlinedTextField(
                        amount,
                        { amount = sanitizeAmountInput(it) },
                        label = { Text("مبلغ به تومان") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                item {
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(categories) { item ->
                            FilterChip(category == item, { category = item }, label = { Text(item) })
                        }
                    }
                }
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("WEEKLY" to "هفتگی", "MONTHLY" to "ماهانه", "YEARLY" to "سالانه").forEach { option ->
                            FilterChip(interval == option.first, { interval = option.first }, label = { Text(option.second) })
                        }
                    }
                }
                item {
                    OutlinedButton(onClick = { showDatePicker = true }, modifier = Modifier.fillMaxWidth()) {
                        Text("اولین اجرا: ${PersianDateFormatter.formatDate(firstRunAt)}")
                    }
                }
                item { OutlinedTextField(note, { note = it.take(1_000) }, label = { Text("یادداشت اختیاری") }, modifier = Modifier.fillMaxWidth()) }
            }
    }
    if (showDatePicker) {
        PersianDatePickerDialog(
            title = "اولین اجرای تراکنش",
            initialEpochMillis = firstRunAt,
            onDismiss = { showDatePicker = false },
            onConfirm = { firstRunAt = it; showDatePicker = false }
        )
    }
}

@Composable
private fun AddAccountDialog(onDismiss: () -> Unit, onSave: (String, String, Long, Int) -> Unit) {
    var name by remember { mutableStateOf("") }
    var opening by remember { mutableStateOf("") }
    var type by remember { mutableStateOf("CARD") }
    var color by remember { mutableStateOf(0) }
    OSFormDialog(
        title = "حساب جدید",
        emoji = "🏦",
        onDismiss = onDismiss,
        onConfirm = { onSave(name.trim(), type, parseAmount(opening), color) },
        confirmLabel = "ساخت حساب",
        confirmEnabled = name.isNotBlank()
    ) {
OutlinedTextField(name, { name = it.take(120) }, label = { Text("نام حساب") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                OutlinedTextField(
                    opening,
                    { opening = sanitizeAmountInput(it) },
                    label = { Text("موجودی اولیه به تومان") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                )
                Text("نوع حساب", style = MaterialTheme.typography.labelLarge)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("CARD" to "کارت", "CASH" to "نقدی", "SAVINGS" to "پس‌انداز").forEach { item ->
                        FilterChip(selected = type == item.first, onClick = { type = item.first }, label = { Text(item.second) })
                    }
                }
                Text("رنگ کارت", style = MaterialTheme.typography.labelLarge)
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    listOf(0xFF7B3F68, 0xFF006D77, 0xFF386A20, 0xFF9B4424, 0xFF4D5FAD, 0xFF6B5778).forEachIndexed { index, value ->
                        Box(
                            Modifier.size(if (color == index) 34.dp else 30.dp)
                                .background(Color(value), CircleShape)
                                .clickable { color = index }
                        )
                    }
                }
    }
}

@Composable
private fun AddTransactionDialog(
    accounts: List<FinancialAccountEntity>,
    onDismiss: () -> Unit,
    onSave: (String, String?, String, Long, String, String) -> Unit
) {
    var selectedAccount by remember { mutableStateOf(accounts.first().id) }
    var selectedTarget by remember { mutableStateOf(accounts.getOrNull(1)?.id) }
    var kind by remember { mutableStateOf("EXPENSE") }
    var amount by remember { mutableStateOf("") }
    var category by remember { mutableStateOf(expenseCategories.first()) }
    var note by remember { mutableStateOf("") }
    val categories = when (kind) {
        "INCOME" -> incomeCategories
        "TRANSFER" -> listOf("انتقال")
        else -> expenseCategories
    }
    OSFormDialog(
        title = "تراکنش جدید",
        emoji = "💳",
        onDismiss = onDismiss,
        onConfirm = { onSave(selectedAccount, selectedTarget, kind, parseAmount(amount), category, note) },
        confirmLabel = "ثبت تراکنش",
        confirmEnabled = parseAmount(amount) > 0 && (kind != "TRANSFER" || selectedTarget != null)
    ) {
LazyColumn(verticalArrangement = Arrangement.spacedBy(11.dp), modifier = Modifier.widthIn(max = 520.dp)) {
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(
                            selected = kind == "EXPENSE",
                            onClick = { kind = "EXPENSE"; category = expenseCategories.first() },
                            label = { Text("هزینه") }
                        )
                        FilterChip(
                            selected = kind == "INCOME",
                            onClick = { kind = "INCOME"; category = incomeCategories.first() },
                            label = { Text("درآمد") }
                        )
                        FilterChip(
                            selected = kind == "TRANSFER",
                            enabled = accounts.size > 1,
                            onClick = {
                                kind = "TRANSFER"
                                category = "انتقال"
                                selectedTarget = accounts.firstOrNull { it.id != selectedAccount }?.id
                            },
                            label = { Text("انتقال") }
                        )
                    }
                }
                item {
                    OutlinedTextField(
                        amount,
                        { amount = sanitizeAmountInput(it) },
                        label = { Text("مبلغ به تومان") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                    )
                }
                item { Text("حساب", style = MaterialTheme.typography.labelLarge) }
                item {
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(accounts, key = { it.id }) { account ->
                            FilterChip(
                                selected = selectedAccount == account.id,
                                onClick = {
                                    selectedAccount = account.id
                                    if (selectedTarget == account.id) {
                                        selectedTarget = accounts.firstOrNull { it.id != account.id }?.id
                                    }
                                },
                                label = { Text(account.name) }
                            )
                        }
                    }
                }
                if (kind == "TRANSFER") {
                    item { Text("حساب مقصد", style = MaterialTheme.typography.labelLarge) }
                    item {
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            items(accounts.filter { it.id != selectedAccount }, key = { it.id }) { account ->
                                FilterChip(
                                    selected = selectedTarget == account.id,
                                    onClick = { selectedTarget = account.id },
                                    label = { Text(account.name) }
                                )
                            }
                        }
                    }
                }
                item { Text("دسته‌بندی", style = MaterialTheme.typography.labelLarge) }
                item {
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(categories) { item ->
                            FilterChip(selected = category == item, onClick = { category = item }, label = { Text("${categoryEmoji(item)} $item") })
                        }
                    }
                }
                item {
                    OutlinedTextField(note, { note = it.take(1_000) }, label = { Text("یادداشت اختیاری") }, modifier = Modifier.fillMaxWidth(), maxLines = 3)
                }
            }
    }
}

@Composable
private fun AddBudgetDialog(periodKey: String, onDismiss: () -> Unit, onSave: (String, Long) -> Unit) {
    var category by remember { mutableStateOf(expenseCategories.first()) }
    var amount by remember { mutableStateOf("") }
    OSFormDialog(
        title = "بودجه ${PersianDateFormatter.currentJalaliMonthLabel()}",
        emoji = "📊",
        onDismiss = onDismiss,
        onConfirm = { onSave(category, parseAmount(amount)) },
        confirmLabel = "ذخیره بودجه",
        confirmEnabled = parseAmount(amount) > 0
    ) {
Text("دسته‌بندی", style = MaterialTheme.typography.labelLarge)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(expenseCategories) { item ->
                        FilterChip(selected = category == item, onClick = { category = item }, label = { Text("${categoryEmoji(item)} $item") })
                    }
                }
                OutlinedTextField(
                    amount,
                    { amount = sanitizeAmountInput(it) },
                    label = { Text("سقف ماهانه به تومان") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                )
                Text("شناسه دوره: ${PersianDateFormatter.toPersianDigits(periodKey)}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline)
    }
}

private fun categoryEmoji(category: String): String = when (category) {
    "خوراک" -> "🍽️"
    "خانه" -> "🏠"
    "رفت‌وآمد" -> "🚕"
    "تفریح" -> "🎬"
    "سلامت" -> "💊"
    "هدیه" -> "🎁"
    "حقوق" -> "💼"
    "پاداش" -> "✨"
    "فروش" -> "🏷️"
    "انتقال" -> "↔️"
    else -> "◉"
}

private fun sanitizeAmountInput(value: String): String = value.mapNotNull { char ->
    when (char) {
        in '0'..'9' -> char
        in '۰'..'۹' -> ('0'.code + (char.code - '۰'.code)).toChar()
        else -> null
    }
}.joinToString("").take(15)

private fun parseAmount(value: String): Long = sanitizeAmountInput(value).toLongOrNull() ?: 0L


@Composable
private fun FinanceFlowChart(transactions: List<FinanceTransactionEntity>) {
    val months = remember(transactions) {
        val keys = mutableListOf<String>()
        repeat(6) { i ->
            val c = java.util.Calendar.getInstance()
            c.add(java.util.Calendar.MONTH, -(5 - i))
            keys += PersianDateFormatter.jalaliMonthKey(c.timeInMillis)
        }
        keys.distinct()
    }
    val flows = remember(transactions, months) {
        months.map { key ->
            val monthRows = transactions.filter { !it.isDeleted && PersianDateFormatter.jalaliMonthKey(it.occurredAt) == key }
            Triple(
                key,
                monthRows.filter { it.kind == "INCOME" }.sumOf { it.amount },
                monthRows.filter { it.kind == "EXPENSE" }.sumOf { it.amount }
            )
        }
    }
    val maxVal = flows.maxOfOrNull { maxOf(it.second, it.third) }?.coerceAtLeast(1L) ?: 1L
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("نمودار تراکنش‌ها", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                    Text("مقایسه درآمد و هزینه در ۶ ماه اخیر", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FinanceLegendDot("درآمد", MaterialTheme.colorScheme.primary)
                    FinanceLegendDot("هزینه", MaterialTheme.colorScheme.error)
                }
            }
            val primaryColor = MaterialTheme.colorScheme.primary
            val errorColor = MaterialTheme.colorScheme.error
            Canvas(Modifier.fillMaxWidth().height(170.dp).padding(top = 14.dp)) {
                val n = flows.size.coerceAtLeast(1)
                val groupGap = size.width * 0.055f
                val groupWidth = (size.width - groupGap * (n + 1)) / n
                val barGap = 4.dp.toPx()
                val barWidth = (groupWidth - barGap) / 2f
                flows.forEachIndexed { index, (_, income, expense) ->
                    val x = groupGap + index * (groupWidth + groupGap)
                    val incomeH = income.toFloat() / maxVal * size.height * .82f
                    val expenseH = expense.toFloat() / maxVal * size.height * .82f
                    drawRoundRect(
                        color = primaryColor,
                        topLeft = Offset(x, size.height - incomeH),
                        size = Size(barWidth, incomeH),
                        cornerRadius = androidx.compose.ui.geometry.CornerRadius(10f, 10f)
                    )
                    drawRoundRect(
                        color = errorColor,
                        topLeft = Offset(x + barWidth + barGap, size.height - expenseH),
                        size = Size(barWidth, expenseH),
                        cornerRadius = androidx.compose.ui.geometry.CornerRadius(10f, 10f)
                    )
                }
            }
            Row(Modifier.fillMaxWidth().padding(top = 6.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                flows.forEach { (key, _, _) ->
                    Text(key.takeLast(2).let { PersianDateFormatter.toPersianDigits(it.toIntOrNull() ?: 0) }, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}

@Composable
private fun FinanceLegendDot(label: String, color: Color) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        Box(Modifier.size(8.dp).background(color, CircleShape))
        Text(label, style = MaterialTheme.typography.labelSmall)
    }
}

@Composable
private fun CategoryBreakdownCard(
    transactions: List<FinanceTransactionEntity>,
    periodKey: String
) {
    val rows = remember(transactions, periodKey) {
        transactions
            .filter { it.kind == "EXPENSE" && PersianDateFormatter.jalaliMonthKey(it.occurredAt) == periodKey }
            .groupBy { it.category.ifBlank { "سایر" } }
            .map { (cat, list) -> cat to list.sumOf { it.amount } }
            .sortedByDescending { it.second }
            .take(6)
    }
    if (rows.isEmpty()) return
    val max = rows.first().second.coerceAtLeast(1L)
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(Modifier.padding(16.dp)) {
            Text("هزینه بر اساس دسته (این ماه)", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
            rows.forEach { (cat, amount) ->
                Column(Modifier.fillMaxWidth().padding(top = 10.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(cat, style = MaterialTheme.typography.bodyMedium)
                        Text(PersianDateFormatter.formatMoney(amount), style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.SemiBold)
                    }
                    LinearProgressIndicator(
                        progress = { (amount.toFloat() / max.toFloat()).coerceIn(0.05f, 1f) },
                        modifier = Modifier.fillMaxWidth().padding(top = 4.dp).height(8.dp),
                    )
                }
            }
        }
    }
}

@Composable
private fun BudgetAlertBanner(
    budgets: List<FinanceBudgetEntity>,
    transactions: List<FinanceTransactionEntity>,
    periodKey: String
) {
    val alerts = remember(budgets, transactions, periodKey) {
        budgets.mapNotNull { budget ->
            val spent = transactions
                .filter {
                    it.kind == "EXPENSE" &&
                        it.category == budget.category &&
                        PersianDateFormatter.jalaliMonthKey(it.occurredAt) == periodKey &&
                        !it.isDeleted
                }
                .sumOf { it.amount }
            if (budget.monthlyLimit <= 0L) return@mapNotNull null
            val percent = ((spent * 100) / budget.monthlyLimit).toInt()
            if (percent >= 80) budget.category to percent else null
        }
    }
    if (alerts.isEmpty()) return
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer.copy(alpha = .7f))
    ) {
        Column(Modifier.padding(14.dp)) {
            Text("هشدار بودجه ماهانه", fontWeight = FontWeight.Bold)
            alerts.forEach { (cat, percent) ->
                Text(
                    "«$cat» به ${PersianDateFormatter.toPersianDigits(percent)}٪ سقف رسیده است.",
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }
        }
    }
}
