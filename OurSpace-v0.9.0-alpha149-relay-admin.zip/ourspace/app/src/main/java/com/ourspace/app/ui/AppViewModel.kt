package com.ourspace.app.ui

import android.app.Application
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import android.provider.OpenableColumns
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.ourspace.app.OurSpaceApplication
import com.ourspace.app.core.database.AttachmentEntity
import com.ourspace.app.core.database.CoupleProfileEntity
import com.ourspace.app.core.database.CycleLogEntity
import com.ourspace.app.core.database.LocationShareEntity
import com.ourspace.app.core.database.CycleSettingsEntity
import com.ourspace.app.core.database.EventEntity
import com.ourspace.app.core.database.HeartPulseEntity
import com.ourspace.app.core.database.SharedPlaceEntity
import com.ourspace.app.core.database.HabitEntity
import com.ourspace.app.core.database.WatchlistItemEntity
import com.ourspace.app.core.database.FinanceBudgetEntity
import com.ourspace.app.core.database.FinanceTransactionEntity
import com.ourspace.app.core.finance.FinanceCalculator
import com.ourspace.app.core.database.FinancialAccountEntity
import com.ourspace.app.core.database.RecurringTransactionEntity
import com.ourspace.app.core.database.SharedDebtEntity
import com.ourspace.app.core.database.MemoryEntity
import com.ourspace.app.core.database.MessageEntity
import com.ourspace.app.core.database.TelegramStickerEntity
import com.ourspace.app.core.database.TelegramStickerPackEntity
import com.ourspace.app.core.database.MoodCheckInEntity
import com.ourspace.app.core.database.ShoppingItemEntity
import com.ourspace.app.core.database.SpecialDateEntity
import com.ourspace.app.core.database.TaskEntity
import com.ourspace.app.core.pairing.PairingClient
import com.ourspace.app.core.pairing.PairingStore
import com.ourspace.app.core.preferences.AppPreferences
import com.ourspace.app.core.relay.RelayClient
import com.ourspace.app.core.relay.RelayConfig
import com.ourspace.app.core.relay.RelayCredentials
import com.ourspace.app.core.relay.RelayBackupClient
import com.ourspace.app.core.security.DeviceIdentityManager
import com.ourspace.app.core.location.LocationPublisher
import com.ourspace.app.core.notification.OurSpaceNotificationCenter
import com.ourspace.app.core.server.HostServerService
import com.ourspace.app.core.sync.CompanionSyncWorker
import com.ourspace.app.core.sync.SyncClient
import com.ourspace.app.core.sync.SyncSnapshotCodec
import com.ourspace.app.core.webrtc.ConnectionDiagnostics
import com.ourspace.app.core.webrtc.WebRtcSession
import com.ourspace.app.feature.chat.ChatShareCard
import com.ourspace.app.widget.OurSpaceWidgetProvider
import com.ourspace.app.widget.OurSpaceTasksWidgetProvider
import com.ourspace.app.widget.OurSpaceShoppingWidgetProvider
import com.ourspace.app.widget.OurSpaceCalendarWidgetProvider
import com.ourspace.app.model.DeviceRole
import com.ourspace.app.ui.theme.AppPalette
import com.ourspace.app.ui.theme.AppThemeMode
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.io.InputStream
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.filter
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext

class AppViewModel(application: Application) : AndroidViewModel(application) {
    data class UiState(
        val isLoading: Boolean = true,
        val role: DeviceRole? = null,
        val trustedHostPayload: String? = null,
        val deviceIdentity: DeviceIdentityManager.DeviceIdentity? = null
    )

    data class PairingActionState(
        val isLoading: Boolean = false,
        val message: String? = null,
        val error: String? = null,
        /** Companion shows this QR to the host (encrypted secret). */
        val replyQrPayload: String? = null,
        /** Host shows this QR after approve so companion can finish. */
        val approvalQrPayload: String? = null,
        /** 4-digit code generated on host for the companion to type. */
        val hostPin: String? = null
    )

    data class SyncState(
        val isSyncing: Boolean = false,
        val lastSyncAt: Long? = null,
        val message: String? = null,
        val error: String? = null,
        val transport: SyncClient.Transport? = null,
        val isRelayPending: Boolean = false
    )

    data class HeartActionState(
        val isSending: Boolean = false,
        val message: String? = null,
        val error: String? = null
    )

    data class LocationActionState(
        val isUpdating: Boolean = false,
        val message: String? = null,
        val error: String? = null
    )

    data class RelayActionState(
        val isSaving: Boolean = false,
        val message: String? = null,
        val error: String? = null
    )

    data class BackupActionState(
        val isBusy: Boolean = false,
        val message: String? = null,
        val error: String? = null
    )

    data class AttachmentActionState(
        val isLoading: Boolean = false,
        val message: String? = null,
        val error: String? = null
    )

    data class ChatActionState(
        val isSending: Boolean = false,
        val message: String? = null,
        val error: String? = null
    )

    data class StickerImportActionState(
        val isLoading: Boolean = false,
        val message: String? = null,
        val error: String? = null
    )

    private data class ImportedAttachment(
        val fileName: String,
        val mimeType: String,
        val content: ByteArray
    )

    private val app = application as OurSpaceApplication
    private val preferences = AppPreferences(application)
    private val notificationCenter = OurSpaceNotificationCenter(application)
    private val identityManager = DeviceIdentityManager()
    private val pairingStore = PairingStore(application)
    private val pairingClient = PairingClient(identityManager)
    private val identity = MutableStateFlow<DeviceIdentityManager.DeviceIdentity?>(null)
    private val typingLock = Any()
    private var localTypingActive = false
    private var lastLocalTypingSignalAt = 0L
    private var lastPeerTypingSignalAt = 0L
    private var peerTypingTimeoutJob: Job? = null
    private val repository by lazy { app.repository }
    private val syncMutex = Mutex()
    private var companionSyncLoop: Job? = null
    @Volatile
    private var lastNudgeSyncAt = 0L

    val pairingAction = MutableStateFlow(PairingActionState())
    val syncState = MutableStateFlow(SyncState())
    val locationAction = MutableStateFlow(LocationActionState())
    val relayAction = MutableStateFlow(RelayActionState())
    val backupAction = MutableStateFlow(BackupActionState())
    val attachmentAction = MutableStateFlow(AttachmentActionState())
    val chatAction = MutableStateFlow(ChatActionState())
    val stickerImportAction = MutableStateFlow(StickerImportActionState())
    /** Peer is currently typing in chat (ephemeral WebRTC / relay presence). */
    val peerTyping = MutableStateFlow(false)
    /** Own message ids still in-flight (sending). */
    val pendingSendIds = MutableStateFlow<Set<String>>(emptySet())
    val pairingSnapshot = pairingStore.observe().stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5_000),
        PairingStore.Snapshot()
    )

    val uiState: StateFlow<UiState> = combine(
        preferences.role,
        preferences.trustedHostPayload,
        identity
    ) { role, trustedHostPayload, deviceIdentity ->
        UiState(
            isLoading = deviceIdentity == null,
            role = role,
            trustedHostPayload = trustedHostPayload,
            deviceIdentity = deviceIdentity
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = UiState()
    )

    val tasks: StateFlow<List<TaskEntity>> by lazy {
        repository.tasks.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    }
    val events: StateFlow<List<EventEntity>> by lazy {
        repository.events.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    }
    val shoppingItems: StateFlow<List<ShoppingItemEntity>> by lazy {
        repository.shoppingItems.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    }
    private val olderChatMessages = MutableStateFlow<List<MessageEntity>>(emptyList())
    private var chatOlderLoading = false

    val messages: StateFlow<List<MessageEntity>> by lazy {
        repository.latestMessages
            .combine(olderChatMessages) { latest, older ->
                (older + latest).distinctBy { it.id }.sortedWith(compareBy<MessageEntity> { it.createdAt }.thenBy { it.id })
            }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    }

    suspend fun loadOlderChatMessages(before: MessageEntity): Int {
        if (chatOlderLoading) return 0
        chatOlderLoading = true
        return try {
            val older = withContext(Dispatchers.IO) { repository.loadOlderMessages(before) }
            if (older.isNotEmpty()) {
                olderChatMessages.value = (olderChatMessages.value + older)
                    .distinctBy { it.id }
                    .sortedWith(compareBy<MessageEntity> { it.createdAt }.thenBy { it.id })
            }
            older.size
        } finally {
            chatOlderLoading = false
        }
    }
    val attachments: StateFlow<List<AttachmentEntity>> by lazy {
        repository.attachments.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    }
    val financialAccounts: StateFlow<List<FinancialAccountEntity>> by lazy {
        repository.financialAccounts.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    }
    val financeTransactions: StateFlow<List<FinanceTransactionEntity>> by lazy {
        repository.financeTransactions.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    }
    val financeBudgets: StateFlow<List<FinanceBudgetEntity>> by lazy {
        repository.financeBudgets.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    }
    val sharedDebts: StateFlow<List<SharedDebtEntity>> by lazy {
        repository.sharedDebts.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    }
    val recurringTransactions: StateFlow<List<RecurringTransactionEntity>> by lazy {
        repository.recurringTransactions.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    }
    val memories: StateFlow<List<MemoryEntity>> by lazy {
        repository.memories.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    }
    val moodCheckIns: StateFlow<List<MoodCheckInEntity>> by lazy {
        repository.moodCheckIns.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    }
    val cycleLogs: StateFlow<List<CycleLogEntity>> by lazy {
        repository.cycleLogs.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    }
    val cycleSettings: StateFlow<CycleSettingsEntity?> by lazy {
        repository.cycleSettings.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)
    }
    val locationShares: StateFlow<List<LocationShareEntity>> by lazy {
        repository.locationShares.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    }
    val heartPulses: StateFlow<List<HeartPulseEntity>> by lazy {
        repository.heartPulses.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    }
    val sharedPlaces: StateFlow<List<SharedPlaceEntity>> by lazy {
        repository.sharedPlaces.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    }
    val habits: StateFlow<List<HabitEntity>> by lazy {
        repository.habits.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    }
    val watchlistItems: StateFlow<List<WatchlistItemEntity>> by lazy {
        repository.watchlistItems.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    }
    /** One-shot UI signal to play full-screen heartbeat animation. */
    val incomingHeartAnimation = MutableStateFlow(false)

    val heartAction = MutableStateFlow(HeartActionState())

    val locationSharingEnabled: StateFlow<Boolean> = preferences.locationSharingEnabled.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5_000), false
    )
    val specialDates: StateFlow<List<SpecialDateEntity>> by lazy {
        repository.specialDates.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    }
    val coupleProfile: StateFlow<CoupleProfileEntity?> by lazy {
        repository.coupleProfile.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)
    }
    val palette: StateFlow<AppPalette> = preferences.palette.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5_000), AppPalette.ROSE
    )
    val themeMode: StateFlow<AppThemeMode> = preferences.themeMode.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5_000), AppThemeMode.SYSTEM
    )
    val telegramBotToken: StateFlow<String> = preferences.telegramBotToken.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5_000), ""
    )
    val telegramStickerPacks: StateFlow<List<TelegramStickerPackEntity>> by lazy {
        repository.telegramStickerPacks.stateIn(
            viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList()
        )
    }

    val relayConfig: StateFlow<RelayConfig> = preferences.relayConfig.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5_000), RelayConfig(false, "")
    )
    val pendingSyncChanges: StateFlow<Int> by lazy {
        app.database.syncChangeDao().observePendingCount()
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), 0)
    }

    /** Still waiting to be published (not yet handed to the transport). */
    val pendingSyncUnsent: StateFlow<Int> by lazy {
        app.database.syncChangeDao().observePendingOnlyCount()
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), 0)
    }

    /** Published on the wire, waiting for peer ACK. */
    val pendingSyncAwaitingAck: StateFlow<Int> by lazy {
        app.database.syncChangeDao().observeSendingCount()
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), 0)
    }

    init {
        WebRtcSession.setTypingListener { on, sentAt -> updatePeerTyping(on, sentAt) }

        ConnectionDiagnostics.clear()
        viewModelScope.launch {
            val base = withContext(Dispatchers.IO) { identityManager.getOrCreateIdentity() }
            // Single-scan pairing: the invite QR already carries the shared secret, so the
            // companion is connected the moment it scans — no reply/approval round-trip.
            val instantInvite = withContext(Dispatchers.IO) {
                val secret = pairingStore.getOrCreateInviteSecret()
                try {
                    val payload = identityManager.buildInstantInvite(base, secret)
                    if (preferences.role.first() == DeviceRole.HOST) {
                        pairingStore.trustInviteAsHost(secret, peerLabel = "همراه")
                    }
                    // Repair older installs where the role was set after this ran once.
                    payload
                } finally {
                    secret.fill(0)
                }
            }
            identity.value = base.copy(pairingPayload = instantInvite)
        }
        // Sync transport is the user-hosted personal relay only.
        // Keep HostServerService in the foreground so relay pollers survive UI close.
        viewModelScope.launch(Dispatchers.IO) {
            val role = preferences.currentRole()
            val paired = pairingStore.trustedSecret() != null
            if (paired && role != null) {
                runCatching { HostServerService.start(getApplication()) }
            }
        }

        viewModelScope.launch(Dispatchers.IO) {
            val deviceId = identity.filter { it != null }.first()!!.deviceId
            while (isActive) {
                val generated = repository.materializeDueRecurringTransactions(deviceId)
                if (generated > 0) autoSync()
                delay(RECURRING_CHECK_INTERVAL)
            }
        }
        viewModelScope.launch(Dispatchers.IO) {
            repository.heartPulses.collect { pulses ->
                val ownId = identity.value?.deviceId ?: return@collect
                // Incoming pulses: notify + animate once
                pulses
                    .filter { !it.isDeleted && it.consumedAt == null && it.senderDeviceId != ownId }
                    .forEach { pulse ->
                        withContext(Dispatchers.Main) {
                            incomingHeartAnimation.value = true
                            notificationCenter.showThinkingOfYou()
                        }
                        repository.markHeartPulseConsumed(pulse)
                    }
                // Ack from partner for pulses we sent
                pulses
                    .filter {
                        !it.isDeleted &&
                            it.senderDeviceId == ownId &&
                            it.acknowledgedAt != null &&
                            it.updatedAt > System.currentTimeMillis() - 15_000
                    }
                    .take(1)
                    .forEach { _ ->
                        // Soft notify only when app is open is fine; optional toast via heartAction
                        withContext(Dispatchers.Main) {
                            heartAction.value = HeartActionState(message = "طرف مقابل تپش قلبت را دید 💗")
                        }
                    }
            }
        }
    }

    fun saveOnboardingRelay(endpoint: String) {
        viewModelScope.launch(Dispatchers.IO) {
            runCatching {
                preferences.setRelayConfig(
                    enabled = true,
                    endpoint = endpoint.trim(),
                    accessToken = com.ourspace.app.core.relay.RelayConfig.DEFAULT_ACCESS_TOKEN
                )
                ConnectionDiagnostics.log("آدرس سرور از راه‌اندازی ذخیره شد")
            }.onFailure {
                ConnectionDiagnostics.log("ذخیره سرور ناموفق: ${it.message}")
            }
        }
    }

    fun completeHostSetup(hostPin: String) {
        val pin = com.ourspace.app.core.relay.RelayPinClient.normalizePin(hostPin)
        if (pin.length != 4) {
            pairingAction.value = PairingActionState(error = "کد میزبان باید دقیقاً ۴ رقم باشد.")
            return
        }
        pairingAction.value = PairingActionState(isLoading = true, message = "در حال آماده‌سازی اتصال…")
        viewModelScope.launch(Dispatchers.IO) {
            try {
                ensureDefaultRelay()
                val relayConfig = preferences.currentRelayConfig()
                com.ourspace.app.core.relay.RelayPinClient.registerHostPin(relayConfig.endpoint, pin)
                preferences.setRole(DeviceRole.HOST)
                pairingStore.pairWithPin(pin)
                enableAutomaticLocationIfPermitted()
                HostServerService.start(getApplication())
                HostServerService.requestImmediateSync(getApplication())
                pairingAction.value = PairingActionState(
                    hostPin = pin,
                    message = "میزبان آماده است؛ این کد را به همراه بده: $pin"
                )
            } catch (error: Exception) {
                pairingAction.value = PairingActionState(error = error.message ?: "راه‌اندازی میزبان ناموفق بود.")
            }
        }
    }

    private suspend fun enableAutomaticLocationIfPermitted() {
        val publisher = LocationPublisher(getApplication())
        if (publisher.hasPermission()) {
            preferences.setLocationSharingEnabled(true)
        }
    }

    /** Host self-heal: make sure the invite secret is stored as the trusted shared key. */
    private fun ensureHostTrust() {
        if (pairingStore.trustedSecret() != null) return
        val secret = pairingStore.getOrCreateInviteSecret()
        try {
            pairingStore.trustInviteAsHost(secret, peerLabel = "همراه")
            ConnectionDiagnostics.log("کلید میزبان بازسازی شد (جفت‌سازی آماده است)")
        } finally {
            secret.fill(0)
        }
    }

    fun completeCompanionSetup(hostPin: String) {
        // First-run pairing uses the same short PIN shown by the host; QR/payload
        // exchange is no longer part of the user-facing onboarding flow.
        pairWithPin(hostPin)
    }


    fun applyCompanionReplyQr(payload: String) {
        viewModelScope.launch(Dispatchers.IO) {
            pairingAction.value = PairingActionState(isLoading = true, message = "در حال خواندن پاسخ همراه…")
            runCatching {
                val reply = pairingClient.parseCompanionReply(payload)
                val secret = identityManager.decryptPairingSecret(reply.encryptedSecret)
                try {
                    pairingStore.receiveIncoming(
                        requestId = reply.requestId,
                        deviceId = reply.deviceId,
                        fingerprint = reply.fingerprint,
                        secret = secret
                    )
                } finally {
                    secret.fill(0)
                }
            }.onSuccess {
                pairingAction.value = PairingActionState(
                    message = "درخواست همراه دریافت شد. تأیید کنید تا QR تأیید ساخته شود."
                )
            }.onFailure { error ->
                pairingAction.value = PairingActionState(
                    error = describePairingError(error, "QR پاسخ همراه معتبر نیست.")
                )
            }
        }
    }

    fun approveIncomingPairing() {
        pairingStore.approveIncoming()
        val incoming = pairingSnapshot.value.incoming
        val requestId = incoming?.requestId
        if (requestId != null) {
            val proof = pairingStore.approvalProof(requestId)
            if (proof != null) {
                pairingAction.value = PairingActionState(
                    message = "تأیید شد. این QR را به گوشی همراه نشان دهید.",
                    approvalQrPayload = pairingClient.buildApprovalQr(requestId, proof)
                )
                return
            }
        }
        pairingAction.value = PairingActionState(message = "درخواست تأیید شد.")
    }

    /**
     * Converts pairing exceptions into a useful message for the UI. Some relay and
     * payload errors wrap the actionable message in one or more causes, so inspect
     * the cause chain before falling back to the generic Persian text.
     */
    private fun describePairingError(error: Throwable, fallback: String): String {
        var current: Throwable? = error
        while (current != null) {
            val message = current.message?.trim()
            if (!message.isNullOrEmpty()) return message
            current = current.cause
        }
        return fallback
    }

    /** Companion scans host approval QR to finish trust. */
    fun applyApprovalQr(payload: String) {
        viewModelScope.launch(Dispatchers.IO) {
            pairingAction.value = PairingActionState(isLoading = true, message = "در حال تأیید نهایی…")
            runCatching {
                val approval = pairingClient.parseApproval(payload)
                val outgoing = pairingSnapshot.value.outgoing
                    ?: throw IOException("درخواست خروجی وجود ندارد.")
                require(outgoing.requestId == approval.requestId) {
                    "این QR برای درخواست فعلی نیست."
                }
                require(pairingStore.verifyProof(approval.requestId, approval.proof)) {
                    "امضای تأیید معتبر نیست."
                }
                pairingStore.markOutgoingApproved()
            }.onSuccess {
                pairingAction.value = PairingActionState(message = "دو گوشی با موفقیت به هم وصل شدند.")
            }.onFailure { error ->
                pairingAction.value = PairingActionState(
                    error = describePairingError(error, "QR تأیید معتبر نیست.")
                )
            }
        }
    }

    
    private suspend fun ensureDefaultRelay() {
        val relay = preferences.currentRelayConfig()
        val endpoint = relay.endpoint.ifBlank { RelayConfig.DEFAULT_ENDPOINT }
        if (!relay.enabled || !relay.isUsable || relay.accessToken != RelayConfig.DEFAULT_ACCESS_TOKEN) {
            preferences.setRelayConfig(
                enabled = true,
                endpoint = endpoint,
                accessToken = RelayConfig.DEFAULT_ACCESS_TOKEN
            )
        }
    }

    /** Host: create a random 4-digit code to tell the companion. */
    fun generateHostPin() {
        pairingAction.value = PairingActionState(isLoading = true)
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val pin = (java.security.SecureRandom().nextInt(9000) + 1000).toString()
                ensureDefaultRelay()
                val relayConfig = preferences.currentRelayConfig()
                com.ourspace.app.core.relay.RelayPinClient.registerHostPin(relayConfig.endpoint, pin)
                preferences.setRole(DeviceRole.HOST)
                pairingStore.pairWithPin(pin)
                HostServerService.start(getApplication())
                HostServerService.requestImmediateSync(getApplication())
                pairingAction.value = PairingActionState(
                    hostPin = pin,
                    message = "این کد را به همراه بگو: $pin"
                )
            } catch (error: Exception) {
                pairingAction.value = PairingActionState(
                    error = error.message ?: "ساخت کد ناموفق بود."
                )
            }
        }
    }

    /** Companion: type the 4-digit code shown on the host phone. */
    fun pairWithPin(pin: String) {
        pairingAction.value = PairingActionState(isLoading = true)
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val cleaned = com.ourspace.app.core.relay.RelayPinClient.normalizePin(pin)
                require(cleaned.length == 4 && cleaned.all { it in '0'..'9' }) { "کد باید ۴ رقم باشد" }
                ensureDefaultRelay()
                val relayConfig = preferences.currentRelayConfig()
                com.ourspace.app.core.relay.RelayPinClient.verifyHostPin(relayConfig.endpoint, cleaned)
                preferences.setRole(DeviceRole.COMPANION)
                pairingStore.pairWithPin(cleaned)
                HostServerService.start(getApplication())
                HostServerService.requestImmediateSync(getApplication())
                pairingAction.value = PairingActionState(
                    message = "متصل شد با کد $cleaned"
                )
            } catch (error: Exception) {
                pairingAction.value = PairingActionState(
                    error = error.message ?: "جفت‌سازی ناموفق بود."
                )
            }
        }
    }

fun rejectIncomingPairing() = pairingStore.rejectIncoming()

    fun cancelOutgoingPairing() {
        pairingStore.clearOutgoing()
        pairingAction.value = PairingActionState()
    }

    fun revokeTrustedDevice() {
        pairingStore.revokeTrust()
        syncState.value = SyncState(message = "اعتماد دستگاه لغو شد. داده‌های محلی حذف نشدند.")
    }

    fun checkPairingStatus() {
        val outgoing = pairingSnapshot.value.outgoing ?: return
        pairingAction.value = PairingActionState(isLoading = true, message = "در حال بررسی تأیید میزبان…")
        viewModelScope.launch(Dispatchers.IO) {
            runCatching { pairingClient.checkStatus(outgoing) }
                .onSuccess { result ->
                    when (result.status) {
                        PairingStore.RequestStatus.PENDING -> {
                            pairingAction.value = PairingActionState(message = "هنوز باید درخواست را روی گوشی میزبان تأیید کنید.")
                        }
                        PairingStore.RequestStatus.REJECTED -> {
                            pairingStore.markOutgoingRejected()
                            pairingAction.value = PairingActionState(error = "درخواست توسط میزبان رد شد.")
                        }
                        PairingStore.RequestStatus.APPROVED -> {
                            val proof = result.proof
                            if (proof != null && pairingStore.verifyProof(outgoing.requestId, proof)) {
                                pairingStore.markOutgoingApproved()
                                pairingAction.value = PairingActionState(message = "دو گوشی با موفقیت مورد اعتماد شدند.")
                                CompanionSyncWorker.schedule(getApplication())
                                runCatching { HostServerService.start(getApplication()) }
                                syncNowInternal()
                            } else {
                                pairingAction.value = PairingActionState(error = "پاسخ میزبان قابل تأیید نبود.")
                            }
                        }
                    }
                }
                .onFailure { error ->
                    pairingAction.value = PairingActionState(error = error.message ?: "میزبان در دسترس نیست.")
                }
        }
    }

    fun ensureHostService(role: DeviceRole?) {
        when (role) {
            DeviceRole.HOST, DeviceRole.COMPANION -> {
                companionSyncLoop?.cancel()
                companionSyncLoop = null
                // Keep-alive WorkManager for BOTH roles so sync continues when UI is closed.
                CompanionSyncWorker.schedule(getApplication())
                runCatching { HostServerService.start(getApplication()) }
                runCatching { HostServerService.requestImmediateSync(getApplication()) }
            }
            null -> {
                companionSyncLoop?.cancel()
                companionSyncLoop = null
                CompanionSyncWorker.cancel(getApplication())
            }
        }
    }

    fun verificationCode(payload: String): String = identityManager.verificationCode(payload)

    fun syncNow() {
        viewModelScope.launch(Dispatchers.IO) { syncNowInternal() }
    }

    private suspend fun syncNowInternal(silent: Boolean = false) = syncMutex.withLock {
        if (!silent) {
            syncState.value = SyncState(isSyncing = true, message = "در حال همگام‌سازی لحظه‌ای…")
        }
        runCatching {
            HostServerService.requestImmediateSync(getApplication())
        }.onSuccess {
            syncState.value = SyncState(
                isSyncing = false,
                lastSyncAt = System.currentTimeMillis(),
                transport = SyncClient.Transport.RELAY,
                message = if (silent) null else "درخواست همگام‌سازی ارسال شد؛ اتصال لحظه‌ای فعال است."
            )
            refreshHomeWidget()
        }.onFailure { error ->
            if (!silent) {
                syncState.value = SyncState(
                    error = error.message ?: "همگام‌سازی انجام نشد."
                )
            }
        }
    }

    private fun refreshHomeWidget() {
        val context = getApplication<Application>()
        runCatching { OurSpaceWidgetProvider.requestUpdate(context) }
        runCatching { OurSpaceTasksWidgetProvider.requestUpdate(context) }
        runCatching { OurSpaceShoppingWidgetProvider.requestUpdate(context) }
        runCatching { OurSpaceCalendarWidgetProvider.requestUpdate(context) }
    }

    private suspend fun autoSync(): Boolean {
        // Wake peer over WebRTC immediately when the DataChannel is open (chat text fast-path),
        // then trigger the durable relay duplex outbound flush.
        WebRtcSession.sendNudge()
        return runCatching { HostServerService.requestImmediateSync(getApplication()) }.isSuccess
    }


    fun addTask(title: String, priority: Int, assignee: String, dueAt: Long? = null) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.addTask(title, priority, assignee, dueAt)
            autoSync()
        }
    }

    fun addTimedTask(title: String, priority: Int, assignee: String, dueAt: Long?, durationMinutes: Int) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.addTask(title, priority, assignee, dueAt, durationMinutes)
            autoSync()
        }
    }

    fun addSharedPlace(title: String, note: String, latitude: Double, longitude: Double, category: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val deviceId = identityManager.getOrCreateIdentity().deviceId
            repository.addSharedPlace(title, note, latitude, longitude, category, deviceId)
            autoSync()
        }
    }

    fun deleteSharedPlace(place: SharedPlaceEntity) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.deleteSharedPlace(place)
            autoSync()
        }
    }

    fun addHabit(title: String, kind: String, scheduleNote: String, note: String = "") {
        viewModelScope.launch(Dispatchers.IO) {
            repository.addHabit(title, kind, scheduleNote, note)
            com.ourspace.app.core.reminder.HabitReminderScheduler.scheduleAll(getApplication())
            autoSync()
        }
    }

    fun toggleHabitDoneToday(habit: HabitEntity) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.toggleHabitDoneToday(habit)
            com.ourspace.app.core.reminder.HabitReminderScheduler.scheduleAll(getApplication())
            autoSync()
        }
    }

    fun deleteHabit(habit: HabitEntity) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.deleteHabit(habit)
            com.ourspace.app.core.reminder.HabitReminderScheduler.scheduleAll(getApplication())
            autoSync()
        }
    }

    fun addWatchlistItem(title: String, mediaType: String, note: String = "") {
        viewModelScope.launch(Dispatchers.IO) {
            repository.addWatchlistItem(title, mediaType, note)
            autoSync()
        }
    }

    fun cycleWatchlistStatus(item: WatchlistItemEntity) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.cycleWatchlistStatus(item)
            autoSync()
        }
    }

    fun deleteWatchlistItem(item: WatchlistItemEntity) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.deleteWatchlistItem(item)
            autoSync()
        }
    }

    suspend fun loadShoppingSuggestions(): List<String> =
        withContext(Dispatchers.IO) { repository.shoppingSuggestions() }

    fun clearCheckedShopping() {
        viewModelScope.launch(Dispatchers.IO) {
            repository.clearCheckedShopping()
            autoSync()
        }
    }

    fun updateTaskSchedule(task: TaskEntity, startAt: Long, durationMinutes: Int) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.updateTaskSchedule(task, startAt, durationMinutes)
            autoSync()
        }
    }

    fun toggleTask(task: TaskEntity) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.toggleTask(task)
            autoSync()
        }
    }

    fun deleteTask(task: TaskEntity) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.deleteTask(task)
            autoSync()
        }
    }

    fun addEvent(title: String, startAt: Long) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.addEvent(title, startAt)
            autoSync()
        }
    }

    fun addTimedEvent(title: String, startAt: Long, durationMinutes: Int) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.addEvent(title, startAt, durationMinutes)
            autoSync()
        }
    }

    fun addWorkScheduleEvents(events: List<EventEntity>) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.addWorkScheduleEvents(events)
            autoSync()
        }
    }

    fun updateEvent(event: EventEntity, title: String, startAt: Long) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.updateEvent(event, title, startAt)
            autoSync()
        }
    }

    fun updateEventSchedule(event: EventEntity, startAt: Long, endAt: Long) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.updateEventSchedule(event, startAt, endAt)
            autoSync()
        }
    }

    fun deleteEvent(event: EventEntity) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.deleteEvent(event)
            autoSync()
        }
    }

    fun addShoppingItem(title: String, quantity: String, category: String, isRecurring: Boolean = false) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.addShoppingItem(title, quantity, category, isRecurring)
            autoSync()
        }
    }

    fun toggleShoppingItem(item: ShoppingItemEntity) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.toggleShoppingItem(item)
            autoSync()
        }
    }

    fun deleteShoppingItem(item: ShoppingItemEntity) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.deleteShoppingItem(item)
            autoSync()
        }
    }

    suspend fun sendMessage(text: String, replyToId: String?): Boolean {
        val deviceId = identity.value?.deviceId
        if (deviceId == null) {
            chatAction.value = ChatActionState(error = "شناسه این گوشی آماده نیست؛ پیام ارسال نشد.")
            return false
        }
        val clean = text.trim().take(5_000)
        if (clean.isBlank()) return false
        chatAction.value = ChatActionState(isSending = true, message = "در حال ذخیره پیام…")
        notifyTyping(false)
        return try {
            val messageId = withContext(Dispatchers.IO) { repository.sendMessage(deviceId, clean, replyToId) }
            if (messageId != null) {
                pendingSendIds.value = pendingSendIds.value + messageId
            }
            val syncRequested = autoSync()
            if (messageId != null) {
                pendingSendIds.value = pendingSendIds.value - messageId
            }
            withContext(Dispatchers.IO) { stampDeliveriesInternal(deviceId) }
            chatAction.value = ChatActionState(message = if (syncRequested) {
                "پیام ذخیره شد و درخواست همگام‌سازی ثبت شد."
            } else {
                "پیام در این گوشی ذخیره شد؛ همگام‌سازی ارسال نشد."
            })
            true
        } catch (error: Exception) {
            chatAction.value = ChatActionState(error = error.message ?: "ذخیره پیام انجام نشد؛ متن را دوباره ارسال کنید.")
            false
        }
    }


    fun setTelegramBotToken(token: String) {
        viewModelScope.launch {
            preferences.setTelegramBotToken(token)
        }
    }

    fun importTelegramStickerPack(nameOrLink: String) {
        viewModelScope.launch {
            stickerImportAction.value = StickerImportActionState(isLoading = true, message = "در حال دریافت پک از تلگرام…")
            try {
                val token = preferences.currentTelegramBotToken()
                require(token.length >= 20) { "ابتدا توکن ربات تلگرام را در تنظیمات وارد کنید" }
                val pack = withContext(Dispatchers.IO) {
                    repository.importTelegramStickerPack(token, nameOrLink)
                }
                stickerImportAction.value = StickerImportActionState(
                    message = "پک «${pack.title}» با ${pack.stickerCount} استیکر اضافه شد"
                )
            } catch (error: Exception) {
                stickerImportAction.value = StickerImportActionState(
                    error = error.message ?: "دریافت پک استیکر ناموفق بود"
                )
            }
        }
    }

    fun deleteTelegramStickerPack(name: String) {
        viewModelScope.launch {
            runCatching {
                withContext(Dispatchers.IO) { repository.deleteTelegramStickerPack(name) }
            }
        }
    }

    suspend fun loadTelegramStickers(packName: String): List<TelegramStickerEntity> =
        withContext(Dispatchers.IO) { repository.getTelegramStickers(packName) }

    fun sendTelegramSticker(stickerId: String, replyToId: String?) {
        viewModelScope.launch {
            attachmentAction.value = AttachmentActionState(isLoading = true, message = "در حال ارسال استیکر…")
            try {
                val deviceId = identity.value?.deviceId ?: return@launch
                withContext(Dispatchers.IO) {
                    repository.sendTelegramSticker(deviceId, stickerId, replyToId)
                }
                val syncRequested = autoSync()
                attachmentAction.value = AttachmentActionState(
                    message = if (syncRequested) "استیکر ارسال و برای همگام‌سازی صف شد."
                    else "استیکر ذخیره شد."
                )
            } catch (error: Exception) {
                attachmentAction.value = AttachmentActionState(
                    error = error.message ?: "ارسال استیکر انجام نشد"
                )
            }
        }
    }

    /**
     * Send only state changes plus an occasional heartbeat; the draft text is never transmitted.
     * WebRTC is the fast path and the relay is the fallback when a direct DataChannel is closed.
     */
    fun notifyTyping(isTyping: Boolean) {
        val sentAt = synchronized(typingLock) {
            val now = System.currentTimeMillis()
            val shouldSend = when {
                isTyping && !localTypingActive -> {
                    localTypingActive = true
                    true
                }
                isTyping && now - lastLocalTypingSignalAt >= LOCAL_TYPING_HEARTBEAT_MS -> true
                !isTyping && localTypingActive -> {
                    localTypingActive = false
                    true
                }
                else -> false
            }
            if (!shouldSend) return
            maxOf(now, lastLocalTypingSignalAt + 1L).also { lastLocalTypingSignalAt = it }
        }

        WebRtcSession.sendTyping(isTyping, sentAt)
        runCatching {
            HostServerService.requestTyping(getApplication(), isTyping, sentAt)
        }.onFailure { error ->
            ConnectionDiagnostics.log("نشانگر تایپ از مسیر Relay ارسال نشد: ${error.message ?: error.javaClass.simpleName}")
        }
    }

    private fun updatePeerTyping(isTyping: Boolean, sentAt: Long) {
        val eventAt = sentAt.takeIf { it > 0L } ?: System.currentTimeMillis()
        synchronized(typingLock) {
            // The same frame may arrive over both WebRTC and Relay, or arrive out of order.
            if (eventAt <= lastPeerTypingSignalAt) return
            lastPeerTypingSignalAt = eventAt
            peerTypingTimeoutJob?.cancel()
            peerTypingTimeoutJob = null
            peerTyping.value = isTyping
            if (isTyping) {
                peerTypingTimeoutJob = viewModelScope.launch {
                    delay(PEER_TYPING_TIMEOUT_MS)
                    synchronized(typingLock) {
                        if (lastPeerTypingSignalAt == eventAt) {
                            peerTyping.value = false
                            peerTypingTimeoutJob = null
                        }
                    }
                }
            }
        }
    }

    fun shareCardToChat(encoded: String) {
        viewModelScope.launch {
            sendMessage(encoded, null)
        }
    }

    fun shareTaskToChat(task: TaskEntity) {
        val body = ChatShareCard.encode(
            ChatShareCard.Type.TASK,
            task.id,
            task.title,
            subtitle = when {
                task.isCompleted -> "انجام‌شده"
                task.dueAt != null -> "مهلت دارد"
                else -> task.assignee.ifBlank { null }
            },
            extra = mapOf(
                "dueAt" to task.dueAt,
                "priority" to task.priority,
                "completed" to task.isCompleted
            )
        )
        shareCardToChat(body)
    }

    fun shareEventToChat(event: EventEntity) {
        val body = ChatShareCard.encode(
            ChatShareCard.Type.EVENT,
            event.id,
            event.title,
            subtitle = null,
            extra = mapOf("startAt" to event.startAt, "endAt" to event.endAt)
        )
        shareCardToChat(body)
    }

    fun shareDebtToChat(debt: SharedDebtEntity) {
        val body = ChatShareCard.encode(
            ChatShareCard.Type.DEBT,
            debt.id,
            debt.title,
            subtitle = "${debt.amount}",
            extra = mapOf(
                "amount" to debt.amount,
                "creditorDeviceId" to debt.creditorDeviceId,
                "debtorDeviceId" to debt.debtorDeviceId
            )
        )
        shareCardToChat(body)
    }

    fun shareMemoryToChat(memory: MemoryEntity) {
        val body = ChatShareCard.encode(
            ChatShareCard.Type.MEMORY,
            memory.id,
            memory.title,
            subtitle = memory.note.takeIf { it.isNotBlank() }?.take(80)
        )
        shareCardToChat(body)
    }

    fun shareLocationToChat(share: LocationShareEntity) {
        val body = ChatShareCard.encode(
            ChatShareCard.Type.LOCATION,
            share.id,
            "موقعیت به‌اشتراک‌گذاشته",
            subtitle = "%.5f, %.5f".format(share.latitude, share.longitude),
            extra = mapOf("lat" to share.latitude, "lng" to share.longitude)
        )
        shareCardToChat(body)
    }

    private suspend fun stampDeliveriesInternal(deviceId: String) {
        val changed = repository.stampIncomingDelivered(deviceId)
        if (changed > 0) autoSync()
    }

    fun stampIncomingDeliveries() {
        val deviceId = identity.value?.deviceId ?: return
        viewModelScope.launch(Dispatchers.IO) {
            stampDeliveriesInternal(deviceId)
        }
    }


    fun sendMessageAttachment(uriValue: String, replyToId: String?) {
        val deviceId = identity.value?.deviceId ?: return
        attachmentAction.value = AttachmentActionState(isLoading = true, message = "در حال آماده‌سازی پیوست امن…")
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val imported = importAttachment(uriValue)
                try {
                    repository.sendMessageAttachment(
                        senderDeviceId = deviceId,
                        fileName = imported.fileName,
                        mimeType = imported.mimeType,
                        content = imported.content,
                        replyToId = replyToId
                    )
                } finally {
                    imported.content.fill(0)
                }
                val syncRequested = autoSync()
                attachmentAction.value = AttachmentActionState(message = if (syncRequested) {
                    "پیوست در این گوشی ذخیره شد؛ درخواست همگام‌سازی ثبت شد، اما دریافت توسط گوشی مقابل هنوز تأیید نشده است."
                } else {
                    "پیوست در این گوشی ذخیره شد؛ درخواست همگام‌سازی ارسال نشد. از دکمه همگام‌سازی دوباره تلاش کنید."
                })
            } catch (error: Exception) {
                attachmentAction.value = AttachmentActionState(
                    error = error.message ?: "افزودن پیوست انجام نشد."
                )
            }
        }
    }

    fun saveAttachmentCopy(attachmentId: String, targetUriValue: String) {
        attachmentAction.value = AttachmentActionState(isLoading = true, message = "در حال بررسی و ذخیره نسخه…")
        viewModelScope.launch(Dispatchers.IO) {
            val targetUri = Uri.parse(targetUriValue)
            val resolver = getApplication<Application>().contentResolver
            try {
                val attachment = repository.verifiedAttachmentForExport(attachmentId)
                resolver.openOutputStream(targetUri, "w")?.use { output ->
                    output.write(attachment.content)
                    output.flush()
                } ?: throw IOException("محل انتخاب‌شده قابل نوشتن نیست.")
                val savedBytes = resolver.openInputStream(targetUri)?.use { readAttachmentBytes(it) }
                    ?: throw IOException("بازخوانی نسخه ذخیره‌شده ممکن نیست.")
                try {
                    val sourceHash = java.security.MessageDigest.getInstance("SHA-256").digest(attachment.content)
                    val savedHash = java.security.MessageDigest.getInstance("SHA-256").digest(savedBytes)
                    require(attachment.content.size == savedBytes.size &&
                        java.security.MessageDigest.isEqual(sourceHash, savedHash)) {
                        "نسخه ذخیره‌شده با فایل اصلی مطابقت ندارد."
                    }
                } finally {
                    savedBytes.fill(0)
                }
                attachmentAction.value = AttachmentActionState(message = "نسخه فایل با بررسی یکپارچگی ذخیره شد.")
            } catch (error: Exception) {
                attachmentAction.value = AttachmentActionState(
                    error = error.message ?: "ذخیره نسخه فایل انجام نشد."
                )
            }
        }
    }

    suspend fun loadAttachmentContent(id: String): AttachmentEntity? =
        withContext(Dispatchers.IO) { repository.findAttachment(id) }

    fun deleteAttachment(attachment: AttachmentEntity) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                repository.deleteAttachment(attachment)
                val syncRequested = autoSync()
                attachmentAction.value = AttachmentActionState(message = if (syncRequested) {
                    "حذف محلی پیوست ثبت شد؛ درخواست همگام‌سازی ثبت شد."
                } else "حذف محلی پیوست ثبت شد؛ همگام‌سازی انجام نشد. دوباره همگام‌سازی کنید.")
            } catch (error: Exception) {
                attachmentAction.value = AttachmentActionState(error = error.message ?: "حذف پیوست انجام نشد.")
            }
        }
    }

    fun addMemoryAttachment(memoryId: String, uriValue: String, rotationDegrees: Int = 0) {
        val deviceId = identity.value?.deviceId ?: return
        attachmentAction.value = AttachmentActionState(isLoading = true, message = "در حال افزودن تصویر خاطره…")
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val imported = importAttachment(uriValue, requireImage = true)
                try {
                    val rotated = rotateImageBytes(imported.content, rotationDegrees)
                    try {
                        repository.addMemoryAttachment(
                            memoryId = memoryId,
                            createdByDeviceId = deviceId,
                            fileName = if (rotationDegrees % 360 != 0) {
                                imported.fileName.replace(Regex("""\.(png|webp|heic)$""", RegexOption.IGNORE_CASE), ".jpg")
                            } else imported.fileName,
                            mimeType = if (rotationDegrees % 360 != 0) "image/jpeg" else imported.mimeType,
                            content = rotated
                        )
                    } finally {
                        if (rotated !== imported.content) rotated.fill(0)
                    }
                } finally {
                    imported.content.fill(0)
                }
                attachmentAction.value = AttachmentActionState(message = "تصویر به خاطره اضافه شد.")
                autoSync()
            } catch (error: Exception) {
                attachmentAction.value = AttachmentActionState(
                    error = error.message ?: "افزودن تصویر خاطره انجام نشد."
                )
            }
        }
    }

    fun rotateMemoryAttachment(attachmentId: String, rotationDegrees: Int) {
        if (rotationDegrees % 360 == 0) return
        attachmentAction.value = AttachmentActionState(isLoading = true, message = "در حال چرخاندن تصویر…")
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val existing = repository.findAttachment(attachmentId)
                    ?: throw IllegalArgumentException("تصویر پیدا نشد.")
                require(existing.content.isNotEmpty()) { "محتوای تصویر در دسترس نیست." }
                val rotated = rotateImageBytes(existing.content, rotationDegrees)
                try {
                    repository.replaceAttachmentContent(
                        attachmentId = attachmentId,
                        content = rotated,
                        mimeType = "image/jpeg",
                        fileName = existing.fileName.replace(Regex("""\.(png|webp|heic)$""", RegexOption.IGNORE_CASE), ".jpg")
                    )
                } finally {
                    rotated.fill(0)
                }
                attachmentAction.value = AttachmentActionState(message = "تصویر چرخانده شد.")
                autoSync()
            } catch (error: Exception) {
                attachmentAction.value = AttachmentActionState(
                    error = error.message ?: "چرخاندن تصویر انجام نشد."
                )
            }
        }
    }

    private fun rotateImageBytes(source: ByteArray, degrees: Int): ByteArray {
        val normalized = ((degrees % 360) + 360) % 360
        if (normalized == 0) return source
        val bitmap = BitmapFactory.decodeByteArray(source, 0, source.size)
            ?: throw IOException("تصویر برای چرخش قابل خواندن نیست.")
        val matrix = Matrix().apply { postRotate(normalized.toFloat()) }
        val rotated = Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
        if (rotated !== bitmap) bitmap.recycle()
        val out = ByteArrayOutputStream()
        val ok = rotated.compress(Bitmap.CompressFormat.JPEG, 90, out)
        rotated.recycle()
        if (!ok) throw IOException("ذخیره تصویر چرخانده‌شده ناموفق بود.")
        return out.toByteArray()
    }

    fun editMessage(message: MessageEntity, newText: String) {
        val deviceId = identity.value?.deviceId ?: return
        if (message.senderDeviceId != deviceId) return
        viewModelScope.launch(Dispatchers.IO) {
            try {
                repository.editMessage(message, newText)
                val syncRequested = autoSync()
                chatAction.value = ChatActionState(message = if (syncRequested) {
                    "ویرایش در این گوشی ثبت شد؛ درخواست همگام‌سازی ثبت شد."
                } else "ویرایش محلی ثبت شد؛ همگام‌سازی انجام نشد. دوباره همگام‌سازی کنید.")
            } catch (error: Exception) {
                chatAction.value = ChatActionState(error = error.message ?: "ویرایش پیام انجام نشد.")
            }
        }
    }

    fun deleteMessage(message: MessageEntity) {
        val deviceId = identity.value?.deviceId ?: return
        if (message.senderDeviceId != deviceId) return
        viewModelScope.launch(Dispatchers.IO) {
            try {
                repository.deleteMessage(message)
                val syncRequested = autoSync()
                chatAction.value = ChatActionState(message = if (syncRequested) {
                    "حذف در این گوشی ثبت شد؛ درخواست همگام‌سازی ثبت شد."
                } else "حذف محلی ثبت شد؛ همگام‌سازی انجام نشد. دوباره همگام‌سازی کنید.")
            } catch (error: Exception) {
                chatAction.value = ChatActionState(error = error.message ?: "حذف پیام انجام نشد.")
            }
        }
    }

    fun reactToMessage(message: MessageEntity, reaction: String) {
        val deviceId = identity.value?.deviceId ?: return
        viewModelScope.launch(Dispatchers.IO) {
            try {
                repository.reactToMessage(message, reaction, deviceId)
                val syncRequested = autoSync()
                chatAction.value = ChatActionState(message = if (syncRequested) {
                    "واکنش ثبت شد؛ درخواست همگام‌سازی ثبت شد."
                } else "واکنش محلی ثبت شد؛ همگام‌سازی انجام نشد. دوباره همگام‌سازی کنید.")
            } catch (error: Exception) {
                chatAction.value = ChatActionState(error = error.message ?: "ثبت واکنش انجام نشد.")
            }
        }
    }

    fun markChatRead() {
        val deviceId = identity.value?.deviceId ?: return
        viewModelScope.launch(Dispatchers.IO) {
            val changed = repository.markIncomingMessagesRead(deviceId)
            if (changed > 0) autoSync()
        }
    }

    suspend fun searchChatMessages(query: String): List<MessageEntity> =
        withContext(Dispatchers.IO) { repository.searchMessages(query) }

    suspend fun findChatMessage(messageId: String): MessageEntity? =
        withContext(Dispatchers.IO) { repository.findMessage(messageId) }

    fun markVisibleChatMessagesRead(messageIds: List<String>) {
        val deviceId = identity.value?.deviceId ?: return
        if (messageIds.isEmpty()) return
        viewModelScope.launch(Dispatchers.IO) {
            val delivered = repository.stampIncomingDelivered(deviceId)
            val changed = repository.markVisibleIncomingMessagesRead(messageIds, deviceId)
            if (changed > 0 || delivered > 0) autoSync()
        }
    }

    fun addFinancialAccount(name: String, type: String, openingBalance: Long, colorSeed: Int) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.addFinancialAccount(name, type, openingBalance, colorSeed)
            autoSync()
        }
    }

    fun correctFinancialAccountBalance(account: FinancialAccountEntity, targetBalance: Long) {
        viewModelScope.launch(Dispatchers.IO) {
            val transactions = financeTransactions.value
            val transactionEffect = FinanceCalculator.accountBalance(account, transactions) - account.openingBalance
            val correctedOpening = targetBalance - transactionEffect
            repository.updateFinancialAccount(account.copy(openingBalance = correctedOpening, updatedAt = System.currentTimeMillis()))
            autoSync()
        }
    }

    private suspend fun checkBudgetAlerts(category: String, periodKey: String) {
        val budgets = repository.financeBudgets // Flow - need one shot
        // Use database via repository method - approximate with state
        val budgetList = try { financeBudgets.value } catch (_: Exception) { emptyList() }
        val budget = budgetList.firstOrNull { it.category == category && it.periodKey == periodKey } ?: return
        val txs = try { financeTransactions.value } catch (_: Exception) { emptyList() }
        val spent = txs.filter {
            it.kind == "EXPENSE" && it.category == category &&
                com.ourspace.app.core.time.PersianDateFormatter.jalaliMonthKey(it.occurredAt) == periodKey &&
                !it.isDeleted
        }.sumOf { it.amount }
        if (budget.monthlyLimit <= 0) return
        val percent = ((spent * 100) / budget.monthlyLimit).toInt()
        when {
            percent >= 100 -> notificationCenter.showBudgetAlert(category, 100)
            percent >= 80 -> notificationCenter.showBudgetAlert(category, 80)
        }
    }

    fun addFinanceTransaction(
        accountId: String,
        targetAccountId: String?,
        kind: String,
        amount: Long,
        category: String,
        note: String
    ) {
        val deviceId = identity.value?.deviceId ?: return
        viewModelScope.launch(Dispatchers.IO) {
            repository.addFinanceTransaction(accountId, targetAccountId, kind, amount, category, note, deviceId)
            autoSync()
            checkBudgetAlerts(category, com.ourspace.app.core.time.PersianDateFormatter.currentJalaliMonthKey())
        }
    }

    fun addFinanceTransactionAt(
        accountId: String, targetAccountId: String?, kind: String, amount: Long,
        category: String, note: String, occurredAt: Long
    ) {
        val deviceId = identity.value?.deviceId ?: return
        viewModelScope.launch(Dispatchers.IO) {
            repository.addFinanceTransaction(accountId, targetAccountId, kind, amount, category, note, deviceId, occurredAt)
            autoSync()
            checkBudgetAlerts(category, com.ourspace.app.core.time.PersianDateFormatter.jalaliMonthKey(occurredAt))
        }
    }

    fun deleteFinanceTransaction(transaction: FinanceTransactionEntity) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.deleteFinanceTransaction(transaction)
            autoSync()
        }
    }

    fun setFinanceBudget(category: String, periodKey: String, monthlyLimit: Long) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.setFinanceBudget(category, periodKey, monthlyLimit)
            autoSync()
        }
    }

    fun addSharedDebt(
        title: String,
        amount: Long,
        direction: String,
        note: String,
        dueAt: Long?
    ) {
        val ownDeviceId = identity.value?.deviceId ?: return
        val peerDeviceId = pairingSnapshot.value.trustedPeer?.deviceId ?: return
        val creditor = if (direction == "I_OWE") peerDeviceId else ownDeviceId
        val debtor = if (direction == "I_OWE") ownDeviceId else peerDeviceId
        viewModelScope.launch(Dispatchers.IO) {
            repository.addSharedDebt(title, amount, creditor, debtor, note, dueAt)
            autoSync()
        }
    }

    fun toggleDebtSettled(debt: SharedDebtEntity) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.toggleDebtSettled(debt)
            autoSync()
        }
    }

    fun deleteSharedDebt(debt: SharedDebtEntity) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.deleteSharedDebt(debt)
            autoSync()
        }
    }

    fun addRecurringTransaction(
        accountId: String,
        targetAccountId: String?,
        kind: String,
        amount: Long,
        category: String,
        note: String,
        interval: String,
        firstRunAt: Long
    ) {
        val deviceId = identity.value?.deviceId ?: return
        viewModelScope.launch(Dispatchers.IO) {
            repository.addRecurringTransaction(
                accountId, targetAccountId, kind, amount, category, note,
                interval, firstRunAt, deviceId
            )
            repository.materializeDueRecurringTransactions(deviceId)
            autoSync()
        }
    }

    fun toggleRecurringTransaction(rule: RecurringTransactionEntity) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.toggleRecurringTransaction(rule)
            autoSync()
        }
    }

    fun deleteRecurringTransaction(rule: RecurringTransactionEntity) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.deleteRecurringTransaction(rule)
            autoSync()
        }
    }

    fun addMemory(title: String, note: String, mood: String, occurredAt: Long) {
        val deviceId = identity.value?.deviceId ?: return
        viewModelScope.launch(Dispatchers.IO) {
            repository.addMemory(title, note, mood, deviceId, occurredAt)
            autoSync()
        }
    }

    fun updateMemory(memory: MemoryEntity, title: String, note: String, mood: String, occurredAt: Long) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.updateMemory(memory, title, note, mood, occurredAt)
            autoSync()
        }
    }

    fun toggleMemoryFavorite(memory: MemoryEntity) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.toggleMemoryFavorite(memory)
            autoSync()
        }
    }

    fun deleteMemory(memory: MemoryEntity) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.deleteMemory(memory)
            autoSync()
        }
    }

    fun setDailyMood(mood: String, note: String) {
        viewModelScope.launch(Dispatchers.IO) {
            runCatching {
                val deviceId = identityManager.getOrCreateIdentity().deviceId
                repository.setDailyMood(
                    deviceId,
                    com.ourspace.app.core.time.PersianDateFormatter.currentJalaliDayKey(),
                    mood,
                    note
                )
                // Wake the persistent duplex session so the change is pushed immediately on both roles.
                runCatching { HostServerService.requestImmediateSync(getApplication()) }
                autoSync()
            }.onFailure { error ->
                android.util.Log.e("OurSpace", "setDailyMood failed", error)
            }
        }
    }

    fun setMoodForDay(dayKey: String, mood: String, note: String) {
        viewModelScope.launch(Dispatchers.IO) {
            runCatching {
                val deviceId = identityManager.getOrCreateIdentity().deviceId
                repository.setDailyMood(deviceId, dayKey, mood, note)
                runCatching { HostServerService.requestImmediateSync(getApplication()) }
                autoSync()
            }.onFailure { error ->
                android.util.Log.e("OurSpace", "setMoodForDay failed", error)
            }
        }
    }

    
    
    fun clearHeartAnimation() {
        incomingHeartAnimation.value = false
    }

    fun acknowledgeLatestHeartPulse() {
        viewModelScope.launch(Dispatchers.IO) {
            val ownId = identityManager.getOrCreateIdentity().deviceId
            val pulse = repository.pendingHeartToAcknowledge(ownId)
            if (pulse != null) {
                repository.acknowledgeHeartPulse(pulse)
                autoSync()
                runCatching { syncNowInternal(silent = true) }
                heartAction.value = HeartActionState(message = "پاسخ «دیدم» ارسال شد")
            }
            incomingHeartAnimation.value = false
        }
    }

    fun sendHeartPulse() {
        viewModelScope.launch(Dispatchers.IO) {
            if (pairingSnapshot.value.trustedPeer == null) {
                heartAction.value = HeartActionState(error = "اول باید جفت‌سازی کنید.")
                return@launch
            }
            heartAction.value = HeartActionState(isSending = true)
            runCatching {
                val deviceId = identityManager.getOrCreateIdentity().deviceId
                repository.sendHeartPulse(deviceId)
                withContext(Dispatchers.Main) {
                    notificationCenter.playHeartbeatVibration()
                }
                autoSync()
                // Host also pushes path by relying on companion poll; try sync for companion.
                runCatching { syncNowInternal(silent = true) }
                heartAction.value = HeartActionState(message = "برای طرف مقابل فرستاده شد 💗")
                delay(2_500)
                if (heartAction.value.message != null) {
                    heartAction.value = HeartActionState()
                }
            }.onFailure { e ->
                heartAction.value = HeartActionState(error = e.message ?: "ارسال نشد")
            }
        }
    }

    fun setLocationSharingEnabled(enabled: Boolean) {
        viewModelScope.launch(Dispatchers.IO) {
            preferences.setLocationSharingEnabled(enabled)
            if (enabled) {
                publishLocationNow(silent = true)
                runCatching { HostServerService.start(getApplication()) }
            } else {
                val deviceId = identityManager.getOrCreateIdentity().deviceId
                repository.stopLocationSharing(deviceId)
            }
        }
    }

    /**
     * Requests the other paired phone to acquire a fresh location fix.
     * The other phone stores it locally first; the normal sync then returns the new point.
     */
    fun refreshPartnerLocation() {
        viewModelScope.launch(Dispatchers.IO) {
            locationAction.value = LocationActionState(isUpdating = true)
            runCatching {
                HostServerService.requestPartnerLocationRefresh(getApplication())
            }.onSuccess {
                locationAction.value = LocationActionState(
                    isUpdating = false,
                    message = "درخواست به‌روزرسانی موقعیت گوشی مقابل ارسال شد."
                )
            }.onFailure { error ->
                locationAction.value = LocationActionState(
                    error = error.message ?: "ارسال درخواست به‌روزرسانی موقعیت ناموفق بود."
                )
            }
        }
    }

    fun publishLocationNow(silent: Boolean = false) {
        viewModelScope.launch(Dispatchers.IO) {
            locationAction.value = LocationActionState(isUpdating = true)
            try {
                // Refresh must never implicitly opt the user back into location sharing.
                if (!preferences.isLocationSharingEnabled()) {
                    locationAction.value = LocationActionState(error = "برای به‌روزرسانی موقعیت، ابتدا اشتراک‌گذاری موقعیت را خودتان روشن کنید.")
                    return@launch
                }
                val publisher = LocationPublisher(getApplication())
                if (!publisher.hasPermission()) {
                    locationAction.value = LocationActionState(error = "مجوز موقعیت داده نشده است.")
                    return@launch
                }
                val fix = publisher.readCurrentLocation()
                    ?: throw IllegalStateException("موقعیت دریافت نشد. GPS یا اینترنت مکان را بررسی کنید.")
                val deviceId = identityManager.getOrCreateIdentity().deviceId
                repository.publishLocation(
                    deviceId = deviceId,
                    latitude = fix.latitude,
                    longitude = fix.longitude,
                    accuracyMeters = fix.accuracy,
                    isSharing = true
                )
                locationAction.value = LocationActionState(
                    message = if (silent) null else "موقعیت به‌روز شد. در حال همگام‌سازی…"
                )
                runCatching { HostServerService.start(getApplication()) }
                runCatching { syncNowInternal(silent = true) }
            } catch (e: Exception) {
                locationAction.value = LocationActionState(error = e.message ?: "خطا در دریافت موقعیت")
            }
        }
    }

    // Periodic location updates are owned by HostServerService so they continue while
    // the UI/ViewModel is not alive. Manual refresh remains available through publishLocationNow().

fun startPeriod(startAt: Long = System.currentTimeMillis(), flowLevel: String = "MEDIUM", note: String = "") {
        viewModelScope.launch(Dispatchers.IO) {
            val deviceId = identityManager.getOrCreateIdentity().deviceId
            repository.startPeriod(deviceId, startAt, flowLevel, note)
        }
    }

    fun endPeriod(log: CycleLogEntity, endAt: Long = System.currentTimeMillis()) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.endPeriod(log, endAt)
        }
    }

    fun deleteCycleLog(log: CycleLogEntity) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.deleteCycleLog(log)
        }
    }

    fun updateCycleSettings(averageCycleDays: Int, averagePeriodDays: Int, trackingEnabled: Boolean) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.updateCycleSettings(averageCycleDays, averagePeriodDays, trackingEnabled)
        }
    }

    fun addSpecialDate(title: String, note: String, occurredAt: Long, repeatYearly: Boolean) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.addSpecialDate(title, note, occurredAt, repeatYearly)
            autoSync()
        }
    }

    fun updateSpecialDate(specialDate: SpecialDateEntity, title: String, note: String, occurredAt: Long, repeatYearly: Boolean) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.updateSpecialDate(specialDate, title, note, occurredAt, repeatYearly)
            autoSync()
        }
    }

    fun deleteSpecialDate(specialDate: SpecialDateEntity) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.deleteSpecialDate(specialDate)
            autoSync()
        }
    }

    fun saveCoupleProfile(firstName: String, secondName: String, startedAt: Long?) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.saveCoupleProfile(firstName, secondName, startedAt)
            autoSync()
        }
    }

    /** Saves the user's OWN relay server endpoint and verifies it is reachable. */
    fun saveRelayConfig(enabled: Boolean, endpoint: String, accessToken: String = "") {
        relayAction.value = RelayActionState(isSaving = true)
        viewModelScope.launch(Dispatchers.IO) {
            try {
                preferences.setRelayConfig(enabled, endpoint, RelayConfig.DEFAULT_ACCESS_TOKEN)
                if (!enabled || endpoint.isBlank()) {
                    relayAction.value = RelayActionState(message = "سرور شخصی غیرفعال شد.")
                    return@launch
                }
                val reachable = RelayClient(
                    endpoint,
                    RelayCredentials.fromAccessToken(RelayConfig.DEFAULT_ACCESS_TOKEN)
                ).health()
                relayAction.value = if (reachable) {
                    RelayActionState(message = "سرور شخصی ذخیره شد و در دسترس است.")
                } else {
                    RelayActionState(error = "سرور ذخیره شد اما پاسخ نداد. آدرس سرور و اینترنت را بررسی کنید.")
                }
                runCatching { HostServerService.start(getApplication()) }
            } catch (error: Exception) {
                relayAction.value = RelayActionState(
                    error = error.message?.takeIf { it.isNotBlank() } ?: "ذخیره سرور ناموفق بود."
                )
            }
        }
    }

    /** Force a complete encrypted snapshot to the private relay server. */
    fun backupNow() {
        if (backupAction.value.isBusy) return
        backupAction.value = BackupActionState(isBusy = true, message = "در حال تهیه و ارسال پشتیبان رمزگذاری‌شده…")
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val config = preferences.currentRelayConfig()
                require(preferences.currentRole() == DeviceRole.HOST) { "تهیه پشتیبان کامل را از گوشی میزبان انجام بده؛ همراه ابتدا باید اطلاعاتش را با میزبان همگام کند." }
                require(config.isUsable) { "ابتدا سرور خصوصی را فعال و آدرس آن را ذخیره کن." }
                val snapshot = SyncSnapshotCodec(app.database, getApplication()).exportSnapshot(includeAttachments = true, schemaVersion = 6)
                val savedAt = RelayBackupClient(config.endpoint, config.accessToken).upload(snapshot)
                backupAction.value = BackupActionState(message = "پشتیبان کامل روی سرور ذخیره شد · ${com.ourspace.app.core.time.PersianDateFormatter.formatDateTime(savedAt)}")
            } catch (error: Exception) {
                backupAction.value = BackupActionState(error = error.message ?: "تهیه پشتیبان ناموفق بود.")
            }
        }
    }

    /** Merge a server snapshot into the local Room database without deleting local records. */
    fun restoreBackup() {
        if (backupAction.value.isBusy) return
        backupAction.value = BackupActionState(isBusy = true, message = "در حال دریافت و بازیابی اطلاعات…")
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val config = preferences.currentRelayConfig()
                require(config.isUsable) { "ابتدا آدرس سرور خصوصی را تنظیم کن." }
                val (savedAt, snapshot) = RelayBackupClient(config.endpoint, config.accessToken).download()
                SyncSnapshotCodec(app.database, getApplication()).mergeSnapshot(snapshot)
                com.ourspace.app.core.reminder.HabitReminderScheduler.scheduleAll(getApplication())
                runCatching { HostServerService.requestImmediateSync(getApplication()) }
                backupAction.value = BackupActionState(message = "بازیابی اطلاعات انجام شد · پشتیبان ${com.ourspace.app.core.time.PersianDateFormatter.formatDateTime(savedAt)}")
            } catch (error: Exception) {
                backupAction.value = BackupActionState(error = error.message ?: "بازیابی پشتیبان ناموفق بود.")
            }
        }
    }

    fun setPalette(palette: AppPalette) {
        viewModelScope.launch { preferences.setPalette(palette) }
    }

    fun setThemeMode(mode: AppThemeMode) {
        viewModelScope.launch { preferences.setThemeMode(mode) }
    }

    fun resetApp() {
        companionSyncLoop?.cancel()
        companionSyncLoop = null
        CompanionSyncWorker.cancel(getApplication())
        viewModelScope.launch(Dispatchers.IO) {
            HostServerService.stop(getApplication())
            pairingStore.clearAll()
            app.database.clearAllTables()
            preferences.reset()
            pairingAction.value = PairingActionState()
            syncState.value = SyncState()
            relayAction.value = RelayActionState()
            attachmentAction.value = AttachmentActionState()
        }
    }

    private fun importAttachment(uriValue: String, requireImage: Boolean = false): ImportedAttachment {
        val uri = Uri.parse(uriValue)
        val resolver = getApplication<Application>().contentResolver
        var fileName = if (requireImage) "تصویر خاطره" else "پیوست"
        var declaredSize = -1L
        resolver.query(
            uri,
            arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE),
            null,
            null,
            null
        )?.use { cursor ->
            if (cursor.moveToFirst()) {
                cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME).takeIf { it >= 0 }?.let { index ->
                    fileName = cursor.getString(index)?.take(180).orEmpty().ifEmpty { fileName }
                }
                cursor.getColumnIndex(OpenableColumns.SIZE).takeIf { it >= 0 }?.let { index ->
                    if (!cursor.isNull(index)) declaredSize = cursor.getLong(index)
                }
            }
        }
        if (declaredSize > MAX_ATTACHMENT_BYTES) {
            throw IOException("حجم پیوست باید حداکثر ۲۰ مگابایت باشد.")
        }
        val mimeType = resolver.getType(uri).orEmpty().ifEmpty { "application/octet-stream" }
        if (requireImage && !mimeType.startsWith("image/")) {
            throw IOException("برای خاطره باید یک تصویر انتخاب شود.")
        }
        val bytes = resolver.openInputStream(uri)?.use { readAttachmentBytes(it) }
            ?: throw IOException("فایل انتخاب‌شده قابل خواندن نیست.")
        if (requireImage || mimeType.startsWith("image/")) {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
            if (bounds.outWidth !in 1..MAX_IMAGE_DIMENSION || bounds.outHeight !in 1..MAX_IMAGE_DIMENSION) {
                bytes.fill(0)
                throw IOException("ساختار یا ابعاد تصویر انتخاب‌شده معتبر نیست.")
            }
            // Compress large photos so they always fit in one sync envelope and transfer faster.
            if (bytes.size > 400_000 && bounds.outWidth > 0) {
                val sample = when {
                    bounds.outWidth > 3200 || bounds.outHeight > 3200 -> 4
                    bounds.outWidth > 1600 || bounds.outHeight > 1600 -> 2
                    else -> 1
                }
                val opts = BitmapFactory.Options().apply { inSampleSize = sample }
                val bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts)
                if (bitmap != null) {
                    val out = ByteArrayOutputStream()
                    val ok = bitmap.compress(Bitmap.CompressFormat.JPEG, 82, out)
                    bitmap.recycle()
                    if (ok && out.size() in 1 until bytes.size) {
                        bytes.fill(0)
                        val compressed = out.toByteArray()
                        return ImportedAttachment(
                            fileName = fileName.replace(Regex("""\.(png|webp|heic)$""", RegexOption.IGNORE_CASE), ".jpg"),
                            mimeType = "image/jpeg",
                            content = compressed
                        )
                    }
                }
            }
        }
        return ImportedAttachment(fileName, mimeType, bytes)
    }

    private fun readAttachmentBytes(stream: InputStream): ByteArray {
        val output = ByteArrayOutputStream()
        val buffer = ByteArray(16 * 1024)
        while (true) {
            val count = stream.read(buffer)
            if (count < 0) break
            if (output.size() + count > MAX_ATTACHMENT_BYTES) {
                buffer.fill(0)
                throw IOException("حجم پیوست باید حداکثر ۲۰ مگابایت باشد.")
            }
            output.write(buffer, 0, count)
        }
        buffer.fill(0)
        val bytes = output.toByteArray()
        if (bytes.isEmpty()) throw IOException("فایل انتخاب‌شده خالی است.")
        return bytes
    }

    // ── Personal relay diagnostics ───────────────────────────────────────────

    val diagnostics: StateFlow<List<String>> = ConnectionDiagnostics.lines
    val syncHealth: StateFlow<ConnectionDiagnostics.Health> = ConnectionDiagnostics.health

    fun clearDiagnostics() = ConnectionDiagnostics.clear()

    /** Checks the actual internet transport used by synchronization. */
    fun runConnectionTest() {
        viewModelScope.launch(Dispatchers.IO) {
            ConnectionDiagnostics.log("── شروع تست سرور شخصی ──")
            val relay = preferences.currentRelayConfig()
            if (!relay.isUsable) {
                ConnectionDiagnostics.log("✗ سرور شخصی فعال نیست")
                ConnectionDiagnostics.log("تنظیمات → سرور خصوصی → آدرس را وارد کنید")
                ConnectionDiagnostics.log("── پایان تست ──")
                return@launch
            }
            ConnectionDiagnostics.log("آدرس: ${relay.endpoint}")
            try {
                val probeCreds = com.ourspace.app.core.relay.RelayCredentials(
                    mailboxId = "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA",
                    authToken = "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"
                )
                val healthClient = com.ourspace.app.core.relay.RelayClient(relay.endpoint, probeCreds)
                val health = healthClient.healthReport()
                if (!health.ok) {
                    ConnectionDiagnostics.log("✗ /health پاسخ نداد")
                    ConnectionDiagnostics.log("سرور ویندوز روشن است؟ پورت ۸۷۸۷ و DDNS؟")
                    ConnectionDiagnostics.log("── پایان تست ──")
                    return@launch
                }
                ConnectionDiagnostics.log("✓ /health OK (protocol=${health.protocol}, uptime=${health.uptimeSec}s)")
                ConnectionDiagnostics.log("  pending=${health.pendingMessages} mailboxes=${health.activeMailboxes}")

                val token = relay.accessToken
                if (token.isBlank()) {
                    ConnectionDiagnostics.log("⚠ کلید مشترک خانه خالی است — در تنظیمات وارد کن")
                    ConnectionDiagnostics.log("── پایان تست ──")
                    return@launch
                }
                try {
                    val credentials = com.ourspace.app.core.relay.RelayCredentials.fromAccessToken(token)
                    ConnectionDiagnostics.log("صندوق مشترک خانه: ${credentials.mailboxId.take(12)}…")
                    val client = com.ourspace.app.core.relay.RelayClient(relay.endpoint, credentials)
                    val dir = com.ourspace.app.core.relay.RelayDirection.TO_HOST
                    val testId = java.util.UUID.randomUUID().toString().replace("-", "").take(32)
                    val envelope = org.json.JSONObject()
                        .put("type", "connection_probe")
                        .put("sentAt", System.currentTimeMillis())
                    client.publish(direction = dir, envelope = envelope, messageId = testId)
                    ConnectionDiagnostics.log("✓ publish آزمایشی OK")
                    val got = client.receive(dir, limit = 20, waitSeconds = 0)
                    val found = got.any { it.messageId == testId }
                    ConnectionDiagnostics.log(if (found) "✓ receive آزمایشی OK" else "⚠ receive: پیام هنوز در صف نیست (ممکن است طبیعی باشد)")
                    client.acknowledge(dir, listOf(testId))
                    ConnectionDiagnostics.ack()
                    ConnectionDiagnostics.log("✓ ACK آزمایشی OK")
                    ConnectionDiagnostics.log("رفت‌وبرگشت همین گوشی تا رله سالم است؛ دریافت گوشی مقابل جداگانه بررسی می‌شود")
                    HostServerService.start(getApplication())
                    HostServerService.requestImmediateSync(getApplication())
                } catch (error: Exception) {
                    ConnectionDiagnostics.log("✗ FAIL — ${error.message ?: error.javaClass.simpleName}")
                    throw error
                }
            } catch (error: Exception) {
                ConnectionDiagnostics.log("✗ FAIL — ${error.message ?: error.javaClass.simpleName}")
            }
            ConnectionDiagnostics.log("── پایان تست ──")
        }
    }


    private companion object {

        /** While the direct channel is open, syncing is cheap, so poll briskly. */
        const val COMPANION_FAST_SYNC_INTERVAL = 3_000L
        const val NUDGE_DEBOUNCE_MS = 700L
        private const val LOCAL_TYPING_HEARTBEAT_MS = 2_500L
        private const val PEER_TYPING_TIMEOUT_MS = 6_000L
        const val RECURRING_CHECK_INTERVAL = 15 * 60 * 1000L
        const val MAX_ATTACHMENT_BYTES = 20 * 1024 * 1024
        const val MAX_IMAGE_DIMENSION = 24_000
    }
}
