package com.ourspace.app.model

enum class DeviceRole(val persistedName: String) {
    HOST("host"),
    COMPANION("companion");

    companion object {
        fun fromPersistedName(value: String?): DeviceRole? =
            entries.firstOrNull { it.persistedName == value }
    }
}
