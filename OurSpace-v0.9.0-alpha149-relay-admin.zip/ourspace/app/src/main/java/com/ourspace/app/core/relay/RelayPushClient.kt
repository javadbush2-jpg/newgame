package com.ourspace.app.core.relay

import android.util.Log
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicReference
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.channels.BufferOverflow
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONObject

/**
 * Persistent WebSocket to the personal relay (`/v1/push`) with automatic reconnect.
 *
 * The server never sends message bodies here — only a wake signal that new
 * encrypted mail is waiting on the HTTP mailbox API.
 *
 * Auth is sent only via Authorization header (token is not put in the URL)
 * so reverse-proxy access logs do not capture the household secret.
 */
class RelayPushClient(
    endpoint: String,
    private val accessToken: String,
    private val scope: CoroutineScope
) {
    private val baseHttp = RelayEndpointValidator.normalize(endpoint).trimEnd('/')
    private val wsUrl = toWebSocketUrl(baseHttp) + "/v1/push"

    private val client = OkHttpClient.Builder()
        .connectTimeout(12, TimeUnit.SECONDS)
        .readTimeout(0, TimeUnit.MILLISECONDS)
        .writeTimeout(15, TimeUnit.SECONDS)
        .pingInterval(20, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .build()

    private val socketRef = AtomicReference<WebSocket?>(null)
    private val open = AtomicBoolean(false)
    private val running = AtomicBoolean(false)
    private var reconnectJob: Job? = null
    private var failures = 0

    private val _events = MutableSharedFlow<PushEvent>(
        extraBufferCapacity = 32,
        onBufferOverflow = BufferOverflow.DROP_OLDEST
    )
    val events: SharedFlow<PushEvent> = _events.asSharedFlow()

    val isConnected: Boolean get() = open.get()

    fun connect() {
        if (!running.compareAndSet(false, true)) {
            // Already running — ensure a socket attempt exists
            if (socketRef.get() == null) openSocket()
            return
        }
        failures = 0
        openSocket()
    }

    fun close() {
        running.set(false)
        reconnectJob?.cancel()
        reconnectJob = null
        open.set(false)
        val sock = socketRef.getAndSet(null)
        runCatching { sock?.close(1000, "bye") }
    }

    private fun openSocket() {
        if (!running.get()) return
        // Avoid duplicate sockets
        if (socketRef.get() != null) return
        val request = Request.Builder()
            .url(wsUrl)
            .header("Authorization", "Bearer $accessToken")
            .header("Sec-WebSocket-Protocol", "ourspace-push")
            .build()
        val ws = client.newWebSocket(request, Listener())
        socketRef.set(ws)
        Log.i(TAG, "ws connecting $wsUrl")
    }

    private fun scheduleReconnect() {
        if (!running.get()) return
        reconnectJob?.cancel()
        reconnectJob = scope.launch {
            failures += 1
            val wait = minOf(15_000L, 500L * (1L shl minOf(failures - 1, 4)))
            Log.i(TAG, "ws reconnect in ${wait}ms (attempt $failures)")
            delay(wait)
            if (!running.get() || !isActive) return@launch
            socketRef.set(null)
            openSocket()
        }
    }

    private inner class Listener : WebSocketListener() {
        override fun onOpen(webSocket: WebSocket, response: Response) {
            if (socketRef.get() != webSocket) {
                webSocket.close(1000, "stale")
                return
            }
            open.set(true)
            failures = 0
            Log.i(TAG, "ws open")
            _events.tryEmit(PushEvent.Connected)
        }

        override fun onMessage(webSocket: WebSocket, text: String) {
            if (socketRef.get() != webSocket) return
            try {
                val json = JSONObject(text)
                when (json.optString("type")) {
                    "hello" -> _events.tryEmit(PushEvent.Connected)
                    "ping" -> webSocket.send("""{"type":"pong"}""")
                    "mail" -> {
                        val direction = json.optString("direction")
                        _events.tryEmit(PushEvent.Mail(direction))
                    }
                    else -> Unit
                }
            } catch (error: Exception) {
                Log.w(TAG, "ws message parse: ${error.message}")
            }
        }

        override fun onClosing(webSocket: WebSocket, code: Int, reason: String) {
            if (socketRef.compareAndSet(webSocket, null)) {
                open.set(false)
                runCatching { webSocket.close(code, reason) }
            }
        }

        override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
            if (socketRef.compareAndSet(webSocket, null)) {
                open.set(false)
            }
            _events.tryEmit(PushEvent.Disconnected)
            Log.i(TAG, "ws closed code=$code")
            scheduleReconnect()
        }

        override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
            if (socketRef.compareAndSet(webSocket, null)) {
                open.set(false)
            }
            _events.tryEmit(PushEvent.Disconnected)
            Log.w(TAG, "ws failure: ${t.message}")
            scheduleReconnect()
        }
    }

    sealed class PushEvent {
        data object Connected : PushEvent()
        data object Disconnected : PushEvent()
        data class Mail(val direction: String) : PushEvent()
    }

    companion object {
        private const val TAG = "OurSpacePush"

        fun toWebSocketUrl(httpBase: String): String {
            val trimmed = httpBase.trimEnd('/')
            return when {
                trimmed.startsWith("https://") -> "wss://" + trimmed.removePrefix("https://")
                trimmed.startsWith("http://") -> "ws://" + trimmed.removePrefix("http://")
                else -> "ws://$trimmed"
            }
        }
    }
}
