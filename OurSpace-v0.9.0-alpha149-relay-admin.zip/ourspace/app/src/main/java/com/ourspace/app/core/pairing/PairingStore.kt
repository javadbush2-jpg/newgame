package com.ourspace.app.core.pairing

import java.security.MessageDigest

import android.content.Context
import android.content.SharedPreferences
import com.ourspace.app.core.security.DeviceIdentityManager
import java.nio.charset.StandardCharsets
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow

class PairingStore(context: Context) {
    enum class RequestStatus { PENDING, APPROVED, REJECTED }

    data class IncomingRequest(
        val requestId: String,
        val deviceId: String,
        val fingerprint: String,
        val verificationCode: String,
        val status: RequestStatus
    )

    data class OutgoingRequest(
        val requestId: String,
        val hostDeviceId: String,
        val hostFingerprint: String,
        val host: String,
        val port: Int,
        val verificationCode: String,
        val status: RequestStatus
    )

    data class TrustedPeer(
        val deviceId: String,
        val fingerprint: String,
        val pairedAt: Long
    )

    data class Snapshot(
        val incoming: IncomingRequest? = null,
        val outgoing: OutgoingRequest? = null,
        val trustedPeer: TrustedPeer? = null
    )

    private val preferences = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    private val secretBox = SecretBox()
    private val identityManager = DeviceIdentityManager()

    fun observe(): Flow<Snapshot> = callbackFlow {
        val listener = SharedPreferences.OnSharedPreferenceChangeListener { _, _ -> trySend(readSnapshot()) }
        preferences.registerOnSharedPreferenceChangeListener(listener)
        trySend(readSnapshot())
        awaitClose { preferences.unregisterOnSharedPreferenceChangeListener(listener) }
    }

    fun receiveIncoming(
        requestId: String,
        deviceId: String,
        fingerprint: String,
        secret: ByteArray
    ): RequestStatus {
        val trustedId = preferences.getString(KEY_TRUSTED_DEVICE, null)
        if (trustedId != null && trustedId != deviceId) return RequestStatus.REJECTED

        preferences.edit()
            .putString(KEY_IN_ID, requestId)
            .putString(KEY_IN_DEVICE, deviceId)
            .putString(KEY_IN_FINGERPRINT, fingerprint)
            .putString(KEY_IN_SECRET, secretBox.seal(secret))
            .putString(KEY_IN_STATUS, RequestStatus.PENDING.name)
            .apply()
        return RequestStatus.PENDING
    }

    fun approveIncoming() {
        val requestId = preferences.getString(KEY_IN_ID, null) ?: return
        val deviceId = preferences.getString(KEY_IN_DEVICE, null) ?: return
        val fingerprint = preferences.getString(KEY_IN_FINGERPRINT, null) ?: return
        val secret = preferences.getString(KEY_IN_SECRET, null) ?: return
        preferences.edit()
            .putString(KEY_IN_STATUS, RequestStatus.APPROVED.name)
            .putString(KEY_TRUSTED_DEVICE, deviceId)
            .putString(KEY_TRUSTED_FINGERPRINT, fingerprint)
            .putString(KEY_TRUSTED_SECRET, secret)
            .putLong(KEY_TRUSTED_AT, System.currentTimeMillis())
            .putString(KEY_APPROVED_REQUEST, requestId)
            .apply()
    }

    fun rejectIncoming() {
        if (preferences.contains(KEY_IN_ID)) {
            preferences.edit().putString(KEY_IN_STATUS, RequestStatus.REJECTED.name).apply()
        }
    }

    fun incomingStatus(requestId: String): RequestStatus? {
        if (preferences.getString(KEY_IN_ID, null) != requestId) return null
        return preferences.getString(KEY_IN_STATUS, null)?.let(RequestStatus::valueOf)
    }

    fun approvalProof(requestId: String): String? {
        if (incomingStatus(requestId) != RequestStatus.APPROVED) return null
        val sealedSecret = preferences.getString(KEY_IN_SECRET, null) ?: return null
        val secret = secretBox.open(sealedSecret)
        return try {
            createProof(secret, requestId)
        } finally {
            secret.fill(0)
        }
    }

    fun saveOutgoing(
        requestId: String,
        hostDeviceId: String,
        hostFingerprint: String,
        host: String,
        port: Int,
        secret: ByteArray
    ) {
        preferences.edit()
            .putString(KEY_OUT_ID, requestId)
            .putString(KEY_OUT_DEVICE, hostDeviceId)
            .putString(KEY_OUT_FINGERPRINT, hostFingerprint)
            .putString(KEY_OUT_HOST, host)
            .putInt(KEY_OUT_PORT, port)
            .putString(KEY_OUT_SECRET, secretBox.seal(secret))
            .putString(KEY_OUT_STATUS, RequestStatus.PENDING.name)
            .apply()
    }

    /**
     * One-scan pairing (v=4): the host embeds a ready shared secret inside its invite QR.
     * The same secret is reused while the invite stays valid so the QR can be reopened.
     */
    fun getOrCreateInviteSecret(): ByteArray {
        preferences.getString(KEY_INVITE_SECRET, null)?.let { return secretBox.open(it) }
        val secret = identityManager.createPairingSecret()
        preferences.edit().putString(KEY_INVITE_SECRET, secretBox.seal(secret)).apply()
        return secret
    }

    /** Host side: become connected immediately, without waiting for an approval round-trip. */
    fun trustInviteAsHost(secret: ByteArray, peerLabel: String) {
        preferences.edit()
            .putString(KEY_TRUSTED_DEVICE, peerLabel)
            .putString(KEY_TRUSTED_FINGERPRINT, identityManager.verificationCode(secret))
            .putString(KEY_TRUSTED_SECRET, secretBox.seal(secret))
            .putLong(KEY_TRUSTED_AT, System.currentTimeMillis())
            .apply()
    }

    /** Companion side: a single scan of the host invite is enough to be fully paired. */
    fun trustInviteAsCompanion(
        hostDeviceId: String,
        hostFingerprint: String,
        host: String,
        port: Int,
        secret: ByteArray
    ) {
        val sealed = secretBox.seal(secret)
        preferences.edit()
            .putString(KEY_OUT_ID, java.util.UUID.randomUUID().toString())
            .putString(KEY_OUT_DEVICE, hostDeviceId)
            .putString(KEY_OUT_FINGERPRINT, hostFingerprint)
            .putString(KEY_OUT_HOST, host)
            .putInt(KEY_OUT_PORT, port)
            .putString(KEY_OUT_SECRET, sealed)
            .putString(KEY_OUT_STATUS, RequestStatus.APPROVED.name)
            .putString(KEY_TRUSTED_DEVICE, hostDeviceId)
            .putString(KEY_TRUSTED_FINGERPRINT, hostFingerprint)
            .putString(KEY_TRUSTED_SECRET, sealed)
            .putLong(KEY_TRUSTED_AT, System.currentTimeMillis())
            .apply()
    }

    fun outgoingSecret(): ByteArray? = preferences.getString(KEY_OUT_SECRET, null)?.let(secretBox::open)

    /** Device id of the paired host (companion side) — stable across secret rotations. */
    fun trustedPeerDeviceId(): String? =
        preferences.getString(KEY_OUT_DEVICE, null)?.takeIf { it.isNotBlank() }

    fun trustedSecret(): ByteArray? = preferences.getString(KEY_TRUSTED_SECRET, null)?.let(secretBox::open)

    fun trustedHostEndpoint(): Pair<String, Int>? {
        val host = preferences.getString(KEY_OUT_HOST, null)?.takeIf { it.isNotBlank() } ?: return null
        val port = preferences.getInt(KEY_OUT_PORT, 0)
        if (port !in 1..65535) return null
        return host to port
    }

    fun markOutgoingApproved(): Boolean {
        val deviceId = preferences.getString(KEY_OUT_DEVICE, null) ?: return false
        val fingerprint = preferences.getString(KEY_OUT_FINGERPRINT, null) ?: return false
        val secret = preferences.getString(KEY_OUT_SECRET, null) ?: return false
        preferences.edit()
            .putString(KEY_OUT_STATUS, RequestStatus.APPROVED.name)
            .putString(KEY_TRUSTED_DEVICE, deviceId)
            .putString(KEY_TRUSTED_FINGERPRINT, fingerprint)
            .putString(KEY_TRUSTED_SECRET, secret)
            .putLong(KEY_TRUSTED_AT, System.currentTimeMillis())
            .apply()
        return true
    }

    fun markOutgoingRejected() = clearOutgoing()

    fun clearOutgoing() {
        preferences.edit()
            .remove(KEY_OUT_ID)
            .remove(KEY_OUT_DEVICE)
            .remove(KEY_OUT_FINGERPRINT)
            .remove(KEY_OUT_HOST)
            .remove(KEY_OUT_PORT)
            .remove(KEY_OUT_SECRET)
            .remove(KEY_OUT_STATUS)
            .apply()
    }

    fun verifyProof(requestId: String, proof: String): Boolean {
        val secret = outgoingSecret() ?: return false
        return try {
            constantTimeEquals(createProof(secret, requestId), proof)
        } finally {
            secret.fill(0)
        }
    }

    /**
     * Simple couple link: both phones enter the same 4-digit code.
     * Derives a stable shared secret (not used for mailbox — household token handles that).
     */
    fun pairWithPin(pin: String) {
        val normalizedPin = com.ourspace.app.core.relay.RelayPinClient.normalizePin(pin)
        require(normalizedPin.length == 4 && normalizedPin.all { it in '0'..'9' }) { "کد باید دقیقاً ۴ رقم باشد" }
        val secret = MessageDigest.getInstance("SHA-256")
            .digest("OurSpacePinV1:$normalizedPin".toByteArray(Charsets.UTF_8))
        try {
            preferences.edit()
                .putString(KEY_TRUSTED_DEVICE, "pin-peer")
                .putString(KEY_TRUSTED_FINGERPRINT, identityManager.verificationCode(secret))
                .putString(KEY_TRUSTED_SECRET, secretBox.seal(secret))
                .putLong(KEY_TRUSTED_AT, System.currentTimeMillis())
                .remove(KEY_IN_ID)
                .remove(KEY_OUT_ID)
                .apply()
        } finally {
            secret.fill(0)
        }
    }

    fun revokeTrust() = preferences.edit().clear().apply()

    fun clearAll() = preferences.edit().clear().apply()

    private fun verificationCodeForSealed(sealed: String): String {
        val secret = secretBox.open(sealed)
        return try {
            identityManager.verificationCode(secret)
        } finally {
            secret.fill(0)
        }
    }

    private fun readSnapshot(): Snapshot {
        val incomingId = preferences.getString(KEY_IN_ID, null)
        val incoming = incomingId?.let {
            val sealed = preferences.getString(KEY_IN_SECRET, null)
            IncomingRequest(
                requestId = it,
                deviceId = preferences.getString(KEY_IN_DEVICE, "") ?: "",
                fingerprint = preferences.getString(KEY_IN_FINGERPRINT, "") ?: "",
                verificationCode = sealed?.let(::verificationCodeForSealed).orEmpty(),
                status = preferences.getString(KEY_IN_STATUS, RequestStatus.PENDING.name)
                    ?.let(RequestStatus::valueOf) ?: RequestStatus.PENDING
            )
        }
        val outgoingId = preferences.getString(KEY_OUT_ID, null)
        val outgoing = outgoingId?.let {
            OutgoingRequest(
                requestId = it,
                hostDeviceId = preferences.getString(KEY_OUT_DEVICE, "") ?: "",
                hostFingerprint = preferences.getString(KEY_OUT_FINGERPRINT, "") ?: "",
                host = preferences.getString(KEY_OUT_HOST, "") ?: "",
                port = preferences.getInt(KEY_OUT_PORT, 8765),
                verificationCode = preferences.getString(KEY_OUT_SECRET, null)
                    ?.let(::verificationCodeForSealed).orEmpty(),
                status = preferences.getString(KEY_OUT_STATUS, RequestStatus.PENDING.name)
                    ?.let(RequestStatus::valueOf) ?: RequestStatus.PENDING
            )
        }
        val trustedId = preferences.getString(KEY_TRUSTED_DEVICE, null)
        val trusted = trustedId?.let {
            TrustedPeer(
                deviceId = it,
                fingerprint = preferences.getString(KEY_TRUSTED_FINGERPRINT, "") ?: "",
                pairedAt = preferences.getLong(KEY_TRUSTED_AT, 0L)
            )
        }
        return Snapshot(incoming, outgoing, trusted)
    }

    companion object {
        fun createProof(secret: ByteArray, requestId: String): String {
            val mac = Mac.getInstance("HmacSHA256")
            mac.init(SecretKeySpec(secret, "HmacSHA256"))
            val bytes = mac.doFinal("ourspace-approved:$requestId".toByteArray(StandardCharsets.UTF_8))
            return java.util.Base64.getUrlEncoder().withoutPadding().encodeToString(bytes)
        }

        private fun constantTimeEquals(first: String, second: String): Boolean {
            val a = first.toByteArray(StandardCharsets.UTF_8)
            val b = second.toByteArray(StandardCharsets.UTF_8)
            return java.security.MessageDigest.isEqual(a, b)
        }

        private const val PREFS = "ourspace_pairing_store_v2"
        private const val KEY_IN_ID = "incoming_id"
        private const val KEY_IN_DEVICE = "incoming_device"
        private const val KEY_IN_FINGERPRINT = "incoming_fingerprint"
        private const val KEY_IN_SECRET = "incoming_secret"
        private const val KEY_IN_STATUS = "incoming_status"
        private const val KEY_APPROVED_REQUEST = "approved_request"
        private const val KEY_OUT_ID = "outgoing_id"
        private const val KEY_OUT_DEVICE = "outgoing_device"
        private const val KEY_OUT_FINGERPRINT = "outgoing_fingerprint"
        private const val KEY_OUT_HOST = "outgoing_host"
        private const val KEY_OUT_PORT = "outgoing_port"
        private const val KEY_OUT_SECRET = "outgoing_secret"
        private const val KEY_OUT_STATUS = "outgoing_status"
        private const val KEY_TRUSTED_DEVICE = "trusted_device"
        private const val KEY_TRUSTED_FINGERPRINT = "trusted_fingerprint"
        private const val KEY_TRUSTED_SECRET = "trusted_secret"
        private const val KEY_INVITE_SECRET = "invite_secret"
        private const val KEY_TRUSTED_AT = "trusted_at"
    }
}
