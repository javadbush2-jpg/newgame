package com.ourspace.app.ui.theme

enum class AppPalette(val persistedName: String, val persianLabel: String) {
    ROSE("rose", "رز عاشقانه"),
    OCEAN("ocean", "اقیانوس آرام"),
    FOREST("forest", "جنگل زنده"),
    SUNSET("sunset", "غروب گرم"),
    LAVENDER("lavender", "اسطوخودوس"),
    MIDNIGHT("midnight", "نیمه‌شب"),
    HONEY("honey", "عسل طلایی");

    companion object {
        fun fromPersistedName(value: String?): AppPalette =
            entries.firstOrNull { it.persistedName == value } ?: ROSE
    }
}

enum class AppThemeMode(val persistedName: String, val persianLabel: String) {
    SYSTEM("system", "خودکار"),
    LIGHT("light", "روشن"),
    DARK("dark", "تاریک");

    companion object {
        fun fromPersistedName(value: String?): AppThemeMode =
            entries.firstOrNull { it.persistedName == value } ?: SYSTEM
    }
}


enum class AppFontFamily(val persistedName: String, val persianLabel: String) {
    SANS("sans", "ساده"),
    SERIF("serif", "کلاسیک"),
    MONO("mono", "تک‌فاصله");

    companion object {
        fun fromPersistedName(value: String?): AppFontFamily = entries.firstOrNull { it.persistedName == value } ?: SANS
    }
}
