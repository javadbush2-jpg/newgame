package com.ourspace.app.core.webrtc

import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.nio.charset.StandardCharsets
import java.util.zip.Deflater
import java.util.zip.Inflater

/**
 * Compact encoding of WebRTC Offer / Answer so it fits reasonably in a QR code.
 * Format (after inflation):
 * {
 *   "v": 1,
 *   "t": "offer" | "answer",
 *   "sdp": "...",
 *   "c": [ { "c": candidate, "m": mid, "i": sdpMLineIndex }, ... ]
 * }
 */
object WebRtcSignaling {

    data class Signal(
        val type: Type,
        val sdp: String,
        val candidates: List<IceCandidatePayload>
    ) {
        enum class Type { OFFER, ANSWER }
    }

    data class IceCandidatePayload(
        val candidate: String,
        val sdpMid: String?,
        val sdpMLineIndex: Int
    )

    fun encode(signal: Signal): String {
        val json = JSONObject()
            .put("v", WebRtcConfig.PROTOCOL_VERSION)
            .put("t", if (signal.type == Signal.Type.OFFER) "offer" else "answer")
            .put("sdp", signal.sdp)
        val arr = JSONArray()
        for (c in signal.candidates) {
            arr.put(
                JSONObject()
                    .put("c", c.candidate)
                    .put("m", c.sdpMid ?: "")
                    .put("i", c.sdpMLineIndex)
            )
        }
        json.put("c", arr)
        val raw = json.toString().toByteArray(StandardCharsets.UTF_8)
        val compressed = deflate(raw)
        return "OSW1:" + Base64.encodeToString(compressed, Base64.URL_SAFE or Base64.NO_WRAP)
    }

    fun decode(payload: String): Signal {
        val cleaned = payload.trim().replace(Regex("\\s+"), "")
        // Accept accidental whitespace/newlines from QR scanners or paste.
        require(cleaned.startsWith("OSW1:")) {
            "کد QR اتصال معتبر نیست. باید با OSW1: شروع شود و کامل اسکن شود."
        }
        val compressed = try {
            Base64.decode(
                cleaned.removePrefix("OSW1:"),
                Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING
            )
        } catch (e: Exception) {
            throw IllegalArgumentException("کد QR خراب یا ناقص است. دوباره بسازید و اسکن کنید.", e)
        }
        val raw = try {
            inflate(compressed)
        } catch (e: Exception) {
            throw IllegalArgumentException("کد QR قابل خواندن نیست. احتمالاً ناقص اسکن شده.", e)
        }
        val json = try {
            JSONObject(String(raw, StandardCharsets.UTF_8))
        } catch (e: Exception) {
            throw IllegalArgumentException("محتوای QR معتبر نیست.", e)
        }
        require(json.optInt("v") == WebRtcConfig.PROTOCOL_VERSION) {
            "نسخه سیگنالینگ پشتیبانی نمی‌شود. هر دو گوشی را به یک نسخه به‌روز کنید."
        }
        val type = when (json.optString("t")) {
            "offer" -> Signal.Type.OFFER
            "answer" -> Signal.Type.ANSWER
            else -> throw IllegalArgumentException("نوع سیگنال QR معتبر نیست.")
        }
        val sdp = json.getString("sdp")
        val candidates = mutableListOf<IceCandidatePayload>()
        val arr = json.optJSONArray("c") ?: JSONArray()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            candidates += IceCandidatePayload(
                candidate = o.getString("c"),
                sdpMid = o.optString("m").takeIf { it.isNotBlank() },
                sdpMLineIndex = o.optInt("i", 0)
            )
        }
        return Signal(type, sdp, candidates)
    }

    private fun deflate(input: ByteArray): ByteArray {
        val deflater = Deflater(Deflater.BEST_COMPRESSION)
        deflater.setInput(input)
        deflater.finish()
        val buffer = ByteArray(input.size + 64)
        val size = deflater.deflate(buffer)
        deflater.end()
        return buffer.copyOf(size)
    }

    private fun inflate(input: ByteArray): ByteArray {
        val inflater = Inflater()
        inflater.setInput(input)
        val out = java.io.ByteArrayOutputStream(input.size * 4)
        val buffer = ByteArray(16 * 1024)
        while (!inflater.finished()) {
            val n = inflater.inflate(buffer)
            if (n == 0 && inflater.needsInput()) break
            out.write(buffer, 0, n)
            if (out.size() > 512 * 1024) {
                inflater.end()
                throw IllegalArgumentException("سیگنال بیش از حد بزرگ است.")
            }
        }
        inflater.end()
        return out.toByteArray()
    }
}
