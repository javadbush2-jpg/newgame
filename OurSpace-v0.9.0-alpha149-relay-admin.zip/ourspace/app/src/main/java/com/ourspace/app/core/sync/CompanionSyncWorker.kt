package com.ourspace.app.core.sync

import android.content.Context
import androidx.work.BackoffPolicy
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.ourspace.app.OurSpaceApplication
import com.ourspace.app.core.preferences.AppPreferences
import com.ourspace.app.core.security.DeviceIdentityManager
import com.ourspace.app.core.server.HostServerService
import com.ourspace.app.model.DeviceRole
import java.util.concurrent.TimeUnit

/**
 * Background wake/recovery for relay sync.
 *
 * Real-time delivery is owned by [HostServerService] + [com.ourspace.app.core.relay.RelayDuplexPoller].
 * Android may kill the process when the app is not visible; this worker periodically
 * restarts the foreground service for BOTH host and companion so updates continue
 * without opening the UI.
 */
class CompanionSyncWorker(
    appContext: Context,
    params: WorkerParameters
) : CoroutineWorker(appContext, params) {
    override suspend fun doWork(): Result {
        val preferences = AppPreferences(applicationContext)
        val role = preferences.currentRole()
        if (role != DeviceRole.HOST && role != DeviceRole.COMPANION) {
            return Result.success()
        }
        if (!preferences.currentRelayConfig().isUsable) {
            return Result.success()
        }

        return runCatching {
            val app = applicationContext as OurSpaceApplication
            val ownDeviceId = DeviceIdentityManager().getOrCreateIdentity().deviceId
            runCatching { app.repository.materializeDueRecurringTransactions(ownDeviceId) }

            // Bring the duplex poller back if the process or FGS was killed.
            HostServerService.requestImmediateSync(applicationContext)

            // Chain the next short wake (WorkManager min periodic is 15m; this is tighter).
            if (inputData.getBoolean(KEY_RESCHEDULE, true)) {
                scheduleNextKeepAlive(applicationContext)
            }
            Result.success()
        }.getOrElse {
            scheduleNextKeepAlive(applicationContext)
            if (runAttemptCount < MAX_RETRIES) Result.retry() else Result.failure()
        }
    }

    companion object {
        private const val PERIODIC_WORK = "ourspace_companion_periodic_sync"
        private const val IMMEDIATE_WORK = "ourspace_companion_immediate_sync"
        private const val KEEPALIVE_WORK = "ourspace_relay_keepalive"
        private const val KEY_RESCHEDULE = "reschedule"
        private const val MAX_RETRIES = 5
        /** Target wake interval while OS allows WorkManager to run. */
        private const val KEEPALIVE_MINUTES = 5L

        private val networkConstraints = Constraints.Builder()
            .setRequiredNetworkType(NetworkType.CONNECTED)
            .build()

        /**
         * Call whenever the device is paired (host or companion).
         * Safe to call repeatedly — unique work policies keep a single schedule.
         */
        fun schedule(context: Context) {
            val appContext = context.applicationContext
            val periodic = PeriodicWorkRequestBuilder<CompanionSyncWorker>(15, TimeUnit.MINUTES)
                .setConstraints(networkConstraints)
                .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 30, TimeUnit.SECONDS)
                .build()
            WorkManager.getInstance(appContext).enqueueUniquePeriodicWork(
                PERIODIC_WORK,
                ExistingPeriodicWorkPolicy.UPDATE,
                periodic
            )
            // First keep-alive soon; subsequent ones self-chain every KEEPALIVE_MINUTES.
            scheduleNextKeepAlive(appContext, initialDelayMinutes = 1L)
            runSoon(appContext)
        }

        fun runSoon(context: Context) {
            val request = OneTimeWorkRequestBuilder<CompanionSyncWorker>()
                .setConstraints(networkConstraints)
                .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 20, TimeUnit.SECONDS)
                .setInputData(
                    androidx.work.Data.Builder().putBoolean(KEY_RESCHEDULE, false).build()
                )
                .build()
            WorkManager.getInstance(context.applicationContext).enqueueUniqueWork(
                IMMEDIATE_WORK,
                ExistingWorkPolicy.REPLACE,
                request
            )
        }

        private fun scheduleNextKeepAlive(context: Context, initialDelayMinutes: Long = KEEPALIVE_MINUTES) {
            val request = OneTimeWorkRequestBuilder<CompanionSyncWorker>()
                .setConstraints(networkConstraints)
                .setInitialDelay(initialDelayMinutes.coerceAtLeast(1L), TimeUnit.MINUTES)
                .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 20, TimeUnit.SECONDS)
                .setInputData(
                    androidx.work.Data.Builder().putBoolean(KEY_RESCHEDULE, true).build()
                )
                .build()
            WorkManager.getInstance(context.applicationContext).enqueueUniqueWork(
                KEEPALIVE_WORK,
                ExistingWorkPolicy.REPLACE,
                request
            )
        }

        fun cancel(context: Context) {
            val wm = WorkManager.getInstance(context.applicationContext)
            wm.cancelUniqueWork(PERIODIC_WORK)
            wm.cancelUniqueWork(IMMEDIATE_WORK)
            wm.cancelUniqueWork(KEEPALIVE_WORK)
        }
    }
}
