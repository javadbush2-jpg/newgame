package com.ourspace.app.feature.home

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.ourspace.app.core.time.PersianDateFormatter
import com.ourspace.app.core.webrtc.ConnectionDiagnostics

/**
 * Shows exactly what the connection pipeline is doing, so a failure can be identified
 * instead of guessed at.
 */
@Composable
fun DiagnosticsPanel(
    lines: List<String>,
    health: com.ourspace.app.core.webrtc.ConnectionDiagnostics.Health = com.ourspace.app.core.webrtc.ConnectionDiagnostics.Health(),
    onRunTest: () -> Unit,
    onClear: () -> Unit
) {
    var expanded by remember { mutableStateOf(false) }
    val context = LocalContext.current
    val inboxSummary = if (health.lastInboundPollAt > 0L) {
        "صندوق ${health.lastInboundDirection} · آخرین بررسی ${PersianDateFormatter.formatTime(health.lastInboundPollAt)} · " +
            "${health.lastInboundBatchSize} پیام در آخرین پاسخ · ${health.inboundPollCount} بررسی موفق"
    } else {
        "هنوز خواندن احراز‌شدهٔ صندوق دریافت ثبت نشده است"
    }
    val reportText = buildString {
        append("وضعیت: ${ConnectionDiagnostics.statusLabelFa(health)}")
        append("\n")
        append(inboxSummary)
        if (lines.isNotEmpty()) {
            append("\n")
            append(lines.joinToString("\n"))
        }
    }

    Column(Modifier.fillMaxWidth()) {
        TextButton(
            onClick = { expanded = !expanded },
            modifier = Modifier.fillMaxWidth()
        ) { Text(if (expanded) "بستن عیب‌یابی اتصال" else "عیب‌یابی اتصال") }

        if (expanded) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(26.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceContainerLow
                ),
                elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
            ) {
                Column(Modifier.padding(18.dp)) {
                    Text("سلامت همگام‌سازی", fontWeight = FontWeight.Black)
                    Text(
                        "وضعیت: ${ConnectionDiagnostics.statusLabelFa(health)}  ·  Pending در لحظه از وضعیت صف برنامه نمایش داده می‌شود",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                    Row(
                        Modifier.fillMaxWidth().padding(vertical = 10.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        HealthChip("ارسال", health.sentCount.toString(), Modifier.weight(1f))
                        HealthChip("دریافت", health.receivedCount.toString(), Modifier.weight(1f))
                        HealthChip("ACK رله", health.ackCount.toString(), Modifier.weight(1f))
                        HealthChip("Latency", if (health.lastLatencyMs >= 0) "${health.lastLatencyMs}ms" else "—", Modifier.weight(1f))
                    }
                    Text(
                        inboxSummary,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(bottom = 10.dp)
                    )
                    Text("گزارش اتصال", fontWeight = FontWeight.Black)
                    Text(
                        "تست سرور فقط دسترسی همین گوشی به رله را می‌سنجد؛ دریافت صندوق جداگانه در وضعیت بالا ثبت می‌شود.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(top = 4.dp, bottom = 10.dp)
                    )

                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(onClick = onRunTest, modifier = Modifier.weight(1f)) {
                            Text("تست سرور")
                        }
                        OutlinedButton(
                            onClick = { copyReport(context, reportText) },
                            modifier = Modifier.weight(1f)
                        ) { Text("کپی گزارش") }
                        OutlinedButton(onClick = onClear) { Text("پاک") }
                    }

                    Column(
                        Modifier
                            .fillMaxWidth()
                            .heightIn(max = 260.dp)
                            .verticalScroll(rememberScrollState())
                            .padding(top = 10.dp)
                    ) {
                        if (lines.isEmpty()) {
                            Text(
                                "هنوز گزارشی ثبت نشده است.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        } else {
                            lines.asReversed().forEach { line ->
                                Text(
                                    line,
                                    style = MaterialTheme.typography.bodySmall,
                                    modifier = Modifier.padding(vertical = 1.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

private fun copyReport(context: Context, text: String) {
    val manager = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
    manager?.setPrimaryClip(ClipData.newPlainText("OurSpace diagnostics", text))
}


@Composable
private fun HealthChip(label: String, value: String, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(Modifier.padding(10.dp)) {
            Text(value, fontWeight = FontWeight.Black)
            Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

private fun com.ourspace.app.core.webrtc.ConnectionDiagnostics.ConnectionState.persianLabel(): String = when (this) {
    com.ourspace.app.core.webrtc.ConnectionDiagnostics.ConnectionState.DISCONNECTED -> "قطع"
    com.ourspace.app.core.webrtc.ConnectionDiagnostics.ConnectionState.CONNECTING -> "در حال اتصال"
    com.ourspace.app.core.webrtc.ConnectionDiagnostics.ConnectionState.CONNECTED -> "متصل به سرور شخصی"
    com.ourspace.app.core.webrtc.ConnectionDiagnostics.ConnectionState.DEGRADED -> "ناپایدار"
    com.ourspace.app.core.webrtc.ConnectionDiagnostics.ConnectionState.RECONNECTING -> "اتصال مجدد"
}
