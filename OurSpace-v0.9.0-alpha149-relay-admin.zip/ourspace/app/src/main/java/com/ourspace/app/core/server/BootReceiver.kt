package com.ourspace.app.core.server

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.ourspace.app.core.pairing.PairingStore
import com.ourspace.app.core.preferences.AppPreferences
import com.ourspace.app.core.sync.CompanionSyncWorker
import com.ourspace.app.model.DeviceRole
import com.ourspace.app.widget.OurSpaceWidgetProvider
import com.ourspace.app.widget.OurSpaceTasksWidgetProvider
import com.ourspace.app.widget.OurSpaceShoppingWidgetProvider
import com.ourspace.app.widget.OurSpaceCalendarWidgetProvider
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action != Intent.ACTION_BOOT_COMPLETED &&
            intent?.action != Intent.ACTION_MY_PACKAGE_REPLACED
        ) return

        val pendingResult = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val appContext = context.applicationContext
                val preferences = AppPreferences(appContext)
                val role = preferences.currentRole()
                val paired = runCatching { PairingStore(appContext).trustedSecret() != null }
                    .getOrDefault(false)
                if (paired && (role == DeviceRole.HOST || role == DeviceRole.COMPANION)) {
                    runCatching { CompanionSyncWorker.schedule(appContext) }
                    runCatching { HostServerService.start(appContext) }
                    runCatching { HostServerService.requestImmediateSync(appContext) }
                }
                runCatching { OurSpaceWidgetProvider.requestUpdate(appContext) }
                runCatching { OurSpaceTasksWidgetProvider.requestUpdate(appContext) }
                runCatching { OurSpaceShoppingWidgetProvider.requestUpdate(appContext) }
                runCatching { OurSpaceCalendarWidgetProvider.requestUpdate(appContext) }
            } finally {
                pendingResult.finish()
            }
        }
    }
}
