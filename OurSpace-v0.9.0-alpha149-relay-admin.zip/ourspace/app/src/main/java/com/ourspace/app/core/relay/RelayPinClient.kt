package com.ourspace.app.core.relay

import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import org.json.JSONObject

/** Short-lived host PIN registration and validation on the private relay. */
object RelayPinClient {
    fun registerHostPin(endpoint: String, pin: String) {
        requireValidPin(pin)
        val response = post(endpoint, "/pairing/host-pin", pin)
        if (!response.optBoolean("registered")) {
            throw IOException("سرور کد میزبان را ثبت نکرد.")
        }
    }

    fun verifyHostPin(endpoint: String, pin: String) {
        requireValidPin(pin)
        val response = post(endpoint, "/pairing/verify-pin", pin)
        if (!response.optBoolean("valid")) {
            throw IOException("کد میزبان اشتباه است یا اعتبار آن تمام شده؛ کد تازه‌ای از میزبان بگیر.")
        }
    }

    /** Normalize Persian/Arabic-Indic keyboard digits to ASCII before hashing or HTTP calls. */
    fun normalizePin(value: String): String = buildString {
        value.forEach { ch ->
            when (ch) {
                in '0'..'9' -> append(ch)
                in '\u06F0'..'\u06F9' -> append(('0'.code + (ch.code - '\u06F0'.code)).toChar())
                in '\u0660'..'\u0669' -> append(('0'.code + (ch.code - '\u0660'.code)).toChar())
            }
        }
    }

    private fun post(endpoint: String, path: String, pin: String): JSONObject {
        val normalizedPin = normalizePin(pin)
        requireValidPin(normalizedPin)
        val base = RelayEndpointValidator.normalize(endpoint).trimEnd('/')
        val connection = (URL(base + path).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 8_000
            readTimeout = 8_000
            doOutput = true
            setRequestProperty("Authorization", "Bearer ${RelayConfig.DEFAULT_ACCESS_TOKEN}")
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
        }
        try {
            connection.outputStream.use {
                it.write(JSONObject().put("pin", normalizedPin).toString().toByteArray(Charsets.UTF_8))
            }
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val body = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (code !in 200..299) {
                val reason = runCatching { JSONObject(body).optString("error") }.getOrDefault("")
                if (reason == "invalid_or_expired_pin") {
                    throw IOException("کد میزبان اشتباه است یا اعتبار آن تمام شده؛ کد تازه‌ای بگیر.")
                }
                if (reason == "too_many_pin_attempts") {
                    throw IOException("تعداد تلاش برای کد زیاد است؛ چند دقیقه بعد دوباره امتحان کن.")
                }
                throw IOException("اتصال به سرور جفت‌سازی ناموفق بود (HTTP $code). آدرس سرور و به‌روزبودن آن را بررسی کن.")
            }
            return JSONObject(body)
        } finally {
            connection.disconnect()
        }
    }

    private fun requireValidPin(pin: String) {
        val normalized = normalizePin(pin)
        require(normalized.length == 4 && normalized.all { it in '0'..'9' }) { "کد باید دقیقاً چهار رقم باشد." }
    }
}
