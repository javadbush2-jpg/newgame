package com.ourspace.app.ui.theme

import androidx.compose.ui.graphics.Color
import com.ourspace.app.core.database.SpecialDateEntity
import com.ourspace.app.core.time.PersianDateFormatter
import java.util.Calendar

/**
 * Soft seasonal / anniversary overlay colors — never overrides the whole palette permanently.
 */
object SeasonalAccent {
    data class Accent(
        val label: String,
        val orbA: Color,
        val orbB: Color
    )

    fun current(
        specialDates: List<SpecialDateEntity>,
        now: Long = System.currentTimeMillis()
    ): Accent? {
        // Anniversary / special within 3 days
        specialDates.filter { !it.isDeleted }.forEach { date ->
            val days = daysUntil(date, now)
            if (days != null && days in 0..3) {
                return Accent(
                    label = if (days == 0) "امروز: ${date.title}" else "نزدیک: ${date.title}",
                    orbA = Color(0xFFFF8FB8),
                    orbB = Color(0xFFFFD6A5)
                )
            }
        }
        // Persian New Year season (Farvardin 1-4 approx via Jalali)
        val j = PersianDateFormatter.jalaliDate(now)
        if (j.month == 1 && j.day in 1..4) {
            return Accent(
                label = "نوروز مبارک",
                orbA = Color(0xFF7CDB9B),
                orbB = Color(0xFFFFE08A)
            )
        }
        // Yalda (Dey 30)
        if (j.month == 10 && j.day in 29..30) {
            return Accent(
                label = "شب یلدا",
                orbA = Color(0xFFC45C8A),
                orbB = Color(0xFF6B3FA0)
            )
        }
        return null
    }

    private fun daysUntil(date: SpecialDateEntity, now: Long): Int? {
        val src = Calendar.getInstance().apply { timeInMillis = date.occurredAt }
        if (!date.repeatYearly) {
            val d = ((date.occurredAt - now) / (24L * 60 * 60 * 1000)).toInt()
            return d.takeIf { it in 0..30 }
        }
        val target = Calendar.getInstance().apply {
            timeInMillis = now
            set(Calendar.MONTH, src.get(Calendar.MONTH))
            set(Calendar.DAY_OF_MONTH, src.get(Calendar.DAY_OF_MONTH))
            set(Calendar.HOUR_OF_DAY, 12)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        if (target.timeInMillis < now - 12 * 60 * 60 * 1000L) {
            target.add(Calendar.YEAR, 1)
        }
        return ((target.timeInMillis - now) / (24L * 60 * 60 * 1000)).toInt()
    }
}
