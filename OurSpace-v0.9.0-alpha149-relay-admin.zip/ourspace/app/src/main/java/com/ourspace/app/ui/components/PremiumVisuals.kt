package com.ourspace.app.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.ourspace.app.ui.design.OSGlow
import com.ourspace.app.ui.design.OSRadius
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/**
 * Soft multi-orb ambient mesh drawn entirely with Canvas.
 * Orbs slowly drift for a living, intimate atmosphere without distracting content.
 */
@Composable
fun LivingAmbientMesh(
    modifier: Modifier = Modifier,
    intensity: Float = 0.85f
) {
    val primary = MaterialTheme.colorScheme.primary
    val secondary = MaterialTheme.colorScheme.secondary
    val tertiary = MaterialTheme.colorScheme.tertiary
    val surface = MaterialTheme.colorScheme.background

    val transition = rememberInfiniteTransition(label = "ambient-mesh")
    val t1 by transition.animateFloat(
        initialValue = 0f,
        targetValue = (2f * PI).toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(18_000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "orb-phase-1"
    )
    val t2 by transition.animateFloat(
        initialValue = 0f,
        targetValue = (2f * PI).toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(24_000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "orb-phase-2"
    )
    val t3 by transition.animateFloat(
        initialValue = 0f,
        targetValue = (2f * PI).toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(21_000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "orb-phase-3"
    )
    val breathe by transition.animateFloat(
        initialValue = 0.92f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(
            animation = tween(7_200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "breathe"
    )

    Canvas(modifier.fillMaxSize().background(surface)) {
        val w = size.width
        val h = size.height
        val largest = size.maxDimension
        val i = intensity.coerceIn(0.4f, 1.4f)

        // Base soft wash
        drawRect(color = surface)

        // Orb 1 — primary, top-leading, slow elliptical drift
        val cx1 = w * (0.12f + 0.06f * sin(t1.toDouble()).toFloat())
        val cy1 = h * (0.08f + 0.05f * cos(t1.toDouble()).toFloat())
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(
                    primary.copy(alpha = OSGlow.orbAlphaPrimary * i),
                    primary.copy(alpha = OSGlow.orbAlphaPrimary * 0.35f * i),
                    Color.Transparent
                ),
                center = Offset(cx1, cy1),
                radius = largest * 0.55f * breathe
            ),
            radius = largest * 0.55f * breathe,
            center = Offset(cx1, cy1)
        )

        // Orb 2 — tertiary, bottom-trailing
        val cx2 = w * (0.88f + 0.05f * cos(t2.toDouble()).toFloat())
        val cy2 = h * (0.78f + 0.06f * sin(t2.toDouble()).toFloat())
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(
                    tertiary.copy(alpha = OSGlow.orbAlphaTertiary * i),
                    tertiary.copy(alpha = 0.04f * i),
                    Color.Transparent
                ),
                center = Offset(cx2, cy2),
                radius = largest * 0.48f
            ),
            radius = largest * 0.48f,
            center = Offset(cx2, cy2)
        )

        // Orb 3 — secondary, mid-field
        val cx3 = w * (0.52f + 0.08f * sin(t3.toDouble()).toFloat())
        val cy3 = h * (0.32f + 0.07f * cos((t3 * 0.7).toDouble()).toFloat())
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(
                    secondary.copy(alpha = OSGlow.orbAlphaSecondary * i),
                    Color.Transparent
                ),
                center = Offset(cx3, cy3),
                radius = largest * 0.38f * (2f - breathe)
            ),
            radius = largest * 0.38f * (2f - breathe),
            center = Offset(cx3, cy3)
        )

        // Subtle diagonal light streak (very soft)
        val streakPath = Path().apply {
            moveTo(-w * 0.1f, h * 0.15f)
            cubicTo(
                w * 0.3f, h * 0.05f,
                w * 0.7f, h * 0.25f,
                w * 1.1f, h * 0.12f
            )
            lineTo(w * 1.1f, h * 0.22f)
            cubicTo(
                w * 0.7f, h * 0.35f,
                w * 0.3f, h * 0.15f,
                -w * 0.1f, h * 0.28f
            )
            close()
        }
        drawPath(
            path = streakPath,
            brush = Brush.horizontalGradient(
                listOf(
                    Color.Transparent,
                    primary.copy(alpha = 0.03f * i),
                    tertiary.copy(alpha = 0.025f * i),
                    Color.Transparent
                )
            )
        )
    }
}

/**
 * Card surface with a soft outer glow drawn behind the shape (Canvas).
 * Gives depth without heavy Material elevation.
 */
@Composable
fun GlowCard(
    modifier: Modifier = Modifier,
    cornerRadius: Dp = OSRadius.lg,
    glowColor: Color = MaterialTheme.colorScheme.primary,
    glowAlpha: Float = 0.14f,
    containerColor: Color = MaterialTheme.colorScheme.surface.copy(alpha = 0.92f),
    borderAlpha: Float = OSGlow.cardBorderAlpha,
    onClick: (() -> Unit)? = null,
    content: @Composable BoxScope.() -> Unit
) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed) 0.975f else 1f,
        animationSpec = spring(dampingRatio = 0.72f, stiffness = 480f),
        label = "glow-card-scale"
    )
    val shape = RoundedCornerShape(cornerRadius)

    Box(
        modifier = modifier
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
            }
            .drawBehind {
                // Soft glow blob behind the card
                val pad = 12.dp.toPx()
                drawRoundRect(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            glowColor.copy(alpha = glowAlpha),
                            glowColor.copy(alpha = glowAlpha * 0.35f),
                            Color.Transparent
                        ),
                        center = Offset(size.width / 2f, size.height * 0.35f),
                        radius = size.maxDimension * 0.75f
                    ),
                    topLeft = Offset(-pad, -pad),
                    size = Size(size.width + pad * 2, size.height + pad * 2),
                    cornerRadius = CornerRadius(cornerRadius.toPx() + pad / 2)
                )
            }
            .clip(shape)
            .background(containerColor)
            .border(
                width = 0.8.dp,
                brush = Brush.linearGradient(
                    listOf(
                        glowColor.copy(alpha = borderAlpha),
                        MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.25f),
                        glowColor.copy(alpha = borderAlpha * 0.5f)
                    )
                ),
                shape = shape
            )
            .then(
                if (onClick != null) {
                    Modifier.clickable(
                        interactionSource = interaction,
                        indication = null,
                        onClick = onClick
                    )
                } else Modifier
            ),
        content = content
    )
}

/**
 * Custom-drawn day cell for the Persian calendar grid.
 * Selected state uses a soft ring + filled disc drawn with Canvas.
 * Event markers are small colored arcs/dots at the bottom.
 */
@Composable
fun CalendarDayCell(
    dayNumber: String,
    isSelected: Boolean,
    isToday: Boolean,
    isCurrentMonth: Boolean,
    markerColors: List<Color>,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    val primary = MaterialTheme.colorScheme.primary
    val onPrimary = MaterialTheme.colorScheme.onPrimary
    val onSurface = MaterialTheme.colorScheme.onSurface
    val onVariant = MaterialTheme.colorScheme.onSurfaceVariant
    val primaryContainer = MaterialTheme.colorScheme.primaryContainer

    val selectProgress by animateFloatAsState(
        targetValue = if (isSelected) 1f else 0f,
        animationSpec = spring(dampingRatio = 0.75f, stiffness = 420f),
        label = "day-select"
    )
    val todayPulse = rememberInfiniteTransition(label = "today-pulse")
    val pulseAlpha by todayPulse.animateFloat(
        initialValue = 0.25f,
        targetValue = 0.55f,
        animationSpec = infiniteRepeatable(
            animation = tween(1_600, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "today-alpha"
    )

    Box(
        modifier = modifier
            .size(50.dp)
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onClick
            ),
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val cx = size.width / 2f
            val cy = size.height / 2f - 2.dp.toPx()
            val r = size.minDimension * 0.38f

            // Today soft ring (when not selected)
            if (isToday && selectProgress < 0.5f) {
                drawCircle(
                    color = primary.copy(alpha = pulseAlpha * (1f - selectProgress)),
                    radius = r + 4.dp.toPx(),
                    center = Offset(cx, cy),
                    style = Stroke(width = 1.6.dp.toPx())
                )
            }

            // Selected filled disc with outer glow
            if (selectProgress > 0.01f) {
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            primary.copy(alpha = 0.28f * selectProgress),
                            Color.Transparent
                        ),
                        center = Offset(cx, cy),
                        radius = r * 1.55f
                    ),
                    radius = r * 1.55f,
                    center = Offset(cx, cy)
                )
                drawCircle(
                    color = primary.copy(alpha = selectProgress),
                    radius = r * selectProgress.coerceAtLeast(0.85f),
                    center = Offset(cx, cy)
                )
            } else if (isToday) {
                drawCircle(
                    color = primaryContainer.copy(alpha = 0.55f),
                    radius = r * 0.92f,
                    center = Offset(cx, cy)
                )
            }

            // High-visibility activity markers: rounded capsules under the day number.
            // Max 4 colors shown; if more, last slot becomes a dark overflow pill.
            if (markerColors.isNotEmpty() && isCurrentMonth) {
                val maxVisible = 4
                val hasOverflow = markerColors.size > maxVisible
                val visible = if (hasOverflow) markerColors.take(maxVisible - 1) else markerColors.take(maxVisible)
                val slotCount = visible.size + if (hasOverflow) 1 else 0
                val pillW = 5.5.dp.toPx()
                val pillH = 3.8.dp.toPx()
                val gap = 2.2.dp.toPx()
                val totalW = slotCount * pillW + (slotCount - 1).coerceAtLeast(0) * gap
                val startX = cx - totalW / 2f
                val top = size.height - 8.5.dp.toPx()
                // Soft track behind markers so they read even on busy backgrounds
                if (slotCount > 0) {
                    drawRoundRect(
                        color = Color.Black.copy(alpha = if (isSelected) 0.12f else 0.06f),
                        topLeft = Offset(startX - 2.dp.toPx(), top - 1.2.dp.toPx()),
                        size = Size(totalW + 4.dp.toPx(), pillH + 2.4.dp.toPx()),
                        cornerRadius = CornerRadius(pillH)
                    )
                }
                visible.forEachIndexed { i, c ->
                    val left = startX + i * (pillW + gap)
                    drawRoundRect(
                        color = c.copy(alpha = 0.95f),
                        topLeft = Offset(left, top),
                        size = Size(pillW, pillH),
                        cornerRadius = CornerRadius(pillH / 2f)
                    )
                }
                if (hasOverflow) {
                    val left = startX + visible.size * (pillW + gap)
                    drawRoundRect(
                        color = onVariant.copy(alpha = 0.75f),
                        topLeft = Offset(left, top),
                        size = Size(pillW, pillH),
                        cornerRadius = CornerRadius(pillH / 2f)
                    )
                }
            }
        }

        // Day number text on top of canvas
        androidx.compose.material3.Text(
            text = dayNumber,
            style = MaterialTheme.typography.labelLarge,
            fontWeight = if (isSelected || isToday) androidx.compose.ui.text.font.FontWeight.Bold
            else androidx.compose.ui.text.font.FontWeight.Medium,
            color = when {
                !isCurrentMonth -> onVariant.copy(alpha = 0.35f)
                isSelected -> onPrimary
                isToday -> primary
                else -> onSurface
            }
        )
    }
}

/**
 * Sliding pill indicator for the bottom navigation.
 * Drawn with Canvas; position is driven by an animated fraction (0..n-1).
 */
@Composable
fun NavPillIndicator(
    selectedIndex: Int,
    itemCount: Int,
    modifier: Modifier = Modifier,
    pillColor: Color = MaterialTheme.colorScheme.primary
) {
    val animatedIndex by animateFloatAsState(
        targetValue = selectedIndex.toFloat(),
        animationSpec = spring(dampingRatio = 0.82f, stiffness = 380f),
        label = "nav-pill-x"
    )

    Canvas(modifier.fillMaxWidth().height(5.dp)) {
        if (itemCount <= 0) return@Canvas
        val slotW = size.width / itemCount
        val pillW = slotW * 0.48f
        val cx = (animatedIndex + 0.5f) * slotW
        val left = cx - pillW / 2f
        val top = 0f
        val h = size.height

        // Soft glow under the pill
        drawRoundRect(
            brush = Brush.horizontalGradient(
                listOf(
                    Color.Transparent,
                    pillColor.copy(alpha = 0.35f),
                    pillColor.copy(alpha = 0.35f),
                    Color.Transparent
                )
            ),
            topLeft = Offset(left - 8.dp.toPx(), top - 2.dp.toPx()),
            size = Size(pillW + 16.dp.toPx(), h + 4.dp.toPx()),
            cornerRadius = CornerRadius(h)
        )
        drawRoundRect(
            color = pillColor,
            topLeft = Offset(left, top),
            size = Size(pillW, h),
            cornerRadius = CornerRadius(h)
        )
    }
}

/**
 * Decorative wave separator drawn with Path — useful under headers.
 */
@Composable
fun SoftWaveDivider(
    modifier: Modifier = Modifier,
    color: Color = MaterialTheme.colorScheme.primary.copy(alpha = 0.18f),
    amplitude: Dp = 6.dp
) {
    Canvas(modifier.fillMaxWidth().height(amplitude * 2)) {
        val amp = amplitude.toPx()
        val path = Path().apply {
            moveTo(0f, size.height / 2f)
            var x = 0f
            while (x < size.width) {
                quadraticTo(
                    x + 20.dp.toPx(), size.height / 2f - amp,
                    x + 40.dp.toPx(), size.height / 2f
                )
                quadraticTo(
                    x + 60.dp.toPx(), size.height / 2f + amp,
                    x + 80.dp.toPx(), size.height / 2f
                )
                x += 80.dp.toPx()
            }
        }
        drawPath(
            path = path,
            color = color,
            style = Stroke(width = 1.5.dp.toPx(), cap = StrokeCap.Round)
        )
    }
}

/**
 * Radial progress ring drawn with Canvas (e.g. cycle day, budget used).
 */
@Composable
fun SoftProgressRing(
    progress: Float,
    modifier: Modifier = Modifier,
    strokeWidth: Dp = 6.dp,
    trackColor: Color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
    progressColor: Color = MaterialTheme.colorScheme.primary,
    glow: Boolean = true
) {
    val animated by animateFloatAsState(
        targetValue = progress.coerceIn(0f, 1f),
        animationSpec = spring(dampingRatio = 0.85f, stiffness = 200f),
        label = "ring-progress"
    )
    Canvas(modifier) {
        val stroke = strokeWidth.toPx()
        val radius = (size.minDimension - stroke) / 2f
        val c = Offset(size.width / 2f, size.height / 2f)
        // Track
        drawCircle(
            color = trackColor,
            radius = radius,
            center = c,
            style = Stroke(width = stroke, cap = StrokeCap.Round)
        )
        if (glow && animated > 0.01f) {
            drawArc(
                color = progressColor.copy(alpha = 0.25f),
                startAngle = -90f,
                sweepAngle = 360f * animated,
                useCenter = false,
                topLeft = Offset(c.x - radius, c.y - radius),
                size = Size(radius * 2, radius * 2),
                style = Stroke(width = stroke * 2.2f, cap = StrokeCap.Round)
            )
        }
        drawArc(
            brush = Brush.sweepGradient(
                listOf(progressColor, progressColor.copy(alpha = 0.75f), progressColor)
            ),
            startAngle = -90f,
            sweepAngle = 360f * animated,
            useCenter = false,
            topLeft = Offset(c.x - radius, c.y - radius),
            size = Size(radius * 2, radius * 2),
            style = Stroke(width = stroke, cap = StrokeCap.Round)
        )
    }
}

/**
 * Tiny sparkle burst drawn with Canvas — for celebration / pairing success moments.
 */
@Composable
fun SparkleBurst(
    active: Boolean,
    modifier: Modifier = Modifier,
    color: Color = MaterialTheme.colorScheme.tertiary
) {
    val progress = remember { Animatable(0f) }
    LaunchedEffect(active) {
        if (active) {
            progress.snapTo(0f)
            progress.animateTo(1f, tween(900, easing = FastOutSlowInEasing))
        }
    }
    val p = progress.value
    if (p <= 0.01f) return

    Canvas(modifier.size(72.dp)) {
        val cx = size.width / 2f
        val cy = size.height / 2f
        val count = 8
        for (i in 0 until count) {
            val angle = (i / count.toFloat()) * 2f * PI.toFloat() + p * 0.4f
            val dist = size.minDimension * 0.15f + size.minDimension * 0.35f * p
            val x = cx + cos(angle) * dist
            val y = cy + sin(angle) * dist
            val a = (1f - p).coerceIn(0f, 1f) * 0.9f
            drawCircle(
                color = color.copy(alpha = a),
                radius = 2.5.dp.toPx() * (1f - p * 0.5f),
                center = Offset(x, y)
            )
        }
    }
}
