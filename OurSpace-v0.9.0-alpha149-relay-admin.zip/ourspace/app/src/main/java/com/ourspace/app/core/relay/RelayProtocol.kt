package com.ourspace.app.core.relay

import java.net.URI
import java.nio.charset.StandardCharsets
import java.security.MessageDigest
import java.util.Base64
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec
import org.json.JSONObject

enum class RelayDirection(val wireName: String) {
    TO_HOST("to-host"),
    TO_COMPANION("to-companion")
}

data class RelayConfig(
    val enabled: Boolean,
    val endpoint: String,
    /** Shared household token — same value on every phone → one mailbox. */
    val accessToken: String = ""
) {
    val isUsable: Boolean get() = enabled && endpoint.isNotBlank() && accessToken.isNotBlank()

    companion object {
        /** Built-in defaults so phones work without manual copy/paste. Still editable in settings. */
        const val DEFAULT_ENDPOINT = "http://ourspace.iddns.ir:8787"
        const val DEFAULT_ACCESS_TOKEN = "SyqmI0T5muBzDBf0plXAYKaMgL5uTZXiEx0sm92ijDQ"
    }
}

data class RelayCredentials(
    val mailboxId: String,
    val authToken: String
) {
    companion object {
        /**
         * The shared connection value is used directly as the relay bearer token.
         * No HMAC/encryption is performed here; SHA-256 only creates a fixed mailbox id.
         */
        fun derive(sharedSecret: ByteArray): RelayCredentials {
            require(sharedSecret.isNotEmpty()) { "Relay connection value is empty" }
            val token = Base64.getUrlEncoder().withoutPadding().encodeToString(sharedSecret)
            return fromAccessToken(token)
        }

        /** Preferred: same household token on every device → single shared mailbox. */
        fun fromAccessToken(accessToken: String): RelayCredentials {
            val token = accessToken.trim()
            require(token.length in 16..128) { "کلید مشترک خانه نامعتبر است" }
            require(token.all { it.isLetterOrDigit() || it == '_' || it == '-' }) {
                "کلید مشترک فقط حروف، عدد، - و _"
            }
            val mailboxBytes = MessageDigest.getInstance("SHA-256")
                .digest(token.toByteArray(StandardCharsets.UTF_8))
            return RelayCredentials(
                mailboxId = Base64.getUrlEncoder().withoutPadding().encodeToString(mailboxBytes),
                authToken = token
            )
        }
    }
}

data class RelayMessage(
    val messageId: String,
    val correlationId: String?,
    val createdAt: Long,
    val expiresAt: Long,
    val envelope: JSONObject
) {
    fun toJson(): JSONObject = JSONObject()
        .put("messageId", messageId)
        .put("correlationId", correlationId ?: JSONObject.NULL)
        .put("createdAt", createdAt)
        .put("expiresAt", expiresAt)
        .put("envelope", envelope)

    companion object {
        fun fromJson(json: JSONObject, now: Long = System.currentTimeMillis()): RelayMessage {
            val messageId = json.getString("messageId")
            val correlationId = if (json.isNull("correlationId")) null else json.getString("correlationId")
            val createdAt = json.getLong("createdAt")
            val expiresAt = json.getLong("expiresAt")
            require(isSafeOpaqueId(messageId)) { "Invalid relay message id" }
            require(correlationId == null || isSafeOpaqueId(correlationId)) { "Invalid correlation id" }
            require(createdAt >= now - MAX_TTL && createdAt <= now + MAX_CLOCK_SKEW) {
                "Invalid relay timestamp"
            }
            require(expiresAt > now && expiresAt >= createdAt && expiresAt <= createdAt + MAX_TTL) {
                "Invalid relay expiry"
            }
            val envelope = json.getJSONObject("envelope")
            require(envelope.toString().toByteArray(StandardCharsets.UTF_8).size <= MAX_ENVELOPE_BYTES) {
                "Relay envelope is too large"
            }
            return RelayMessage(messageId, correlationId, createdAt, expiresAt, envelope)
        }

        fun isSafeOpaqueId(value: String): Boolean =
            value.length in 16..100 && value.all {
                it in 'a'..'z' || it in 'A'..'Z' || it in '0'..'9' || it == '-' || it == '_'
            }

        const val MAX_ENVELOPE_BYTES = 32 * 1024 * 1024
        const val MAX_TTL = 7 * 24 * 60 * 60 * 1000L
        const val DEFAULT_TTL = 24 * 60 * 60 * 1000L
        private const val MAX_CLOCK_SKEW = 10 * 60 * 1000L
    }
}

object RelayEndpointValidator {
    fun normalize(raw: String): String {
        var candidate = raw.trim().trimEnd('/')
        // Users often paste host:port without scheme.
        if (!candidate.contains("://")) {
            candidate = "http://$candidate"
        }
        require(candidate.length in 12..500) { "آدرس سرور شخصی نامعتبر است" }
        val uri = URI(candidate)
        require(uri.userInfo == null && uri.query == null && uri.fragment == null) {
            "آدرس نباید شامل نام کاربری، کوئری یا # باشد"
        }
        require(!uri.host.isNullOrBlank()) { "نام میزبان در آدرس مشخص نیست" }
        require(
            uri.scheme.equals("http", ignoreCase = true) ||
                uri.scheme.equals("https", ignoreCase = true)
        ) {
            "آدرس سرور باید با http یا https شروع شود"
        }
        // Prefer explicit port for home relays when missing on non-default schemes is ok.
        return candidate
    }
}
