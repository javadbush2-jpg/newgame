package com.ourspace.app.core.security

import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.net.Inet4Address
import java.net.NetworkInterface
import java.net.URI
import java.net.URLDecoder
import java.nio.ByteBuffer
import java.nio.charset.StandardCharsets
import java.security.KeyFactory
import java.security.KeyPairGenerator
import java.security.KeyStore
import java.security.MessageDigest
import java.security.PublicKey
import java.security.SecureRandom
import java.security.spec.MGF1ParameterSpec
import java.security.spec.X509EncodedKeySpec
import javax.crypto.Cipher
import javax.crypto.spec.OAEPParameterSpec
import javax.crypto.spec.PSource

class DeviceIdentityManager {
    data class DeviceIdentity(
        val deviceId: String,
        val fingerprint: String,
        val publicKey: String,
        val pairingPayload: String,
        val localAddress: String?
    )

    data class ParsedPairingPayload(
        val deviceId: String,
        val host: String? = null,
        val port: Int? = null,
        val publicKey: String,
        val relayEndpoint: String? = null,
        /** True when the payload can be used without a reachable LAN endpoint (QR/WebRTC flow). */
        val offlineCapable: Boolean = false,
        /** v=4 one-scan pairing: shared secret carried directly inside the invite QR. */
        val sharedSecret: String? = null
    )

    fun getOrCreateIdentity(): DeviceIdentity {
        val publicKey = getOrCreateKeyPairPublicKey()
        val digest = MessageDigest.getInstance("SHA-256").digest(publicKey.encoded)
        val deviceId = digest.take(12).joinToString("") { "%02x".format(it) }
        val fingerprint = digest.take(6).joinToString(" ") { "%02X".format(it) }
        val encodedKey = Base64.encodeToString(
            publicKey.encoded,
            Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING
        )
        val host = findPrivateIpv4Address()
        // v=3 base invite; AppViewModel upgrades it to a v=4 single-scan invite.
        val payload = "ourspace://pair?v=3&device=$deviceId&key=$encodedKey"
        return DeviceIdentity(deviceId, fingerprint, encodedKey, payload, host)
    }

    /**
     * Builds a single-scan invite: the companion only has to scan this once and is paired.
     */
    fun buildInstantInvite(
        identity: DeviceIdentity,
        sharedSecret: ByteArray
    ): String {
        val encodedSecret = Base64.encodeToString(
            sharedSecret,
            Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING
        )
        // No LAN address in the invite: syncing happens over the internet only, and a local
        // 192.168.x.x endpoint would be useless (and confusing) on a different network.
        return "ourspace://pair?v=4&device=${identity.deviceId}&key=${identity.publicKey}" +
            "&s=$encodedSecret"
    }

    fun parsePairingPayload(payload: String): ParsedPairingPayload? = runCatching {
        val cleaned = payload.trim()
        val uri = URI(cleaned)
        if (uri.scheme != "ourspace" || uri.host != "pair") return null
        val query = uri.rawQuery.orEmpty().split('&').mapNotNull { part ->
            val split = part.split('=', limit = 2)
            if (split.size != 2) null else {
                URLDecoder.decode(split[0], StandardCharsets.UTF_8.name()) to
                    URLDecoder.decode(split[1], StandardCharsets.UTF_8.name())
            }
        }.toMap()
        val version = query["v"] ?: return null
        val deviceId = query["device"] ?: return null
        val key = query["key"] ?: return null
        when (version) {
            // v=4: single-scan pairing — the invite already carries the shared secret.
            "4" -> ParsedPairingPayload(
                deviceId = deviceId,
                host = query["host"]?.takeUnless { it == "unavailable" || it.isBlank() },
                port = query["port"]?.toIntOrNull()?.takeIf { it in 1..65535 },
                publicKey = key,
                offlineCapable = true,
                sharedSecret = query["s"]?.takeIf { it.isNotBlank() }
            )
            "3" -> ParsedPairingPayload(
                deviceId = deviceId,
                host = null,
                port = null,
                publicKey = key,
                offlineCapable = true
            )
            "2" -> {
                val host = query["host"]?.takeUnless { it == "unavailable" }
                val port = query["port"]?.toIntOrNull()?.takeIf { it in 1..65535 }
                val relayEndpoint = query["relay"]?.take(500)?.takeIf { it.isNotBlank() }
                // Prefer offline if host missing — still usable for QR reply flow.
                ParsedPairingPayload(
                    deviceId = deviceId,
                    host = host,
                    port = port,
                    publicKey = key,
                    relayEndpoint = relayEndpoint,
                    offlineCapable = host == null || port == null
                )
            }
            else -> null
        }
    }.getOrNull()

    fun encryptForPublicKey(encodedPublicKey: String, plain: ByteArray): String {
        val publicBytes = Base64.decode(encodedPublicKey, Base64.URL_SAFE or Base64.NO_WRAP)
        val publicKey = KeyFactory.getInstance(KeyProperties.KEY_ALGORITHM_RSA)
            .generatePublic(X509EncodedKeySpec(publicBytes))
        val cipher = Cipher.getInstance(RSA_TRANSFORMATION)
        // AndroidKeyStore always uses SHA-1 for the MGF1 function, even when the
        // transformation name says SHA-256. The encrypting side runs outside the
        // keystore, so the OAEP parameters must be passed explicitly — otherwise the
        // host fails to decrypt the companion reply ("QR پاسخ همراه معتبر نیست").
        cipher.init(Cipher.ENCRYPT_MODE, publicKey, oaepParams(MGF1ParameterSpec.SHA1))
        return Base64.encodeToString(
            cipher.doFinal(plain),
            Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING
        )
    }

    fun decryptPairingSecret(encodedCiphertext: String): ByteArray {
        val keyStore = KeyStore.getInstance(ANDROID_KEYSTORE).apply { load(null) }
        val privateKey = keyStore.getKey(KEY_ALIAS, null)
            ?: throw IllegalStateException("کلید امنیتی این دستگاه پیدا نشد. اپ را حذف و دوباره نصب کنید.")
        val ciphertext = decodeFlexibleBase64(encodedCiphertext)
        // Try the parameters we encrypt with first, then the historical variants so that
        // a phone running an older build can still complete pairing.
        val attempts = listOf<OAEPParameterSpec?>(
            oaepParams(MGF1ParameterSpec.SHA1),
            oaepParams(MGF1ParameterSpec.SHA256),
            null
        )
        var lastError: Exception? = null
        for (params in attempts) {
            try {
                val cipher = Cipher.getInstance(RSA_TRANSFORMATION)
                if (params == null) {
                    cipher.init(Cipher.DECRYPT_MODE, privateKey)
                } else {
                    cipher.init(Cipher.DECRYPT_MODE, privateKey, params)
                }
                return cipher.doFinal(ciphertext)
            } catch (error: Exception) {
                lastError = error
            }
        }
        throw IllegalStateException(
            "رمزگشایی پاسخ همراه ناموفق بود (${lastError?.javaClass?.simpleName ?: "نامشخص"}). " +
                "مطمئن شوید هر دو گوشی روی همین نسخه اپ هستند و QR تازه ساخته شده است.",
            lastError
        )
    }

    /** Accepts URL-safe or standard Base64, with or without padding. */
    private fun decodeFlexibleBase64(value: String): ByteArray {
        val cleaned = value.trim().replace("\\s".toRegex(), "")
        val flags = Base64.NO_WRAP
        return runCatching { Base64.decode(cleaned, Base64.URL_SAFE or flags) }
            .recoverCatching { Base64.decode(cleaned, flags) }
            .getOrElse {
                throw IllegalArgumentException("محتوای رمزشده در QR خوانا نیست.", it)
            }
    }

    private fun oaepParams(mgf1Digest: MGF1ParameterSpec): OAEPParameterSpec =
        OAEPParameterSpec("SHA-256", "MGF1", mgf1Digest, PSource.PSpecified.DEFAULT)

    fun createPairingSecret(): ByteArray = ByteArray(32).also(SecureRandom()::nextBytes)

    fun fingerprintForPublicKey(encodedPublicKey: String): String {
        val digest = publicKeyDigest(encodedPublicKey)
        return digest.take(6).joinToString(" ") { "%02X".format(it) }
    }

    fun deviceIdForPublicKey(encodedPublicKey: String): String =
        publicKeyDigest(encodedPublicKey).take(12).joinToString("") { "%02x".format(it) }

    private fun publicKeyDigest(encodedPublicKey: String): ByteArray {
        val bytes = Base64.decode(encodedPublicKey, Base64.URL_SAFE or Base64.NO_WRAP)
        return MessageDigest.getInstance("SHA-256").digest(bytes)
    }

    fun verificationCode(value: String): String = verificationCode(value.toByteArray())

    fun verificationCode(value: ByteArray): String {
        val digest = MessageDigest.getInstance("SHA-256").digest(value)
        val positiveInt = ByteBuffer.wrap(digest.copyOfRange(0, 4)).int and Int.MAX_VALUE
        return (positiveInt % 1_000_000).toString().padStart(6, '0')
    }

    fun isValidPairingPayload(payload: String): Boolean = parsePairingPayload(payload) != null

    private fun getOrCreateKeyPairPublicKey(): PublicKey {
        val keyStore = KeyStore.getInstance(ANDROID_KEYSTORE).apply { load(null) }
        keyStore.getCertificate(KEY_ALIAS)?.publicKey?.let { return it }

        val generator = KeyPairGenerator.getInstance(
            KeyProperties.KEY_ALGORITHM_RSA,
            ANDROID_KEYSTORE
        )
        val spec = KeyGenParameterSpec.Builder(
            KEY_ALIAS,
            KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
        )
            .setKeySize(2048)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_RSA_OAEP)
            .setDigests(KeyProperties.DIGEST_SHA256, KeyProperties.DIGEST_SHA1)
            .setRandomizedEncryptionRequired(true)
            .build()
        generator.initialize(spec)
        return generator.generateKeyPair().public
    }

    private fun findPrivateIpv4Address(): String? = runCatching {
        NetworkInterface.getNetworkInterfaces().toList()
            .asSequence()
            .filter { it.isUp && !it.isLoopback }
            .flatMap { it.inetAddresses.toList().asSequence() }
            .filterIsInstance<Inet4Address>()
            .firstOrNull { it.isSiteLocalAddress && !it.isLoopbackAddress }
            ?.hostAddress
    }.getOrNull()

    private companion object {
        const val ANDROID_KEYSTORE = "AndroidKeyStore"
        const val KEY_ALIAS = "ourspace_pairing_rsa_identity_v2"
        const val RSA_TRANSFORMATION = "RSA/ECB/OAEPWithSHA-256AndMGF1Padding"
        const val DEFAULT_LAN_PORT = 8765
    }
}
