package com.ourspace.app.core.location

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.os.Looper
import androidx.core.content.ContextCompat
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

/**
 * Reads a single fresh location fix using the platform LocationManager
 * (no Google Play Services required).
 */
class LocationPublisher(private val context: Context) {
    companion object {
        // Never publish an old cached coordinate as though it were a fresh GPS fix.
        private const val MAX_FALLBACK_AGE_MS = 5 * 60 * 1000L
    }
    fun hasPermission(): Boolean {
        val fine = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION)
        val coarse = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION)
        return fine == PackageManager.PERMISSION_GRANTED || coarse == PackageManager.PERMISSION_GRANTED
    }

    @SuppressLint("MissingPermission")
    suspend fun readCurrentLocation(timeoutMs: Long = 12_000L): Location? {
        if (!hasPermission()) return null
        val manager = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        val providers = listOfNotNull(
            LocationManager.GPS_PROVIDER.takeIf { manager.isProviderEnabled(it) },
            LocationManager.NETWORK_PROVIDER.takeIf { manager.isProviderEnabled(it) }
        )
        if (providers.isEmpty()) {
            return listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)
                .mapNotNull { manager.getLastKnownLocation(it) }
                .maxByOrNull { it.time }
                ?.takeIf { System.currentTimeMillis() - it.time <= MAX_FALLBACK_AGE_MS }
        }
        // Prefer a recent last-known fix to avoid long waits.
        val last = providers.mapNotNull { manager.getLastKnownLocation(it) }
            .maxByOrNull { it.time }
        if (last != null && System.currentTimeMillis() - last.time < 60_000L) {
            return last
        }
        return suspendCancellableCoroutine { cont ->
            var completed = false
            val listener = object : LocationListener {
                override fun onLocationChanged(location: Location) {
                    if (completed) return
                    completed = true
                    runCatching { manager.removeUpdates(this) }
                    cont.resume(location)
                }
                @Deprecated("Deprecated in Java")
                override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
                override fun onProviderEnabled(provider: String) {}
                override fun onProviderDisabled(provider: String) {}
            }
            cont.invokeOnCancellation {
                runCatching { manager.removeUpdates(listener) }
            }
            try {
                providers.forEach { provider ->
                    manager.requestLocationUpdates(
                        provider,
                        0L,
                        0f,
                        listener,
                        Looper.getMainLooper()
                    )
                }
                android.os.Handler(Looper.getMainLooper()).postDelayed({
                    if (!completed) {
                        completed = true
                        runCatching { manager.removeUpdates(listener) }
                        val fallback = providers.mapNotNull { manager.getLastKnownLocation(it) }
                            .maxByOrNull { it.time }
                            ?.takeIf { System.currentTimeMillis() - it.time <= MAX_FALLBACK_AGE_MS }
                        cont.resume(fallback)
                    }
                }, timeoutMs)
            } catch (_: SecurityException) {
                completed = true
                cont.resume(null)
            } catch (_: Exception) {
                completed = true
                cont.resume(null)
            }
        }
    }
}
