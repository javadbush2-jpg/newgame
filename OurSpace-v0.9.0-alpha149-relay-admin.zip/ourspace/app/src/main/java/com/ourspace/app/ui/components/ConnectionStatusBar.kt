package com.ourspace.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.ourspace.app.core.webrtc.ConnectionDiagnostics

/**
 * Compact, always-visible connection health for home + chat headers.
 */
@Composable
fun ConnectionStatusBar(
    modifier: Modifier = Modifier,
    compact: Boolean = false
) {
    val health by ConnectionDiagnostics.health.collectAsState()
    val label = ConnectionDiagnostics.statusLabelFa(health)
    val detail = ConnectionDiagnostics.detailLabelFa(health)
    val dot = statusColor(health.state, health.pushConnected)

    if (compact) {
        Row(
            modifier = modifier,
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Box(Modifier.size(8.dp).clip(CircleShape).background(dot))
            Text(
                label,
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1
            )
        }
        return
    }

    Row(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = 0.85f))
            .padding(horizontal = 14.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Box(Modifier.size(10.dp).clip(CircleShape).background(dot))
        Column(Modifier.weight(1f)) {
            Text(label, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
            Text(
                detail,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 2
            )
        }
        if (health.pushConnected) {
            Text(
                "فوری",
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier
                    .clip(RoundedCornerShape(999.dp))
                    .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.12f))
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            )
        }
    }
}

@Composable
private fun statusColor(
    state: ConnectionDiagnostics.ConnectionState,
    pushConnected: Boolean
): Color {
    val scheme = MaterialTheme.colorScheme
    return when (state) {
        ConnectionDiagnostics.ConnectionState.CONNECTED ->
            if (pushConnected) Color(0xFF2E9E6A) else scheme.primary
        ConnectionDiagnostics.ConnectionState.CONNECTING,
        ConnectionDiagnostics.ConnectionState.RECONNECTING -> Color(0xFFE0A100)
        ConnectionDiagnostics.ConnectionState.DEGRADED -> Color(0xFFE07A3D)
        ConnectionDiagnostics.ConnectionState.DISCONNECTED -> scheme.error
    }
}
