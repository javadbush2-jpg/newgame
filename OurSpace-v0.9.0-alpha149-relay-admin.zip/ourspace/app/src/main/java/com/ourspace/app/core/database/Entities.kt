package com.ourspace.app.core.database

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "tasks")
data class TaskEntity(
    @PrimaryKey val id: String,
    val title: String,
    val note: String = "",
    val assignee: String = "مشترک",
    val dueAt: Long? = null,
    val durationMinutes: Int = 60,
    val priority: Int = 1,
    val isCompleted: Boolean = false,
    val isDeleted: Boolean = false,
    val createdAt: Long,
    val updatedAt: Long
)

@Entity(tableName = "events")
data class EventEntity(
    @PrimaryKey val id: String,
    val title: String,
    val details: String = "",
    val startAt: Long,
    val endAt: Long? = null,
    val isShared: Boolean = true,
    val isDeleted: Boolean = false,
    val createdAt: Long,
    val updatedAt: Long
)

@Entity(tableName = "shopping_items")
data class ShoppingItemEntity(
    @PrimaryKey val id: String,
    val title: String,
    val quantity: String = "۱ عدد",
    val category: String = "سایر",
    val isChecked: Boolean = false,
    @ColumnInfo(defaultValue = "0")
    val isRecurring: Boolean = false,
    val isDeleted: Boolean = false,
    val createdAt: Long,
    val updatedAt: Long
)

@Entity(
    tableName = "messages",
    indices = [Index("createdAt"), Index("updatedAt")]
)
data class MessageEntity(
    @PrimaryKey val id: String,
    val senderDeviceId: String,
    val text: String,
    val replyToId: String? = null,
    val reaction: String? = null,
    val reactionByDeviceId: String? = null,
    val reactionUpdatedAt: Long? = null,
    val reaction2: String? = null,
    val reaction2ByDeviceId: String? = null,
    val reaction2UpdatedAt: Long? = null,
    /** When the peer device first materialised this message (delivery receipt). */
    val deliveredAt: Long? = null,
    val readAt: Long? = null,
    val editedAt: Long? = null,
    val isDeleted: Boolean = false,
    val createdAt: Long,
    val updatedAt: Long
)

@Entity(
    tableName = "financial_accounts",
    indices = [Index("updatedAt")]
)
data class FinancialAccountEntity(
    @PrimaryKey val id: String,
    val name: String,
    val type: String = "CASH",
    val openingBalance: Long = 0,
    val colorSeed: Int = 0,
    val isArchived: Boolean = false,
    val isDeleted: Boolean = false,
    val createdAt: Long,
    val updatedAt: Long
)

@Entity(
    tableName = "finance_transactions",
    indices = [Index("accountId"), Index("targetAccountId"), Index("occurredAt"), Index("updatedAt")]
)
data class FinanceTransactionEntity(
    @PrimaryKey val id: String,
    val accountId: String,
    val targetAccountId: String? = null,
    val kind: String,
    val amount: Long,
    val category: String,
    val note: String = "",
    val payerDeviceId: String,
    val occurredAt: Long,
    val isDeleted: Boolean = false,
    val createdAt: Long,
    val updatedAt: Long
)

@Entity(
    tableName = "finance_budgets",
    indices = [Index("periodKey"), Index("updatedAt")]
)
data class FinanceBudgetEntity(
    @PrimaryKey val id: String,
    val category: String,
    val periodKey: String,
    val monthlyLimit: Long,
    val isDeleted: Boolean = false,
    val createdAt: Long,
    val updatedAt: Long
)

@Entity(
    tableName = "shared_debts",
    indices = [Index("creditorDeviceId"), Index("debtorDeviceId"), Index("dueAt"), Index("updatedAt")]
)
data class SharedDebtEntity(
    @PrimaryKey val id: String,
    val title: String,
    val amount: Long,
    val creditorDeviceId: String,
    val debtorDeviceId: String,
    val note: String = "",
    val dueAt: Long? = null,
    val settledAt: Long? = null,
    val isDeleted: Boolean = false,
    val createdAt: Long,
    val updatedAt: Long
)

@Entity(
    tableName = "recurring_transactions",
    indices = [Index("accountId"), Index("nextRunAt"), Index("createdByDeviceId"), Index("updatedAt")]
)
data class RecurringTransactionEntity(
    @PrimaryKey val id: String,
    val accountId: String,
    val targetAccountId: String? = null,
    val kind: String,
    val amount: Long,
    val category: String,
    val note: String = "",
    val interval: String,
    val anchorJalaliDay: Int,
    val nextRunAt: Long,
    val lastGeneratedAt: Long? = null,
    val createdByDeviceId: String,
    val isActive: Boolean = true,
    val isDeleted: Boolean = false,
    val createdAt: Long,
    val updatedAt: Long
)

@Entity(
    tableName = "memories",
    indices = [Index("occurredAt"), Index("updatedAt")]
)
data class MemoryEntity(
    @PrimaryKey val id: String,
    val title: String,
    val note: String = "",
    val mood: String = "LOVE",
    val createdByDeviceId: String,
    val occurredAt: Long,
    val isFavorite: Boolean = false,
    val isDeleted: Boolean = false,
    val createdAt: Long,
    val updatedAt: Long
)

@Entity(
    tableName = "mood_checkins",
    indices = [Index("dayKey"), Index("updatedAt")]
)
data class MoodCheckInEntity(
    @PrimaryKey val id: String,
    val deviceId: String,
    val dayKey: String,
    val mood: String,
    val note: String = "",
    val isDeleted: Boolean = false,
    val createdAt: Long,
    val updatedAt: Long
)

@Entity(
    tableName = "special_dates",
    indices = [Index("occurredAt"), Index("updatedAt")]
)
data class SpecialDateEntity(
    @PrimaryKey val id: String,
    val title: String,
    val note: String = "",
    val occurredAt: Long,
    val repeatYearly: Boolean = true,
    val isDeleted: Boolean = false,
    val createdAt: Long,
    val updatedAt: Long
)

@Entity(tableName = "couple_profile")
data class CoupleProfileEntity(
    @PrimaryKey val id: String = "couple-profile",
    val firstPersonName: String = "",
    val secondPersonName: String = "",
    val relationshipStartedAt: Long? = null,
    val createdAt: Long,
    val updatedAt: Long
)

@Entity(
    tableName = "attachments",
    indices = [Index("messageId"), Index("memoryId"), Index("updatedAt")]
)
data class AttachmentEntity(
    @PrimaryKey val id: String,
    val messageId: String? = null,
    val memoryId: String? = null,
    val fileName: String,
    val mimeType: String,
    val sizeBytes: Long,
    val sha256: String,
    val content: ByteArray,
    val createdByDeviceId: String,
    val isDeleted: Boolean = false,
    val createdAt: Long,
    val updatedAt: Long
)

@Entity(
    tableName = "sync_changes",
    indices = [
        Index("changedAt"),
        Index("nextAttemptAt"),
        Index(value = ["state", "priority", "changedAt"]),
        Index(value = ["entityType", "entityId"])
    ]
)
data class SyncChangeEntity(
    @PrimaryKey val changeId: String,
    val entityType: String,
    val entityId: String,
    val changedAt: Long,
    @ColumnInfo(defaultValue = "PENDING")
    val state: String = "PENDING",
    @ColumnInfo(defaultValue = "0")
    val attempts: Int = 0,
    @ColumnInfo(defaultValue = "0")
    val nextAttemptAt: Long = 0L,
    val lastAttemptAt: Long? = null,
    val lastMessageId: String? = null,
    @ColumnInfo(defaultValue = "100")
    val priority: Int = 100,
    @ColumnInfo(defaultValue = "0")
    val createdAt: Long = changedAt
)


@Entity(tableName = "sync_versions", primaryKeys = ["entityType", "entityId"])
data class SyncVersionEntity(
    val entityType: String,
    val entityId: String,
    val updatedAt: Long,
    val originDeviceId: String,
    val changeId: String,
    val appliedAt: Long
)

@Entity(tableName = "sync_runtime_control")
data class SyncRuntimeControlEntity(
    @PrimaryKey val id: Int = 1,
    val suppressOutbox: Boolean = false
)

@Entity(tableName = "sync_session_state")
data class SyncSessionStateEntity(
    @PrimaryKey val id: Int = 1,
    val state: String = "DISCONNECTED",
    val lastConnectedAt: Long = 0L,
    val lastSyncAt: Long = 0L,
    val lastErrorAt: Long = 0L,
    val lastError: String? = null,
    val consecutiveFailures: Int = 0
)

@Entity(tableName = "sync_acknowledgements")
data class SyncAcknowledgementEntity(
    @PrimaryKey val changeId: String,
    val receivedAt: Long
)

@Entity(
    tableName = "cycle_logs",
    indices = [Index("startAt"), Index("updatedAt")]
)
data class CycleLogEntity(
    @PrimaryKey val id: String,
    /** Start of menstrual period (epoch millis, local day). */
    val startAt: Long,
    /** End of period; null while ongoing. */
    val endAt: Long? = null,
    /** LIGHT / MEDIUM / HEAVY / SPOTTING / UNKNOWN */
    val flowLevel: String = "UNKNOWN",
    val note: String = "",
    val recordedByDeviceId: String,
    val isDeleted: Boolean = false,
    val createdAt: Long,
    val updatedAt: Long
)

@Entity(tableName = "cycle_settings")
data class CycleSettingsEntity(
    @PrimaryKey val id: String = "cycle-settings",
    /** Average full cycle length in days (period start to next period start). */
    val averageCycleDays: Int = 28,
    /** Typical bleeding length in days. */
    val averagePeriodDays: Int = 5,
    /** When false, UI can hide predictions; data still stays encrypted locally. */
    val trackingEnabled: Boolean = true,
    val createdAt: Long,
    val updatedAt: Long
)

@Entity(
    tableName = "location_shares",
    indices = [Index("updatedAt")]
)
data class LocationShareEntity(
    /** Primary key is deviceId so each phone has one live row. */
    @PrimaryKey val id: String,
    val latitude: Double,
    val longitude: Double,
    val accuracyMeters: Float = 0f,
    val isSharing: Boolean = true,
    val isDeleted: Boolean = false,
    val createdAt: Long,
    val updatedAt: Long
)

@Entity(
    tableName = "heart_pulses",
    indices = [Index("createdAt"), Index("updatedAt")]
)
data class HeartPulseEntity(
    @PrimaryKey val id: String,
    val senderDeviceId: String,
    /** When the receiver has shown notification / animation. */
    val consumedAt: Long? = null,
    /** When the receiver explicitly tapped "I saw it". */
    val acknowledgedAt: Long? = null,
    val isDeleted: Boolean = false,
    val createdAt: Long,
    val updatedAt: Long
)

@Entity(
    tableName = "shared_places",
    indices = [Index("updatedAt")]
)
data class SharedPlaceEntity(
    @PrimaryKey val id: String,
    val title: String,
    val note: String = "",
    val latitude: Double,
    val longitude: Double,
    /** HOME / CAFE / TRAVEL / MEMORY / OTHER */
    val category: String = "OTHER",
    val createdByDeviceId: String,
    val isDeleted: Boolean = false,
    val createdAt: Long,
    val updatedAt: Long
)

@Entity(
    tableName = "habits",
    indices = [Index("updatedAt"), Index("kind")]
)
data class HabitEntity(
    @PrimaryKey val id: String,
    val title: String,
    val note: String = "",
    /** HABIT / MEDICINE */
    val kind: String = "HABIT",
    /** Free-text schedule, e.g. هر روز صبح / هر ۸ ساعت */
    val scheduleNote: String = "",
    /** Jalali or epoch day key of last completion */
    val lastCompletedDayKey: String = "",
    val isDeleted: Boolean = false,
    val createdAt: Long,
    val updatedAt: Long
)

@Entity(
    tableName = "watchlist_items",
    indices = [Index("updatedAt"), Index("status")]
)
data class WatchlistItemEntity(
    @PrimaryKey val id: String,
    val title: String,
    val note: String = "",
    /** MOVIE / SERIES */
    val mediaType: String = "MOVIE",
    /** WANT / WATCHING / DONE */
    val status: String = "WANT",
    val isDeleted: Boolean = false,
    val createdAt: Long,
    val updatedAt: Long
)

/** Local-only Telegram sticker pack cache (not peer-synced). */
@Entity(
    tableName = "telegram_sticker_packs",
    indices = [Index("importedAt")]
)
data class TelegramStickerPackEntity(
    @PrimaryKey val name: String,
    val title: String,
    val isAnimated: Boolean = false,
    val stickerCount: Int = 0,
    val importedAt: Long,
    val updatedAt: Long
)

/** Local-only individual stickers from imported Telegram packs. */
@Entity(
    tableName = "telegram_stickers",
    indices = [Index("packName"), Index("fileUniqueId")]
)
data class TelegramStickerEntity(
    @PrimaryKey val id: String,
    val packName: String,
    val fileUniqueId: String,
    val emoji: String = "⭐",
    val isAnimated: Boolean = false,
    val mimeType: String,
    val fileName: String,
    val sizeBytes: Long,
    val content: ByteArray,
    val createdAt: Long
)
