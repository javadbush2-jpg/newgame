package com.ourspace.app.core.security

import android.util.Base64
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec
import org.json.JSONObject

/** AES-GCM envelope for realtime application payloads. Pairing secret never travels over the wire. */
object SyncPayloadCrypto {
    private const val VERSION = 1
    private const val NONCE_BYTES = 12
    private const val TAG_BITS = 128

    fun encrypt(payload: JSONObject, secret: ByteArray): JSONObject {
        val nonce = ByteArray(NONCE_BYTES).also(SecureRandom()::nextBytes)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, key(secret), GCMParameterSpec(TAG_BITS, nonce))
        val ciphertext = cipher.doFinal(payload.toString().toByteArray(Charsets.UTF_8))
        return JSONObject()
            .put("type", "ourspace_encrypted")
            .put("v", VERSION)
            .put("nonce", Base64.encodeToString(nonce, Base64.NO_WRAP))
            .put("ciphertext", Base64.encodeToString(ciphertext, Base64.NO_WRAP))
            .apply { payload.optString("messageId").takeIf { it.isNotBlank() }?.let { put("messageId", it) } }
    }

    fun decrypt(envelope: JSONObject, secret: ByteArray): JSONObject {
        require(envelope.optInt("v") == VERSION) { "Unsupported encrypted sync version" }
        val nonce = Base64.decode(envelope.getString("nonce"), Base64.NO_WRAP)
        val ciphertext = Base64.decode(envelope.getString("ciphertext"), Base64.NO_WRAP)
        require(nonce.size == NONCE_BYTES)
        require(ciphertext.size <= MAX_CIPHERTEXT_BYTES)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, key(secret), GCMParameterSpec(TAG_BITS, nonce))
        return JSONObject(String(cipher.doFinal(ciphertext), Charsets.UTF_8))
    }

    private fun key(secret: ByteArray): SecretKeySpec {
        val digest = MessageDigest.getInstance("SHA-256").digest(secret)
        return SecretKeySpec(digest, "AES")
    }

    private const val MAX_CIPHERTEXT_BYTES = 240_000
}
