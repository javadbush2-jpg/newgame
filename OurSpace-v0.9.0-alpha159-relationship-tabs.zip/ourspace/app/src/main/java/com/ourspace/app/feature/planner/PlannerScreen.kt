package com.ourspace.app.feature.planner

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.DateRange
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.ShoppingCart
import androidx.compose.material3.AlertDialog
import com.ourspace.app.ui.design.OSConfirmDialog
import com.ourspace.app.ui.design.OSFormDialog
import androidx.compose.material3.Switch
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Tab
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import com.ourspace.app.core.cycle.CycleCalendarDisplay
import com.ourspace.app.core.cycle.CycleInsights
import com.ourspace.app.core.database.EventEntity
import com.ourspace.app.core.database.CycleLogEntity
import com.ourspace.app.core.database.CycleSettingsEntity
import com.ourspace.app.core.database.ShoppingItemEntity
import com.ourspace.app.core.database.SpecialDateEntity
import com.ourspace.app.core.database.TaskEntity
import com.ourspace.app.core.database.HabitEntity
import com.ourspace.app.core.time.PersianDateFormatter
import com.ourspace.app.ui.components.PersianDatePickerDialog
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar
import java.util.UUID

@Composable
fun PlannerScreen(
    tasks: List<TaskEntity>,
    events: List<EventEntity>,
    shoppingItems: List<ShoppingItemEntity>,
    specialDates: List<SpecialDateEntity> = emptyList(),
    cycleLogs: List<CycleLogEntity> = emptyList(),
    cycleSettings: CycleSettingsEntity? = null,
    habits: List<HabitEntity> = emptyList(),
    onAddTask: (String, Int, String, Long?, Int) -> Unit,
    onToggleTask: (TaskEntity) -> Unit,
    onDeleteTask: (TaskEntity) -> Unit,
    onAddEvent: (String, Long) -> Unit,
    onAddWorkScheduleEvents: (List<EventEntity>) -> Unit = { items -> items.forEach { onAddEvent(it.title, it.startAt) } },
    onUpdateEvent: (EventEntity, String, Long) -> Unit = { _, _, _ -> },
    onDeleteEvent: (EventEntity) -> Unit,
    onAddShopping: (String, String, String, Boolean) -> Unit,
    onToggleShopping: (ShoppingItemEntity) -> Unit,
    onDeleteShopping: (ShoppingItemEntity) -> Unit,
    onClearCheckedShopping: () -> Unit = {},
    onAddHabit: (String, String, String, String) -> Unit = { _, _, _, _ -> },
    onToggleHabitDoneToday: (HabitEntity) -> Unit = {},
    onDeleteHabit: (HabitEntity) -> Unit = {},
    onShareTaskToChat: (TaskEntity) -> Unit = {},
    onShareEventToChat: (EventEntity) -> Unit = {}
) {
    val appContext = LocalContext.current.applicationContext
    var selectedTab by remember { mutableIntStateOf(0) }
    var showCreateDialog by remember { mutableStateOf(false) }
    var workScheduleRefresh by remember { mutableIntStateOf(0) }
    // Ensure shift/office occurrences exist for calendar even if user never opens «ساعات کاری» tab
    LaunchedEffect(workScheduleRefresh, events.size) {
        val profiles = WorkScheduleStore.load(appContext)
        if (profiles.isEmpty()) return@LaunchedEffect
        val now = System.currentTimeMillis()
        val horizon = now + 90L * 24 * 60 * 60 * 1000
        val existingMarkers = events.filterNot { it.isDeleted }.map { it.details }.toSet()
        val blocked = WorkScheduleStore.exceptions(appContext)
        val additions = mutableListOf<EventEntity>()
        val nowCreated = System.currentTimeMillis()
        profiles.forEach { profile ->
            buildWorkOccurrences(profile, now, horizon).forEach { (start, end) ->
                val marker = workMarker(profile.id, start)
                if (marker !in existingMarkers && marker !in blocked) {
                    val title = if (profile.type == "SHIFT") "${profile.name} · شیفت کاری" else "${profile.name} · ساعت اداری"
                    additions += EventEntity(
                        id = java.util.UUID.nameUUIDFromBytes(marker.toByteArray(Charsets.UTF_8)).toString(),
                        title = title,
                        details = marker,
                        startAt = start,
                        endAt = end,
                        isShared = true,
                        createdAt = nowCreated,
                        updatedAt = nowCreated
                    )
                }
            }
        }
        if (additions.isNotEmpty()) onAddWorkScheduleEvents(additions)
    }
    val tabs = listOf("کارها", "هفتگی", "قرار", "خرید", "عادات", "ساعات کاری")

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            PlannerSummary(tasks, events, shoppingItems)
            ScrollableTabRow(selectedTabIndex = selectedTab) {
                tabs.forEachIndexed { index, title ->
                    Tab(
                        selected = selectedTab == index,
                        onClick = { selectedTab = index },
                        text = { Text(title) }
                    )
                }
            }
            AnimatedContent(
                targetState = selectedTab,
                transitionSpec = {
                    (slideInHorizontally { it / 5 } + fadeIn()).togetherWith(
                        slideOutHorizontally { -it / 6 } + fadeOut()
                    )
                },
                label = "planner-tabs"
            ) { tab ->
                when (tab) {
                    0 -> TasksList(tasks, onToggleTask, onDeleteTask, onShareTaskToChat)
                    1 -> WeeklyDivisionBoard(tasks, onToggleTask)
                    2 -> EventsList(events, onDeleteEvent, onUpdateEvent, onShareEventToChat)
                    3 -> ShoppingList(shoppingItems, onToggleShopping, onDeleteShopping, onClearCheckedShopping)
                    4 -> HabitsBoard(habits, onToggleHabitDoneToday, onDeleteHabit)
                    else -> WorkHoursBoard(events, onAddWorkScheduleEvents, onDeleteEvent, workScheduleRefresh)
                }
            }
        }
        FloatingActionButton(
            onClick = { showCreateDialog = true },
            modifier = Modifier.align(Alignment.BottomEnd).padding(20.dp)
        ) { Icon(Icons.Default.Add, "افزودن") }
    }

    if (showCreateDialog) {
        when (selectedTab) {
            0, 1 -> AddTaskDialog(onDismiss = { showCreateDialog = false }) { title, priority, assignee, dueAt, durationMinutes ->
                onAddTask(title, priority, assignee, dueAt, durationMinutes)
                showCreateDialog = false
            }
            2 -> AddEventDialog(onDismiss = { showCreateDialog = false }) { title, startAt ->
                onAddEvent(title, startAt)
                showCreateDialog = false
            }
            4 -> AddHabitDialog(onDismiss = { showCreateDialog = false }) { title, kind, schedule, note ->
                onAddHabit(title, kind, schedule, note)
                showCreateDialog = false
            }
            5 -> WorkScheduleDialog(
                onDismiss = { showCreateDialog = false },
                onSave = { profile ->
                    WorkScheduleStore.add(appContext, profile)
                    workScheduleRefresh++
                    showCreateDialog = false
                }
            )
            else -> AddShoppingDialog(
                existingItems = shoppingItems,
                onDismiss = { showCreateDialog = false }
            ) { title, quantity, category, recurring ->
                onAddShopping(title, quantity, category, recurring)
                showCreateDialog = false
            }
        }
    }
}

private data class WorkScheduleProfile(
    val id: String,
    val name: String,
    val type: String,
    val anchorAt: Long,
    val startHour: Int,
    val startMinute: Int,
    val endHour: Int = 17,
    val workDays: Set<Int> = setOf(Calendar.SATURDAY, Calendar.SUNDAY, Calendar.MONDAY, Calendar.TUESDAY, Calendar.WEDNESDAY)
)

private object WorkScheduleStore {
    private const val PREFS = "work_hours_schedule_v1"
    private const val PROFILES = "profiles"
    private const val EXCEPTIONS = "exceptions"

    fun load(context: android.content.Context): List<WorkScheduleProfile> {
        val raw = context.getSharedPreferences(PREFS, android.content.Context.MODE_PRIVATE).getString(PROFILES, "[]") ?: "[]"
        return runCatching {
            val array = JSONArray(raw)
            (0 until array.length()).map { i ->
                val o = array.getJSONObject(i)
                WorkScheduleProfile(
                    id = o.getString("id"), name = o.getString("name"), type = o.getString("type"),
                    anchorAt = o.getLong("anchorAt"), startHour = o.getInt("startHour"),
                    startMinute = o.optInt("startMinute", 0), endHour = o.optInt("endHour", 17),
                    workDays = runCatching {
                        val days = o.optJSONArray("workDays")
                        if (days == null || days.length() == 0) setOf(Calendar.SATURDAY, Calendar.SUNDAY, Calendar.MONDAY, Calendar.TUESDAY, Calendar.WEDNESDAY)
                        else (0 until days.length()).map { days.getInt(it) }.toSet()
                    }.getOrDefault(setOf(Calendar.SATURDAY, Calendar.SUNDAY, Calendar.MONDAY, Calendar.TUESDAY, Calendar.WEDNESDAY))
                )
            }
        }.getOrDefault(emptyList())
    }

    fun add(context: android.content.Context, profile: WorkScheduleProfile) {
        val all = load(context).filterNot { it.id == profile.id } + profile
        saveProfiles(context, all)
    }

    fun remove(context: android.content.Context, profileId: String) {
        saveProfiles(context, load(context).filterNot { it.id == profileId })
    }

    private fun saveProfiles(context: android.content.Context, profiles: List<WorkScheduleProfile>) {
        val array = JSONArray()
        profiles.forEach { p ->
            val days = JSONArray(); p.workDays.sorted().forEach { days.put(it) }
            array.put(JSONObject().put("id", p.id).put("name", p.name).put("type", p.type)
                .put("anchorAt", p.anchorAt).put("startHour", p.startHour).put("startMinute", p.startMinute).put("endHour", p.endHour).put("workDays", days))
        }
        context.getSharedPreferences(PREFS, android.content.Context.MODE_PRIVATE).edit().putString(PROFILES, array.toString()).apply()
    }

    fun exceptions(context: android.content.Context): Set<String> {
        val raw = context.getSharedPreferences(PREFS, android.content.Context.MODE_PRIVATE).getString(EXCEPTIONS, "[]") ?: "[]"
        return runCatching { val a = JSONArray(raw); (0 until a.length()).map { a.getString(it) }.toSet() }.getOrDefault(emptySet())
    }

    fun addException(context: android.content.Context, key: String) {
        val all = exceptions(context) + key
        val array = JSONArray(); all.forEach { array.put(it) }
        context.getSharedPreferences(PREFS, android.content.Context.MODE_PRIVATE).edit().putString(EXCEPTIONS, array.toString()).apply()
    }
}

private fun dayName(day: Int): String = when (day) {
    Calendar.SATURDAY -> "شنبه"
    Calendar.SUNDAY -> "یکشنبه"
    Calendar.MONDAY -> "دوشنبه"
    Calendar.TUESDAY -> "سه‌شنبه"
    Calendar.WEDNESDAY -> "چهارشنبه"
    Calendar.THURSDAY -> "پنجشنبه"
    Calendar.FRIDAY -> "جمعه"
    else -> "روز نامشخص"
}

private fun workMarker(profileId: String, occurrenceAt: Long) = "OS_WORK|$profileId|$occurrenceAt"

private fun normalizeWorkDigits(value: String): String = buildString {
    value.forEach { ch ->
        when (ch) {
            in '۰'..'۹' -> append(('0'.code + (ch - '۰')).toChar())
            in '٠'..'٩' -> append(('0'.code + (ch - '٠')).toChar())
            else -> if (ch.isDigit()) append(ch)
        }
    }
}

private fun buildWorkOccurrences(profile: WorkScheduleProfile, from: Long, until: Long): List<Pair<Long, Long>> {
    val result = mutableListOf<Pair<Long, Long>>()
    if (profile.type == "SHIFT") {
        val cycle = 60L * 60L * 60L * 1000L // 12 hours on + 48 hours off
        val duration = 12L * 60L * 60L * 1000L
        var start = profile.anchorAt
        if (start < from) start += ((from - start + cycle - 1) / cycle) * cycle
        while (start < until) { result += start to (start + duration); start += cycle }
    } else {
        val cal = Calendar.getInstance()
        cal.timeInMillis = maxOf(profile.anchorAt, from)
        cal.set(Calendar.HOUR_OF_DAY, 0); cal.set(Calendar.MINUTE, 0); cal.set(Calendar.SECOND, 0); cal.set(Calendar.MILLISECOND, 0)
        while (cal.timeInMillis < until) {
            val day = cal.get(Calendar.DAY_OF_WEEK)
            if (day in profile.workDays) {
                val dayStart = cal.timeInMillis
                val start = Calendar.getInstance().apply { timeInMillis = dayStart; set(Calendar.HOUR_OF_DAY, profile.startHour); set(Calendar.MINUTE, profile.startMinute); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }.timeInMillis
                val endHour = if (profile.endHour <= profile.startHour) profile.startHour + 1 else profile.endHour
                val end = Calendar.getInstance().apply { timeInMillis = dayStart; set(Calendar.HOUR_OF_DAY, endHour); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }.timeInMillis
                if (start >= from && start >= profile.anchorAt && end > start) result += start to end
            }
            cal.add(Calendar.DAY_OF_MONTH, 1)
        }
    }
    return result
}

@Composable
private fun WorkHoursBoard(
    events: List<EventEntity>,
    onAddWorkScheduleEvents: (List<EventEntity>) -> Unit,
    onDeleteEvent: (EventEntity) -> Unit,
    refreshKey: Int
) {
    val context = LocalContext.current.applicationContext
    var profiles by remember { mutableStateOf(WorkScheduleStore.load(context)) }
    var exceptions by remember { mutableStateOf(WorkScheduleStore.exceptions(context)) }
    LaunchedEffect(refreshKey) {
        profiles = WorkScheduleStore.load(context)
        exceptions = WorkScheduleStore.exceptions(context)
    }
    var generatedCount by remember { mutableIntStateOf(0) }
    var profileToDelete by remember { mutableStateOf<WorkScheduleProfile?>(null) }
    var editingProfile by remember { mutableStateOf<WorkScheduleProfile?>(null) }
    var occurrenceToDelete by remember { mutableStateOf<EventEntity?>(null) }
    var showAutoGenerationNotice by remember { mutableStateOf(false) }
    var clockNow by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) { while (true) { kotlinx.coroutines.delay(60_000L); clockNow = System.currentTimeMillis() } }
    val now = clockNow
    val horizon = now + 90L * 24 * 60 * 60 * 1000
    val generatedEvents = events.filter { it.details.startsWith("OS_WORK|") && !it.isDeleted }.sortedBy { it.startAt }

    fun generateMissingOccurrences(profile: WorkScheduleProfile): Int {
        val existingMarkers = events.filterNot { it.isDeleted }.map { it.details }.toSet()
        val blocked = WorkScheduleStore.exceptions(context)
        val nowCreated = System.currentTimeMillis()
        val additions = buildWorkOccurrences(profile, now, horizon).mapNotNull { (start, end) ->
            val marker = workMarker(profile.id, start)
            if (marker in existingMarkers || marker in blocked) null else {
                val title = if (profile.type == "SHIFT") "${profile.name} · شیفت کاری" else "${profile.name} · ساعت اداری"
                EventEntity(id = UUID.nameUUIDFromBytes(marker.toByteArray(Charsets.UTF_8)).toString(), title = title, details = marker,
                    startAt = start, endAt = end, isShared = true, createdAt = nowCreated, updatedAt = nowCreated)
            }
        }
        if (additions.isNotEmpty()) onAddWorkScheduleEvents(additions)
        return additions.size
    }

    LaunchedEffect(refreshKey, profiles, events.size, clockNow / (24L * 60 * 60 * 1000)) {
        val added = profiles.sumOf { generateMissingOccurrences(it) }
        if (added > 0) { generatedCount = added; showAutoGenerationNotice = true }
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("ساعات کاری", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Text("برای هر شغل یک الگوی جدا بساز. برنامه ۹۰ روز آینده به‌صورت خودکار در تقویم ثبت می‌شود؛ هر نوبت را هم می‌توانی به‌دلیل مرخصی یا تغییر برنامه حذف کنی.", style = MaterialTheme.typography.bodyMedium)
                Text("الگوی شیفتی: ۱۲ ساعت کار و ۴۸ ساعت استراحت. الگوی اداری: روزهای هفته و ساعت شروع/پایان قابل تنظیم است.", style = MaterialTheme.typography.bodySmall)
            }
        }
        if (profiles.isEmpty()) {
            Card { Text("هنوز الگوی کاری تعریف نشده است. از دکمه + پایین صفحه، شیفتی یا اداری را اضافه کن.", Modifier.padding(16.dp)) }
        }
        profiles.forEach { profile ->
            Card {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.weight(1f)) {
                            Text(profile.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            Text(if (profile.type == "SHIFT") "شیفت ۱۲ ساعت کار / ۴۸ ساعت استراحت" else "ساعات اداری · ${profile.startHour.toString().padStart(2, '0')}:${profile.startMinute.toString().padStart(2, '0')} تا ${profile.endHour.toString().padStart(2, '0')}:۰۰ · ${profile.workDays.sorted().joinToString("، ") { dayName(it) }}", style = MaterialTheme.typography.bodySmall)
                            Text("شروع الگو: ${PersianDateFormatter.formatDate(profile.anchorAt)}", style = MaterialTheme.typography.bodySmall)
                        }
                        IconButton(onClick = { editingProfile = profile }) { Icon(Icons.Outlined.Edit, contentDescription = "ویرایش الگوی کاری") }
                        IconButton(onClick = { profileToDelete = profile }) { Icon(Icons.Outlined.Delete, contentDescription = "حذف الگوی کاری") }
                    }
                    OutlinedButton(onClick = {
                        generatedCount = generateMissingOccurrences(profile)
                        showAutoGenerationNotice = false
                    }, modifier = Modifier.fillMaxWidth()) { Text("تکمیل برنامه ۹۰ روز آینده") }
                }
            }
        }
        if (generatedCount > 0) Text("${if (showAutoGenerationNotice) "برنامه به‌صورت خودکار تکمیل شد؛ " else "درخواست ثبت ارسال شد؛ "} ${PersianDateFormatter.toPersianDigits(generatedCount)} نوبت جدید. پس از همگام‌شدن، نوبت‌ها در تقویم دیده می‌شوند.", color = MaterialTheme.colorScheme.primary)
        Text("نوبت‌های ثبت‌شده", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        if (generatedEvents.isEmpty()) {
            Text("هنوز نوبت کاری ثبت نشده است.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        } else {
            generatedEvents.forEach { event ->
                val marker = event.details
                Card {
                    Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(event.title, fontWeight = FontWeight.SemiBold)
                            Text("${PersianDateFormatter.formatDate(event.startAt)} · ${java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault()).format(java.util.Date(event.startAt))}–${java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault()).format(java.util.Date(event.endAt ?: event.startAt))}", style = MaterialTheme.typography.bodySmall)
                        }
                        TextButton(onClick = { occurrenceToDelete = event }) { Text("حذف این نوبت") }
                    }
                }
            }
        }
        if (exceptions.isNotEmpty()) Text("حذف‌های استثنایی ذخیره شده‌اند و هنگام ساخت مجدد برنامه دوباره تولید نمی‌شوند.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
    profileToDelete?.let { profile ->
        OSConfirmDialog(
            title = "حذف الگوی کاری؟",
            message = "الگوی «${profile.name}» حذف می‌شود و نوبت‌های آینده ساخته‌شده از همین الگو نیز از تقویم حذف خواهند شد. نوبت‌های گذشته نگه داشته می‌شوند.",
            confirmLabel = "حذف الگو و نوبت‌های آینده",
            dismissLabel = "انصراف",
            destructive = true,
            emoji = "🗓️",
            onConfirm = {
                WorkScheduleStore.remove(context, profile.id)
                profiles = profiles.filterNot { it.id == profile.id }
                events.filter { it.details.startsWith("OS_WORK|${profile.id}|") && it.startAt >= System.currentTimeMillis() && !it.isDeleted }.forEach(onDeleteEvent)
                profileToDelete = null
            },
            onDismiss = { profileToDelete = null }
        )
    }
    occurrenceToDelete?.let { event ->
        OSConfirmDialog(
            title = "حذف نوبت کاری؟",
            message = "نوبت «${event.title}» در ${PersianDateFormatter.formatDateTime(event.startAt)} حذف شود؟ این حذف به‌عنوان استثنا ذخیره می‌شود.",
            confirmLabel = "حذف نوبت",
            dismissLabel = "انصراف",
            destructive = true,
            emoji = "🗑️",
            onConfirm = {
                WorkScheduleStore.addException(context, event.details)
                exceptions = exceptions + event.details
                onDeleteEvent(event)
                occurrenceToDelete = null
            },
            onDismiss = { occurrenceToDelete = null }
        )
    }
    editingProfile?.let { profile ->
        WorkScheduleDialog(
            initialProfile = profile,
            onDismiss = { editingProfile = null },
            onSave = { updated ->
                if (updated != profile) {
                    events.filter { it.details.startsWith("OS_WORK|${profile.id}|") && it.startAt >= System.currentTimeMillis() && !it.isDeleted }.forEach(onDeleteEvent)
                }
                WorkScheduleStore.add(context, updated)
                profiles = WorkScheduleStore.load(context)
                editingProfile = null
            }
        )
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun WorkScheduleDialog(initialProfile: WorkScheduleProfile? = null, onDismiss: () -> Unit, onSave: (WorkScheduleProfile) -> Unit) {
    var name by remember(initialProfile?.id) { mutableStateOf(initialProfile?.name ?: "") }
    var type by remember(initialProfile?.id) { mutableStateOf(initialProfile?.type ?: "SHIFT") }
    var anchorAt by remember(initialProfile?.id) { mutableLongStateOf(initialProfile?.anchorAt ?: System.currentTimeMillis()) }
    var startHour by remember(initialProfile?.id) { mutableStateOf((initialProfile?.startHour ?: 7).toString()) }
    var startMinute by remember(initialProfile?.id) { mutableStateOf((initialProfile?.startMinute ?: 0).toString()) }
    var endHour by remember(initialProfile?.id) { mutableStateOf((initialProfile?.endHour ?: 17).toString()) }
    var workDays by remember(initialProfile?.id) { mutableStateOf(initialProfile?.workDays ?: setOf(Calendar.SATURDAY, Calendar.SUNDAY, Calendar.MONDAY, Calendar.TUESDAY, Calendar.WEDNESDAY)) }
    var showDatePicker by remember { mutableStateOf(false) }
    OSFormDialog(
        title = if (initialProfile == null) "تعریف ساعات کاری" else "ویرایش الگوی کاری",
        emoji = "👷",
        onDismiss = onDismiss,
        onConfirm = { val sh = startHour.toIntOrNull() ?: -1
            val sm = startMinute.toIntOrNull() ?: -1
            val eh = endHour.toIntOrNull() ?: -1
            val day = Calendar.getInstance().apply { timeInMillis = anchorAt; set(Calendar.HOUR_OF_DAY, sh); set(Calendar.MINUTE, sm); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }.timeInMillis
            if (name.isNotBlank() && sh in 0..23 && sm in 0..59 && (type == "SHIFT" || (eh in 0..23 && eh > sh && workDays.isNotEmpty()))) {
                onSave(WorkScheduleProfile(initialProfile?.id ?: UUID.randomUUID().toString(), name.trim(), type, day, sh, sm, eh, workDays))
            } },
        confirmLabel = if (initialProfile == null) "ذخیره الگو" else "ذخیره تغییرات",
        confirmEnabled = name.isNotBlank()
    ) {
OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("نام شغل (مثلاً کار شیفتی یا اداری)") }, singleLine = true)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = type == "SHIFT", onClick = { type = "SHIFT"; startHour = "7"; startMinute = "0" }, label = { Text("شیفتی ۱۲/۴۸") })
                    FilterChip(selected = type == "OFFICE", onClick = { type = "OFFICE"; startHour = "9"; startMinute = "0"; endHour = "17" }, label = { Text("اداری") })
                }
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("تاریخ شروع")
                    AssistChip(onClick = { showDatePicker = true }, label = { Text(PersianDateFormatter.formatDate(anchorAt)) })
                }
                Text("ساعت شروع", style = MaterialTheme.typography.labelLarge)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = startHour, onValueChange = { startHour = normalizeWorkDigits(it).take(2) }, label = { Text("ساعت ۰–۲۳") }, modifier = Modifier.weight(1f), singleLine = true)
                    OutlinedTextField(value = startMinute, onValueChange = { startMinute = normalizeWorkDigits(it).take(2) }, label = { Text("دقیقه ۰–۵۹") }, modifier = Modifier.weight(1f), singleLine = true)
                }
                if (type == "OFFICE") {
                    OutlinedTextField(value = endHour, onValueChange = { endHour = normalizeWorkDigits(it).take(2) }, label = { Text("ساعت پایان ۰–۲۳") }, singleLine = true)
                    Text("روزهای کاری", style = MaterialTheme.typography.labelLarge)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf(Calendar.SATURDAY, Calendar.SUNDAY, Calendar.MONDAY, Calendar.TUESDAY, Calendar.WEDNESDAY, Calendar.THURSDAY, Calendar.FRIDAY).forEach { day ->
                            FilterChip(selected = day in workDays, onClick = { workDays = if (day in workDays) workDays - day else workDays + day }, label = { Text(dayName(day)) })
                        }
                    }
                }
                Text(if (type == "SHIFT") "از تاریخ و ساعت شروع، هر ۶۰ ساعت یک شیفت ۱۲ ساعته ساخته می‌شود." else "روزهای انتخاب‌شده، با ساعت شروع و پایان تعیین‌شده.", style = MaterialTheme.typography.bodySmall)
    }
    if (showDatePicker) PersianDatePickerDialog(title = "تاریخ شروع الگوی کاری", initialEpochMillis = anchorAt, onDismiss = { showDatePicker = false }, onConfirm = { anchorAt = it; showDatePicker = false })
}

@Composable
private fun PlannerSummary(
    tasks: List<TaskEntity>,
    events: List<EventEntity>,
    shoppingItems: List<ShoppingItemEntity>
) {
    val activeTasks = tasks.filterNot { it.isDeleted }
    val activeEvents = events.filter { !it.isDeleted && !it.details.orEmpty().startsWith("OS_WORK|") }
    val activeShopping = shoppingItems.filterNot { it.isDeleted }
    val openTasks = activeTasks.count { !it.isCompleted }
    val doneTasks = activeTasks.count { it.isCompleted }
    val totalTasks = activeTasks.size.coerceAtLeast(1)
    val progress = doneTasks.toFloat() / totalTasks.toFloat()
    val overdue = activeTasks.count { !it.isCompleted && it.dueAt != null && it.dueAt < System.currentTimeMillis() }
    val openShopping = activeShopping.count { !it.isChecked }
    val now = System.currentTimeMillis()
    val weekEnd = now + 7L * 24 * 60 * 60 * 1000
    val weekEvents = activeEvents.count { it.startAt in now..weekEnd }
    val urgent = activeTasks.count { !it.isCompleted && it.priority >= 2 }
    Card(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 10.dp),
        shape = RoundedCornerShape(26.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
    ) {
        Column(Modifier.padding(18.dp)) {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                SummaryMetric(PersianDateFormatter.toPersianDigits(openTasks), "کار باز")
                SummaryMetric(PersianDateFormatter.toPersianDigits(overdue), "از مهلت گذشته")
                SummaryMetric(PersianDateFormatter.toPersianDigits(weekEvents), "قرار هفته")
                SummaryMetric(PersianDateFormatter.toPersianDigits(openShopping), "خرید مانده")
            }
            Spacer(Modifier.height(12.dp))
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    "پیشرفت کارها",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onPrimaryContainer
                )
                Text(
                    "${PersianDateFormatter.toPersianDigits(doneTasks)} / ${PersianDateFormatter.toPersianDigits(activeTasks.size)}",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onPrimaryContainer
                )
            }
            androidx.compose.material3.LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier.fillMaxWidth().padding(top = 6.dp).height(8.dp),
                trackColor = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = .15f),
                color = MaterialTheme.colorScheme.primary
            )
            if (urgent > 0) {
                Text(
                    "${PersianDateFormatter.toPersianDigits(urgent)} کار فوری در صف است",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.error,
                    modifier = Modifier.padding(top = 8.dp)
                )
            }
        }
    }
}

@Composable
private fun SummaryMetric(value: String, label: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Black)
        Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onPrimaryContainer)
    }
}

@Composable
private fun TasksList(
    tasks: List<TaskEntity>,
    onToggle: (TaskEntity) -> Unit,
    onDelete: (TaskEntity) -> Unit,
    onShare: (TaskEntity) -> Unit = {}
) {
    var filter by remember { mutableIntStateOf(0) } // 0 all, 1 open, 2 done, 3 overdue, 4 urgent
    var assigneeFilter by remember { mutableStateOf("همه") }
    var taskToDelete by remember { mutableStateOf<TaskEntity?>(null) }
    var clockNow by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) { while (true) { kotlinx.coroutines.delay(60_000L); clockNow = System.currentTimeMillis() } }
    val now = clockNow
    val activeTasks = tasks.filterNot { it.isDeleted }
    val filtered = remember(activeTasks, filter, assigneeFilter, now) {
        var list = when (filter) {
            1 -> activeTasks.filter { !it.isCompleted }
            2 -> activeTasks.filter { it.isCompleted }
            3 -> activeTasks.filter { !it.isCompleted && it.dueAt != null && it.dueAt < now }
            4 -> activeTasks.filter { !it.isCompleted && it.priority >= 2 }
            else -> activeTasks
        }
        if (assigneeFilter != "همه") {
            list = list.filter { it.assignee == assigneeFilter }
        }
        list.sortedWith(
            compareBy<TaskEntity> { it.isCompleted }
                .thenByDescending { it.priority }
                .thenBy { it.dueAt ?: Long.MAX_VALUE }
        )
    }
    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            listOf("همه", "باز", "انجام‌شده", "گذشته", "فوری").forEachIndexed { index, label ->
                AssistChip(
                    onClick = { filter = index },
                    label = { Text(if (filter == index) "✓ $label" else label) }
                )
            }
        }
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            listOf("همه", "من", "همسرم", "مشترک").forEach { label ->
                AssistChip(
                    onClick = { assigneeFilter = label },
                    label = { Text(if (assigneeFilter == label) "✓ $label" else label) }
                )
            }
        }
        EmptyAwareList(
            isEmpty = filtered.isEmpty(),
            emptyTitle = if (activeTasks.isEmpty()) "هنوز کاری ثبت نشده" else "موردی در این فیلتر نیست",
            emptySubtitle = "با دکمه + کار جدید اضافه کنید.",
            icon = { Icon(Icons.Outlined.CheckCircle, null, modifier = Modifier.size(56.dp)) }
        ) {
            items(filtered, key = { it.id }) { task ->
                val overdue = !task.isCompleted && task.dueAt != null && task.dueAt < now
                Card(
                    modifier = Modifier.fillMaxWidth().animateContentSize().clickable { onToggle(task) },
                    shape = RoundedCornerShape(22.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = when {
                            task.isCompleted -> MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = 0.7f)
                            overdue -> MaterialTheme.colorScheme.errorContainer.copy(alpha = .45f)
                            else -> MaterialTheme.colorScheme.surface
                        }
                    )
                ) {
                    Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = task.isCompleted, onCheckedChange = { onToggle(task) })
                        Column(Modifier.weight(1f).alpha(if (task.isCompleted) .58f else 1f)) {
                            Text(
                                task.title,
                                fontWeight = FontWeight.SemiBold,
                                textDecoration = if (task.isCompleted) TextDecoration.LineThrough else null
                            )
                            Text(
                                buildString {
                                    append(task.assignee)
                                    append(" • ")
                                    append(priorityLabel(task.priority))
                                    append(" • مدت: ")
                                    append(if (task.durationMinutes >= 60) "${task.durationMinutes / 60} ساعت${if (task.durationMinutes % 60 > 0) " و ${task.durationMinutes % 60} دقیقه" else ""}" else "${task.durationMinutes} دقیقه")
                                    task.dueAt?.let {
                                        append(" • ")
                                        append(if (overdue) "گذشته از موعد: " else "مهلت: ")
                                        append(PersianDateFormatter.formatDate(it))
                                    }
                                },
                                style = MaterialTheme.typography.bodySmall,
                                color = if (overdue) MaterialTheme.colorScheme.error else priorityColor(task.priority)
                            )
                        }
                        IconButton(onClick = { onShare(task) }) { Icon(Icons.Outlined.Share, "اشتراک در چت") }
                        IconButton(onClick = { taskToDelete = task }) { Icon(Icons.Outlined.Delete, "حذف") }
                    }
                }
                Spacer(Modifier.height(10.dp))
            }
        }
    }
    taskToDelete?.let { task ->
        OSConfirmDialog(
            title = "حذف کار؟",
            message = "کار «${task.title}» حذف شود؟",
            confirmLabel = "حذف",
            dismissLabel = "انصراف",
            destructive = true,
            emoji = "✓",
            onConfirm = { onDelete(task); taskToDelete = null },
            onDismiss = { taskToDelete = null }
        )
    }
}

@Composable
private fun EventsList(
    events: List<EventEntity>,
    onDelete: (EventEntity) -> Unit,
    onUpdate: (EventEntity, String, Long) -> Unit,
    onShare: (EventEntity) -> Unit = {}
) {
    var editingEvent by remember { mutableStateOf<EventEntity?>(null) }
    var eventToDelete by remember { mutableStateOf<EventEntity?>(null) }
    val visibleEvents = events.filter { !it.isDeleted && !it.details.orEmpty().startsWith("OS_WORK|") }
    EmptyAwareList(
        isEmpty = visibleEvents.isEmpty(),
        emptyTitle = "قرار ملاقاتی ثبت نشده است",
        emptySubtitle = "قرار یا مناسبت بعدی را اضافه کنید.",
        icon = { Icon(Icons.Outlined.DateRange, null, modifier = Modifier.size(56.dp)) }
    ) {
        items(visibleEvents, key = { it.id }) { event ->
            Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(22.dp)) {
                Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier.size(46.dp).background(MaterialTheme.colorScheme.tertiaryContainer, RoundedCornerShape(15.dp)),
                        contentAlignment = Alignment.Center
                    ) { Icon(Icons.Outlined.DateRange, null, tint = MaterialTheme.colorScheme.onTertiaryContainer) }
                    Column(Modifier.weight(1f).padding(horizontal = 14.dp)) {
                        Text(event.title, fontWeight = FontWeight.Bold)
                        Text(
                            PersianDateFormatter.formatDateTime(event.startAt),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    IconButton(onClick = { editingEvent = event }) { Icon(Icons.Outlined.Edit, "اصلاح قرار") }
                    IconButton(onClick = { onShare(event) }) { Icon(Icons.Outlined.Share, "اشتراک در چت") }
                    IconButton(onClick = { eventToDelete = event }) { Icon(Icons.Outlined.Delete, "حذف") }
                }
            }
            Spacer(Modifier.height(10.dp))
        }
    }
    editingEvent?.let { event ->
        EditEventDialog(
            event = event,
            onDismiss = { editingEvent = null },
            onSave = { title, startAt ->
                onUpdate(event, title, startAt)
                editingEvent = null
            }
        )
    }
}

@Composable
private fun ShoppingList(
    items: List<ShoppingItemEntity>,
    onToggle: (ShoppingItemEntity) -> Unit,
    onDelete: (ShoppingItemEntity) -> Unit,
    onClearChecked: () -> Unit = {}
) {
    var itemToDelete by remember { mutableStateOf<ShoppingItemEntity?>(null) }
    var confirmClearChecked by remember { mutableStateOf(false) }
    val visibleItems = items.filterNot { it.isDeleted }
    val checkedCount = visibleItems.count { it.isChecked }
    Column(Modifier.fillMaxSize()) {
        if (checkedCount > 0) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    "${PersianDateFormatter.toPersianDigits(checkedCount)} مورد خریداری‌شده",
                    style = MaterialTheme.typography.bodySmall
                )
                TextButton(onClick = { confirmClearChecked = true }) { Text("پاک‌سازی خریداری‌شده‌ها") }
            }
        }
    EmptyAwareList(
        isEmpty = visibleItems.isEmpty(),
        emptyTitle = "فهرست خرید خالی است",
        emptySubtitle = "اقلام موردنیاز خانه را همین‌جا بنویسید.",
        icon = { Icon(Icons.Outlined.ShoppingCart, null, modifier = Modifier.size(56.dp)) }
    ) {
        items(visibleItems, key = { it.id }) { item ->
            Card(
                modifier = Modifier.fillMaxWidth().clickable { onToggle(item) },
                shape = RoundedCornerShape(22.dp)
            ) {
                Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = item.isChecked, onCheckedChange = { onToggle(item) })
                    Column(Modifier.weight(1f).alpha(if (item.isChecked) .55f else 1f)) {
                        Text(
                            item.title,
                            fontWeight = FontWeight.SemiBold,
                            textDecoration = if (item.isChecked) TextDecoration.LineThrough else null
                        )
                        Text(
                            buildString {
                                append(item.quantity)
                                append(" • ")
                                append(item.category)
                                if (item.isRecurring) append(" • تکرارشونده")
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = if (item.isRecurring) MaterialTheme.colorScheme.primary
                            else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    IconButton(onClick = { itemToDelete = item }) { Icon(Icons.Outlined.Delete, "حذف") }
                }
            }
            Spacer(Modifier.height(10.dp))
        }
    }
    }
    if (confirmClearChecked) {
        OSConfirmDialog(
            title = "پاک‌سازی خریداری‌شده‌ها؟",
            message = "تمام اقلام علامت‌خورده به‌عنوان خریداری‌شده از فهرست حذف می‌شوند.",
            confirmLabel = "پاک‌سازی",
            dismissLabel = "انصراف",
            destructive = true,
            emoji = "🛒",
            onConfirm = { onClearChecked(); confirmClearChecked = false },
            onDismiss = { confirmClearChecked = false }
        )
    }
    itemToDelete?.let { item ->
        OSConfirmDialog(
            title = "حذف کالا؟",
            message = "«${item.title}» از فهرست خرید حذف شود؟",
            confirmLabel = "حذف",
            dismissLabel = "انصراف",
            destructive = true,
            emoji = "🧺",
            onConfirm = { onDelete(item); itemToDelete = null },
            onDismiss = { itemToDelete = null }
        )
    }
}

@Composable
private fun EmptyAwareList(
    isEmpty: Boolean,
    emptyTitle: String,
    emptySubtitle: String,
    icon: @Composable () -> Unit,
    content: androidx.compose.foundation.lazy.LazyListScope.() -> Unit
) {
    if (isEmpty) {
        Column(
            Modifier.fillMaxSize().padding(36.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(
                Modifier.size(104.dp).background(
                    MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.8f),
                    CircleShape
                ),
                contentAlignment = Alignment.Center
            ) { icon() }
            Text(
                emptyTitle,
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Black,
                modifier = Modifier.padding(top = 22.dp)
            )
            Text(
                emptySubtitle,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                style = MaterialTheme.typography.bodyMedium,
                modifier = Modifier.padding(top = 8.dp)
            )
        }
    } else {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 18.dp, end = 18.dp, top = 16.dp, bottom = 96.dp),
            content = content
        )
    }
}

@Composable
private fun AddTaskDialog(onDismiss: () -> Unit, onAdd: (String, Int, String, Long?, Int) -> Unit) {
    var title by remember { mutableStateOf("") }
    var priority by remember { mutableIntStateOf(1) }
    var durationMinutes by remember { mutableIntStateOf(60) }
    var assignee by remember { mutableStateOf("مشترک") }
    var dueAt by remember { mutableStateOf<Long?>(null) }
    var hour by remember { mutableIntStateOf(12) }
    var minute by remember { mutableIntStateOf(0) }
    var showDatePicker by remember { mutableStateOf(false) }
    InputDialog("کار جدید", title, { title = it }, onDismiss, {
        val timed = dueAt?.let { applyTime(it, hour, minute) }
        onAdd(title, priority, assignee, timed, durationMinutes)
    }) {
        Text("مدت تخمینی انجام کار", style = MaterialTheme.typography.labelLarge)
        Text("زمان انتخابی در تقویم برای برنامه‌ریزی کار استفاده می‌شود.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
            listOf(15 to "۱۵ دقیقه", 30 to "۳۰ دقیقه", 60 to "۱ ساعت", 120 to "۲ ساعت", 240 to "۴ ساعت").forEach { (minutes, label) ->
                AssistChip(onClick = { durationMinutes = minutes }, label = { Text(if (durationMinutes == minutes) "✓ $label" else label) })
            }
        }
    
        Text("اولویت", style = MaterialTheme.typography.labelLarge)
        Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            listOf(0 to "کم", 1 to "معمولی", 2 to "فوری").forEach { (value, label) ->
                AssistChip(onClick = { priority = value }, label = { Text(if (priority == value) "✓ $label" else label) })
            }
        }
        Text("مسئول", style = MaterialTheme.typography.labelLarge)
        Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            listOf("مشترک", "من", "همسرم").forEach { value ->
                AssistChip(onClick = { assignee = value }, label = { Text(if (assignee == value) "✓ $value" else value) })
            }
        }
        Text("تاریخ و ساعت برنامه‌ریزی / مهلت (اختیاری)", style = MaterialTheme.typography.labelLarge)
        Row(horizontalArrangement = Arrangement.spacedBy(7.dp), verticalAlignment = Alignment.CenterVertically) {
            AssistChip(
                onClick = { showDatePicker = true },
                label = {
                    Text(
                        dueAt?.let { PersianDateFormatter.formatDate(it) } ?: "انتخاب تاریخ"
                    )
                }
            )
            if (dueAt != null) {
                TextButton(onClick = { dueAt = null }) { Text("حذف مهلت") }
            }
        }
        if (dueAt != null) {
            TimePickerRow(hour = hour, minute = minute, onHour = { hour = it }, onMinute = { minute = it })
        }
    }
    if (showDatePicker) {
        PersianDatePickerDialog(
            title = "زمان برنامه‌ریزی یا مهلت کار",
            initialEpochMillis = dueAt ?: (System.currentTimeMillis() + 24 * 60 * 60 * 1000L),
            onDismiss = { showDatePicker = false },
            onConfirm = { dueAt = it; showDatePicker = false }
        )
    }
}

@Composable
private fun EditEventDialog(
    event: EventEntity,
    onDismiss: () -> Unit,
    onSave: (String, Long) -> Unit
) {
    var title by remember(event.id) { mutableStateOf(event.title) }
    var eventAt by remember(event.id) { mutableLongStateOf(event.startAt) }
    var hour by remember(event.id) {
        mutableIntStateOf(java.util.Calendar.getInstance().apply { timeInMillis = event.startAt }.get(java.util.Calendar.HOUR_OF_DAY))
    }
    var minute by remember(event.id) {
        mutableIntStateOf(java.util.Calendar.getInstance().apply { timeInMillis = event.startAt }.get(java.util.Calendar.MINUTE).let {
            listOf(0, 15, 30, 45).minByOrNull { m -> kotlin.math.abs(m - it) } ?: 0
        })
    }
    var showDatePicker by remember { mutableStateOf(false) }
    InputDialog("اصلاح قرار", title, { title = it }, onDismiss, {
        onSave(title.trim(), applyTime(eventAt, hour, minute))
    }) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            onClick = { showDatePicker = true },
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow)
        ) {
            Text(
                "تاریخ قرار: ${PersianDateFormatter.formatDate(eventAt)}",
                modifier = Modifier.padding(12.dp),
                style = MaterialTheme.typography.bodySmall
            )
        }
        TimePickerRow(hour = hour, minute = minute, onHour = { hour = it }, onMinute = { minute = it })
        Text("عنوان، تاریخ و ساعت قرار را اصلاح کن.", style = MaterialTheme.typography.bodySmall)
    }
    if (showDatePicker) {
        PersianDatePickerDialog(
            title = "تاریخ قرار",
            initialEpochMillis = eventAt,
            onDismiss = { showDatePicker = false },
            onConfirm = { eventAt = it; showDatePicker = false }
        )
    }
}

@Composable
private fun AddEventDialog(onDismiss: () -> Unit, onAdd: (String, Long) -> Unit) {
    var title by remember { mutableStateOf("") }
    var eventAt by remember { mutableStateOf(System.currentTimeMillis() + 24 * 60 * 60 * 1000L) }
    var hour by remember { mutableIntStateOf(12) }
    var minute by remember { mutableIntStateOf(0) }
    var showDatePicker by remember { mutableStateOf(false) }
    InputDialog("قرار جدید", title, { title = it }, onDismiss, {
        onAdd(title, applyTime(eventAt, hour, minute))
    }) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            onClick = { showDatePicker = true },
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow)
        ) {
            Text(
                "تاریخ قرار: ${PersianDateFormatter.formatDate(eventAt)}",
                modifier = Modifier.padding(12.dp),
                style = MaterialTheme.typography.bodySmall
            )
        }
        TimePickerRow(hour = hour, minute = minute, onHour = { hour = it }, onMinute = { minute = it })
        Text("تاریخ شمسی و ساعت قرار را انتخاب کن.", style = MaterialTheme.typography.bodySmall)
    }
    if (showDatePicker) {
        PersianDatePickerDialog(
            title = "تاریخ قرار",
            initialEpochMillis = eventAt,
            onDismiss = { showDatePicker = false },
            onConfirm = { eventAt = it; showDatePicker = false }
        )
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun AddShoppingDialog(
    existingItems: List<ShoppingItemEntity>,
    onDismiss: () -> Unit,
    onAdd: (String, String, String, Boolean) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var quantity by remember { mutableIntStateOf(1) }
    var category by remember { mutableStateOf("خانه") }
    var recurring by remember { mutableStateOf(false) }
    val suggestions = remember(existingItems) {
        existingItems
            .filter { !it.isDeleted }
            .groupingBy { it.title.trim() }
            .eachCount()
            .entries
            .sortedByDescending { it.value }
            .map { it.key }
            .filter { it.isNotBlank() }
            .take(10)
    }
    InputDialog("افزودن به خرید", title, { title = it }, onDismiss, { onAdd(title, "${PersianDateFormatter.toPersianDigits(quantity)} عدد", category, recurring) }) {
        if (suggestions.isNotEmpty()) {
            Text("پیشنهاد هوشمند", style = MaterialTheme.typography.labelLarge)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                suggestions.take(5).forEach { suggestion ->
                    AssistChip(
                        onClick = { title = suggestion },
                        label = { Text(suggestion) }
                    )
                }
            }
        }
        Text("تعداد کالا", style = MaterialTheme.typography.labelLarge)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { if (quantity > 1) quantity-- }, enabled = quantity > 1) {
                Text("−", style = MaterialTheme.typography.headlineMedium)
            }
            Text(
                PersianDateFormatter.toPersianDigits(quantity),
                modifier = Modifier.padding(horizontal = 24.dp),
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.SemiBold
            )
            IconButton(onClick = { if (quantity < 99) quantity++ }, enabled = quantity < 99) {
                Text("+", style = MaterialTheme.typography.headlineMedium)
            }
        }
        Text("برای تغییر تعداد از دکمه‌های − و + استفاده کنید.", style = MaterialTheme.typography.bodySmall)
        Text("دسته‌بندی", style = MaterialTheme.typography.labelLarge)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            SHOPPING_CATEGORIES.forEach { value ->
                AssistChip(
                    onClick = { category = value },
                    label = { Text(if (category == value) "✓ $value" else value) }
                )
            }
        }
        Row(
            Modifier.fillMaxWidth().padding(top = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Checkbox(checked = recurring, onCheckedChange = { recurring = it })
            Text("تکرارشونده (بعد از خرید دوباره در لیست بماند)", style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
private fun WeeklyDivisionBoard(
    tasks: List<TaskEntity>,
    onToggle: (TaskEntity) -> Unit
) {
    val activeTasks = tasks.filter { !it.isDeleted && !it.isCompleted }
    var clockNow by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) { while (true) { kotlinx.coroutines.delay(60_000L); clockNow = System.currentTimeMillis() } }
    val calendar = Calendar.getInstance().apply { timeInMillis = clockNow; set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }
    val todayStart = calendar.timeInMillis
    val dayMs = 24L * 60 * 60 * 1000
    val overdue = activeTasks.filter { it.dueAt != null && it.dueAt < clockNow }
    val noDate = activeTasks.filter { it.dueAt == null }
    val upcoming = (0..6).map { offset ->
        val dayStart = todayStart + offset * dayMs
        val start = if (offset == 0) maxOf(dayStart, clockNow) else dayStart
        val end = dayStart + dayMs
        val dayCalendar = Calendar.getInstance().apply { timeInMillis = start }
        val dayTitle = (if (offset == 0) "امروز" else if (offset == 1) "فردا" else dayName(dayCalendar.get(Calendar.DAY_OF_WEEK))) + " · " + PersianDateFormatter.formatDate(start)
        dayTitle to activeTasks.filter { it.dueAt != null && it.dueAt >= start && it.dueAt < end }
    }
    val any = overdue.isNotEmpty() || noDate.isNotEmpty() || upcoming.any { it.second.isNotEmpty() }
    EmptyAwareList(
        isEmpty = !any,
        emptyTitle = "برای این هفته کاری باز نیست",
        emptySubtitle = "برای زمان‌بندی هفتگی، هنگام ساخت کار مهلت تعیین کنید.",
        icon = { Icon(Icons.Outlined.CheckCircle, null, modifier = Modifier.size(56.dp)) }
    ) {
        if (overdue.isNotEmpty()) {
            item { Text("عقب‌افتاده · ${PersianDateFormatter.toPersianDigits(overdue.size)} کار", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.error) }
            items(overdue, key = { "overdue-${it.id}" }) { task -> WeeklyTaskCard(task, onToggle) }
        }
        upcoming.forEach { (title, dayTasks) ->
            item { Text("$title · ${PersianDateFormatter.toPersianDigits(dayTasks.size)} کار", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall, modifier = Modifier.padding(top = 8.dp, bottom = 4.dp)) }
            if (dayTasks.isEmpty()) item { Text("کاری زمان‌بندی نشده", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(bottom = 6.dp)) }
            else items(dayTasks, key = { "day-${it.id}" }) { task -> WeeklyTaskCard(task, onToggle) }
        }
        if (noDate.isNotEmpty()) {
            item { Text("بدون مهلت · ${PersianDateFormatter.toPersianDigits(noDate.size)} کار", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall, modifier = Modifier.padding(top = 8.dp)) }
            items(noDate, key = { "undated-${it.id}" }) { task -> WeeklyTaskCard(task, onToggle) }
        }
    }
}

@Composable
private fun WeeklyTaskCard(task: TaskEntity, onToggle: (TaskEntity) -> Unit) {
    Card(modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp).clickable { onToggle(task) }, shape = RoundedCornerShape(16.dp)) {
        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Checkbox(checked = task.isCompleted, onCheckedChange = { onToggle(task) })
            Column(Modifier.weight(1f)) {
                Text(task.title, fontWeight = FontWeight.SemiBold)
                Text("${task.assignee} · ${priorityLabel(task.priority)} · ${if (task.durationMinutes >= 60) "${task.durationMinutes / 60} ساعت" else "${task.durationMinutes} دقیقه"}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
private fun InputDialog(
    title: String,
    value: String,
    onValueChange: (String) -> Unit,
    onDismiss: () -> Unit,
    onConfirm: () -> Unit,
    extraContent: @Composable ColumnScope.() -> Unit
) {
    OSFormDialog(
        title = title,
        emoji = "✏️",
        onDismiss = onDismiss,
        onConfirm = { onConfirm() },
        confirmLabel = "ذخیره",
        confirmEnabled = value.isNotBlank()
    ) {
OutlinedTextField(
                    value = value,
                    onValueChange = onValueChange,
                    label = { Text("عنوان") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                extraContent()
    }
}

private fun priorityLabel(priority: Int): String = when (priority) {
    2 -> "فوری"
    1 -> "مهم"
    else -> "عادی"
}

@Composable
private fun priorityColor(priority: Int): Color = when (priority) {
    2 -> MaterialTheme.colorScheme.error
    1 -> MaterialTheme.colorScheme.tertiary
    else -> MaterialTheme.colorScheme.onSurfaceVariant
}

/** Shopping categories offered when adding an item. */
private val SHOPPING_CATEGORIES = listOf(
    "خانه",
    "خوراکی",
    "میوه و سبزیجات",
    "گوشت و پروتئین",
    "لبنیات",
    "نان و غلات",
    "تنقلات",
    "نوشیدنی",
    "بهداشتی",
    "آرایشی",
    "دارو و سلامت",
    "شوینده",
    "لوازم خانه",
    "پوشاک",
    "کودک",
    "حیوان خانگی",
    "لوازم‌التحریر",
    "دیجیتال",
    "هدیه",
    "سفر",
    "متفرقه"
)


@Composable
private fun localCalendarDayEnd(epoch: Long): Long = java.util.Calendar.getInstance().apply {
    timeInMillis = epoch
    add(java.util.Calendar.DAY_OF_YEAR, 1)
    set(java.util.Calendar.HOUR_OF_DAY, 0)
    set(java.util.Calendar.MINUTE, 0)
    set(java.util.Calendar.SECOND, 0)
    set(java.util.Calendar.MILLISECOND, 0)
    add(java.util.Calendar.MILLISECOND, -1)
}.timeInMillis

@Composable
private fun MonthCalendarBoard(
    tasks: List<TaskEntity>,
    events: List<EventEntity>,
    specialDates: List<SpecialDateEntity>,
    cycleLogs: List<CycleLogEntity>,
    cycleSettings: CycleSettingsEntity?
) {
    var monthOffset by remember { mutableIntStateOf(0) }
    var selectedDayStart by remember { mutableStateOf<Long?>(null) }
    // This board is Jalali throughout: title, weekday alignment, day count and selected-day ranges.
    val currentJalali = remember { PersianDateFormatter.jalaliDate(System.currentTimeMillis()) }
    val absoluteMonth = currentJalali.year * 12 + currentJalali.month - 1 + monthOffset
    val year = Math.floorDiv(absoluteMonth, 12)
    val month = Math.floorMod(absoluteMonth, 12) + 1
    val monthStartMs = remember(year, month) { PersianDateFormatter.toEpochMillis(year, month, 1, 0) }
    val daysInMonth = PersianDateFormatter.daysInJalaliMonth(year, month)
    val firstDow = java.util.Calendar.getInstance().apply { timeInMillis = monthStartMs }.get(java.util.Calendar.DAY_OF_WEEK) % 7
    val jalaliLabel = "${PersianDateFormatter.jalaliMonthName(month)} ${PersianDateFormatter.toPersianDigits(year)}"

    fun dayStart(day: Int): Long = PersianDateFormatter.toEpochMillis(year, month, day, 0)
    fun dayEnd(day: Int): Long = if (day < daysInMonth) dayStart(day + 1) - 1 else PersianDateFormatter.toEpochMillis(year, month, day, 23).let { it + 59L * 60_000L + 59_999L }
    val calendarNow = Calendar.getInstance().apply {
        timeInMillis = System.currentTimeMillis()
        set(Calendar.HOUR_OF_DAY, 0)
        set(Calendar.MINUTE, 0)
        set(Calendar.SECOND, 0)
        set(Calendar.MILLISECOND, 0)
    }.timeInMillis
    fun calculatedPeriodEnd(log: CycleLogEntity): Long =
        CycleCalendarDisplay.actualPeriodEndAt(log, calendarNow)
    fun isBleedingOn(log: CycleLogEntity, start: Long, end: Long): Boolean =
        CycleCalendarDisplay.isActualPeriodOn(log, start, end, calendarNow)
    val predictedPeriod = CycleCalendarDisplay.predictedNextPeriod(cycleLogs, cycleSettings, calendarNow)

    val monthEndMs = dayEnd(daysInMonth)
    val monthEvents = events.filter { !it.isDeleted && !it.details.orEmpty().startsWith("OS_WORK|") && it.startAt in monthStartMs..monthEndMs }.sortedBy { it.startAt }
    val monthTasks = tasks.filter {
        !it.isDeleted && it.dueAt != null && it.dueAt!! in monthStartMs..monthEndMs
    }.sortedBy { it.dueAt }
    val monthSpecials = specialDates.filter { sd ->
        !sd.isDeleted && (1..daysInMonth).any { d -> marksDay(sd, dayStart(d)) }
    }
    val periodDays = (1..daysInMonth).count { d ->
        val s = dayStart(d); val e = dayEnd(d)
        cycleLogs.any { log -> isBleedingOn(log, s, e) } || predictedPeriod?.overlaps(s, e) == true
    }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextButton(onClick = { monthOffset-- }) { Text("‹ قبلی") }
            Text(jalaliLabel, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Black)
            TextButton(onClick = { monthOffset++ }) { Text("بعدی ›") }
        }
        Spacer(Modifier.height(8.dp))
        Card(
            Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.55f)
            )
        ) {
            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("خلاصه این ماه", fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleSmall)
                Text(
                    "قرار: ${PersianDateFormatter.toPersianDigits(monthEvents.size)}  ·  کار: ${PersianDateFormatter.toPersianDigits(monthTasks.size)}  ·  مناسبت: ${PersianDateFormatter.toPersianDigits(monthSpecials.size)}  ·  روزهای قاعدگی/پیش‌بینی: ${PersianDateFormatter.toPersianDigits(periodDays)}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            listOf("ش", "ی", "د", "س", "چ", "پ", "ج").forEach { d ->
                Text(d, modifier = Modifier.weight(1f), style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        Spacer(Modifier.height(6.dp))
        val cells = firstDow + daysInMonth
        val rows = (cells + 6) / 7
        for (r in 0 until rows) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                for (c in 0 until 7) {
                    val idx = r * 7 + c
                    val day = idx - firstDow + 1
                    if (day in 1..daysInMonth) {
                        val start = dayStart(day)
                        val end = dayEnd(day)
                        val dayEvents = events.filter { !it.isDeleted && !it.details.orEmpty().startsWith("OS_WORK|") && it.startAt in start..end }
                        val dayTasks = tasks.filter { !it.isDeleted && !it.isCompleted && it.dueAt != null && it.dueAt!! in start..end }
                        val daySpecials = specialDates.filter { !it.isDeleted && marksDay(it, start) }
                        val dayPeriods = cycleLogs.filter { !it.isDeleted && it.startAt in start..end }
                        val actualBleeding = cycleLogs.any { log -> isBleedingOn(log, start, end) }
                        val predictedBleeding = !actualBleeding && predictedPeriod?.overlaps(start, end) == true
                        val bleeding = actualBleeding || predictedBleeding
                        val has = dayEvents.isNotEmpty() || dayTasks.isNotEmpty() || daySpecials.isNotEmpty() || bleeding || dayPeriods.isNotEmpty()
                        val selected = selectedDayStart == start
                        Column(
                            Modifier
                                .weight(1f)
                                .height(62.dp)
                                .background(
                                    when {
                                        selected -> MaterialTheme.colorScheme.primary.copy(alpha = .20f)
                                        actualBleeding && daySpecials.isNotEmpty() -> MaterialTheme.colorScheme.tertiary.copy(alpha = .22f)
                                        predictedBleeding && daySpecials.isNotEmpty() -> Color(0xFFE9A4D8).copy(alpha = .24f)
                                        actualBleeding -> MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = .75f)
                                        predictedBleeding -> Color(0xFFE9A4D8).copy(alpha = .42f)
                                        daySpecials.isNotEmpty() -> MaterialTheme.colorScheme.secondaryContainer.copy(alpha = .7f)
                                        dayEvents.isNotEmpty() -> MaterialTheme.colorScheme.primaryContainer.copy(alpha = .65f)
                                        dayTasks.isNotEmpty() -> MaterialTheme.colorScheme.surfaceVariant.copy(alpha = .7f)
                                        else -> MaterialTheme.colorScheme.surfaceVariant.copy(alpha = .35f)
                                    }, RoundedCornerShape(12.dp)
                                )
                                .clickable { selectedDayStart = start }
                                .padding(4.dp)
                        ) {
                            Text(PersianDateFormatter.toPersianDigits(day), style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                            if (has) {
                                Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                                    if (actualBleeding) {
                                        Box(Modifier.size(6.dp).background(MaterialTheme.colorScheme.tertiary, CircleShape))
                                    } else if (predictedBleeding) {
                                        Box(Modifier.size(6.dp).background(Color(0xFFE9A4D8), CircleShape))
                                    }
                                    if (dayEvents.isNotEmpty()) {
                                        Box(Modifier.size(6.dp).background(MaterialTheme.colorScheme.primary, CircleShape))
                                    }
                                    if (dayTasks.isNotEmpty()) {
                                        Box(Modifier.size(6.dp).background(MaterialTheme.colorScheme.outline, CircleShape))
                                    }
                                    if (daySpecials.isNotEmpty()) {
                                        Box(Modifier.size(6.dp).background(MaterialTheme.colorScheme.secondary, CircleShape))
                                    }
                                }
                            }
                        }
                    } else Spacer(Modifier.weight(1f).height(58.dp))
                }
            }
            Spacer(Modifier.height(4.dp))
        }
        Spacer(Modifier.height(12.dp))
        Text(
            "قاعدگی ثبت‌شده: حداکثر ۵ روز" +
                (predictedPeriod?.let { " · پیش‌بینی: ${PersianDateFormatter.toPersianDigits(it.displayDays)} روز اول" } ?: "") +
                " · اصلی: قرار · خاکستری: کار · ثانویه: مناسبت",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(Modifier.height(14.dp))
        Text("برنامه ماه", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Black)
        Spacer(Modifier.height(8.dp))
        if (monthEvents.isEmpty() && monthTasks.isEmpty() && monthSpecials.isEmpty() && periodDays == 0) {
            Text(
                "برای این ماه قرار، کار یا مناسبتی ثبت نشده است.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        } else {
            monthSpecials.forEach { sd ->
                Card(
                    Modifier.fillMaxWidth().padding(bottom = 8.dp),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.65f))
                ) {
                    Column(Modifier.padding(12.dp)) {
                        Text("★ ${sd.title}", fontWeight = FontWeight.Bold)
                        Text(
                            PersianDateFormatter.formatDate(sd.occurredAt) + if (sd.repeatYearly) " · هر سال" else "",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
            monthEvents.forEach { ev ->
                Card(
                    Modifier.fillMaxWidth().padding(bottom = 8.dp),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Column(Modifier.padding(12.dp)) {
                        Text("• ${ev.title}", fontWeight = FontWeight.Bold)
                        Text(
                            PersianDateFormatter.formatDateTime(ev.startAt),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
            monthTasks.forEach { task ->
                Card(
                    Modifier.fillMaxWidth().padding(bottom = 8.dp),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Column(Modifier.padding(12.dp)) {
                        Text(
                            "✓ ${task.title}${if (task.isCompleted) " (انجام‌شده)" else ""}",
                            fontWeight = FontWeight.SemiBold
                        )
                        task.dueAt?.let {
                            Text(
                                "مهلت: ${PersianDateFormatter.formatDate(it)}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(24.dp))
    }

    selectedDayStart?.let { start ->
        val end = localCalendarDayEnd(start)
        val selectedEvents = events.filter { !it.isDeleted && !it.details.orEmpty().startsWith("OS_WORK|") && it.startAt in start..end }
        // شیفت شب فقط در روز شروع نمایش داده می‌شود
        val selectedWorkEvents = events.filter { event ->
            !event.isDeleted &&
                event.details.orEmpty().startsWith("OS_WORK|") &&
                event.startAt in start..end
        }.sortedBy { it.startAt }
        val selectedTasks = tasks.filter { !it.isDeleted && it.dueAt != null && it.dueAt!! in start..end }
        val selectedSpecials = specialDates.filter { !it.isDeleted && marksDay(it, start) }
        val periodStarts = cycleLogs.filter { !it.isDeleted && it.startAt in start..end }
        val activePeriod = cycleLogs.firstOrNull { isBleedingOn(it, start, end) }
        val logsUpToSelectedDay = cycleLogs.filter { !it.isDeleted && it.startAt <= end }
        val selectedCycle = CycleInsights.snapshot(logsUpToSelectedDay, cycleSettings, start)
        val cycleDay = selectedCycle.dayInCycle
        val predicted = if (cycleSettings?.trackingEnabled == false) null else selectedCycle.predictedNextStartAt
        val selectedIsPredicted = activePeriod == null && predictedPeriod?.overlaps(start, end) == true
        val j = PersianDateFormatter.jalaliDate(start)
        val title = "اطلاعات ${PersianDateFormatter.toPersianDigits(j.day)} ${PersianDateFormatter.jalaliMonthName(j.month)}"
        OSFormDialog(
            title = title,
            emoji = "📅",
            onDismiss = { selectedDayStart = null },
            onConfirm = { selectedDayStart = null },
            confirmLabel = "بستن",
            showDismissButton = false
        ) {

                    if (activePeriod != null) {
                        Text("🌸 در دورهٔ ثبت‌شده هستید", fontWeight = FontWeight.Bold)
                        Text("روز چرخه: ${PersianDateFormatter.toPersianDigits(cycleDay ?: 1)}")
                        if (periodStarts.isNotEmpty()) Text("این روز به‌عنوان شروع پریود ثبت شده است.")
                        Text("نمایش دوره تا: ${PersianDateFormatter.formatDate(calculatedPeriodEnd(activePeriod))} (حداکثر ۵ روز اول)")
                    } else if (selectedIsPredicted) {
                        Text("🌸 بازهٔ پیش‌بینی‌شدهٔ دوره", fontWeight = FontWeight.Bold)
                        Text("شروع تقریبی: ${predictedPeriod?.let { PersianDateFormatter.formatDate(it.startAt) } ?: "—"}")
                        Text("فقط ${PersianDateFormatter.toPersianDigits(predictedPeriod?.displayDays ?: CycleCalendarDisplay.PREDICTED_PERIOD_DAYS)} روز اول پیش‌بینی در تقویم نمایش داده می‌شود.")
                        cycleDay?.let { Text("روز چرخه: ${PersianDateFormatter.toPersianDigits(it)}") }
                    } else if (cycleDay != null) {
                        Text("روز چرخه: ${PersianDateFormatter.toPersianDigits(cycleDay)}")
                        predicted?.let { Text("شروع تقریبی بعدی: ${PersianDateFormatter.formatDate(it)}") }
                    }
                    if (selectedWorkEvents.isNotEmpty()) {
                        Text("ساعات شغل و شیفت‌ها", fontWeight = FontWeight.Bold)
                        selectedWorkEvents.forEach { work ->
                            Text("• ${work.title}: ${PersianDateFormatter.formatTime(work.startAt)} تا ${PersianDateFormatter.formatTime(work.endAt ?: (work.startAt + 60L * 60_000L))}")
                        }
                    }
                    if (selectedEvents.isNotEmpty()) {
                        Text("قرارها", fontWeight = FontWeight.Bold)
                        selectedEvents.forEach { Text("• ${it.title}") }
                    }
                    if (selectedTasks.isNotEmpty()) {
                        Text("کارها", fontWeight = FontWeight.Bold)
                        selectedTasks.forEach { Text("• ${it.title}${if (it.isCompleted) " ✓" else ""}") }
                    }
                    if (selectedSpecials.isNotEmpty()) {
                        Text("مناسبت‌ها", fontWeight = FontWeight.Bold)
                        selectedSpecials.forEach { Text("• ${it.title}${it.note.takeIf { n -> n.isNotBlank() }?.let { n -> " — $n" } ?: ""}") }
                    }
                    if (selectedEvents.isEmpty() && selectedWorkEvents.isEmpty() && selectedTasks.isEmpty() && selectedSpecials.isEmpty() && activePeriod == null && cycleDay == null) {
                        Text("برای این روز اطلاعاتی ثبت نشده است.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
        }
    }
}

private fun marksDay(date: SpecialDateEntity, dayStart: Long): Boolean {
    val cal = java.util.Calendar.getInstance().apply { timeInMillis = dayStart }
    val src = java.util.Calendar.getInstance().apply { timeInMillis = date.occurredAt }
    return if (date.repeatYearly) {
        cal.get(java.util.Calendar.MONTH) == src.get(java.util.Calendar.MONTH) &&
            cal.get(java.util.Calendar.DAY_OF_MONTH) == src.get(java.util.Calendar.DAY_OF_MONTH)
    } else {
        val end = dayStart + 24L * 60 * 60 * 1000
        date.occurredAt in dayStart until end
    }
}

@Composable
private fun HabitsBoard(
    habits: List<HabitEntity>,
    onToggle: (HabitEntity) -> Unit,
    onDelete: (HabitEntity) -> Unit
) {
    // Refresh the day key periodically so "done today" resets after midnight
    // without requiring the user to leave the screen.
    var clock by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        while (true) {
            kotlinx.coroutines.delay(60_000L)
            clock = System.currentTimeMillis()
        }
    }
    val today = remember(clock) {
        com.ourspace.app.core.time.PersianDateFormatter.currentJalaliDayKey()
    }
    var habitToDelete by remember { mutableStateOf<HabitEntity?>(null) }
    val visibleHabits = habits.filterNot { it.isDeleted }
    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        item {
            Text("عادات و دارو", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Black)
            Text(
                "یادآوری ساده مشترک — با یک ضربه امروز را انجام‌شده کنید.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        if (visibleHabits.isEmpty()) {
            item {
                Text(
                    "هنوز عادتی ثبت نشده. از دکمه + نوع «عادت/دارو» را بسازید.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        } else {
            items(visibleHabits, key = { it.id }) { habit ->
                val done = habit.lastCompletedDayKey == today
                Card(
                    Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (done) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.55f)
                        else MaterialTheme.colorScheme.surface
                    )
                ) {
                    Row(
                        Modifier.fillMaxWidth().padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(
                                (if (habit.kind == "MEDICINE") "💊 " else "✨ ") + habit.title,
                                fontWeight = FontWeight.Bold
                            )
                            if (habit.scheduleNote.isNotBlank()) {
                                Text(habit.scheduleNote, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            if (habit.note.isNotBlank()) {
                                Text("یادداشت: ${habit.note}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Text(
                                if (done) "امروز انجام شد" else "برای امروز مانده",
                                style = MaterialTheme.typography.labelSmall,
                                color = if (done) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        TextButton(onClick = { onToggle(habit) }) {
                            Text(if (done) "لغو" else "انجام")
                        }
                        TextButton(onClick = { habitToDelete = habit }) { Text("حذف") }
                    }
                }
            }
        }
    }
    habitToDelete?.let { habit ->
        OSConfirmDialog(
            title = "حذف مورد؟",
            message = "«${habit.title}» از فهرست عادات و داروها حذف شود؟",
            confirmLabel = "حذف",
            dismissLabel = "انصراف",
            destructive = true,
            emoji = "💊",
            onConfirm = { onDelete(habit); habitToDelete = null },
            onDismiss = { habitToDelete = null }
        )
    }
}


@Composable
private fun AddHabitDialog(
    onDismiss: () -> Unit,
    onConfirm: (title: String, kind: String, scheduleNote: String, note: String) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var schedule by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var kindMedicine by remember { mutableStateOf(false) }
    var hour by remember { mutableIntStateOf(8) }
    var minute by remember { mutableIntStateOf(0) }
    var useClock by remember { mutableStateOf(true) }
    OSFormDialog(
        title = "عادت یا دارو",
        emoji = "💊",
        onDismiss = onDismiss,
        onConfirm = {
            if (title.isNotBlank()) {
                val scheduleNote = if (useClock) {
                    "ساعت ${hour.toString().padStart(2, '0')}:${minute.toString().padStart(2, '0')}"
                } else {
                    schedule.trim()
                }
                onConfirm(title.trim(), if (kindMedicine) "MEDICINE" else "HABIT", scheduleNote, note.trim())
            }
        },
        confirmLabel = "ثبت",
        confirmEnabled = title.isNotBlank()
    ) {
OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("عنوان") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("ساعت مشخص", modifier = Modifier.weight(1f))
                    Switch(checked = useClock, onCheckedChange = { useClock = it })
                }
                if (useClock) {
                    TimePickerRow(hour = hour, minute = minute, onHour = { hour = it }, onMinute = { minute = it })
                } else {
                    OutlinedTextField(
                        value = schedule,
                        onValueChange = { schedule = it },
                        label = { Text("زمان‌بندی متنی (مثلاً هر روز صبح)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                OutlinedTextField(value = note, onValueChange = { note = it }, label = { Text("یادداشت") }, modifier = Modifier.fillMaxWidth())
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("دارو است", modifier = Modifier.weight(1f))
                    Switch(checked = kindMedicine, onCheckedChange = { kindMedicine = it })
                }
    }
}

private fun applyTime(epoch: Long, hour: Int, minute: Int): Long =
    java.util.Calendar.getInstance().apply {
        timeInMillis = epoch
        set(java.util.Calendar.HOUR_OF_DAY, hour.coerceIn(0, 23))
        set(java.util.Calendar.MINUTE, minute.coerceIn(0, 59))
        set(java.util.Calendar.SECOND, 0)
        set(java.util.Calendar.MILLISECOND, 0)
    }.timeInMillis

@Composable
private fun TimePickerRow(
    hour: Int,
    minute: Int,
    onHour: (Int) -> Unit,
    onMinute: (Int) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text("ساعت", style = MaterialTheme.typography.labelLarge)
        Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            (0..23).forEach { h ->
                FilterChip(
                    selected = hour == h,
                    onClick = { onHour(h) },
                    label = { Text(PersianDateFormatter.toPersianDigits(h.toString().padStart(2, '0'))) }
                )
            }
        }
        Text("دقیقه", style = MaterialTheme.typography.labelLarge)
        Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            listOf(0, 15, 30, 45).forEach { m ->
                FilterChip(
                    selected = minute == m,
                    onClick = { onMinute(m) },
                    label = { Text(PersianDateFormatter.toPersianDigits(m.toString().padStart(2, '0'))) }
                )
            }
        }
        Text(
            "زمان انتخاب‌شده: ${PersianDateFormatter.toPersianDigits(hour.toString().padStart(2, '0'))}:${PersianDateFormatter.toPersianDigits(minute.toString().padStart(2, '0'))}",
            color = MaterialTheme.colorScheme.primary,
            style = MaterialTheme.typography.bodySmall
        )
    }
}
