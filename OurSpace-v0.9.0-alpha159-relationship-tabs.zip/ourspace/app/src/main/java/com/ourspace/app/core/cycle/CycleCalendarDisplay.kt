package com.ourspace.app.core.cycle

import com.ourspace.app.core.database.CycleLogEntity
import com.ourspace.app.core.database.CycleSettingsEntity
import java.util.Calendar

/** Calendar-only ranges: logged periods are capped at five days; the next estimate shows three. */
object CycleCalendarDisplay {
    const val MAX_RECORDED_PERIOD_DAYS = 5
    const val PREDICTED_PERIOD_DAYS = 3

    data class PeriodWindow(val startAt: Long, val endAt: Long, val displayDays: Int) {
        fun overlaps(dayStart: Long, dayEnd: Long): Boolean =
            startAt <= dayEnd && endAt >= dayStart
    }

    /**
     * Return the visible end for a logged period. A stale/open log can be auto-closed by the
     * next cycle's start, so its stored end must never expand the calendar mark past day five.
     * Earlier user-recorded ends are kept; open logs are not projected beyond today.
     */
    fun actualPeriodEndAt(
        log: CycleLogEntity,
        now: Long = System.currentTimeMillis()
    ): Long {
        val maximumEnd = endOfDayAfterDays(log.startAt, MAX_RECORDED_PERIOD_DAYS - 1)
        val recordedEnd = log.endAt?.coerceAtLeast(log.startAt) ?: maximumEnd
        return minOf(recordedEnd, maximumEnd, endOfDay(now))
    }

    fun isActualPeriodOn(
        log: CycleLogEntity,
        dayStart: Long,
        dayEnd: Long,
        now: Long = System.currentTimeMillis()
    ): Boolean =
        !log.isDeleted && log.startAt <= dayEnd && actualPeriodEndAt(log, now) >= dayStart

    /**
     * Build a local-calendar estimate for the next period. Forecasts are hidden when tracking
     * is disabled and cover at most the first three days, independent of a stale log endAt.
     */
    fun predictedNextPeriod(
        logs: List<CycleLogEntity>,
        settings: CycleSettingsEntity?,
        now: Long = System.currentTimeMillis()
    ): PeriodWindow? {
        if (settings?.trackingEnabled == false) return null
        val predictedStart = CycleInsights.snapshot(logs, settings, now).predictedNextStartAt ?: return null
        val start = startOfDay(predictedStart)
        val configuredLength = (settings?.averagePeriodDays ?: 5).coerceIn(1, 15)
        val displayDays = minOf(PREDICTED_PERIOD_DAYS, configuredLength)
        return PeriodWindow(
            startAt = start,
            endAt = endOfDayAfterDays(start, displayDays - 1),
            displayDays = displayDays
        )
    }

    private fun startOfDay(epoch: Long): Long = Calendar.getInstance().apply {
        timeInMillis = epoch
        set(Calendar.HOUR_OF_DAY, 0)
        set(Calendar.MINUTE, 0)
        set(Calendar.SECOND, 0)
        set(Calendar.MILLISECOND, 0)
    }.timeInMillis

    private fun endOfDay(epoch: Long): Long = Calendar.getInstance().apply {
        timeInMillis = startOfDay(epoch)
        add(Calendar.DAY_OF_YEAR, 1)
        add(Calendar.MILLISECOND, -1)
    }.timeInMillis

    private fun endOfDayAfterDays(epoch: Long, daysAfterStart: Int): Long = Calendar.getInstance().apply {
        timeInMillis = startOfDay(epoch)
        add(Calendar.DAY_OF_YEAR, daysAfterStart.coerceAtLeast(0))
        add(Calendar.DAY_OF_YEAR, 1)
        add(Calendar.MILLISECOND, -1)
    }.timeInMillis
}
