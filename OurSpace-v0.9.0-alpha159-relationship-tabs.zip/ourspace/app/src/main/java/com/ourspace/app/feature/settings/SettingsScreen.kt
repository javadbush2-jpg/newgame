package com.ourspace.app.feature.settings

import android.Manifest
import android.app.NotificationManager
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings
import android.net.Uri
import android.os.PowerManager
import androidx.activity.compose.BackHandler
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.compose.ui.platform.LocalContext
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.selection.toggleable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.Notifications
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material.icons.outlined.Wifi
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ourspace.app.core.notification.NotificationCategory
import com.ourspace.app.core.notification.NotificationPreferenceStore
import com.ourspace.app.core.notification.OurSpaceNotificationCenter
import com.ourspace.app.core.preferences.AppPreferences
import com.ourspace.app.core.database.TelegramStickerPackEntity
import com.ourspace.app.ui.theme.AppFontFamily
import kotlinx.coroutines.launch
import com.ourspace.app.core.pairing.PairingStore
import com.ourspace.app.core.relay.RelayConfig
import com.ourspace.app.core.security.DeviceIdentityManager
import com.ourspace.app.core.sync.SyncClient
import com.ourspace.app.core.time.PersianDateFormatter
import com.ourspace.app.core.webrtc.ConnectionDiagnostics
import com.ourspace.app.feature.home.DiagnosticsPanel
import com.ourspace.app.feature.home.PairingPanel
import com.ourspace.app.feature.home.PrivateServerPanel
import com.ourspace.app.model.DeviceRole
import com.ourspace.app.ui.AppViewModel
import com.ourspace.app.ui.design.OSGroupedSection
import com.ourspace.app.ui.design.OSGroupRow
import com.ourspace.app.ui.design.OSLargeTitle
import com.ourspace.app.ui.design.OSSectionSpacer
import com.ourspace.app.ui.design.OSSpacing
import com.ourspace.app.ui.theme.AppPalette
import com.ourspace.app.ui.theme.AppThemeMode

/**
 * Central place for connection, pairing, appearance and device security.
 * Connection controls were moved here from the home dashboard to keep Home focused on daily life.
 */
@Composable
fun SettingsScreen(
    role: DeviceRole,
    identity: DeviceIdentityManager.DeviceIdentity,
    pairingSnapshot: PairingStore.Snapshot,
    pairingAction: AppViewModel.PairingActionState,
    syncState: AppViewModel.SyncState,
    relayConfig: RelayConfig,
    relayAction: AppViewModel.RelayActionState,
    backupAction: AppViewModel.BackupActionState = AppViewModel.BackupActionState(),
    onBackupNow: () -> Unit = {},
    onRestoreBackup: () -> Unit = {},
    pendingSyncChanges: Int,
    pendingSyncUnsent: Int = 0,
    pendingSyncAwaitingAck: Int = 0,
    diagnostics: List<String>,
    syncHealth: ConnectionDiagnostics.Health,
    palette: AppPalette,
    themeMode: AppThemeMode,
    onSaveRelayConfig: (Boolean, String, String) -> Unit,
    onRunConnectionTest: () -> Unit,
    onClearDiagnostics: () -> Unit,
    onApprovePairing: () -> Unit,
    onRejectPairing: () -> Unit,
    onCheckPairing: () -> Unit,
    onCancelPairing: () -> Unit,
    onRevokeTrust: () -> Unit,
    onSync: () -> Unit,
    onPairPayload: (String) -> Unit,
    onScanCompanionReply: (String) -> Unit,
    onScanApproval: (String) -> Unit,
    onPairWithPin: (String) -> Unit = {},
    onGenerateHostPin: () -> Unit = {},
    onSetPalette: (AppPalette) -> Unit,
    onSetThemeMode: (AppThemeMode) -> Unit,
    onReset: () -> Unit,
    telegramBotToken: String = "",
    onSetTelegramBotToken: (String) -> Unit = {},
    stickerImportAction: AppViewModel.StickerImportActionState = AppViewModel.StickerImportActionState(),
    onImportTelegramPack: (String) -> Unit = {},
    telegramStickerPacks: List<TelegramStickerPackEntity> = emptyList(),
    onDeleteTelegramPack: (String) -> Unit = {}
) {
    val isPaired = pairingSnapshot.trustedPeer != null
    var selectedSection by remember { mutableStateOf<SettingsSection?>(null) }
    BackHandler(enabled = selectedSection != null) { selectedSection = null }
    val context = LocalContext.current
    var notificationPreferences by remember(context) {
        mutableStateOf(NotificationPreferenceStore.readAll(context))
    }
    fun updateNotificationPreference(category: NotificationCategory, enabled: Boolean) {
        NotificationPreferenceStore.setEnabled(context, category, enabled)
        notificationPreferences = notificationPreferences + (category to enabled)
        if (!enabled) OurSpaceNotificationCenter(context).clearNotificationsForCategory(category)
    }
    val appNotificationsEnabled = NotificationManagerCompat.from(context).areNotificationsEnabled()
    val runtimePermissionGranted = Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU ||
        ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
    val messageChannelEnabled = Build.VERSION.SDK_INT < Build.VERSION_CODES.O || runCatching {
        context.getSystemService(NotificationManager::class.java)
            .getNotificationChannel("ourspace_private_updates")?.importance
            ?.let { it != NotificationManager.IMPORTANCE_NONE } ?: false
    }.getOrDefault(false)
    val heartChannelEnabled = Build.VERSION.SDK_INT < Build.VERSION_CODES.O || runCatching {
        context.getSystemService(NotificationManager::class.java)
            .getNotificationChannel("ourspace_heart_pulse")?.importance
            ?.let { it != NotificationManager.IMPORTANCE_NONE } ?: false
    }.getOrDefault(false)
    val reminderChannelEnabled = Build.VERSION.SDK_INT < Build.VERSION_CODES.O || runCatching {
        context.getSystemService(NotificationManager::class.java)
            .getNotificationChannel("ourspace_reminders")?.importance
            ?.let { it != NotificationManager.IMPORTANCE_NONE } ?: false
    }.getOrDefault(false)
    val notificationStatus = when {
        !appNotificationsEnabled -> "اعلان‌های برنامه در تنظیمات اندروید خاموش هستند"
        !runtimePermissionGranted -> "مجوز اعلان داده نشده است"
        !messageChannelEnabled -> "کانال پیام‌های گفتگو و تغییرات خاموش است"
        !heartChannelEnabled -> "کانال تپش قلب خاموش است"
        !reminderChannelEnabled -> "کانال یادآوری‌ها و هشدارهای بودجه خاموش است"
        else -> "دسته‌های موردنظر را از گزینه‌های زیر انتخاب کنید"
    }
    val activeSection = selectedSection
    if (activeSection == null) {
        SettingsHomeScreen(
            isPaired = isPaired,
            notificationStatus = notificationStatus,
            pendingSyncChanges = pendingSyncChanges,
            telegramPackCount = telegramStickerPacks.size,
            onOpenSection = { selectedSection = it }
        )
    } else {
        Column(Modifier.fillMaxSize()) {
            SettingsDetailHeader(
                section = activeSection,
                onBack = { selectedSection = null }
            )
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(bottom = 100.dp)
            ) {
                when (activeSection) {
                    SettingsSection.NOTIFICATIONS -> {
                        item {
                            OSGroupedSection(
                                title = "اجازهٔ اعلان‌ها",
                                footer = "مجوز و کانال‌های اندروید باید روشن باشند؛ نوع اعلان‌ها را در بخش‌های زیر جداگانه انتخاب کنید. اعلان دائمی و بی‌صدای سرویس میزبان برای حفظ همگام‌سازی باقی می‌ماند."
                            ) {
                                OSGroupRow(
                                    title = if (appNotificationsEnabled && runtimePermissionGranted) "اجازهٔ اعلان در اندروید فعال است" else "بررسی تنظیمات اعلان",
                                    subtitle = notificationStatus,
                                    leading = Icons.Outlined.Notifications,
                                    showDivider = false,
                                    onClick = {
                                        runCatching {
                                            context.startActivity(
                                                Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                                                    .putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName)
                                            )
                                        }
                                    }
                                )
                            }
                        }

                        item { OSSectionSpacer() }

                        item {
                            OSGroupedSection(title = "گفتگو و قلب", footer = "این انتخاب‌ها فقط روی همین گوشی ذخیره می‌شوند.") {
                                NotificationPreferenceRow(
                                    category = NotificationCategory.CHAT_MESSAGES,
                                    checked = notificationPreferences[NotificationCategory.CHAT_MESSAGES] ?: true,
                                    onCheckedChange = { updateNotificationPreference(NotificationCategory.CHAT_MESSAGES, it) },
                                    showDivider = true
                                )
                                NotificationPreferenceRow(
                                    category = NotificationCategory.HEART_PULSES,
                                    checked = notificationPreferences[NotificationCategory.HEART_PULSES] ?: true,
                                    onCheckedChange = { updateNotificationPreference(NotificationCategory.HEART_PULSES, it) },
                                    showDivider = false
                                )
                            }
                        }

                        item { OSSectionSpacer() }

                        item {
                            OSGroupedSection(title = "تغییرات و همگام‌سازی", footer = "خاموش‌کردن این اعلان‌ها، دریافت یا همگام‌سازی داده‌ها را متوقف نمی‌کند.") {
                                NotificationPreferenceRow(
                                    category = NotificationCategory.SHARED_DATA_UPDATES,
                                    checked = notificationPreferences[NotificationCategory.SHARED_DATA_UPDATES] ?: false,
                                    onCheckedChange = { updateNotificationPreference(NotificationCategory.SHARED_DATA_UPDATES, it) },
                                    showDivider = true
                                )
                                NotificationPreferenceRow(
                                    category = NotificationCategory.SYNC_STATUS,
                                    checked = notificationPreferences[NotificationCategory.SYNC_STATUS] ?: false,
                                    onCheckedChange = { updateNotificationPreference(NotificationCategory.SYNC_STATUS, it) },
                                    showDivider = true
                                )
                                NotificationPreferenceRow(
                                    category = NotificationCategory.PARTNER_MOOD_UPDATES,
                                    checked = notificationPreferences[NotificationCategory.PARTNER_MOOD_UPDATES] ?: false,
                                    onCheckedChange = { updateNotificationPreference(NotificationCategory.PARTNER_MOOD_UPDATES, it) },
                                    showDivider = false
                                )
                            }
                        }

                        item { OSSectionSpacer() }

                        item {
                            OSGroupedSection(title = "یادآوری‌ها و هشدارها", footer = "یادآوری‌ها شامل عادت و دارو، کارها، قرار و مناسبت، حال روزانه، چرخه و خرید هستند.") {
                                NotificationPreferenceRow(
                                    category = NotificationCategory.REMINDERS,
                                    checked = notificationPreferences[NotificationCategory.REMINDERS] ?: false,
                                    onCheckedChange = { updateNotificationPreference(NotificationCategory.REMINDERS, it) },
                                    showDivider = true
                                )
                                NotificationPreferenceRow(
                                    category = NotificationCategory.BUDGET_ALERTS,
                                    checked = notificationPreferences[NotificationCategory.BUDGET_ALERTS] ?: false,
                                    onCheckedChange = { updateNotificationPreference(NotificationCategory.BUDGET_ALERTS, it) },
                                    showDivider = false
                                )
                            }
                        }

                        item { OSSectionSpacer() }
                    }
                    SettingsSection.CONNECTION -> {
                        item {
                            val powerManager = context.getSystemService(android.content.Context.POWER_SERVICE) as? PowerManager
                            val ignoringBattery = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                                powerManager?.isIgnoringBatteryOptimizations(context.packageName) == true
                            } else true
                            OSGroupedSection(
                                title = "پس‌زمینه و باتری",
                                footer = "برای دریافت سریع پیام وقتی اپ باز نیست، محدودیت بهینه‌سازی باتری را بردارید و اعلان‌ها را روشن نگه دارید."
                            ) {
                                OSGroupRow(
                                    title = if (ignoringBattery) "اجرای پس‌زمینه آزاد است" else "آزادسازی اجرای پس‌زمینه",
                                    subtitle = if (ignoringBattery) {
                                        "محدودیت بهینه‌سازی باتری برای OurSpace خاموش است"
                                    } else {
                                        "برای همگام‌سازی آنی در پس‌زمینه لمس کنید"
                                    },
                                    leading = Icons.Outlined.Settings,
                                    showDivider = true,
                                    onClick = {
                                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !ignoringBattery) {
                                            runCatching {
                                                context.startActivity(
                                                    Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
                                                        .setData(Uri.parse("package:${context.packageName}"))
                                                )
                                            }.onFailure {
                                                runCatching {
                                                    context.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                                                }
                                            }
                                        } else {
                                            runCatching {
                                                context.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                                            }
                                        }
                                    }
                                )
                                OSGroupRow(
                                    title = "ثبت مجدد توکن اعلان سرور",
                                    subtitle = "اگر پیام در پس‌زمینه دیر می‌رسد، یک‌بار لمس کنید",
                                    leading = Icons.Outlined.Notifications,
                                    showDivider = false,
                                    onClick = {
                                        com.ourspace.app.core.push.FcmTokenRegistrar.refreshAndUpload(context)
                                    }
                                )
                            }
                        }

                        item { OSSectionSpacer() }

                        item {
                            OSGroupedSection(
                                title = "وضعیت اتصال",
                                footer = when (role) {
                                    DeviceRole.HOST -> "این گوشی میزبان فضای خصوصی است."
                                    DeviceRole.COMPANION -> "این گوشی به‌عنوان همراه متصل می‌شود."
                                }
                            ) {
                                OSGroupRow(
                                    title = when {
                                        syncState.isSyncing -> "در حال همگام‌سازی…"
                                        syncState.error != null -> "خطا در همگام‌سازی"
                                        isPaired -> "جفت‌سازی فعال"
                                        else -> "هنوز جفت نشده"
                                    },
                                    subtitle = when {
                                        syncState.error != null -> syncState.error
                                        pendingSyncChanges > 0 ->
                                            buildString {
                                                if (pendingSyncUnsent > 0) append("${PersianDateFormatter.toPersianDigits(pendingSyncUnsent)} در انتظار ارسال")
                                                if (pendingSyncUnsent > 0 && pendingSyncAwaitingAck > 0) append(" · ")
                                                if (pendingSyncAwaitingAck > 0) append("${PersianDateFormatter.toPersianDigits(pendingSyncAwaitingAck)} منتظر تأیید همراه")
                                                if (pendingSyncUnsent == 0 && pendingSyncAwaitingAck == 0)
                                                    append("${PersianDateFormatter.toPersianDigits(pendingSyncChanges)} تغییر در صف ارسال")
                                            }
                                        syncState.lastSyncAt != null ->
                                            "آخرین همگام‌سازی: ${PersianDateFormatter.formatDateTime(syncState.lastSyncAt)}"
                                        isPaired -> "آمادهٔ ارسال و دریافت"
                                        else -> "از بخش جفت‌سازی شروع کنید"
                                    },
                                    leading = Icons.Outlined.Wifi,
                                    showDivider = true,
                                    onClick = onSync
                                )
                                OSGroupRow(
                                    title = "نقش دستگاه",
                                    subtitle = if (role == DeviceRole.HOST) "میزبان" else "همراه",
                                    leading = Icons.Outlined.Info,
                                    showDivider = true
                                )
                                OSGroupRow(
                                    title = "سلامت اتصال",
                                    subtitle = buildString {
                                        append(ConnectionDiagnostics.statusLabelFa(syncHealth))
                                        append(" · ارسال ")
                                        append(PersianDateFormatter.toPersianDigits(syncHealth.sentCount.toInt()))
                                        append(" · دریافت ")
                                        append(PersianDateFormatter.toPersianDigits(syncHealth.receivedCount.toInt()))
                                        append(" · ACK رله ")
                                        append(PersianDateFormatter.toPersianDigits(syncHealth.ackCount.toInt()))
                                        if (syncHealth.failedCount > 0) {
                                            append(" · ناموفق ")
                                            append(PersianDateFormatter.toPersianDigits(syncHealth.failedCount.toInt()))
                                        }
                                        if (syncHealth.lastAckAt > 0L) {
                                            append(" · آخرین ACK رله ")
                                            append(PersianDateFormatter.formatTime(syncHealth.lastAckAt))
                                        }
                                    },
                                    leading = Icons.Outlined.Info,
                                    showDivider = true
                                )
                                OSGroupRow(
                                    title = "همگام‌سازی اکنون",
                                    subtitle = when {
                                        pendingSyncChanges > 0 ->
                                            "برای خالی کردن صف لمس کنید · ${PersianDateFormatter.toPersianDigits(pendingSyncChanges)} مورد مانده"
                                        syncState.lastSyncAt != null ->
                                            "آخرین موفقیت: ${PersianDateFormatter.formatDateTime(syncState.lastSyncAt)}"
                                        else -> "لمس کنید تا همگام‌سازی اجباری شود"
                                    },
                                    leading = Icons.Outlined.Wifi,
                                    showDivider = false,
                                    onClick = onSync
                                )
                            }
                        }

                        item { OSSectionSpacer() }

                        item {
                            Column(Modifier.padding(horizontal = OSSpacing.screenHorizontal)) {
                                SectionCaption(icon = Icons.Outlined.Share, title = "سرور خصوصی")
                                PrivateServerPanel(
                                    config = relayConfig,
                                    action = relayAction,
                                    onSave = onSaveRelayConfig
                                )
                                Spacer(Modifier.height(12.dp))
                                OSGroupedSection(
                                    title = "پشتیبان و بازیابی",
                                    footer = backupAction.error ?: backupAction.message
                                        ?: "میزبان هر دقیقه پشتیبان رمزگذاری‌شده را به‌روزرسانی می‌کند؛ این گزینه برای اجرای فوری یا بازیابی روی گوشی جدید است."
                                ) {
                                    if (role == DeviceRole.HOST) {
                                        OSGroupRow(
                                            title = if (backupAction.isBusy) "در حال تهیه پشتیبان…" else "تهیه پشتیبان کامل اکنون",
                                            subtitle = "ذخیره پیام‌ها، خاطرات، برنامه‌ها، داده‌های مالی و پیوست‌ها روی سرور",
                                            leading = Icons.Outlined.Share,
                                            showDivider = true,
                                            onClick = if (backupAction.isBusy) null else onBackupNow
                                        )
                                    }
                                    OSGroupRow(
                                        title = if (backupAction.isBusy) "در حال پردازش…" else "بازیابی اطلاعات از سرور",
                                        subtitle = "برای گوشی جدید یا نصب مجدد؛ اطلاعات پشتیبان با داده‌های محلی ادغام می‌شوند",
                                        leading = Icons.Outlined.Info,
                                        showDivider = false,
                                        onClick = if (backupAction.isBusy) null else onRestoreBackup
                                    )
                                }
                            }
                        }

                        item { OSSectionSpacer() }

                        item {
                            Column(Modifier.padding(horizontal = OSSpacing.screenHorizontal)) {
                                SectionCaption(icon = Icons.Outlined.Wifi, title = "سلامت اتصال")
                                DiagnosticsPanel(
                                    lines = diagnostics,
                                    health = syncHealth,
                                    onRunTest = onRunConnectionTest,
                                    onClear = onClearDiagnostics
                                )
                            }
                        }

                        item { OSSectionSpacer() }
                    }
                    SettingsSection.PAIRING -> {
                        item {
                            Column(Modifier.padding(horizontal = OSSpacing.screenHorizontal)) {
                                SectionCaption(icon = Icons.Outlined.Lock, title = "جفت‌سازی امن")
                            }
                        }

                        item {
                            Column(Modifier.padding(horizontal = OSSpacing.screenHorizontal)) {
                                PairingPanel(
                                    role = role,
                                    identity = identity,
                                    snapshot = pairingSnapshot,
                                    action = pairingAction,
                                    syncState = syncState,
                                    onApprove = onApprovePairing,
                                    onReject = onRejectPairing,
                                    onCheckStatus = onCheckPairing,
                                    onCancelOutgoing = onCancelPairing,
                                    onRevokeTrust = onRevokeTrust,
                                    onSync = onSync,
                                    onPairPayload = onPairPayload,
                                    onScanCompanionReply = onScanCompanionReply,
                                    onScanApproval = onScanApproval,
                                            onPairWithPin = onPairWithPin,
                                            onGenerateHostPin = onGenerateHostPin
                                )
                            }
                        }

                        item { OSSectionSpacer() }
                    }
                    SettingsSection.TELEGRAM_STICKERS -> {
                        item {
                            Column(Modifier.padding(horizontal = OSSpacing.screenHorizontal)) {
                                SectionCaption(icon = Icons.Outlined.Share, title = "استیکر تلگرام")
                                var tokenDraft by remember(telegramBotToken) { mutableStateOf(telegramBotToken) }
                                var telegramPackDraft by remember { mutableStateOf("") }
                                var pendingDeleteStickerPack by remember { mutableStateOf<TelegramStickerPackEntity?>(null) }
                                Card(
                                    Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(26.dp),
                                    colors = CardDefaults.cardColors(
                                        containerColor = MaterialTheme.colorScheme.surfaceContainerLow
                                    )
                                ) {
                                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                        Text(
                                            "پک و فایل‌های استیکر پس از دریافت با گوشی دیگر همگام می‌شوند؛ توکن ربات فقط روی همین گوشی می‌ماند و طرف مقابل برای استفاده از پک به توکن نیاز ندارد.",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                        OutlinedTextField(
                                            value = tokenDraft,
                                            onValueChange = { tokenDraft = it },
                                            modifier = Modifier.fillMaxWidth(),
                                            label = { Text("توکن ربات تلگرام") },
                                            placeholder = { Text("123456:ABC...") },
                                            singleLine = true,
                                            shape = RoundedCornerShape(16.dp)
                                        )
                                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                            Button(
                                                onClick = { onSetTelegramBotToken(tokenDraft.trim()) },
                                                enabled = tokenDraft.trim() != telegramBotToken.trim()
                                            ) { Text("ذخیره توکن") }
                                            if (telegramBotToken.isNotBlank()) {
                                                TextButton(onClick = {
                                                    tokenDraft = ""
                                                    onSetTelegramBotToken("")
                                                }) { Text("پاک کردن") }
                                            }
                                        }
                                        if (telegramBotToken.isNotBlank()) {
                                            Text(
                                                "توکن ذخیره شده ✓",
                                                style = MaterialTheme.typography.labelMedium,
                                                color = MaterialTheme.colorScheme.primary
                                            )
                                        }
                                        HorizontalDivider()
                                        Text(
                                            "افزودن پک تلگرام",
                                            style = MaterialTheme.typography.titleSmall,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                        OutlinedTextField(
                                            value = telegramPackDraft,
                                            onValueChange = { telegramPackDraft = it },
                                            modifier = Modifier.fillMaxWidth(),
                                            label = { Text("لینک یا نام پک") },
                                            placeholder = { Text("t.me/addstickers/PackName") },
                                            singleLine = true,
                                            shape = RoundedCornerShape(16.dp),
                                            enabled = !stickerImportAction.isLoading
                                        )
                                        Button(
                                            onClick = {
                                                val pack = telegramPackDraft.trim()
                                                if (pack.isNotEmpty()) onImportTelegramPack(pack)
                                            },
                                            enabled = telegramPackDraft.isNotBlank() &&
                                                telegramBotToken.isNotBlank() && !stickerImportAction.isLoading
                                        ) {
                                            Text(if (stickerImportAction.isLoading) "در حال دریافت…" else "افزودن پک")
                                        }
                                        if (telegramBotToken.isBlank()) {
                                            Text(
                                                "برای افزودن پک، ابتدا توکن ربات را ذخیره کن.",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                        stickerImportAction.message?.let {
                                            Text(it, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                                        }
                                        stickerImportAction.error?.let {
                                            Text(it, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.error)
                                        }
                                        HorizontalDivider()
                                        Text(
                                            "پک‌های ذخیره‌شده",
                                            style = MaterialTheme.typography.titleSmall,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                        if (telegramStickerPacks.isEmpty()) {
                                            Text(
                                                "هنوز پکی به کتابخانه اضافه نشده است.",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        } else {
                                            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                                telegramStickerPacks.forEachIndexed { index, pack ->
                                                    Row(
                                                        Modifier.fillMaxWidth().padding(vertical = 2.dp),
                                                        verticalAlignment = Alignment.CenterVertically
                                                    ) {
                                                        Column(Modifier.weight(1f)) {
                                                            Text(pack.title, style = MaterialTheme.typography.bodyMedium)
                                                            Text(
                                                                "${pack.stickerCount} استیکر · کتابخانهٔ مشترک",
                                                                style = MaterialTheme.typography.labelSmall,
                                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                                            )
                                                        }
                                                        IconButton(onClick = { pendingDeleteStickerPack = pack }) {
                                                            Icon(
                                                                Icons.Outlined.Delete,
                                                                contentDescription = "حذف پک ${pack.title}",
                                                                tint = MaterialTheme.colorScheme.error
                                                            )
                                                        }
                                                    }
                                                    if (index < telegramStickerPacks.lastIndex) HorizontalDivider()
                                                }
                                            }
                                        }
                                    }
                                }
                                pendingDeleteStickerPack?.let { pack ->
                                    AlertDialog(
                                        onDismissRequest = { pendingDeleteStickerPack = null },
                                        title = { Text("حذف پک استیکر") },
                                        text = { Text("پک «${pack.title}» و فایل‌هایش از کتابخانهٔ هر دو گوشی حذف می‌شود.") },
                                        confirmButton = {
                                            TextButton(onClick = {
                                                onDeleteTelegramPack(pack.name)
                                                pendingDeleteStickerPack = null
                                            }) { Text("حذف") }
                                        },
                                        dismissButton = {
                                            TextButton(onClick = { pendingDeleteStickerPack = null }) { Text("انصراف") }
                                        }
                                    )
                                }
                            }
                        }
                    }
                    SettingsSection.APPEARANCE -> {
                        item {
                            Column(Modifier.padding(horizontal = OSSpacing.screenHorizontal)) {
                                SectionCaption(icon = Icons.Outlined.Settings, title = "ظاهر")
                                AppearanceSettingsCard(
                                    palette = palette,
                                    themeMode = themeMode,
                                    onSetPalette = onSetPalette,
                                    onSetThemeMode = onSetThemeMode
                                )
                                Spacer(Modifier.height(12.dp))
                                PersonalizationSettingsCard()
                            }
                        }

                        item { OSSectionSpacer() }
                    }
                    SettingsSection.DEVICE_SECURITY -> {
                        item {
                            Column(Modifier.padding(horizontal = OSSpacing.screenHorizontal)) {
                                SectionCaption(icon = Icons.Outlined.Lock, title = "دستگاه و امنیت")
                                Card(
                                    Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(26.dp),
                                    colors = CardDefaults.cardColors(
                                        containerColor = MaterialTheme.colorScheme.surfaceContainerLow
                                    )
                                ) {
                                    Column(Modifier.padding(18.dp)) {
                                        Text(
                                            "شناسه این دستگاه",
                                            style = MaterialTheme.typography.labelLarge,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                        Text(
                                            identity.deviceId.take(16) + "…",
                                            style = MaterialTheme.typography.bodyMedium,
                                            fontWeight = FontWeight.SemiBold,
                                            modifier = Modifier.padding(top = 4.dp)
                                        )
                                        HorizontalDivider(Modifier.padding(vertical = 14.dp))
                                        Text(
                                            "بازنشانی، جفت‌سازی و داده‌های همگام‌سازی این گوشی را پاک می‌کند. روی دستگاه مقابل تأثیری ندارد.",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                        TextButton(
                                            onClick = onReset,
                                            modifier = Modifier.padding(top = 8.dp)
                                        ) {
                                            Text("بازنشانی این دستگاه", color = MaterialTheme.colorScheme.error)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                item { Spacer(Modifier.height(OSSpacing.xxxl)) }
            }
        }
    }

}


private enum class SettingsSection(val title: String, val icon: ImageVector) {
    NOTIFICATIONS("اعلان‌ها", Icons.Outlined.Notifications),
    CONNECTION("اتصال و همگام‌سازی", Icons.Outlined.Wifi),
    PAIRING("جفت‌سازی امن", Icons.Outlined.Lock),
    TELEGRAM_STICKERS("استیکر تلگرام", Icons.Outlined.Share),
    APPEARANCE("ظاهر و شخصی‌سازی", Icons.Outlined.Settings),
    DEVICE_SECURITY("دستگاه و امنیت", Icons.Outlined.Info)
}

@Composable
private fun SettingsHomeScreen(
    isPaired: Boolean,
    notificationStatus: String,
    pendingSyncChanges: Int,
    telegramPackCount: Int,
    onOpenSection: (SettingsSection) -> Unit
) {
    val sections = SettingsSection.values()
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 100.dp)
    ) {
        item {
            OSLargeTitle(
                title = "تنظیمات",
                subtitle = if (isPaired) "کنترل اتصال، اعلان‌ها و ظاهر فضای مشترک"
                else "اتصال امن و شخصی‌سازی دستگاه"
            )
        }
        item { OSSectionSpacer() }
        item {
            OSGroupedSection(
                title = "موضوعات تنظیمات",
                footer = "برای مشاهده یا تغییر گزینه‌ها، یکی از بخش‌ها را باز کنید."
            ) {
                sections.forEachIndexed { index, section ->
                    val summary = when (section) {
                        SettingsSection.NOTIFICATIONS -> notificationStatus
                        SettingsSection.CONNECTION -> if (pendingSyncChanges > 0) {
                            "$pendingSyncChanges تغییر در صف همگام‌سازی"
                        } else "وضعیت اتصال، باتری، سرور و پشتیبان"
                        SettingsSection.PAIRING -> if (isPaired) {
                            "اتصال امن برقرار است"
                        } else "اتصال امن با دستگاه دیگر"
                        SettingsSection.TELEGRAM_STICKERS -> if (telegramPackCount > 0) {
                            "$telegramPackCount پک در کتابخانهٔ مشترک"
                        } else "افزودن و مدیریت پک‌های مشترک"
                        SettingsSection.APPEARANCE -> "فونت، پالت رنگ و حالت نمایش"
                        SettingsSection.DEVICE_SECURITY -> "شناسه و بازنشانی امن دستگاه"
                    }
                    OSGroupRow(
                        title = section.title,
                        subtitle = summary,
                        leading = section.icon,
                        trailingText = "‹",
                        showDivider = index < sections.lastIndex,
                        onClick = { onOpenSection(section) }
                    )
                }
            }
        }
        item { Spacer(Modifier.height(OSSpacing.xxxl)) }
    }
}

@Composable
private fun SettingsDetailHeader(
    section: SettingsSection,
    onBack: () -> Unit
) {
    Column {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = OSSpacing.screenHorizontal, vertical = OSSpacing.xs),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(
                    Icons.AutoMirrored.Outlined.ArrowBack,
                    contentDescription = "بازگشت"
                )
            }
            Column(Modifier.weight(1f).padding(start = OSSpacing.xs)) {
                Text(
                    "تنظیمات",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    section.title,
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }
        HorizontalDivider(Modifier.padding(horizontal = OSSpacing.screenHorizontal))
    }
}

@Composable
private fun PersonalizationSettingsCard() {
    val context = LocalContext.current
    val prefs = androidx.compose.runtime.remember(context) { AppPreferences(context.applicationContext) }
    val scope = rememberCoroutineScope()
    val fontScale by prefs.fontScale.collectAsState(initial = 1.0f)
    val fontFamily by prefs.fontFamily.collectAsState(initial = AppFontFamily.SANS)
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(26.dp)) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("شخصی‌سازی نوشته‌ها", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text("اندازه و سبک نوشته‌ها در سراسر برنامه اعمال می‌شود.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                Text("اندازه فونت", style = MaterialTheme.typography.labelLarge)
                Spacer(Modifier.weight(1f))
                Text("${(fontScale * 100).toInt()}٪", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
            }
            Slider(
                value = fontScale,
                onValueChange = { value -> scope.launch { prefs.setFontScale(value) } },
                valueRange = 0.85f..1.35f,
                steps = 9
            )
            Text("نمونه نوشته فارسی — فضای مشترک شما", fontSize = (16f * fontScale).sp, fontFamily = when (fontFamily) {
                AppFontFamily.SANS -> androidx.compose.ui.text.font.FontFamily.SansSerif
                AppFontFamily.SERIF -> androidx.compose.ui.text.font.FontFamily.Serif
                AppFontFamily.MONO -> androidx.compose.ui.text.font.FontFamily.Monospace
            })
            Text("سبک فونت", style = MaterialTheme.typography.labelLarge)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                AppFontFamily.entries.forEach { family ->
                    FilterChip(
                        selected = fontFamily == family,
                        onClick = { scope.launch { prefs.setFontFamily(family) } },
                        label = { Text(family.persianLabel) },
                        modifier = Modifier.weight(1f)
                    )
                }
            }
            HorizontalDivider(Modifier.padding(vertical = 4.dp))
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.weight(1f)) {
                    Text("بازگردانی ظاهر پیش‌فرض", style = MaterialTheme.typography.bodyLarge)
                    Text("فونت، اندازه نوشته، رنگ و حالت نمایش", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                TextButton(onClick = {
                    scope.launch {
                        prefs.setFontScale(1.0f)
                        prefs.setFontFamily(AppFontFamily.SANS)
                    }
                }) { Text("بازگردانی") }
            }
        }
    }
}

@Composable
private fun SectionCaption(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.padding(bottom = 10.dp, top = 4.dp)
    ) {
        Icon(icon, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
        Text(
            title,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(start = 8.dp)
        )
    }
}

@Composable
private fun AppearanceSettingsCard(
    palette: AppPalette,
    themeMode: AppThemeMode,
    onSetPalette: (AppPalette) -> Unit,
    onSetThemeMode: (AppThemeMode) -> Unit
) {
    val swatches = mapOf(
        AppPalette.ROSE to Color(0xFF9C4F72),
        AppPalette.OCEAN to Color(0xFF007C83),
        AppPalette.FOREST to Color(0xFF4D7C32),
        AppPalette.SUNSET to Color(0xFFB85A35),
        AppPalette.LAVENDER to Color(0xFF6B4FA0),
        AppPalette.MIDNIGHT to Color(0xFF3D5A80),
        AppPalette.HONEY to Color(0xFF8B6914)
    )
    Card(
        Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(26.dp)
    ) {
        Column(Modifier.padding(18.dp)) {
            Text("پالت رنگ", style = MaterialTheme.typography.labelLarge)
            Row(
                Modifier.fillMaxWidth().padding(top = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                AppPalette.entries.forEach { item ->
                    Box(
                        Modifier
                            .size(if (palette == item) 44.dp else 38.dp)
                            .background(swatches.getValue(item), CircleShape)
                            .clickable { onSetPalette(item) },
                        contentAlignment = Alignment.Center
                    ) {
                        if (palette == item) {
                            Text("✓", color = Color.White, fontWeight = FontWeight.Black)
                        }
                    }
                }
            }
            Text(
                "حالت نمایش",
                style = MaterialTheme.typography.labelLarge,
                modifier = Modifier.padding(top = 16.dp)
            )
            Row(
                Modifier.fillMaxWidth().padding(top = 10.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                AppThemeMode.entries.forEach { mode ->
                    FilterChip(
                        selected = themeMode == mode,
                        onClick = { onSetThemeMode(mode) },
                        label = { Text(mode.persianLabel) },
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }
    }
}

@Composable
private fun NotificationPreferenceRow(
    category: NotificationCategory,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    showDivider: Boolean
) {
    Column {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .toggleable(
                    value = checked,
                    role = Role.Switch,
                    onValueChange = onCheckedChange
                )
                .padding(horizontal = OSSpacing.md, vertical = OSSpacing.sm),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text(
                    category.title,
                    style = MaterialTheme.typography.bodyLarge,
                    fontWeight = FontWeight.Medium
                )
                Text(
                    category.description,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 2.dp)
                )
            }
            Spacer(Modifier.size(8.dp))
            Switch(checked = checked, onCheckedChange = null)
        }
        if (showDivider) {
            HorizontalDivider(
                modifier = Modifier.padding(start = OSSpacing.md),
                color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.45f),
                thickness = 0.6.dp
            )
        }
    }
}
