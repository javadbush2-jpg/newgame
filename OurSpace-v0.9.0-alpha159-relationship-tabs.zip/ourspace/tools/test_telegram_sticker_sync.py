#!/usr/bin/env python3
"""SQLite contract test for the Telegram-sticker sync migration and outbox triggers."""

from __future__ import annotations

import base64
from pathlib import Path
import re
import sqlite3
import unittest


ROOT = Path(__file__).resolve().parents[1]
DATABASE_SOURCE = ROOT / "app/src/main/java/com/ourspace/app/core/database/OurSpaceDatabase.kt"
INCREMENTAL_SOURCE = ROOT / "app/src/main/java/com/ourspace/app/core/sync/IncrementalSyncCodec.kt"
SNAPSHOT_SOURCE = ROOT / "app/src/main/java/com/ourspace/app/core/sync/SyncSnapshotCodec.kt"


def source_block(source: str, start: str, end: str) -> str:
    start_at = source.index(start)
    end_at = source.index(end, start_at)
    return source[start_at:end_at]


def exec_sql_literals(source: str) -> list[str]:
    pattern = re.compile(
        r'database\.execSQL\(\s*(?:"""(.*?)"""\.trimIndent\(\)|"((?:\\.|[^"\\])*)")\s*\)',
        re.DOTALL,
    )
    statements = []
    for match in pattern.finditer(source):
        statement = match.group(1) if match.group(1) is not None else match.group(2)
        statements.append(statement.replace('\\"', '"').replace('\\\\', '\\').strip())
    return statements


class TelegramStickerSyncContractTest(unittest.TestCase):
    def setUp(self):
        self.db = sqlite3.connect(":memory:")
        self.db.executescript(
            """
            CREATE TABLE sync_runtime_control (
                id INTEGER NOT NULL PRIMARY KEY, suppressOutbox INTEGER NOT NULL DEFAULT 0
            );
            INSERT INTO sync_runtime_control(id, suppressOutbox) VALUES(1, 0);
            CREATE TABLE sync_changes (
                changeId TEXT NOT NULL PRIMARY KEY, entityType TEXT NOT NULL,
                entityId TEXT NOT NULL, changedAt INTEGER NOT NULL, state TEXT NOT NULL,
                attempts INTEGER NOT NULL, nextAttemptAt INTEGER NOT NULL,
                lastAttemptAt INTEGER, lastMessageId TEXT, priority INTEGER NOT NULL,
                createdAt INTEGER NOT NULL
            );
            CREATE TABLE telegram_sticker_packs (
                name TEXT NOT NULL PRIMARY KEY, title TEXT NOT NULL,
                isAnimated INTEGER NOT NULL DEFAULT 0, stickerCount INTEGER NOT NULL DEFAULT 0,
                importedAt INTEGER NOT NULL, updatedAt INTEGER NOT NULL
            );
            CREATE TABLE telegram_stickers (
                id TEXT NOT NULL PRIMARY KEY, packName TEXT NOT NULL,
                fileUniqueId TEXT NOT NULL, emoji TEXT NOT NULL,
                isAnimated INTEGER NOT NULL DEFAULT 0, mimeType TEXT NOT NULL,
                fileName TEXT NOT NULL, sizeBytes INTEGER NOT NULL, content BLOB NOT NULL,
                createdAt INTEGER NOT NULL
            );
            INSERT INTO telegram_sticker_packs VALUES('pack_alpha', 'Pack Alpha', 0, 2, 100, 120);
            INSERT INTO telegram_stickers VALUES
                ('pack_alpha:file_1', 'pack_alpha', 'file_1', '🙂', 0, 'image/webp', 'one.webp', 3, X'010203', 120),
                ('pack_alpha:file_2', 'pack_alpha', 'file_2', '⭐', 1, 'application/x-tgsticker', 'two.tgs', 2, X'0405', 120);
            """
        )
        source = DATABASE_SOURCE.read_text(encoding="utf-8")
        migration = source_block(source, "val MIGRATION_21_22", "val MIGRATION_19_20")
        # Execute the exact ALTER/UPDATE SQL strings from the Room migration.
        for statement in exec_sql_literals(migration):
            self.db.execute(statement)

        seeder = source_block(source, "private fun seedTelegramStickerChanges", "private fun seedExistingChanges")
        for statement in exec_sql_literals(seeder):
            self.db.execute(statement)

        trigger_builder = source_block(
            source, "private fun installTelegramStickerSyncTriggers", "private fun tableExists"
        )
        templates = exec_sql_literals(trigger_builder)
        self.assertEqual(1, len(templates), "Expected one shared sticker trigger template")
        for table, entity_type, id_column in (
            ("telegram_sticker_packs", "telegramStickerPacks", "name"),
            ("telegram_stickers", "telegramStickers", "id"),
        ):
            for operation, suffix in (("INSERT", "insert"), ("UPDATE", "update")):
                statement = templates[0]
                for token, value in (
                    ("${table}", table),
                    ("${suffix}", suffix),
                    ("$table", table),
                    ("$type", entity_type),
                    ("$idColumn", id_column),
                    ("$operation", operation),
                    ("$suffix", suffix),
                ):
                    statement = statement.replace(token, value)
                self.db.executescript(statement)

    def tearDown(self):
        self.db.close()

    def test_migration_backfills_pack_metadata_and_existing_binary_rows(self):
        columns = {
            table: {row[1] for row in self.db.execute(f"PRAGMA table_info({table})")}
            for table in ("telegram_sticker_packs", "telegram_stickers")
        }
        self.assertIn("isDeleted", columns["telegram_sticker_packs"])
        self.assertIn("updatedAt", columns["telegram_stickers"])
        self.assertEqual(
            (0, 120),
            self.db.execute(
                "SELECT isDeleted, updatedAt FROM telegram_sticker_packs WHERE name='pack_alpha'"
            ).fetchone(),
        )
        self.assertEqual(
            [("telegramStickerPacks", "pack_alpha"),
             ("telegramStickers", "pack_alpha:file_1"),
             ("telegramStickers", "pack_alpha:file_2")],
            self.db.execute(
                "SELECT entityType, entityId FROM sync_changes ORDER BY entityType, entityId"
            ).fetchall(),
        )
        self.assertEqual(
            [(120,), (120,)],
            self.db.execute("SELECT updatedAt FROM telegram_stickers ORDER BY id").fetchall(),
        )

    def test_new_pack_and_sticker_writes_are_enqueued_and_delete_is_a_tombstone(self):
        self.db.execute(
            "INSERT INTO telegram_sticker_packs VALUES('pack_beta', 'Pack Beta', 0, 1, 200, 200, 0)"
        )
        self.db.execute(
            "INSERT INTO telegram_stickers VALUES "
            "('pack_beta:file_3', 'pack_beta', 'file_3', '🎉', 0, 'image/webp', 'three.webp', 3, X'060708', 200, 200)"
        )
        self.db.execute(
            "UPDATE telegram_sticker_packs SET isDeleted=1, stickerCount=0, updatedAt=201 "
            "WHERE name='pack_beta'"
        )
        self.db.execute("DELETE FROM telegram_stickers WHERE packName='pack_beta'")
        new_changes = self.db.execute(
            "SELECT entityType, entityId, changedAt FROM sync_changes "
            "WHERE entityId IN ('pack_beta', 'pack_beta:file_3') "
            "ORDER BY entityType, changedAt"
        ).fetchall()
        self.assertEqual(
            [("telegramStickerPacks", "pack_beta", 200),
             ("telegramStickerPacks", "pack_beta", 201),
             ("telegramStickers", "pack_beta:file_3", 200)],
            new_changes,
        )
        self.assertEqual(
            (1, 0),
            self.db.execute(
                "SELECT isDeleted, stickerCount FROM telegram_sticker_packs WHERE name='pack_beta'"
            ).fetchone(),
        )
        self.assertEqual(0, self.db.execute(
            "SELECT COUNT(*) FROM telegram_stickers WHERE packName='pack_beta'"
        ).fetchone()[0])

    def test_maximum_sticker_fits_under_incremental_and_relay_envelope_limits(self):
        # The Bot API client caps one raw sticker at 2 MiB; URL-safe Base64 expands it by 4/3.
        raw = b"x" * (2 * 1024 * 1024)
        encoded = base64.urlsafe_b64encode(raw).rstrip(b"=")
        item_size = len(b'{"entityType":"telegramStickers","payload":{"content":"') + len(encoded) + 8
        self.assertLess(item_size, 28 * 1024 * 1024)
        self.assertLess(item_size, 32 * 1024 * 1024)

    def test_snapshot_and_delta_register_both_sticker_entity_types(self):
        incremental = INCREMENTAL_SOURCE.read_text(encoding="utf-8")
        snapshot = SNAPSHOT_SOURCE.read_text(encoding="utf-8")
        self.assertIn('"telegramStickerPacks"', incremental)
        self.assertIn('"telegramStickers"', incremental)
        self.assertIn('snapshot.put("telegramStickers"', snapshot)
        self.assertIn('snapshot.optJSONArray("telegramStickerPacks")', snapshot)
        self.assertIn('snapshot.optJSONArray("telegramStickers")', snapshot)


if __name__ == "__main__":
    unittest.main()
