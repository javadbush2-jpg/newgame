import os
import shutil
import sqlite3
import tempfile
import time
import unittest
import json
import threading
from http.server import ThreadingHTTPServer
from urllib.request import Request, urlopen
from urllib.error import HTTPError

from server import (
    EPHEMERAL_MAX_TTL_MS,
    RelayStore,
    is_ephemeral_envelope,
    mailbox_for_token,
    should_archive_envelope,
    validate_acknowledgements,
    validate_message,
)


class RelayServerTest(unittest.TestCase):
    def setUp(self):
        # ignore_cleanup_errors helps on Windows when SQLite briefly holds the file.
        self.temp = tempfile.TemporaryDirectory(ignore_cleanup_errors=True)
        self.db_path = os.path.join(self.temp.name, "relay.sqlite3")
        self.store = RelayStore(self.db_path)
        self.now = int(time.time() * 1000)
        self.message = {
            "messageId": "550e8400-e29b-41d4-a716-446655440000",
            "correlationId": None,
            "createdAt": self.now,
            "expiresAt": self.now + 60_000,
            "envelope": {
                "type": "incremental_exchange",
                "requestId": "550e8400-e29b-41d4-a716-446655440000",
                "sentAt": self.now,
                "delta": {},
            },
        }

    def tearDown(self):
        # Windows keeps SQLite WAL handles open unless we switch journal mode and close.
        try:
            if os.path.exists(self.db_path):
                conn = sqlite3.connect(self.db_path, timeout=5)
                try:
                    conn.execute("PRAGMA journal_mode=DELETE")
                    conn.execute("PRAGMA wal_checkpoint(TRUNCATE)")
                    conn.commit()
                finally:
                    conn.close()
        except Exception:
            pass
        self.store = None
        self.temp.cleanup()

    def test_database_path_is_resolved_to_absolute_path(self):
        self.assertTrue(os.path.isabs(self.store.path))

    def test_health_returns_503_when_database_directory_disappears(self):
        import server as relay_server
        db_dir = os.path.join(self.temp.name, "vanishing-db-dir")
        store = RelayStore(os.path.join(db_dir, "relay.sqlite3"))
        shutil.rmtree(db_dir)
        httpd = ThreadingHTTPServer(("127.0.0.1", 0), relay_server.RelayHandler)
        httpd.store = store
        httpd.limiter = relay_server.RateLimiter()
        thread = threading.Thread(target=httpd.serve_forever, daemon=True)
        thread.start()
        try:
            url = f"http://127.0.0.1:{httpd.server_address[1]}/health"
            with self.assertRaises(HTTPError) as error:
                urlopen(url, timeout=3)
            self.assertEqual(503, error.exception.code)
            payload = json.loads(error.exception.read())
            self.assertEqual("degraded", payload["status"])
            self.assertEqual("database_unavailable", payload["error"])
        finally:
            httpd.shutdown()
            httpd.server_close()
            thread.join(timeout=2)

    def test_health_stats_ignore_expired_rows_without_deleting_them(self):
        now_ms = int(time.time() * 1000)
        with self.store.transaction() as database:
            database.execute(
                """INSERT INTO relay_messages(
                    mailbox_id, direction, message_id, correlation_id,
                    created_at, expires_at, envelope_json
                ) VALUES (?, ?, ?, ?, ?, ?, ?)""",
                ("M" * 43, "to-host", "ExpiredMessage12345", None,
                 now_ms - 10_000, now_ms - 1, "{}"),
            )
        snapshot = self.store.stats_snapshot()
        self.assertEqual(0, snapshot["pendingMessages"])
        with self.store.transaction() as database:
            remaining = database.execute(
                "SELECT COUNT(*) FROM relay_messages WHERE message_id=?",
                ("ExpiredMessage12345",),
            ).fetchone()[0]
        self.assertEqual(1, remaining)

    def test_household_token_matches_android_default(self):
        from server import DEFAULT_HOUSEHOLD_TOKEN, load_or_create_household_token
        token_path = os.path.join(self.temp.name, "household.json")
        with open(token_path, "w", encoding="utf-8") as fh:
            fh.write('{"token":"old-random-token-that-does-not-match"}')
        token, mailbox = load_or_create_household_token(token_path)
        self.assertEqual(DEFAULT_HOUSEHOLD_TOKEN, token)
        self.assertEqual(mailbox_for_token(DEFAULT_HOUSEHOLD_TOKEN), mailbox)
        with open(token_path, "r", encoding="utf-8") as fh:
            self.assertEqual(DEFAULT_HOUSEHOLD_TOKEN, __import__("json").load(fh)["token"])

    def test_pin_pairing_endpoints_register_and_validate(self):
        import server as relay_server
        old_values = (
            relay_server.HOUSEHOLD_TOKEN,
            relay_server.HOUSEHOLD_MAILBOX,
            relay_server.HOST_PIN_HASH,
            relay_server.HOST_PIN_EXPIRES_AT,
        )
        httpd = ThreadingHTTPServer(("127.0.0.1", 0), relay_server.RelayHandler)
        httpd.store = self.store
        httpd.limiter = relay_server.RateLimiter()
        relay_server.HOUSEHOLD_TOKEN = relay_server.DEFAULT_HOUSEHOLD_TOKEN
        relay_server.HOUSEHOLD_MAILBOX = relay_server.mailbox_for_token(relay_server.DEFAULT_HOUSEHOLD_TOKEN)
        relay_server.HOST_PIN_HASH = None
        relay_server.HOST_PIN_EXPIRES_AT = 0.0
        thread = threading.Thread(target=httpd.serve_forever, daemon=True)
        thread.start()
        base = f"http://127.0.0.1:{httpd.server_address[1]}"
        headers = {
            "Authorization": f"Bearer {relay_server.DEFAULT_HOUSEHOLD_TOKEN}",
            "Content-Type": "application/json",
        }
        try:
            request = Request(base + "/pairing/host-pin", data=json.dumps({"pin": "4821"}).encode(), headers=headers, method="POST")
            with urlopen(request, timeout=3) as response:
                self.assertTrue(json.loads(response.read())["registered"])

            valid = Request(base + "/pairing/verify-pin", data=json.dumps({"pin": "4821"}).encode(), headers=headers, method="POST")
            with urlopen(valid, timeout=3) as response:
                self.assertTrue(json.loads(response.read())["valid"])

            wrong = Request(base + "/pairing/verify-pin", data=json.dumps({"pin": "1111"}).encode(), headers=headers, method="POST")
            with self.assertRaises(HTTPError) as error:
                urlopen(wrong, timeout=3)
            self.assertEqual(403, error.exception.code)
        finally:
            httpd.shutdown()
            httpd.server_close()
            thread.join(timeout=2)
            (relay_server.HOUSEHOLD_TOKEN, relay_server.HOUSEHOLD_MAILBOX,
             relay_server.HOST_PIN_HASH, relay_server.HOST_PIN_EXPIRES_AT) = old_values

    def test_encrypted_backup_store_round_trip(self):
        backup = {"v": 1, "nonce": "dGVzdG5vbmNl", "ciphertext": "Y2lwaGVydGV4dA"}
        mailbox = mailbox_for_token("A" * 43)
        self.store.save_backup(mailbox, self.now, backup)
        restored = self.store.get_backup(mailbox)
        self.assertEqual((self.now, backup), restored)
        # Older uploads must not replace a newer snapshot.
        self.store.save_backup(mailbox, self.now - 1, {"v": 1, "nonce": "old", "ciphertext": "old"})
        self.assertEqual((self.now, backup), self.store.get_backup(mailbox))

    def test_backup_http_endpoints_require_token_and_round_trip(self):
        import server as relay_server
        old_values = (relay_server.HOUSEHOLD_TOKEN, relay_server.HOUSEHOLD_MAILBOX)
        relay_server.HOUSEHOLD_TOKEN = relay_server.DEFAULT_HOUSEHOLD_TOKEN
        relay_server.HOUSEHOLD_MAILBOX = relay_server.mailbox_for_token(relay_server.DEFAULT_HOUSEHOLD_TOKEN)
        httpd = ThreadingHTTPServer(("127.0.0.1", 0), relay_server.RelayHandler)
        httpd.store = self.store
        httpd.limiter = relay_server.RateLimiter()
        thread = threading.Thread(target=httpd.serve_forever, daemon=True)
        thread.start()
        base = f"http://127.0.0.1:{httpd.server_address[1]}"
        headers = {"Authorization": f"Bearer {relay_server.DEFAULT_HOUSEHOLD_TOKEN}", "Content-Type": "application/json"}
        backup = {"v": 1, "nonce": "dGVzdG5vbmNl", "ciphertext": "Y2lwaGVydGV4dA"}
        try:
            request = Request(base + "/v1/backup", data=json.dumps({"updatedAt": self.now, "backup": backup}).encode(), headers=headers, method="POST")
            with urlopen(request, timeout=3) as response:
                self.assertTrue(json.loads(response.read())["stored"])
            request = Request(base + "/v1/backup", headers={"Authorization": headers["Authorization"]}, method="GET")
            with urlopen(request, timeout=3) as response:
                payload = json.loads(response.read())
                self.assertEqual(self.now, payload["updatedAt"])
                self.assertEqual(backup, payload["backup"])
        finally:
            httpd.shutdown()
            httpd.server_close()
            thread.join(timeout=2)
            relay_server.HOUSEHOLD_TOKEN, relay_server.HOUSEHOLD_MAILBOX = old_values

    def test_mailbox_is_hash_of_bearer_token(self):
        token = "A" * 43
        self.assertEqual(43, len(mailbox_for_token(token)))
        self.assertNotEqual(mailbox_for_token(token), mailbox_for_token("B" * 43))

    def test_publish_is_idempotent_but_conflict_is_rejected(self):
        message = validate_message(dict(self.message))
        self.assertTrue(self.store.publish("M" * 43, "to-host", message))
        self.assertFalse(self.store.publish("M" * 43, "to-host", message))
        changed = dict(message)
        changed["envelope"] = {"type": "changed"}
        # Reusing a transport ID with a newer body is an intentional replace operation;
        # it avoids multiplying queue rows when an ACK list changes during retry.
        self.assertTrue(self.store.publish("M" * 43, "to-host", changed))
        queued = self.store.receive("M" * 43, "to-host", 20)
        self.assertEqual(1, len(queued))
        self.assertEqual("changed", queued[0]["envelope"]["type"])

    def test_full_mailbox_applies_backpressure_without_evicting_unacknowledged_messages(self):
        import server as relay_server
        old_limit = relay_server.MAX_MESSAGES_PER_MAILBOX
        old_total = relay_server.MAX_TOTAL_MESSAGES
        relay_server.MAX_MESSAGES_PER_MAILBOX = 1
        relay_server.MAX_TOTAL_MESSAGES = 100
        mailbox = "M" * 43
        first = validate_message(dict(self.message))
        try:
            self.assertTrue(self.store.publish(mailbox, "to-host", first))
            second = dict(self.message)
            second["messageId"] = "650e8400-e29b-41d4-a716-446655440001"
            second["createdAt"] = self.now + 1
            second["envelope"] = {"type": "incremental_exchange", "requestId": second["messageId"], "delta": {"x": 1}}
            with self.assertRaises(OverflowError):
                self.store.publish(mailbox, "to-host", validate_message(second))
            queued = self.store.receive(mailbox, "to-host", 20)
            self.assertEqual(1, len(queued))
            self.assertEqual(first["messageId"], queued[0]["messageId"])
        finally:
            relay_server.MAX_MESSAGES_PER_MAILBOX = old_limit
            relay_server.MAX_TOTAL_MESSAGES = old_total

    def test_receive_requires_acknowledgement_before_delete(self):
        import server as relay_server
        before = dict(relay_server.STATS)
        self.store.publish("M" * 43, "to-host", validate_message(dict(self.message)))
        first = self.store.receive("M" * 43, "to-host", 20)
        second = self.store.receive("M" * 43, "to-host", 20)
        self.assertEqual(1, len(first))
        self.assertEqual(first, second)
        self.assertEqual(1, self.store.acknowledge("M" * 43, "to-host", [self.message["messageId"]]))
        self.assertEqual([], self.store.receive("M" * 43, "to-host", 20))
        self.assertEqual(before["receive"] + 3, relay_server.STATS["receive"])
        self.assertEqual(before["receive_to_host"] + 3, relay_server.STATS["receive_to_host"])
        self.assertEqual(before["receive_messages_to_host"] + 2, relay_server.STATS["receive_messages_to_host"])
        self.assertEqual(before["ack"] + 1, relay_server.STATS["ack"])
        self.assertEqual(before["ack_to_host"] + 1, relay_server.STATS["ack_to_host"])
        self.assertEqual(before["ack_deleted_to_host"] + 1, relay_server.STATS["ack_deleted_to_host"])

    def test_authenticated_mailbox_get_returns_server_time_and_receive_stats(self):
        import server as relay_server
        old_values = (relay_server.HOUSEHOLD_TOKEN, relay_server.HOUSEHOLD_MAILBOX)
        relay_server.HOUSEHOLD_TOKEN = relay_server.DEFAULT_HOUSEHOLD_TOKEN
        relay_server.HOUSEHOLD_MAILBOX = mailbox_for_token(relay_server.DEFAULT_HOUSEHOLD_TOKEN)
        httpd = ThreadingHTTPServer(("127.0.0.1", 0), relay_server.RelayHandler)
        httpd.store = self.store
        httpd.limiter = relay_server.RateLimiter()
        thread = threading.Thread(target=httpd.serve_forever, daemon=True)
        thread.start()
        mailbox = relay_server.HOUSEHOLD_MAILBOX
        self.store.publish(mailbox, "to-companion", validate_message(dict(self.message)))
        before = int(time.time() * 1000)
        try:
            request = Request(
                f"http://127.0.0.1:{httpd.server_address[1]}/v1/mailboxes/{mailbox}/to-companion/messages?limit=20&wait=0",
                headers={"Authorization": f"Bearer {relay_server.DEFAULT_HOUSEHOLD_TOKEN}"},
                method="GET",
            )
            with urlopen(request, timeout=3) as response:
                payload = json.loads(response.read())
            after = int(time.time() * 1000)
            self.assertEqual(1, len(payload["messages"]))
            self.assertGreaterEqual(payload["serverTimeMs"], before)
            self.assertLessEqual(payload["serverTimeMs"], after)
            self.assertGreaterEqual(relay_server.STATS["receive_to_companion"], 1)
            self.assertGreaterEqual(relay_server.STATS["receive_messages_to_companion"], 1)
        finally:
            httpd.shutdown()
            httpd.server_close()
            thread.join(timeout=2)
            relay_server.HOUSEHOLD_TOKEN, relay_server.HOUSEHOLD_MAILBOX = old_values

    def test_acknowledgement_input_is_bounded_and_deduplicated(self):
        value = self.message["messageId"]
        self.assertEqual([value], validate_acknowledgements({"messageIds": [value, value]}))
        with self.assertRaises(ValueError):
            validate_acknowledgements({"messageIds": ["unsafe/path"]})


    def test_typing_presence_is_ephemeral_and_never_archived(self):
        now = int(time.time() * 1000)
        mailbox = mailbox_for_token("typing-presence-test-token-123456")
        envelope = {
            "type": "typing_presence",
            "isTyping": True,
            "sentAt": now,
        }
        self.assertTrue(is_ephemeral_envelope(envelope))
        self.assertFalse(should_archive_envelope(envelope))
        message = {
            "messageId": "TypingPresenceMessage12345",
            "correlationId": None,
            "createdAt": now,
            "expiresAt": now + 4 * 60 * 60 * 1000,
            "envelope": envelope,
        }

        self.assertTrue(self.store.publish(mailbox, "to-host", validate_message(message)))
        with self.store.transaction() as db:
            pending = db.execute(
                "SELECT expires_at FROM relay_messages WHERE mailbox_id=? AND direction=? AND message_id=?",
                (mailbox, "to-host", message["messageId"]),
            ).fetchone()
            archived = db.execute(
                "SELECT COUNT(*) FROM relay_archive WHERE mailbox_id=? AND direction=? AND message_id=?",
                (mailbox, "to-host", message["messageId"]),
            ).fetchone()[0]
        self.assertIsNotNone(pending)
        self.assertLessEqual(pending[0], int(time.time() * 1000) + EPHEMERAL_MAX_TTL_MS + 1_000)
        self.assertEqual(0, archived)

    def test_message_type_report_breaks_down_queue_archive_and_errors_and_is_admin_only(self):
        import server as relay_server

        mailbox = mailbox_for_token("admin-message-report-test-token-123456")
        now = int(time.time() * 1000)

        def publish(message_id, envelope):
            message = {
                "messageId": message_id,
                "correlationId": None,
                "createdAt": int(time.time() * 1000),
                "expiresAt": int(time.time() * 1000) + 60_000,
                "envelope": envelope,
            }
            self.assertTrue(self.store.publish(mailbox, "to-host", validate_message(message)))

        publish("TypingPresenceReport123", {"type": "typing_presence", "isTyping": True, "sentAt": now})
        archived_id = "ArchivedReportMessage123"
        publish(archived_id, {
            "type": "incremental_exchange",
            "delta": {"changes": [{"entityType": "messages", "entityId": "msg-1", "payload": {"text": "durable"}}]},
        })
        self.assertEqual(1, self.store.acknowledge(mailbox, "to-host", [archived_id]))

        publish("PendingErrorReport123", {
            "type": "incremental_exchange_result",
            "delta": {"changes": [{"entityType": "heartPulses", "entityId": "pulse-1", "payload": {}}]},
            "error": True,
            "message": "peer rejected update",
        })
        publish("LocationErrorReport123", {
            "type": "incremental_exchange_result",
            "delta": {"changes": [{"entityType": "heartPulses", "entityId": "pulse-2", "payload": {}}]},
            "locationRefreshError": "GPS refresh failed",
        })
        archived_error_id = "ArchivedErrorReport123"
        publish(archived_error_id, {"type": "relay_error", "errorCode": "upstream_timeout"})
        self.assertEqual(1, self.store.acknowledge(mailbox, "to-host", [archived_error_id]))

        report = relay_server.admin_ui.message_type_report(
            self.store, mailbox=mailbox[:12], direction="to-host", log_file=""
        )
        by_type = {item["type"]: item for item in report["types"]}
        self.assertEqual(3, report["pendingTotal"])
        self.assertEqual(2, report["archiveTotal"])
        self.assertEqual(2, report["errorEnvelopePending"])
        self.assertEqual(1, report["errorEnvelopeArchived"])
        self.assertEqual(1, by_type["typing_presence"]["pending"])
        self.assertEqual(1, by_type["incremental_exchange"]["archived"])
        self.assertEqual(2, by_type["incremental_exchange_result"]["errorsPending"])
        self.assertEqual(1, by_type["relay_error"]["errorsArchived"])
        self.assertEqual(
            {"peer rejected update", "GPS refresh failed", "upstream_timeout"},
            {item["reason"] for item in report["errorMessages"]},
        )
        self.assertIn(b'data-tab="messages"', relay_server.admin_ui.admin_html_bytes())
        self.assertIn(b"message-types", relay_server.admin_ui.admin_html_bytes())

        old_values = (relay_server.HOUSEHOLD_TOKEN, relay_server.HOUSEHOLD_MAILBOX)
        relay_server.HOUSEHOLD_TOKEN = relay_server.DEFAULT_HOUSEHOLD_TOKEN
        relay_server.HOUSEHOLD_MAILBOX = mailbox_for_token(relay_server.DEFAULT_HOUSEHOLD_TOKEN)
        httpd = ThreadingHTTPServer(("127.0.0.1", 0), relay_server.RelayHandler)
        httpd.store = self.store
        httpd.limiter = relay_server.RateLimiter()
        thread = threading.Thread(target=httpd.serve_forever, daemon=True)
        thread.start()
        base = f"http://127.0.0.1:{httpd.server_address[1]}/admin/api/message-types"
        try:
            with self.assertRaises(HTTPError) as error:
                urlopen(base, timeout=3)
            self.assertEqual(401, error.exception.code)
            request = Request(
                base + "?mailbox=" + mailbox[:12],
                headers={"Authorization": f"Bearer {relay_server.DEFAULT_HOUSEHOLD_TOKEN}"},
            )
            with urlopen(request, timeout=3) as response:
                payload = json.loads(response.read())
            self.assertEqual(200, response.status)
            self.assertEqual(2, payload["errorEnvelopePending"])
            self.assertGreaterEqual(payload["serverCounters"]["unauthorized"], 1)
        finally:
            httpd.shutdown()
            httpd.server_close()
            thread.join(timeout=2)
            relay_server.HOUSEHOLD_TOKEN, relay_server.HOUSEHOLD_MAILBOX = old_values

    def test_message_flow_report_distinguishes_queue_receive_and_missing_ack(self):
        import server as relay_server

        mailbox = "F" * 43
        actor = {"device_id": "a" * 24, "role": "host", "identified": True}
        message = validate_message(dict(self.message))
        self.store.publish(mailbox, "to-host", message)
        device = {
            "mailbox_id": mailbox,
            "mailbox_prefix": mailbox[:12],
            "device_id": actor["device_id"],
            "role": "host",
            "identified": True,
            "online": True,
            "last_seen_at": self.now,
            "last_http_seen_at": self.now,
            "websocket_connections": 0,
            "connection": "http",
            "last_action": "receive",
        }

        before_receive = relay_server.admin_ui.relay_flow_report(
            self.store, devices=[device], mailbox=mailbox[:12], limit=20,
            stuck_after_ms=30_000, now_ms=self.now + 1_000,
        )
        self.assertEqual(1, before_receive["pendingTotal"])
        self.assertEqual("queued", before_receive["pendingMessages"][0]["stage"])
        self.assertEqual(1, before_receive["flows"][0]["queuedCount"])

        delivered = self.store.receive(mailbox, "to-host", 20)
        self.store.record_received(mailbox, "to-host", delivered, actor)
        after_receive = relay_server.admin_ui.relay_flow_report(
            self.store, devices=[device], mailbox=mailbox[:12], limit=20,
            stuck_after_ms=30_000, now_ms=self.now + 35_000,
        )
        pending = after_receive["pendingMessages"][0]
        self.assertEqual("awaiting_ack", pending["stage"])
        self.assertEqual("ack_from_recipient", pending["blockedAt"])
        self.assertTrue(pending["targetOnline"])
        self.assertTrue(pending["stuck"])
        self.assertEqual("ack_missing", pending["stuckReason"])
        self.assertEqual(1, pending["deliveryCount"])

        self.store.acknowledge(mailbox, "to-host", [message["messageId"]], actor=actor)
        after_ack = relay_server.admin_ui.relay_flow_report(
            self.store, devices=[device], mailbox=mailbox[:12], limit=20,
        )
        self.assertEqual(0, after_ack["pendingTotal"])
        self.assertIn("ack", {event["action"] for event in after_ack["recentEvents"]})

    def test_parallel_receive_audits_do_not_race_on_delivery_primary_key(self):
        mailbox = "R" * 43
        actor = {"device_id": "d" * 24, "role": "host", "identified": True}
        message = validate_message(dict(self.message))
        self.store.publish(mailbox, "to-host", message)
        delivered = self.store.receive(mailbox, "to-host", 20)
        worker_count = 12
        barrier = threading.Barrier(worker_count)
        failures = []
        failures_lock = threading.Lock()

        def observe_delivery():
            try:
                barrier.wait(timeout=5)
                self.store.record_received(mailbox, "to-host", delivered, actor)
            except Exception as error:  # noqa: BLE001 — gather worker failures for assertion
                with failures_lock:
                    failures.append(error)

        workers = [threading.Thread(target=observe_delivery) for _ in range(worker_count)]
        for worker in workers:
            worker.start()
        for worker in workers:
            worker.join(timeout=15)
        self.assertFalse(any(worker.is_alive() for worker in workers), "receive audit worker hung")
        self.assertEqual([], failures)
        with self.store.transaction() as database:
            row = database.execute(
                """SELECT delivery_count FROM relay_deliveries
                   WHERE mailbox_id=? AND direction=? AND message_id=? AND device_id=?""",
                (mailbox, "to-host", message["messageId"], actor["device_id"]),
            ).fetchone()
            first_events = database.execute(
                """SELECT COUNT(*) FROM relay_device_events
                   WHERE mailbox_id=? AND device_id=? AND action='receive'""",
                (mailbox, actor["device_id"]),
            ).fetchone()[0]
        self.assertIsNotNone(row)
        self.assertEqual(worker_count, row[0])
        self.assertEqual(1, first_events)

    def test_http_device_headers_drive_presence_receive_ack_and_admin_flow(self):
        import server as relay_server

        old_values = (relay_server.HOUSEHOLD_TOKEN, relay_server.HOUSEHOLD_MAILBOX)
        old_presence = {key: dict(value) for key, value in relay_server.DEVICE_PRESENCE.items()}
        token = "device-flow-household-token-1234567890"
        mailbox = mailbox_for_token(token)
        relay_server.HOUSEHOLD_TOKEN = token
        relay_server.HOUSEHOLD_MAILBOX = mailbox
        relay_server.DEVICE_PRESENCE.clear()
        httpd = ThreadingHTTPServer(("127.0.0.1", 0), relay_server.RelayHandler)
        httpd.store = self.store
        httpd.limiter = relay_server.RateLimiter()
        thread = threading.Thread(target=httpd.serve_forever, daemon=True)
        thread.start()
        base = f"http://127.0.0.1:{httpd.server_address[1]}"
        companion_headers = {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json",
            "X-OurSpace-Device-Id": "b" * 24,
            "X-OurSpace-Device-Role": "companion",
        }
        host_headers = {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json",
            "X-OurSpace-Device-Id": "c" * 24,
            "X-OurSpace-Device-Role": "host",
        }
        message = {
            **self.message,
            "messageId": "DeviceFlowMessage12345",
            "createdAt": int(time.time() * 1000),
            "expiresAt": int(time.time() * 1000) + 60_000,
            "envelope": {
                "type": "incremental_exchange",
                "requestId": "DeviceFlowMessage12345",
                "delta": {"changes": [
                    {"entityType": "tasks", "entityId": "task-1", "payload": {"title": "private"}},
                    {"entityType": "messages", "entityId": "msg-1", "payload": {"text": "private"}},
                ]},
            },
        }
        endpoint = f"{base}/v1/mailboxes/{mailbox}/to-host"
        try:
            request = Request(
                endpoint + "/messages", data=json.dumps(message).encode(),
                headers=companion_headers, method="POST",
            )
            with urlopen(request, timeout=3) as response:
                self.assertEqual(201, response.status)

            request = Request(
                endpoint + "/messages?limit=20", headers=host_headers, method="GET"
            )
            with urlopen(request, timeout=3) as response:
                self.assertEqual(1, len(json.loads(response.read())["messages"]))

            ack_body = json.dumps({"messageIds": [message["messageId"]]}).encode()
            request = Request(
                endpoint + "/acknowledgements", data=ack_body,
                headers=host_headers, method="POST",
            )
            with urlopen(request, timeout=3) as response:
                self.assertEqual(1, json.loads(response.read())["acknowledged"])

            flow_url = base + "/admin/api/message-flow?mailbox=" + mailbox[:12]
            with self.assertRaises(HTTPError) as unauthorized:
                urlopen(flow_url, timeout=3)
            self.assertEqual(401, unauthorized.exception.code)
            request = Request(
                flow_url,
                headers={"Authorization": f"Bearer {token}"},
            )
            with urlopen(request, timeout=3) as response:
                report = json.loads(response.read())
            self.assertEqual(0, report["pendingTotal"])
            device_roles = {device["role"] for device in report["devices"]}
            self.assertTrue({"host", "companion"}.issubset(device_roles))
            self.assertTrue(all(device["identified"] for device in report["devices"]))
            historical = relay_server.admin_ui.relay_flow_report(
                self.store, devices=[], mailbox=mailbox[:12], limit=20,
            )
            self.assertTrue(historical["devices"])
            self.assertTrue(all(not device["online"] for device in historical["devices"]))
            actions = {event["action"] for event in report["recentEvents"]}
            self.assertTrue({"publish", "receive", "ack"}.issubset(actions))
            publish_event = next(event for event in report["recentEvents"] if event["action"] == "publish")
            self.assertEqual({"tasks": 1, "messages": 1}, publish_event["details"]["entityTypes"])
            self.assertIn(b'data-tab="flow"', relay_server.admin_ui.admin_html_bytes())
        finally:
            httpd.shutdown()
            httpd.server_close()
            thread.join(timeout=2)
            relay_server.HOUSEHOLD_TOKEN, relay_server.HOUSEHOLD_MAILBOX = old_values
            relay_server.DEVICE_PRESENCE.clear()
            relay_server.DEVICE_PRESENCE.update(old_presence)

    def test_archive_survives_acknowledgement(self):
        token = "archive-test-token-1234567890"
        mailbox = mailbox_for_token(token)
        message = {
            "messageId": "ArchiveMessage123456",
            "correlationId": None,
            "createdAt": int(time.time() * 1000),
            "expiresAt": int(time.time() * 1000) + 60_000,
            "envelope": {"type": "incremental_exchange", "delta": {"changes": [{"entityType": "messages", "entityId": "msg-1", "payload": {"text": "durable"}}]}},
        }
        self.store.publish(mailbox, "to-host", message)
        self.assertEqual(self.store.acknowledge(mailbox, "to-host", [message["messageId"]]), 1)
        with self.store.transaction() as db:
            row = db.execute(
                "SELECT envelope_json FROM relay_archive WHERE mailbox_id=? AND direction=? AND message_id=?",
                (mailbox, "to-host", message["messageId"]),
            ).fetchone()
        self.assertIsNotNone(row)
        self.assertIn("incremental_exchange", row[0])


if __name__ == "__main__":
    unittest.main()
