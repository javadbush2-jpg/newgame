#!/usr/bin/env python3
"""OurSpace personal relay server — durable HTTP mailbox + long-poll + WebSocket push.

Stores relay envelopes durably. Delivery rows are temporary; the archive is permanent.
No pairing secrets are written to the archive.
WebSocket /v1/push wakes connected phones immediately when mail is published
(content still retrieved via the encrypted HTTP mailbox API).
"""

from __future__ import annotations

import argparse
from contextlib import contextmanager
import base64
import hashlib
import hmac
import json
import logging
import os
import re
import sqlite3
import sys
import threading
import time
from collections import defaultdict, deque
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from logging.handlers import RotatingFileHandler
from urllib.parse import parse_qs, urlsplit, urlencode, quote
from urllib.request import Request, urlopen
from urllib.error import URLError, HTTPError


# WebSocket push hub (stdlib) — same directory as this file
import importlib.util as _ilu
from pathlib import Path as _Path
_ws_path = _Path(__file__).resolve().parent / "ws_hub.py"
_ws_spec = _ilu.spec_from_file_location("ws_hub", _ws_path)
ws_hub = _ilu.module_from_spec(_ws_spec)  # type: ignore[arg-type]
assert _ws_spec and _ws_spec.loader
_ws_spec.loader.exec_module(ws_hub)  # type: ignore[union-attr]

_admin_path = _Path(__file__).resolve().parent / "admin_ui.py"
_admin_spec = _ilu.spec_from_file_location("admin_ui", _admin_path)
admin_ui = _ilu.module_from_spec(_admin_spec)  # type: ignore[arg-type]
assert _admin_spec and _admin_spec.loader
_admin_spec.loader.exec_module(admin_ui)  # type: ignore[union-attr]

_blob_path = _Path(__file__).resolve().parent / "blob_store.py"
_blob_spec = _ilu.spec_from_file_location("blob_store", _blob_path)
blob_store_mod = _ilu.module_from_spec(_blob_spec)  # type: ignore[arg-type]
assert _blob_spec and _blob_spec.loader
_blob_spec.loader.exec_module(blob_store_mod)  # type: ignore[union-attr]

MAX_BODY = 96 * 1024 * 1024 + 64 * 1024
MAX_RESPONSE = 96 * 1024 * 1024 + 512 * 1024
MAX_TTL_MS = 7 * 24 * 60 * 60 * 1000
MAX_CLOCK_SKEW_MS = 10 * 60 * 1000
MAX_FETCH = 50
MAX_ACK = 100
MAX_MESSAGES_PER_MAILBOX = int(os.environ.get("OURSPACE_MAX_MESSAGES_PER_MAILBOX", "5000"))
MAX_TOTAL_MESSAGES = 100_000
# Archive must not store full photo Base64 forever — that balloons the DB to hundreds of MB.
# 0 = never auto-delete archive rows (user data retention). Space is reclaimed by
# slimming payloads (no Base64) + VACUUM, not by deleting history.
ARCHIVE_RETENTION_DAYS = int(os.environ.get("OURSPACE_ARCHIVE_RETENTION_DAYS", "0"))
ARCHIVE_MAX_ROWS = int(os.environ.get("OURSPACE_ARCHIVE_MAX_ROWS", "0"))
ARCHIVE_SLIM_MAX_CHARS = 8_000
RATE_WINDOW_SECONDS = 60
RATE_REQUESTS = 400
GLOBAL_RATE_REQUESTS = 8_000
MAX_LONG_POLL_SEC = 25
ID_RE = re.compile(r"^[A-Za-z0-9_-]{16,100}$")
MAILBOX_RE = re.compile(r"^[A-Za-z0-9_-]{43}$")
TOKEN_RE = re.compile(r"^[A-Za-z0-9_-]{16,128}$")
# Must match RelayConfig.DEFAULT_ACCESS_TOKEN in the Android app.
DEFAULT_HOUSEHOLD_TOKEN = "SyqmI0T5muBzDBf0plXAYKaMgL5uTZXiEx0sm92ijDQ"
ROUTE_RE = re.compile(
    r"^/v1/mailboxes/([A-Za-z0-9_-]{43})/(to-host|to-companion)/(messages|acknowledgements)$"
)

START_MONO = time.monotonic()
RELAY_LOG_PATH = ""
BLOB_STORE = None  # type: ignore
START_MS = int(time.time() * 1000)
STATS = {
    "publish": 0,
    "receive": 0,
    "receive_to_host": 0,
    "receive_to_companion": 0,
    "receive_messages_to_host": 0,
    "receive_messages_to_companion": 0,
    "ack": 0,
    "ack_to_host": 0,
    "ack_to_companion": 0,
    "ack_deleted_to_host": 0,
    "ack_deleted_to_companion": 0,
    "unauthorized": 0,
    "errors": 0,
    "long_poll_wake": 0,
    "ws_push": 0,
    "ws_connections": 0,
}
STATS_LOCK = threading.Lock()

# Benign client disconnects (mobile long-poll cancel, network hop, app background).
CLIENT_GONE = (ConnectionResetError, BrokenPipeError, ConnectionAbortedError, TimeoutError)
DDNS_STATUS: dict = {
    "enabled": False,
    "hostname": "",
    "lastOk": False,
    "lastAt": 0,
    "lastMessage": "",
    "lastIp": "",
    "intervalSec": 0,
}
DDNS_LOCK = threading.Lock()
ACTIVE_MAILBOXES: set[str] = set()
ACTIVE_LOCK = threading.Lock()
DEVICE_ID_RE = re.compile(r"^[a-f0-9]{24}$")
DEVICE_ONLINE_WINDOW_MS = 90_000
DEVICE_PRESENCE_LOG_INTERVAL_MS = 5 * 60_000
MESSAGE_STUCK_AFTER_MS = 120_000
DEVICE_PRESENCE: dict[tuple[str, str], dict] = {}
DEVICE_PRESENCE_LOCK = threading.Lock()
HOUSEHOLD_TOKEN: str | None = None
HOUSEHOLD_MAILBOX: str | None = None
HOST_PIN_HASH: str | None = None
HOST_PIN_EXPIRES_AT: float = 0.0
HOST_PIN_LOCK = threading.Lock()
PIN_ATTEMPTS: dict[str, deque[float]] = defaultdict(deque)


def _infer_device_role(command: str, direction: str, resource: str) -> str:
    """Infer the peer role for older clients that do not yet send device headers."""
    if resource not in ("messages", "acknowledgements") or direction not in ("to-host", "to-companion"):
        return "unknown"
    recipient = "host" if direction == "to-host" else "companion"
    if command == "POST" and resource == "messages":
        return "companion" if recipient == "host" else "host"
    return recipient


def _touch_device_presence(
    mailbox: str,
    actor: dict,
    action: str = "",
    channel: str = "http",
    websocket_delta: int = 0,
) -> None:
    now_ms = int(time.time() * 1000)
    device_id = str(actor.get("device_id") or "unknown")
    role = str(actor.get("role") or "unknown")
    key = (mailbox, device_id)
    with DEVICE_PRESENCE_LOCK:
        state = DEVICE_PRESENCE.setdefault(key, {
            "mailbox_id": mailbox,
            "device_id": device_id,
            "role": role,
            "identified": bool(actor.get("identified")),
            "first_seen_at": now_ms,
            "last_seen_at": now_ms,
            "last_http_seen_at": 0,
            "websocket_connections": 0,
            "websocket_last_seen_at": 0,
            "last_action": "",
        })
        state["role"] = role if role != "unknown" else state.get("role", "unknown")
        state["identified"] = bool(state.get("identified") or actor.get("identified"))
        state["last_seen_at"] = now_ms
        if channel == "http":
            state["last_http_seen_at"] = now_ms
        elif channel == "websocket":
            state["websocket_last_seen_at"] = now_ms
        if websocket_delta:
            state["websocket_connections"] = max(
                0, int(state.get("websocket_connections", 0)) + websocket_delta
            )
        if action:
            state["last_action"] = action


def _device_presence_log_due(mailbox: str, actor: dict) -> bool:
    now_ms = int(time.time() * 1000)
    key = (mailbox, str(actor.get("device_id") or "unknown"))
    with DEVICE_PRESENCE_LOCK:
        state = DEVICE_PRESENCE.get(key)
        if state is None:
            return False
        last_logged = int(state.get("last_logged_event_at") or 0)
        if now_ms - last_logged < DEVICE_PRESENCE_LOG_INTERVAL_MS:
            return False
        state["last_logged_event_at"] = now_ms
        return True


def _device_presence_snapshot(mailbox_prefix: str = "") -> list[dict]:
    now_ms = int(time.time() * 1000)
    with DEVICE_PRESENCE_LOCK:
        devices = {key: dict(value) for key, value in DEVICE_PRESENCE.items()}
    try:
        socket_devices = ws_hub.HUB.presence_snapshot()
    except AttributeError:
        socket_devices = []
    for socket_device in socket_devices:
        mailbox = str(socket_device.get("mailbox_id") or "")
        device_id = str(socket_device.get("device_id") or "unknown")
        key = (mailbox, device_id)
        state = devices.setdefault(key, {
            "mailbox_id": mailbox,
            "device_id": device_id,
            "role": socket_device.get("role") or "unknown",
            "identified": bool(socket_device.get("identified")),
            "first_seen_at": socket_device.get("connected_at") or now_ms,
            "last_seen_at": socket_device.get("last_seen_at") or now_ms,
            "last_http_seen_at": 0,
            "websocket_connections": 0,
            "websocket_last_seen_at": 0,
            "last_action": "websocket_connected",
        })
        state["role"] = socket_device.get("role") or state.get("role", "unknown")
        state["identified"] = bool(state.get("identified") or socket_device.get("identified"))
        state["websocket_connections"] = int(socket_device.get("connections") or 0)
        state["websocket_last_seen_at"] = int(socket_device.get("last_seen_at") or 0)
        state["last_seen_at"] = max(
            int(state.get("last_seen_at") or 0),
            int(state["websocket_last_seen_at"] or 0),
        )
    result = []
    prefix = (mailbox_prefix or "").strip()
    for state in devices.values():
        mailbox = str(state.get("mailbox_id") or "")
        if prefix and not mailbox.startswith(prefix):
            continue
        last_http = int(state.get("last_http_seen_at") or 0)
        sockets = int(state.get("websocket_connections") or 0)
        online = sockets > 0 or (last_http > 0 and now_ms - last_http <= DEVICE_ONLINE_WINDOW_MS)
        result.append({
            **state,
            "online": online,
            "connection": "websocket" if sockets else ("http" if last_http else "unknown"),
            "mailbox_prefix": mailbox[:12],
        })
    return sorted(result, key=lambda device: (device.get("role") or "", device.get("device_id") or ""))

PIN_ATTEMPTS_LOCK = threading.Lock()
# mailbox+direction -> Condition for race-free long-poll wake
WAKE_CONDITIONS: dict[str, threading.Condition] = {}
WAKE_LOCK = threading.Lock()

LOG = logging.getLogger("ourspace.relay")


def b64url(raw: bytes) -> str:
    return base64.urlsafe_b64encode(raw).rstrip(b"=").decode("ascii")


def mailbox_for_token(token: str) -> str:
    return b64url(hashlib.sha256(token.encode("ascii")).digest())


def wake_key(mailbox: str, direction: str) -> str:
    return f"{mailbox}|{direction}"


def _wake_condition(key: str) -> threading.Condition:
    condition = WAKE_CONDITIONS.get(key)
    if condition is None:
        condition = threading.Condition(WAKE_LOCK)
        WAKE_CONDITIONS[key] = condition
    return condition


def notify_waiters(mailbox: str, direction: str) -> None:
    key = wake_key(mailbox, direction)
    with WAKE_LOCK:
        _wake_condition(key).notify_all()
    # Instant wake for phones holding a WebSocket to /v1/push
    try:
        sent = ws_hub.HUB.notify(mailbox, direction)
        if sent:
            with STATS_LOCK:
                STATS["ws_push"] += sent
    except Exception as exc:  # noqa: BLE001
        LOG.warning("ws notify failed: %s", exc)
    # FCM data-only wake (no message body) for phones that are force-stopped / Doze
    try:
        fcm_wake_mailbox(mailbox, direction)
    except Exception as exc:  # noqa: BLE001
        LOG.warning("fcm wake failed: %s", exc)


def wait_for_mail(mailbox: str, direction: str, timeout_sec: float, has_mail) -> bool:
    """Wait without a lost-wakeup race.

    The condition is acquired before the final mailbox re-check. A publisher cannot
    notify between that re-check and the condition wait because publish() must acquire
    the same WAKE_LOCK before notifying.
    """
    key = wake_key(mailbox, direction)
    deadline = time.monotonic() + max(0.0, timeout_sec)
    with WAKE_LOCK:
        condition = _wake_condition(key)
        while True:
            if has_mail():
                return True
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                return False
            condition.wait(timeout=remaining)



def fcm_server_key() -> str | None:
    """Prefer env; otherwise optional drop-in file next to the database (zero extra setup)."""
    key = (os.environ.get("FCM_SERVER_KEY") or os.environ.get("OURSPACE_FCM_SERVER_KEY") or "").strip()
    if key:
        return key
    # relay-data/fcm-server-key.txt — only if the operator chooses to enable Google FCM
    for candidate in (
        os.environ.get("OURSPACE_FCM_KEY_FILE"),
        os.path.join("relay-data", "fcm-server-key.txt"),
        os.path.join(os.path.dirname(os.path.abspath(__file__)), "relay-data", "fcm-server-key.txt"),
        os.path.join(os.path.dirname(os.path.abspath(__file__)), "fcm-server-key.txt"),
    ):
        if not candidate:
            continue
        try:
            if os.path.isfile(candidate):
                with open(candidate, "r", encoding="utf-8") as fh:
                    value = fh.read().strip()
                if value and not value.startswith("#"):
                    return value
        except OSError:
            continue
    return None


def fcm_wake_mailbox(mailbox: str, direction: str) -> int:
    """Send data-only high-priority FCM to registered tokens. Returns number attempted."""
    key = fcm_server_key()
    if not key:
        return 0
    # store is on the server instance — use global via module-level last store if available
    store = getattr(fcm_wake_mailbox, "_store", None)
    if store is None:
        return 0
    tokens = store.list_push_tokens(mailbox)
    if not tokens:
        return 0
    # Legacy HTTP API — still widely used for server keys from Firebase console
    payload = {
        "registration_ids": tokens[:20],
        "priority": "high",
        "content_available": True,
        "data": {
            "type": "ourspace_mail",
            "direction": direction,
            "at": str(int(time.time() * 1000)),
        },
        # No notification{} block → data-only; app wakes without lock-screen text.
    }
    body = json.dumps(payload).encode("utf-8")
    req = Request(
        "https://fcm.googleapis.com/fcm/send",
        data=body,
        headers={
            "Authorization": f"key={key}",
            "Content-Type": "application/json; charset=utf-8",
        },
        method="POST",
    )
    try:
        with urlopen(req, timeout=8) as resp:
            raw = resp.read().decode("utf-8", errors="replace")
            LOG.info("fcm wake mailbox=%s dir=%s tokens=%s resp=%s", mailbox[:12], direction, len(tokens), raw[:160])
            with STATS_LOCK:
                STATS["fcm_wake"] = STATS.get("fcm_wake", 0) + 1
            return len(tokens)
    except (URLError, HTTPError, TimeoutError, OSError) as exc:
        LOG.warning("fcm http error: %s", exc)
        return 0


class RateLimiter:
    def __init__(self) -> None:
        self._entries: dict[str, deque[float]] = defaultdict(deque)
        self._global: deque[float] = deque()
        self._lock = threading.Lock()

    def allow(self, mailbox: str) -> bool:
        now = time.monotonic()
        cutoff = now - RATE_WINDOW_SECONDS
        with self._lock:
            while self._global and self._global[0] <= cutoff:
                self._global.popleft()
            if len(self._global) >= GLOBAL_RATE_REQUESTS:
                return False
            entries = self._entries[mailbox]
            while entries and entries[0] <= cutoff:
                entries.popleft()
            if len(entries) >= RATE_REQUESTS:
                return False
            self._global.append(now)
            entries.append(now)
            return True



# ---------------------------------------------------------------------------
# Selective persistence: what the personal relay should remember long-term
# ---------------------------------------------------------------------------
# Durable = user content worth keeping on the server (memories, chat, plans, …)
# Ephemeral = delivery-only signals (heart pulse, live location) — queue only, short TTL
DURABLE_ENTITY_TYPES = frozenset({
    "tasks", "events", "shopping", "messages",
    "financialAccounts", "financeTransactions", "financeBudgets",
    "sharedDebts", "recurringTransactions",
    "memories", "moodCheckIns", "specialDates", "coupleProfile",
    "cycleLogs", "cycleSettings", "sharedPlaces", "habits", "watchlistItems",
    "attachments",
})
EPHEMERAL_ENTITY_TYPES = frozenset({
    "heartPulses",
    "locationShares",
})
EPHEMERAL_ENVELOPE_TYPES = frozenset({
    "location_refresh_request",
    "typing_presence",
})
# Delivery-queue TTL cap for pure ephemeral traffic (2 hours)
EPHEMERAL_MAX_TTL_MS = 2 * 60 * 60 * 1000


def _delta_entity_types(envelope: dict) -> set[str]:
    types: set[str] = set()
    delta = envelope.get("delta")
    if not isinstance(delta, dict):
        return types
    changes = delta.get("changes")
    if not isinstance(changes, list):
        return types
    for item in changes:
        if isinstance(item, dict):
            et = str(item.get("entityType") or "").strip()
            if et:
                types.add(et)
    return types


def is_ephemeral_envelope(envelope: dict) -> bool:
    """True when the envelope only carries short-lived signals (no durable user content)."""
    if not isinstance(envelope, dict):
        return False
    etype = str(envelope.get("type") or "")
    if etype in EPHEMERAL_ENVELOPE_TYPES:
        return True
    if etype in ("attachment_blob", "attachment_chunk", "attachment_tombstone"):
        return False
    if etype in ("incremental_exchange", "incremental_exchange_result"):
        types = _delta_entity_types(envelope)
        if not types:
            # Pure ACK / empty delta — no need to archive
            return True
        # Ephemeral only if every entity is ephemeral (e.g. only heartPulses)
        return types.issubset(EPHEMERAL_ENTITY_TYPES)
    return False


def should_archive_envelope(envelope: dict) -> bool:
    """Archive only envelopes that carry durable household content."""
    if not isinstance(envelope, dict):
        return False
    if is_ephemeral_envelope(envelope):
        return False
    etype = str(envelope.get("type") or "")
    if etype in ("attachment_blob", "attachment_chunk", "attachment_tombstone"):
        return True
    if etype in ("incremental_exchange", "incremental_exchange_result"):
        types = _delta_entity_types(envelope)
        return bool(types & DURABLE_ENTITY_TYPES)
    # Unknown types: keep a slim audit trail
    return True


def archive_envelope_json(envelope: dict) -> str:
    """Compact durable archive: keep useful metadata, never store photo Base64 or ephemeral noise."""
    try:
        slim = dict(envelope) if isinstance(envelope, dict) else {"raw": str(envelope)[:500]}
        etype = str(slim.get("type") or "")
        if etype == "attachment_chunk":
            chunk = slim.get("chunk")
            if isinstance(chunk, dict):
                chunk = dict(chunk)
                data = chunk.get("data")
                if isinstance(data, str):
                    chunk["data"] = f"[omitted {len(data)} chars]"
                    chunk["dataOmitted"] = True
                att = chunk.get("attachment")
                if isinstance(att, dict):
                    att = dict(att)
                    content = att.get("content")
                    if isinstance(content, str) and len(content) > 64:
                        att["content"] = f"[omitted {len(content)} chars]"
                    chunk["attachment"] = att
                slim["chunk"] = chunk
        # Large incremental deltas: keep counts / types, drop full entity payloads if huge.
        elif etype in ("incremental_exchange", "incremental_exchange_result"):
            delta = slim.get("delta")
            if isinstance(delta, dict):
                changes = delta.get("changes") if isinstance(delta.get("changes"), list) else []
                acks = delta.get("acknowledgedChanges") or delta.get("acknowledgements")
                types: dict[str, int] = {}
                durable_summary: list[dict] = []
                for item in changes:
                    if not isinstance(item, dict):
                        continue
                    k = str(item.get("entityType") or "?")
                    types[k] = types.get(k, 0) + 1
                    if k in DURABLE_ENTITY_TYPES and len(durable_summary) < 40:
                        payload = item.get("payload") if isinstance(item.get("payload"), dict) else {}
                        durable_summary.append({
                            "entityType": k,
                            "entityId": str(item.get("entityId") or "")[:64],
                            "changeId": str(item.get("changeId") or "")[:80],
                            "changedAt": item.get("changedAt"),
                            "title": str(payload.get("title") or payload.get("text") or payload.get("name") or "")[:120],
                        })
                # Always store a structured summary (not full payloads) for durable history
                slim["delta"] = {
                    "protocol": delta.get("protocol"),
                    "schema": delta.get("schema"),
                    "changesCount": len(changes),
                    "ackCount": len(acks) if isinstance(acks, list) else 0,
                    "entityTypes": types,
                    "durableSummary": durable_summary,
                    "omittedPayloads": True,
                }
                slim.pop("acknowledgementIds", None)
        encoded = json.dumps(slim, separators=(",", ":"), ensure_ascii=True)
        if len(encoded) > 64_000:
            encoded = json.dumps(
                {
                    "type": etype or "unknown",
                    "omitted": True,
                    "originalChars": len(encoded),
                    "note": "envelope too large for archive",
                },
                separators=(",", ":"),
            )
        return encoded
    except Exception:  # noqa: BLE001
        return json.dumps({"type": "archive_error"}, separators=(",", ":"))


class RelayStore:
    def __init__(self, path: str) -> None:
        # Resolve relative paths exactly once. A later cwd change (for example from
        # an embedding/service launcher) must never redirect requests to another DB.
        self.path = os.path.abspath(os.path.expanduser(path))
        self._event_prune_lock = threading.Lock()
        self._last_event_prune_ms = 0
        self._initialize()

    def connect(self) -> sqlite3.Connection:
        parent = os.path.dirname(self.path) or os.curdir
        connection: sqlite3.Connection | None = None
        try:
            # Do not silently recreate the parent directory here: if it vanished
            # after startup, creating an empty DB would hide a data-loss incident.
            if not os.path.isdir(parent):
                raise sqlite3.OperationalError("database_parent_directory_missing")
            connection = sqlite3.connect(self.path, timeout=10)
            connection.execute("PRAGMA foreign_keys=ON")
            connection.execute("PRAGMA busy_timeout=10000")
            return connection
        except (OSError, sqlite3.Error) as exc:
            if connection is not None:
                try:
                    connection.close()
                except sqlite3.Error:
                    pass
            try:
                parent_exists = os.path.isdir(parent)
                parent_writable = os.access(parent, os.W_OK) if parent_exists else False
                database_exists = os.path.isfile(self.path)
            except OSError:
                parent_exists = parent_writable = database_exists = False
            LOG.error(
                "sqlite_connect_failed db=%s parent_exists=%s parent_writable=%s "
                "db_exists=%s error=%r",
                self.path, parent_exists, parent_writable, database_exists, exc,
            )
            raise

    @contextmanager
    def transaction(self):
        """Open one SQLite connection, commit/rollback its transaction, and always close it."""
        connection = self.connect()
        try:
            with connection:
                yield connection
        finally:
            connection.close()

    def _initialize(self) -> None:
        os.makedirs(os.path.dirname(os.path.abspath(self.path)), exist_ok=True)
        with self.transaction() as database:
            database.execute("PRAGMA journal_mode=WAL")
            database.execute(
                """
                CREATE TABLE IF NOT EXISTS relay_messages (
                    mailbox_id TEXT NOT NULL,
                    direction TEXT NOT NULL,
                    message_id TEXT NOT NULL,
                    correlation_id TEXT,
                    created_at INTEGER NOT NULL,
                    expires_at INTEGER NOT NULL,
                    envelope_json TEXT NOT NULL,
                    PRIMARY KEY(mailbox_id, direction, message_id)
                )
                """
            )
            database.execute(
                """
                CREATE INDEX IF NOT EXISTS relay_messages_delivery
                ON relay_messages(mailbox_id, direction, created_at)
                """
            )
            database.execute(
                """
                CREATE INDEX IF NOT EXISTS relay_messages_expiry
                ON relay_messages(expires_at)
                """
            )
            # Permanent audit/archive of every envelope accepted by the relay.
            # The delivery queue may be ACKed/expired, but the archived exchange remains.
            database.execute(
                """
                CREATE TABLE IF NOT EXISTS relay_archive (
                    archive_id INTEGER PRIMARY KEY AUTOINCREMENT,
                    mailbox_id TEXT NOT NULL,
                    direction TEXT NOT NULL,
                    message_id TEXT NOT NULL,
                    correlation_id TEXT,
                    created_at INTEGER NOT NULL,
                    expires_at INTEGER NOT NULL,
                    archived_at INTEGER NOT NULL,
                    envelope_json TEXT NOT NULL,
                    UNIQUE(mailbox_id, direction, message_id)
                )
                """
            )
            database.execute(
                """
                CREATE TABLE IF NOT EXISTS push_tokens (
                    mailbox_id TEXT NOT NULL,
                    token TEXT NOT NULL,
                    platform TEXT NOT NULL DEFAULT 'android',
                    updated_at INTEGER NOT NULL,
                    PRIMARY KEY(mailbox_id, token)
                )
                """
            )
            database.execute(
                """
                CREATE INDEX IF NOT EXISTS push_tokens_mailbox
                ON push_tokens(mailbox_id, updated_at)
                """
            )
            database.execute(
                """
                CREATE INDEX IF NOT EXISTS relay_archive_time
                ON relay_archive(mailbox_id, archived_at)
                """
            )
            database.execute(
                """
                CREATE INDEX IF NOT EXISTS relay_archive_message
                ON relay_archive(message_id)
                """
            )
            # Latest full-device snapshot, encrypted on the client before upload.
            database.execute(
                """
                CREATE TABLE IF NOT EXISTS household_backups (
                    mailbox_id TEXT PRIMARY KEY,
                    updated_at INTEGER NOT NULL,
                    backup_json TEXT NOT NULL
                )
                """
            )
            # Compact device-action audit trail (never stores message contents).
            database.execute(
                """
                CREATE TABLE IF NOT EXISTS relay_device_events (
                    event_id INTEGER PRIMARY KEY AUTOINCREMENT,
                    event_at INTEGER NOT NULL,
                    mailbox_id TEXT NOT NULL,
                    device_id TEXT NOT NULL,
                    role TEXT NOT NULL DEFAULT 'unknown',
                    action TEXT NOT NULL,
                    direction TEXT NOT NULL DEFAULT '',
                    message_id TEXT NOT NULL DEFAULT '',
                    message_type TEXT NOT NULL DEFAULT '',
                    result TEXT NOT NULL DEFAULT '',
                    details_json TEXT NOT NULL DEFAULT '{}'
                )
                """
            )
            database.execute(
                "CREATE INDEX IF NOT EXISTS relay_device_events_time "
                "ON relay_device_events(mailbox_id, event_at DESC)"
            )
            database.execute(
                "CREATE INDEX IF NOT EXISTS relay_device_events_message "
                "ON relay_device_events(mailbox_id, direction, message_id, event_at DESC)"
            )
            # Delivery observations distinguish "still queued" from "served but not ACKed".
            database.execute(
                """
                CREATE TABLE IF NOT EXISTS relay_deliveries (
                    mailbox_id TEXT NOT NULL,
                    direction TEXT NOT NULL,
                    message_id TEXT NOT NULL,
                    device_id TEXT NOT NULL,
                    role TEXT NOT NULL DEFAULT 'unknown',
                    first_delivered_at INTEGER NOT NULL,
                    last_delivered_at INTEGER NOT NULL,
                    delivery_count INTEGER NOT NULL DEFAULT 1,
                    last_event_at INTEGER NOT NULL,
                    PRIMARY KEY(mailbox_id, direction, message_id, device_id)
                )
                """
            )
            database.execute(
                "CREATE INDEX IF NOT EXISTS relay_deliveries_message "
                "ON relay_deliveries(mailbox_id, direction, message_id)"
            )

    @staticmethod
    def _event_message_type(envelope) -> str:
        if isinstance(envelope, dict):
            return str(envelope.get("type") or "(بدون نوع)")[:100]
        try:
            parsed = json.loads(envelope or "{}")
            return str(parsed.get("type") or "(بدون نوع)")[:100] if isinstance(parsed, dict) else "(بدون نوع)"
        except (TypeError, json.JSONDecodeError):
            return "(بدون نوع)"

    @staticmethod
    def _event_message_details(envelope) -> dict:
        if isinstance(envelope, str):
            try:
                envelope = json.loads(envelope)
            except (TypeError, json.JSONDecodeError):
                return {}
        if not isinstance(envelope, dict):
            return {}
        delta = envelope.get("delta")
        if not isinstance(delta, dict):
            return {}
        changes = delta.get("changes")
        entity_types: dict[str, int] = {}
        if isinstance(changes, list):
            for change in changes:
                if not isinstance(change, dict):
                    continue
                entity_type = str(change.get("entityType") or "(unknown)")[:64]
                entity_types[entity_type] = entity_types.get(entity_type, 0) + 1
        acknowledgements = (
            delta.get("acknowledgedChanges")
            or delta.get("acknowledgements")
            or delta.get("acknowledgedIds")
        )
        return {
            "changeCount": len(changes) if isinstance(changes, list) else 0,
            "entityTypes": entity_types,
            "ackCount": len(acknowledgements) if isinstance(acknowledgements, list) else 0,
        }

    def _insert_device_event(
        self,
        database: sqlite3.Connection,
        mailbox: str,
        actor: dict,
        action: str,
        direction: str = "",
        message_id: str = "",
        message_type: str = "",
        result: str = "",
        details: dict | None = None,
        event_at: int | None = None,
    ) -> int:
        encoded_details = json.dumps(details or {}, separators=(",", ":"), ensure_ascii=True)
        if len(encoded_details) > 4_096:
            encoded_details = '{"truncated":true}'
        cursor = database.execute(
            """INSERT INTO relay_device_events(
                event_at, mailbox_id, device_id, role, action, direction,
                message_id, message_type, result, details_json
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                int(event_at or time.time() * 1000),
                mailbox,
                str(actor.get("device_id") or "unknown")[:64],
                str(actor.get("role") or "unknown")[:16],
                str(action)[:64],
                str(direction)[:24],
                str(message_id)[:100],
                str(message_type)[:100],
                str(result)[:120],
                encoded_details,
            ),
        )
        return int(cursor.lastrowid or 0)

    def _log_device_event(
        self,
        event_id: int,
        mailbox: str,
        actor: dict,
        action: str,
        direction: str,
        message_id: str,
        message_type: str,
        result: str,
    ) -> None:
        LOG.info(
            "device_action event=%s device=%s role=%s action=%s mailbox=%s dir=%s id=%s type=%s result=%s",
            event_id,
            str(actor.get("device_id") or "unknown")[:24],
            str(actor.get("role") or "unknown"),
            action,
            mailbox[:12],
            direction or "-",
            message_id[:16] or "-",
            message_type or "-",
            result or "-",
        )

    def _prune_device_events_if_due(self, now_ms: int) -> None:
        with self._event_prune_lock:
            if now_ms - self._last_event_prune_ms < 60 * 60 * 1000:
                return
            self._last_event_prune_ms = now_ms
        cutoff = now_ms - 7 * 24 * 60 * 60 * 1000
        try:
            with self.transaction() as database:
                database.execute("DELETE FROM relay_device_events WHERE event_at < ?", (cutoff,))
                count = int(database.execute("SELECT COUNT(*) FROM relay_device_events").fetchone()[0])
                if count > 100_000:
                    database.execute(
                        """DELETE FROM relay_device_events WHERE event_id IN (
                            SELECT event_id FROM relay_device_events ORDER BY event_id ASC LIMIT ?
                        )""",
                        (count - 100_000,),
                    )
                database.execute("DELETE FROM relay_deliveries WHERE last_delivered_at < ?", (cutoff,))
        except sqlite3.Error:
            LOG.warning("device_event_prune_failed", exc_info=True)

    def record_device_event(
        self,
        mailbox: str,
        actor: dict,
        action: str,
        direction: str = "",
        message_id: str = "",
        message_type: str = "",
        result: str = "",
        details: dict | None = None,
    ) -> None:
        now_ms = int(time.time() * 1000)
        try:
            with self.transaction() as database:
                event_id = self._insert_device_event(
                    database, mailbox, actor, action, direction, message_id,
                    message_type, result, details, event_at=now_ms,
                )
        except sqlite3.Error:
            LOG.exception("device_event_write_failed action=%s mailbox=%s", action, mailbox[:12])
            return
        self._log_device_event(event_id, mailbox, actor, action, direction, message_id, message_type, result)
        self._prune_device_events_if_due(now_ms)

    def record_received(self, mailbox: str, direction: str, messages: list[dict], actor: dict) -> None:
        if not messages:
            return
        now_ms = int(time.time() * 1000)
        logged: list[tuple] = []
        with self.transaction() as database:
            for message in messages:
                message_id = str(message.get("messageId") or "")
                if not message_id:
                    continue
                message_type = self._event_message_type(message.get("envelope"))
                device_id = str(actor.get("device_id") or "unknown")[:64]
                role = str(actor.get("role") or "unknown")[:16]
                # Multiple HTTP workers can return the same unacknowledged message to
                # concurrent polls from one device. Make the first-observation claim
                # atomic instead of SELECT-then-INSERT, which races on the composite PK.
                inserted = database.execute(
                    """INSERT OR IGNORE INTO relay_deliveries(
                        mailbox_id, direction, message_id, device_id, role,
                        first_delivered_at, last_delivered_at, delivery_count, last_event_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                    (mailbox, direction, message_id, device_id, role, now_ms, now_ms, 1, now_ms),
                ).rowcount == 1
                if inserted:
                    count = 1
                    event_action = "receive"
                else:
                    existing = database.execute(
                        """SELECT delivery_count, last_event_at FROM relay_deliveries
                           WHERE mailbox_id=? AND direction=? AND message_id=? AND device_id=?""",
                        (mailbox, direction, message_id, device_id),
                    ).fetchone()
                    if existing is None:
                        raise sqlite3.IntegrityError("delivery_observation_missing_after_conflict")
                    count = int(existing[0]) + 1
                    should_log_retry = now_ms - int(existing[1]) >= 30_000
                    event_action = "receive_retry" if should_log_retry else ""
                    database.execute(
                        """UPDATE relay_deliveries
                           SET role=?, last_delivered_at=?, delivery_count=?,
                               last_event_at=CASE WHEN ? THEN ? ELSE last_event_at END
                           WHERE mailbox_id=? AND direction=? AND message_id=? AND device_id=?""",
                        (role, now_ms, count, int(should_log_retry), now_ms, mailbox, direction, message_id, device_id),
                    )
                if event_action:
                    details = self._event_message_details(message.get("envelope"))
                    details["deliveryCount"] = count
                    event_id = self._insert_device_event(
                        database, mailbox, actor, event_action, direction, message_id,
                        message_type, "served", details, event_at=now_ms,
                    )
                    logged.append((event_id, message_id, message_type, event_action))
        for event_id, message_id, message_type, action in logged:
            self._log_device_event(event_id, mailbox, actor, action, direction, message_id, message_type, "served")
        if logged:
            self._prune_device_events_if_due(now_ms)

    def save_backup(self, mailbox: str, updated_at: int, backup: dict) -> None:
        encoded = json.dumps(backup, separators=(",", ":"), ensure_ascii=True)
        if len(encoded.encode("utf-8")) > 94 * 1024 * 1024:
            raise OverflowError("backup_too_large")
        with self.transaction() as database:
            database.execute(
                """INSERT INTO household_backups(mailbox_id, updated_at, backup_json)
                   VALUES (?, ?, ?)
                   ON CONFLICT(mailbox_id) DO UPDATE SET
                     updated_at=excluded.updated_at, backup_json=excluded.backup_json
                   WHERE excluded.updated_at >= household_backups.updated_at""",
                (mailbox, updated_at, encoded),
            )

    def get_backup(self, mailbox: str) -> tuple[int, dict] | None:
        with self.transaction() as database:
            row = database.execute(
                "SELECT updated_at, backup_json FROM household_backups WHERE mailbox_id=?",
                (mailbox,),
            ).fetchone()
        return (int(row[0]), json.loads(row[1])) if row else None

    def stats_snapshot(self) -> dict:
        now_ms = int(time.time() * 1000)
        # /health is a monitoring endpoint: keep it read-only. Expired rows are
        # removed by normal mailbox operations; health only counts unexpired rows.
        with self.transaction() as database:
            total = database.execute(
                "SELECT COUNT(*) FROM relay_messages WHERE expires_at > ?", (now_ms,)
            ).fetchone()[0]
            mailboxes = database.execute(
                "SELECT COUNT(DISTINCT mailbox_id) FROM relay_messages WHERE expires_at > ?",
                (now_ms,),
            ).fetchone()[0]
            oldest = database.execute(
                "SELECT MIN(created_at) FROM relay_messages WHERE expires_at > ?", (now_ms,)
            ).fetchone()[0]
            archived = database.execute("SELECT COUNT(*) FROM relay_archive").fetchone()[0]
        return {
            "pendingMessages": int(total),
            "activeMailboxes": int(mailboxes),
            "oldestPendingAt": oldest,
            "archivedMessages": int(archived),
        }

    def table_byte_estimates(self) -> dict:
        """Approximate payload size per table (SQLite length of text/blob columns)."""
        now_ms = int(time.time() * 1000)
        with self.transaction() as database:
            pending_bytes = database.execute(
                "SELECT COALESCE(SUM(length(envelope_json)),0) FROM relay_messages WHERE expires_at > ?",
                (now_ms,),
            ).fetchone()[0]
            archive_bytes = database.execute(
                "SELECT COALESCE(SUM(length(envelope_json)),0) FROM relay_archive"
            ).fetchone()[0]
            backup_bytes = database.execute(
                "SELECT COALESCE(SUM(length(backup_json)),0) FROM household_backups"
            ).fetchone()[0]
            token_rows = database.execute("SELECT COUNT(*) FROM push_tokens").fetchone()[0]
            archive_rows = database.execute("SELECT COUNT(*) FROM relay_archive").fetchone()[0]
            pending_rows = database.execute(
                "SELECT COUNT(*) FROM relay_messages WHERE expires_at > ?", (now_ms,)
            ).fetchone()[0]
        file_bytes = 0
        try:
            if os.path.isfile(self.path):
                file_bytes = os.path.getsize(self.path)
        except OSError:
            pass
        return {
            "fileBytes": int(file_bytes),
            "pendingRows": int(pending_rows),
            "pendingEnvelopeBytes": int(pending_bytes or 0),
            "archiveRows": int(archive_rows),
            "archiveEnvelopeBytes": int(archive_bytes or 0),
            "backupEnvelopeBytes": int(backup_bytes or 0),
            "pushTokenRows": int(token_rows),
        }

    def prune_archive(self, retention_days: int | None = None, max_rows: int | None = None) -> dict:
        """Optional explicit delete. Default retention 0 = do nothing (keep all history)."""
        days = ARCHIVE_RETENTION_DAYS if retention_days is None else int(retention_days)
        max_rows_cfg = ARCHIVE_MAX_ROWS if max_rows is None else int(max_rows)
        deleted_age = 0
        deleted_cap = 0
        if days > 0:
            cutoff = int(time.time() * 1000) - days * 24 * 60 * 60 * 1000
            with self.transaction() as database:
                cur = database.execute(
                    "DELETE FROM relay_archive WHERE archived_at < ?",
                    (cutoff,),
                )
                deleted_age = int(cur.rowcount or 0)
        if max_rows_cfg > 0:
            with self.transaction() as database:
                row = database.execute("SELECT COUNT(*) FROM relay_archive").fetchone()
                total = int(row[0] if row else 0)
                if total > max_rows_cfg:
                    overflow = total - max_rows_cfg
                    cur2 = database.execute(
                        """
                        DELETE FROM relay_archive WHERE archive_id IN (
                            SELECT archive_id FROM relay_archive
                            ORDER BY archived_at ASC LIMIT ?
                        )
                        """,
                        (overflow,),
                    )
                    deleted_cap = int(cur2.rowcount or 0)
        LOG.info(
            "archive_prune retention_days=%s deleted_age=%s max_rows=%s deleted_cap=%s",
            days, deleted_age, max_rows_cfg, deleted_cap,
        )
        return {
            "deletedByAge": deleted_age,
            "deletedByCap": deleted_cap,
            "retentionDays": days,
            "maxRows": max_rows_cfg,
            "note": "default is keep-all; pass days>0 only if you intentionally want deletion",
        }

    def slim_existing_archive(self, batch_size: int = 200) -> dict:
        """Rewrite fat archive rows in place: keep every row, strip Base64/huge payloads.

        Does NOT delete any archive_id. After this, call vacuum() to reclaim disk file size.
        """
        scanned = 0
        updated = 0
        saved_chars = 0
        batch_size = max(20, min(int(batch_size), 500))
        last_id = 0
        while True:
            with self.transaction() as database:
                rows = database.execute(
                    """
                    SELECT archive_id, envelope_json FROM relay_archive
                    WHERE archive_id > ?
                    ORDER BY archive_id ASC
                    LIMIT ?
                    """,
                    (last_id, batch_size),
                ).fetchall()
            if not rows:
                break
            for archive_id, envelope_json in rows:
                scanned += 1
                last_id = int(archive_id)
                if not envelope_json:
                    continue
                original_len = len(envelope_json)
                # Skip already-slim rows
                if original_len < 2_000 and (
                    '"dataOmitted"' in envelope_json
                    or '"omitted":true' in envelope_json
                    or '"omitted": true' in envelope_json
                ):
                    continue
                # Only rewrite if it looks heavy (Base64-ish or large)
                if original_len < 4_000 and '"data"' not in envelope_json and '"content"' not in envelope_json:
                    continue
                try:
                    envelope = json.loads(envelope_json)
                except Exception:  # noqa: BLE001
                    continue
                slim = archive_envelope_json(envelope if isinstance(envelope, dict) else {})
                if len(slim) >= original_len:
                    continue
                with self.transaction() as database:
                    database.execute(
                        "UPDATE relay_archive SET envelope_json=? WHERE archive_id=?",
                        (slim, archive_id),
                    )
                updated += 1
                saved_chars += original_len - len(slim)
            if len(rows) < batch_size:
                break
        LOG.info(
            "archive_slim scanned=%s updated=%s saved_chars=%s",
            scanned, updated, saved_chars,
        )
        return {
            "scanned": scanned,
            "updated": updated,
            "savedChars": saved_chars,
            "savedBytesApprox": saved_chars,
            "deleted": 0,
            "note": "all rows kept; only bulky payloads compacted",
        }

    def dedupe_pending(self, mailbox: str = "", direction: str = "") -> dict:
        """Keep one newest row per identical envelope body; delete the rest.

        Solves sync-storm duplicates (same ~150KB incremental_exchange repeated every few seconds).
        """
        where = ["1=1"]
        args: list = []
        if mailbox:
            where.append("mailbox_id LIKE ?")
            args.append(f"{mailbox}%")
        if direction in ("to-host", "to-companion"):
            where.append("direction = ?")
            args.append(direction)
        clause = " AND ".join(where)
        kept = 0
        deleted = 0
        with self.transaction() as database:
            rows = database.execute(
                f"""
                SELECT mailbox_id, direction, message_id, created_at, envelope_json
                FROM relay_messages
                WHERE {clause}
                ORDER BY created_at DESC
                """,
                args,
            ).fetchall()
            seen: set[tuple] = set()
            drop_ids: list[tuple] = []
            for mailbox_id, direction_row, message_id, created_at, envelope_json in rows:
                key = (mailbox_id, direction_row, envelope_json)
                if key in seen:
                    drop_ids.append((mailbox_id, direction_row, message_id))
                else:
                    seen.add(key)
                    kept += 1
            for mailbox_id, direction_row, message_id in drop_ids:
                database.execute(
                    """
                    DELETE FROM relay_messages
                    WHERE mailbox_id=? AND direction=? AND message_id=?
                    """,
                    (mailbox_id, direction_row, message_id),
                )
                deleted += 1
        LOG.info("dedupe_pending kept=%s deleted=%s dir=%s", kept, deleted, direction or "all")
        return {"kept": kept, "deleted": deleted, "direction": direction or "all"}

    def purge_ephemeral_stored(self) -> dict:
        """Delete historically stored ephemeral traffic (heart pulses, live location, pure ACKs).

        Durable content (memories, messages, plans, finance, …) is kept.
        """
        deleted_archive = 0
        deleted_pending = 0
        scanned_archive = 0
        batch = 300
        last_id = 0
        while True:
            with self.transaction() as database:
                rows = database.execute(
                    """
                    SELECT archive_id, envelope_json FROM relay_archive
                    WHERE archive_id > ?
                    ORDER BY archive_id ASC
                    LIMIT ?
                    """,
                    (last_id, batch),
                ).fetchall()
            if not rows:
                break
            drop_ids: list[int] = []
            for archive_id, envelope_json in rows:
                scanned_archive += 1
                last_id = int(archive_id)
                try:
                    env = json.loads(envelope_json) if envelope_json else {}
                except Exception:  # noqa: BLE001
                    continue
                if is_ephemeral_envelope(env if isinstance(env, dict) else {}):
                    drop_ids.append(int(archive_id))
            if drop_ids:
                with self.transaction() as database:
                    database.executemany(
                        "DELETE FROM relay_archive WHERE archive_id=?",
                        [(i,) for i in drop_ids],
                    )
                deleted_archive += len(drop_ids)
            if len(rows) < batch:
                break

        # Pending queue: drop pure ephemeral rows (heart/location) so they do not block capacity
        with self.transaction() as database:
            rows = database.execute(
                "SELECT mailbox_id, direction, message_id, envelope_json FROM relay_messages"
            ).fetchall()
            for mailbox_id, direction, message_id, envelope_json in rows:
                try:
                    env = json.loads(envelope_json) if envelope_json else {}
                except Exception:  # noqa: BLE001
                    continue
                if is_ephemeral_envelope(env if isinstance(env, dict) else {}):
                    database.execute(
                        """
                        DELETE FROM relay_messages
                        WHERE mailbox_id=? AND direction=? AND message_id=?
                        """,
                        (mailbox_id, direction, message_id),
                    )
                    deleted_pending += 1

        LOG.info(
            "purge_ephemeral scanned_archive=%s deleted_archive=%s deleted_pending=%s",
            scanned_archive, deleted_archive, deleted_pending,
        )
        return {
            "scannedArchive": scanned_archive,
            "deletedArchive": deleted_archive,
            "deletedPending": deleted_pending,
        }

    def vacuum(self, purge_ephemeral: bool = True) -> dict:
        """Optionally purge old ephemeral rows, then reclaim disk space with VACUUM."""
        purge_result: dict = {}
        if purge_ephemeral:
            try:
                purge_result = self.purge_ephemeral_stored()
            except Exception as exc:  # noqa: BLE001
                LOG.warning("purge_ephemeral before vacuum failed: %s", exc)
                purge_result = {"error": str(exc)}
            try:
                # Also drop expired delivery rows
                now_ms = int(time.time() * 1000)
                with self.transaction() as database:
                    cur = database.execute(
                        "DELETE FROM relay_messages WHERE expires_at <= ?",
                        (now_ms,),
                    )
                    purge_result["deletedExpired"] = int(cur.rowcount or 0)
            except Exception as exc:  # noqa: BLE001
                LOG.warning("purge expired before vacuum failed: %s", exc)

        before = 0
        try:
            if os.path.isfile(self.path):
                before = os.path.getsize(self.path)
        except OSError:
            pass
        connection = self.connect()
        try:
            connection.execute("VACUUM")
            connection.commit()
        finally:
            connection.close()
        after = 0
        try:
            if os.path.isfile(self.path):
                after = os.path.getsize(self.path)
        except OSError:
            pass
        LOG.info("vacuum before=%s after=%s freed=%s purge=%s", before, after, max(0, before - after), purge_result)
        return {
            "beforeBytes": before,
            "afterBytes": after,
            "freedBytes": max(0, before - after),
            "ephemeralPurge": purge_result,
        }

    def save_push_token(self, mailbox: str, token: str, platform: str = "android") -> None:
        now_ms = int(time.time() * 1000)
        with self.transaction() as database:
            database.execute(
                """
                INSERT INTO push_tokens(mailbox_id, token, platform, updated_at)
                VALUES (?, ?, ?, ?)
                ON CONFLICT(mailbox_id, token) DO UPDATE SET
                    platform=excluded.platform,
                    updated_at=excluded.updated_at
                """,
                (mailbox, token, platform[:32], now_ms),
            )

    def delete_push_token(self, mailbox: str, token: str) -> None:
        with self.transaction() as database:
            database.execute(
                "DELETE FROM push_tokens WHERE mailbox_id=? AND token=?",
                (mailbox, token),
            )

    def list_push_tokens(self, mailbox: str) -> list[str]:
        with self.transaction() as database:
            rows = database.execute(
                "SELECT token FROM push_tokens WHERE mailbox_id=? ORDER BY updated_at DESC LIMIT 20",
                (mailbox,),
            ).fetchall()
        return [r[0] for r in rows]

    def publish(self, mailbox: str, direction: str, message: dict) -> bool:

        # Store photo/file bytes on disk; keep SQLite JSON lean (sha256 reference only).
        envelope_obj = message.get("envelope") or {}
        if BLOB_STORE is not None and isinstance(envelope_obj, dict):
            envelope_obj = blob_store_mod.extract_and_store_chunk_blobs(BLOB_STORE, envelope_obj)
            message = dict(message)
            message["envelope"] = envelope_obj
        envelope_json = json.dumps(message["envelope"], separators=(",", ":"), ensure_ascii=True)
        now_ms = int(time.time() * 1000)
        # Shorten delivery window for pure ephemeral signals (heart / live location).
        env_obj = message.get("envelope") if isinstance(message.get("envelope"), dict) else {}
        if is_ephemeral_envelope(env_obj):
            max_exp = now_ms + EPHEMERAL_MAX_TTL_MS
            if int(message.get("expiresAt") or 0) > max_exp:
                message = dict(message)
                message["expiresAt"] = max_exp
        with self.transaction() as database:
            database.execute("DELETE FROM relay_messages WHERE expires_at <= ?", (now_ms,))
            existing = database.execute(
                """
                SELECT correlation_id, created_at, expires_at, envelope_json
                FROM relay_messages
                WHERE mailbox_id=? AND direction=? AND message_id=?
                """,
                (mailbox, direction, message["messageId"]),
            ).fetchone()
            if existing is not None:
                same = (
                    (existing[0] == message.get("correlationId"))
                    and existing[1] == message["createdAt"]
                    and existing[2] == message["expiresAt"]
                    and existing[3] == envelope_json
                )
                if same:
                    return False
                # Same transport id, updated body (e.g. newer acknowledgement list).
                # Replace in place so retries do not fail with message_conflict or multiply rows.
                database.execute(
                    """DELETE FROM relay_deliveries
                       WHERE mailbox_id=? AND direction=? AND message_id=?""",
                    (mailbox, direction, message["messageId"]),
                )
                database.execute(
                    """
                    UPDATE relay_messages
                    SET correlation_id=?, created_at=?, expires_at=?, envelope_json=?
                    WHERE mailbox_id=? AND direction=? AND message_id=?
                    """,
                    (
                        message.get("correlationId"),
                        message["createdAt"],
                        message["expiresAt"],
                        envelope_json,
                        mailbox,
                        direction,
                        message["messageId"],
                    ),
                )
                LOG.info(
                    "publish_replace mailbox=%s dir=%s id=%s bytes=%s",
                    mailbox[:12], direction, str(message["messageId"])[:12], len(envelope_json),
                )
                return True
            # Dedup first: same body already waiting → do not grow the queue.
            dup = database.execute(
                """
                SELECT message_id FROM relay_messages
                WHERE mailbox_id=? AND direction=? AND envelope_json=?
                LIMIT 1
                """,
                (mailbox, direction, envelope_json),
            ).fetchone()
            if dup is not None:
                LOG.info(
                    "publish_dedup mailbox=%s dir=%s existing=%s bytes=%s",
                    mailbox[:12], direction, str(dup[0])[:12], len(envelope_json),
                )
                return False

            total = database.execute("SELECT COUNT(*) FROM relay_messages").fetchone()[0]
            per = database.execute(
                "SELECT COUNT(*) FROM relay_messages WHERE mailbox_id=?",
                (mailbox,),
            ).fetchone()[0]
            # Never evict an unacknowledged delivery to make room. The mailbox is the
            # durable hand-off between devices; deleting its oldest row here can silently
            # lose user data when a peer is offline. Apply back-pressure instead and let
            # the sender retry after the receiver acknowledges existing messages.
            if total >= MAX_TOTAL_MESSAGES or per >= MAX_MESSAGES_PER_MAILBOX:
                LOG.warning(
                    "mailbox_full mailbox=%s total=%s per_mailbox=%s",
                    mailbox[:12], total, per,
                )
                raise OverflowError("mailbox_full")
            database.execute(
                """
                INSERT INTO relay_messages(
                    mailbox_id, direction, message_id, correlation_id,
                    created_at, expires_at, envelope_json
                ) VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    mailbox,
                    direction,
                    message["messageId"],
                    message["correlationId"],
                    message["createdAt"],
                    message["expiresAt"],
                    envelope_json,
                ),
            )
            # Selective archive: durable content (memories, chat, plans, …) only.
            # Typing, heart pulses, and live location stay in the delivery queue with a short TTL.
            env_for_policy = message.get("envelope") or {}
            if should_archive_envelope(env_for_policy if isinstance(env_for_policy, dict) else {}):
                archive_json = archive_envelope_json(
                    env_for_policy if isinstance(env_for_policy, dict) else {}
                )
                database.execute(
                    """
                    INSERT OR IGNORE INTO relay_archive(
                        mailbox_id, direction, message_id, correlation_id,
                        created_at, expires_at, archived_at, envelope_json
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        mailbox,
                        direction,
                        message["messageId"],
                        message.get("correlationId"),
                        message["createdAt"],
                        message["expiresAt"],
                        now_ms,
                        archive_json,
                    ),
                )
        notify_waiters(mailbox, direction)
        with ACTIVE_LOCK:
            ACTIVE_MAILBOXES.add(mailbox)
        with STATS_LOCK:
            STATS["publish"] += 1
        LOG.info("publish mailbox=%s dir=%s id=%s", mailbox[:12], direction, message["messageId"][:12])
        return True

    def receive(self, mailbox: str, direction: str, limit: int) -> list[dict]:
        now_ms = int(time.time() * 1000)
        with self.transaction() as database:
            database.execute("DELETE FROM relay_messages WHERE expires_at <= ?", (now_ms,))
            rows = database.execute(
                """
                SELECT message_id, correlation_id, created_at, expires_at, envelope_json
                FROM relay_messages
                WHERE mailbox_id=? AND direction=?
                ORDER BY created_at ASC
                LIMIT ?
                """,
                (mailbox, direction, limit),
            ).fetchall()
        suffix = direction.replace("-", "_")
        with STATS_LOCK:
            STATS["receive"] += 1
            receive_key = f"receive_{suffix}"
            messages_key = f"receive_messages_{suffix}"
            STATS[receive_key] = STATS.get(receive_key, 0) + 1
            STATS[messages_key] = STATS.get(messages_key, 0) + len(rows)
        result = []
        for row in rows:
            env = json.loads(row[4])
            if BLOB_STORE is not None:
                env = blob_store_mod.rehydrate_chunk_blobs(BLOB_STORE, env)
            result.append(
                {
                    "messageId": row[0],
                    "correlationId": row[1],
                    "createdAt": row[2],
                    "expiresAt": row[3],
                    "envelope": env,
                }
            )
        # Empty long-poll requests are deliberately not logged at INFO (they are frequent).
        # A non-empty receive is the decisive signal when diagnosing a missing ACK.
        if result:
            LOG.info("receive mailbox=%s dir=%s count=%s", mailbox[:12], direction, len(result))
        return result

    def has_pending(self, mailbox: str, direction: str) -> bool:
        now_ms = int(time.time() * 1000)
        with self.transaction() as database:
            database.execute("DELETE FROM relay_messages WHERE expires_at <= ?", (now_ms,))
            row = database.execute(
                "SELECT 1 FROM relay_messages WHERE mailbox_id=? AND direction=? LIMIT 1",
                (mailbox, direction),
            ).fetchone()
        return row is not None

    def acknowledge(
        self,
        mailbox: str,
        direction: str,
        message_ids: list[str],
        actor: dict | None = None,
    ) -> int:
        if not message_ids:
            return 0
        unique_ids = list(dict.fromkeys(message_ids))
        placeholders = ",".join("?" * len(unique_ids))
        logged: list[tuple] = []
        now_ms = int(time.time() * 1000)
        with self.transaction() as database:
            rows = []
            if actor is not None:
                rows = database.execute(
                    f"""SELECT message_id, envelope_json FROM relay_messages
                        WHERE mailbox_id=? AND direction=? AND message_id IN ({placeholders})""",
                    (mailbox, direction, *unique_ids),
                ).fetchall()
            cursor = database.execute(
                f"""
                DELETE FROM relay_messages
                WHERE mailbox_id=? AND direction=? AND message_id IN ({placeholders})
                """,
                (mailbox, direction, *unique_ids),
            )
            deleted = int(cursor.rowcount or 0)
            database.execute(
                f"""DELETE FROM relay_deliveries
                    WHERE mailbox_id=? AND direction=? AND message_id IN ({placeholders})""",
                (mailbox, direction, *unique_ids),
            )
            if actor is not None and rows:
                for message_id, envelope_json in rows:
                    message_type = self._event_message_type(envelope_json)
                    details = self._event_message_details(envelope_json)
                    details["acknowledged"] = True
                    event_id = self._insert_device_event(
                        database, mailbox, actor, "ack", direction, message_id,
                        message_type, "acknowledged", details, event_at=now_ms,
                    )
                    logged.append((event_id, message_id, message_type, "acknowledged"))
            elif actor is not None:
                event_id = self._insert_device_event(
                    database, mailbox, actor, "ack", direction, "", "", "no_pending_match",
                    {"requested": len(unique_ids), "deleted": 0}, event_at=now_ms,
                )
                logged.append((event_id, "", "", "no_pending_match"))
        suffix = direction.replace("-", "_")
        with STATS_LOCK:
            STATS["ack"] += 1
            ack_key = f"ack_{suffix}"
            deleted_key = f"ack_deleted_{suffix}"
            STATS[ack_key] = STATS.get(ack_key, 0) + 1
            STATS[deleted_key] = STATS.get(deleted_key, 0) + deleted
        LOG.info("ack mailbox=%s dir=%s count=%s", mailbox[:12], direction, deleted)
        if actor is not None:
            for event_id, message_id, message_type, result in logged:
                self._log_device_event(event_id, mailbox, actor, "ack", direction, message_id, message_type, result)
            self._prune_device_events_if_due(now_ms)
        return deleted


class RelayHandler(BaseHTTPRequestHandler):
    server_version = "OurSpaceRelay/2"
    sys_version = ""
    protocol_version = "HTTP/1.1"
    close_connection = True

    @property
    def store(self) -> RelayStore:
        return self.server.store  # type: ignore[attr-defined]

    @property
    def limiter(self) -> RateLimiter:
        return self.server.limiter  # type: ignore[attr-defined]

    def log_message(self, fmt: str, *args: object) -> None:
        # Access log without tokens/bodies
        LOG.debug("http %s", fmt % args)

    def _device_actor(self, mailbox: str, direction: str = "", resource: str = "") -> dict:
        raw_id = (self.headers.get("X-OurSpace-Device-Id") or "").strip().lower()
        identified = bool(DEVICE_ID_RE.fullmatch(raw_id))
        role = (self.headers.get("X-OurSpace-Device-Role") or "").strip().lower()
        if role not in ("host", "companion"):
            role = _infer_device_role(self.command, direction, resource)
        device_id = raw_id if identified else (f"legacy-{role}" if role in ("host", "companion") else "unknown")
        return {
            "device_id": device_id,
            "role": role or "unknown",
            "identified": identified,
            "label": f"{role or 'unknown'}:{device_id[:8]}",
        }

    def _record_device_event(
        self,
        mailbox: str,
        actor: dict,
        action: str,
        direction: str = "",
        message_id: str = "",
        message_type: str = "",
        result: str = "",
        details: dict | None = None,
    ) -> None:
        _touch_device_presence(mailbox, actor, action=action, channel="http")
        self.store.record_device_event(
            mailbox, actor, action, direction, message_id, message_type, result, details
        )

    def backup_mailbox(self) -> str | None:
        authorization = self.headers.get("Authorization", "")
        if not authorization.startswith("Bearer "):
            self.send_error_json(HTTPStatus.UNAUTHORIZED, "unauthorized")
            return None
        token = authorization[7:]
        if not TOKEN_RE.fullmatch(token):
            self.send_error_json(HTTPStatus.UNAUTHORIZED, "unauthorized")
            return None
        if HOUSEHOLD_TOKEN is not None and HOUSEHOLD_MAILBOX is not None:
            if not hmac.compare_digest(token, HOUSEHOLD_TOKEN):
                self.send_error_json(HTTPStatus.UNAUTHORIZED, "unauthorized")
                return None
            mailbox = HOUSEHOLD_MAILBOX
        else:
            mailbox = mailbox_for_token(token)
        if not self.limiter.allow(mailbox):
            self.send_error_json(HTTPStatus.TOO_MANY_REQUESTS, "rate_limited")
            return None
        self._relay_actor = self._device_actor(mailbox, "", "backup")
        _touch_device_presence(mailbox, self._relay_actor, channel="http")
        return mailbox

    def _mailbox_from_auth(self) -> str | None:
        authorization = self.headers.get("Authorization", "")
        if not authorization.startswith("Bearer "):
            self.send_error_json(HTTPStatus.UNAUTHORIZED, "unauthorized")
            return None
        token = authorization[7:].strip()
        if not TOKEN_RE.fullmatch(token):
            self.send_error_json(HTTPStatus.UNAUTHORIZED, "unauthorized")
            return None
        if HOUSEHOLD_TOKEN is not None and not hmac.compare_digest(token, HOUSEHOLD_TOKEN):
            self.send_error_json(HTTPStatus.UNAUTHORIZED, "unauthorized")
            return None
        return HOUSEHOLD_MAILBOX if HOUSEHOLD_MAILBOX is not None else mailbox_for_token(token)

    def handle_push_token_register(self, parsed) -> None:
        mailbox = self._mailbox_from_auth()
        if mailbox is None:
            return
        actor = self._device_actor(mailbox, "", "push_tokens")
        self._relay_actor = actor
        _touch_device_presence(mailbox, actor, channel="http")
        try:
            payload = self.read_json()
            token = str(payload.get("token") or "").strip()
            platform = str(payload.get("platform") or "android").strip() or "android"
            if len(token) < 20 or len(token) > 4096:
                raise ValueError("invalid_token")
            self.store.save_push_token(mailbox, token, platform)
            with ACTIVE_LOCK:
                ACTIVE_MAILBOXES.add(mailbox)
            self._record_device_event(mailbox, actor, "push_token_register", result="stored", details={"platform": platform[:32]})
            self.send_json(HTTPStatus.OK, {"ok": True, "stored": True})
            LOG.info("push token registered mailbox=%s…", mailbox[:12])
        except ValueError as exc:
            self.send_error_json(HTTPStatus.BAD_REQUEST, str(exc))
        except Exception as exc:  # noqa: BLE001
            LOG.exception("push token register failed")
            self.send_error_json(HTTPStatus.INTERNAL_SERVER_ERROR, "error")

    def handle_push_token_delete(self, parsed) -> None:
        mailbox = self._mailbox_from_auth()
        if mailbox is None:
            return
        actor = self._device_actor(mailbox, "", "push_tokens")
        self._relay_actor = actor
        _touch_device_presence(mailbox, actor, channel="http")
        try:
            payload = self.read_json()
            token = str(payload.get("token") or "").strip()
            if token:
                self.store.delete_push_token(mailbox, token)
            self._record_device_event(mailbox, actor, "push_token_delete", result="ok", details={"tokenProvided": bool(token)})
            self.send_json(HTTPStatus.OK, {"ok": True})
        except Exception as exc:  # noqa: BLE001
            self.send_error_json(HTTPStatus.BAD_REQUEST, "invalid")

    def handle_websocket_push(self, parsed) -> None:

        """Upgrade to WebSocket and stream mail-wake events for the household mailbox."""
        upgrade = (self.headers.get("Upgrade") or "").lower()
        connection = (self.headers.get("Connection") or "").lower()
        sec_key = self.headers.get("Sec-WebSocket-Key")
        sec_version = (self.headers.get("Sec-WebSocket-Version") or "").strip()
        if upgrade != "websocket" or "upgrade" not in connection or not sec_key:
            self.send_error_json(
                HTTPStatus.BAD_REQUEST,
                "websocket_upgrade_required",
                detail="Connect with Upgrade: websocket to /v1/push",
            )
            return
        if sec_version and sec_version != "13":
            self.send_error_json(HTTPStatus.BAD_REQUEST, "unsupported_websocket_version")
            return
        # Prefer Authorization header so household token is not written into access logs.
        # Query ?token= remains supported for simple debug clients.
        query = parse_qs(parsed.query, keep_blank_values=False)
        token = ""
        auth = self.headers.get("Authorization") or ""
        if auth.lower().startswith("bearer "):
            token = auth[7:].strip()
        if not token:
            token = (query.get("token") or [""])[0].strip()
        if not token or not TOKEN_RE.fullmatch(token):
            self.send_error_json(HTTPStatus.UNAUTHORIZED, "unauthorized")
            return
        if HOUSEHOLD_TOKEN is not None and not hmac.compare_digest(token, HOUSEHOLD_TOKEN):
            self.send_error_json(HTTPStatus.UNAUTHORIZED, "unauthorized")
            return
        mailbox = HOUSEHOLD_MAILBOX if HOUSEHOLD_MAILBOX is not None else mailbox_for_token(token)
        if HOUSEHOLD_MAILBOX is not None and mailbox != HOUSEHOLD_MAILBOX:
            self.send_error_json(HTTPStatus.UNAUTHORIZED, "unauthorized")
            return
        if not self.limiter.allow(mailbox):
            self.send_error_json(HTTPStatus.TOO_MANY_REQUESTS, "rate_limited")
            return
        with ACTIVE_LOCK:
            ACTIVE_MAILBOXES.add(mailbox)
        actor = self._device_actor(mailbox, "", "push")
        self._relay_actor = actor
        _touch_device_presence(mailbox, actor, action="websocket_connected", channel="websocket", websocket_delta=1)
        self.store.record_device_event(mailbox, actor, "websocket_connected", result="connected")
        with STATS_LOCK:
            STATS["ws_connections"] = STATS.get("ws_connections", 0) + 1
        # Takes over the socket until disconnect (blocks this worker thread).
        try:
            ws_hub.handle_websocket(
                self, mailbox, sec_key, token_ok=True,
                device_id=actor["device_id"], role=actor["role"], identified=actor["identified"],
            )
        finally:
            _touch_device_presence(mailbox, actor, action="websocket_disconnected", channel="websocket", websocket_delta=-1)
            self.store.record_device_event(mailbox, actor, "websocket_disconnected", result="closed")

    def handle_backup_get(self) -> None:

        mailbox = self.backup_mailbox()
        if mailbox is None:
            return
        item = self.store.get_backup(mailbox)
        actor = getattr(self, "_relay_actor", self._device_actor(mailbox, "", "backup"))
        if item is None:
            self._record_device_event(mailbox, actor, "backup_download", result="not_found")
            self.send_error_json(HTTPStatus.NOT_FOUND, "backup_not_found")
            return
        updated_at, backup = item
        self._record_device_event(mailbox, actor, "backup_download", result="ok", details={"updatedAt": updated_at})
        self.send_json(HTTPStatus.OK, {"updatedAt": updated_at, "backup": backup})

    def handle_backup_post(self) -> None:
        mailbox = self.backup_mailbox()
        if mailbox is None:
            return
        try:
            payload = self.read_json()
            if set(payload) != {"updatedAt", "backup"}:
                raise ValueError("invalid_backup_fields")
            updated_at = payload["updatedAt"]
            backup = payload["backup"]
            if not isinstance(updated_at, int) or isinstance(updated_at, bool) or updated_at <= 0:
                raise ValueError("invalid_backup_timestamp")
            if not isinstance(backup, dict) or set(backup) != {"v", "nonce", "ciphertext"}:
                raise ValueError("invalid_backup_envelope")
            if backup.get("v") != 1 or not isinstance(backup.get("nonce"), str) or not isinstance(backup.get("ciphertext"), str):
                raise ValueError("invalid_backup_envelope")
            if len(backup["nonce"]) > 64 or len(backup["ciphertext"]) > 92 * 1024 * 1024:
                raise OverflowError("backup_too_large")
            self.store.save_backup(mailbox, updated_at, backup)
            actor = getattr(self, "_relay_actor", self._device_actor(mailbox, "", "backup"))
            self._record_device_event(
                mailbox, actor, "backup_upload", result="stored",
                details={"updatedAt": updated_at, "ciphertextChars": len(backup.get("ciphertext") or "")},
            )
            self.send_json(HTTPStatus.OK, {"stored": True, "updatedAt": updated_at})
        except OverflowError as exc:
            self.send_error_json(HTTPStatus.REQUEST_ENTITY_TOO_LARGE, str(exc))
        except (ValueError, json.JSONDecodeError) as exc:
            self.send_error_json(HTTPStatus.BAD_REQUEST, str(exc))
        except Exception:
            LOG.exception("backup_store_failed")
            self.send_error_json(HTTPStatus.INTERNAL_SERVER_ERROR, "backup_store_failed")


    def _admin_authorized(self) -> bool:
        """Accept household token or OURSPACE_ADMIN_TOKEN."""
        authorization = self.headers.get("Authorization", "")
        token = ""
        if authorization.startswith("Bearer "):
            token = authorization[7:].strip()
        if not token:
            # Allow query token for first HTML load convenience is disabled; JSON only uses Bearer
            qs = parse_qs(urlsplit(self.path).query)
            token = (qs.get("token") or [""])[0].strip()
        if not token or not TOKEN_RE.fullmatch(token):
            return False
        admin_env = (os.environ.get("OURSPACE_ADMIN_TOKEN") or "").strip()
        if admin_env and hmac.compare_digest(token, admin_env):
            return True
        if HOUSEHOLD_TOKEN is not None and hmac.compare_digest(token, HOUSEHOLD_TOKEN):
            return True
        return False


    def handle_blob_api(self, parsed) -> None:
        """Binary photo/file API: PUT/GET /v1/mailboxes/{id}/blobs/{sha256}"""
        parts = [p for p in parsed.path.split("/") if p]
        # v1 mailboxes {mb} blobs {sha}
        if len(parts) != 5 or parts[0] != "v1" or parts[1] != "mailboxes" or parts[3] != "blobs":
            self.send_error_json(HTTPStatus.NOT_FOUND, "not_found")
            return
        mailbox = parts[2]
        sha = parts[4].lower().strip()
        if not re.fullmatch(r"[a-f0-9]{64}", sha):
            self.send_error_json(HTTPStatus.BAD_REQUEST, "invalid_sha256")
            return
        if not MAILBOX_RE.fullmatch(mailbox):
            self.send_error_json(HTTPStatus.BAD_REQUEST, "invalid_mailbox")
            return
        auth_mb = self._mailbox_from_auth()
        if auth_mb is None:
            return
        if auth_mb != mailbox and not (HOUSEHOLD_MAILBOX and mailbox == HOUSEHOLD_MAILBOX):
            # household mode: single mailbox
            if HOUSEHOLD_MAILBOX is not None and auth_mb == HOUSEHOLD_MAILBOX:
                pass
            else:
                self.send_error_json(HTTPStatus.FORBIDDEN, "forbidden")
                return
        actor = self._device_actor(mailbox, "", "blobs")
        self._relay_actor = actor
        _touch_device_presence(mailbox, actor, channel="http")
        if BLOB_STORE is None:
            self.send_error_json(HTTPStatus.SERVICE_UNAVAILABLE, "blobs_unavailable")
            return

        if self.command == "GET":
            data = BLOB_STORE.get(sha)
            if data is None:
                self._record_device_event(mailbox, actor, "blob_download", result="not_found", details={"sha256Prefix": sha[:12]})
                self.send_error_json(HTTPStatus.NOT_FOUND, "blob_not_found")
                return
            meta = BLOB_STORE.meta(sha) or {}
            mime = meta.get("mimeType") or "application/octet-stream"
            self._record_device_event(
                mailbox, actor, "blob_download", result="ok",
                details={"sha256Prefix": sha[:12], "sizeBytes": len(data), "mimeType": str(mime)[:80]},
            )
            self.send_response(HTTPStatus.OK)
            self.send_header("Content-Type", mime)
            self.send_header("Content-Length", str(len(data)))
            self.send_header("X-Content-SHA256", sha)
            self.send_header("Cache-Control", "private, max-age=86400")
            self.end_headers()
            self.wfile.write(data)
            return

        if self.command == "PUT":
            length = int(self.headers.get("Content-Length") or "0")
            if length <= 0 or length > 48 * 1024 * 1024:
                self.send_error_json(HTTPStatus.BAD_REQUEST, "invalid_size")
                return
            body = self.rfile.read(length)
            if len(body) != length:
                self.send_error_json(HTTPStatus.BAD_REQUEST, "truncated_body")
                return
            actual = blob_store_mod.BlobStore.hash_bytes(body)
            if actual != sha:
                self.send_error_json(HTTPStatus.BAD_REQUEST, "sha256_mismatch")
                return
            mime = self.headers.get("Content-Type") or "application/octet-stream"
            name = self.headers.get("X-File-Name") or ""
            stored = BLOB_STORE.put(body, mime_type=mime, file_name=name, source="http_put")
            self._record_device_event(
                mailbox, actor, "blob_upload", result="stored",
                details={"sha256Prefix": str(stored)[:12], "sizeBytes": length, "mimeType": str(mime)[:80]},
            )
            self.send_json(HTTPStatus.OK, {"sha256": stored, "sizeBytes": length, "stored": True})
            return

        self.send_error_json(HTTPStatus.METHOD_NOT_ALLOWED, "method_not_allowed")

    def handle_admin(self, parsed) -> None:
        path = parsed.path.rstrip("/") or "/admin"
        if path in ("/admin", "/admin/"):
            body = admin_ui.admin_html_bytes()
            self.send_response(HTTPStatus.OK)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(body)
            return

        if not path.startswith("/admin/api"):
            self.send_error_json(HTTPStatus.NOT_FOUND, "not_found")
            return

        if not self._admin_authorized():
            with STATS_LOCK:
                STATS["unauthorized"] += 1
            self.send_error_json(HTTPStatus.UNAUTHORIZED, "unauthorized")
            return

        qs = parse_qs(parsed.query)
        try:
            if path == "/admin/api/overview":
                try:
                    snap = self.store.stats_snapshot()
                except (sqlite3.Error, OSError):
                    self.send_json(HTTPStatus.SERVICE_UNAVAILABLE, {"status": "degraded", "error": "database_unavailable"})
                    return
                with STATS_LOCK:
                    counters = dict(STATS)
                with DDNS_LOCK:
                    ddns = dict(DDNS_STATUS)
                body = {
                    "service": "ourspace-relay",
                    "status": "ok",
                    "protocol": 3,
                    "version": 3,
                    "uptimeSec": int(time.monotonic() - START_MONO),
                    "startedAt": START_MS,
                    "pendingMessages": snap["pendingMessages"],
                    "activeMailboxes": snap["activeMailboxes"],
                    "oldestPendingAt": snap["oldestPendingAt"],
                    "archivedMessages": snap["archivedMessages"],
                    "counters": counters,
                    "ddns": ddns,
                    "householdMode": HOUSEHOLD_TOKEN is not None,
                    "householdMailboxPrefix": (HOUSEHOLD_MAILBOX[:12] if HOUSEHOLD_MAILBOX else None),
                    "pairingHint": (
                        "OK_single_pair" if len(ACTIVE_MAILBOXES) <= 1
                        else "WARNING_multiple_mailboxes_means_phones_not_sharing_same_pairing_secret"
                    ),
                    "features": [
                        "durable-mailbox", "permanent-archive", "websocket-push", "fcm-wake",
                        "admin-panel", "admin-db", "admin-logs", "admin-message-types",
                        "admin-message-flow", "device-action-logs",
                    ],
                    "wsConnections": ws_hub.HUB.count(),
                    "fcmConfigured": fcm_server_key() is not None,
                    "directionBreakdown": admin_ui.db_direction_breakdown(self.store),
                    "database": admin_ui.db_table_stats(self.store),
                    "size": {
                        **self.store.table_byte_estimates(),
                        **(BLOB_STORE.stats() if BLOB_STORE is not None else {}),
                    },
                }
                self.send_json(HTTPStatus.OK, body)
                return

            if path == "/admin/api/tables":
                self.send_json(HTTPStatus.OK, admin_ui.db_table_stats(self.store))
                return

            if path == "/admin/api/rows":
                table = (qs.get("table") or ["relay_messages"])[0]
                limit = int((qs.get("limit") or ["50"])[0])
                offset = int((qs.get("offset") or ["0"])[0])
                mailbox = (qs.get("mailbox") or [""])[0]
                direction = (qs.get("direction") or [""])[0]
                q = (qs.get("q") or [""])[0]
                self.send_json(
                    HTTPStatus.OK,
                    admin_ui.db_browse(
                        self.store, table=table, limit=limit, offset=offset,
                        mailbox=mailbox, direction=direction, q=q,
                    ),
                )
                return

            if path == "/admin/api/message":
                table = (qs.get("table") or ["relay_messages"])[0]
                message_id = (qs.get("messageId") or [""])[0]
                mailbox = (qs.get("mailbox") or [""])[0]
                detail = admin_ui.db_message_detail(self.store, table, message_id, mailbox)
                if detail is None:
                    self.send_error_json(HTTPStatus.NOT_FOUND, "not_found")
                    return
                self.send_json(HTTPStatus.OK, detail)
                return

            if path == "/admin/api/message-types":
                report = admin_ui.message_type_report(
                    self.store,
                    mailbox=(qs.get("mailbox") or [""])[0],
                    direction=(qs.get("direction") or [""])[0],
                    recent_limit=int((qs.get("limit") or ["100"])[0]),
                    log_file=RELAY_LOG_PATH,
                )
                with STATS_LOCK:
                    report["serverCounters"] = {
                        "errors": int(STATS.get("errors", 0)),
                        "unauthorized": int(STATS.get("unauthorized", 0)),
                    }
                self.send_json(HTTPStatus.OK, report)
                return

            if path == "/admin/api/message-flow":
                mailbox = (qs.get("mailbox") or [""])[0].strip()
                limit = int((qs.get("limit") or ["100"])[0])
                devices = _device_presence_snapshot(mailbox)
                report = admin_ui.relay_flow_report(
                    self.store,
                    devices=devices,
                    mailbox=mailbox,
                    limit=limit,
                    stuck_after_ms=MESSAGE_STUCK_AFTER_MS,
                )
                self.send_json(HTTPStatus.OK, report)
                return

            if path == "/admin/api/logs":
                limit = int((qs.get("limit") or ["200"])[0])
                level = (qs.get("level") or [""])[0]
                lines = admin_ui.recent_logs(limit=limit, level=level, log_file=RELAY_LOG_PATH)
                self.send_json(HTTPStatus.OK, {"lines": lines, "count": len(lines)})
                return

            # --- Admin maintenance actions (GET or POST; several URL aliases) ---
            action_name = ""
            for prefix in (
                "/admin/api/actions/",
                "/admin/api/action/",
                "/admin/api/",
            ):
                if path.startswith(prefix):
                    action_name = path[len(prefix):].strip("/")
                    break
            # Also accept bare action leaf names
            if not action_name and path.startswith("/admin/api/"):
                action_name = path.rsplit("/", 1)[-1]

            if action_name in {
                "purge-expired", "clear-pending", "dedupe-pending",
                "slim-archive", "prune-archive", "vacuum", "purge-ephemeral",
            }:
                mailbox = (qs.get("mailbox") or [""])[0]
                direction = (qs.get("direction") or [""])[0]
                if action_name == "purge-expired":
                    deleted = admin_ui.purge_expired(self.store)
                    LOG.info("admin purge_expired deleted=%s", deleted)
                    self.send_json(HTTPStatus.OK, {"ok": True, "action": action_name, "deleted": deleted})
                    return
                if action_name == "clear-pending":
                    deleted = admin_ui.clear_pending(self.store, mailbox=mailbox, direction=direction)
                    LOG.info("admin clear_pending deleted=%s", deleted)
                    self.send_json(HTTPStatus.OK, {"ok": True, "action": action_name, "deleted": deleted})
                    return
                if action_name == "dedupe-pending":
                    result = self.store.dedupe_pending(mailbox=mailbox, direction=direction)
                    result["ok"] = True
                    result["action"] = action_name
                    LOG.info("admin dedupe_pending %s", result)
                    self.send_json(HTTPStatus.OK, result)
                    return
                if action_name == "slim-archive":
                    result = self.store.slim_existing_archive()
                    result["ok"] = True
                    result["action"] = action_name
                    LOG.info("admin slim_archive %s", result)
                    self.send_json(HTTPStatus.OK, result)
                    return
                if action_name == "prune-archive":
                    days = qs.get("days")
                    retention = int(days[0]) if days and days[0].isdigit() else 0
                    if retention <= 0:
                        self.send_error_json(HTTPStatus.BAD_REQUEST, "days_required_to_delete")
                        return
                    result = self.store.prune_archive(retention_days=retention)
                    result["ok"] = True
                    result["action"] = action_name
                    self.send_json(HTTPStatus.OK, result)
                    return
                if action_name == "purge-ephemeral":
                    result = self.store.purge_ephemeral_stored()
                    result["ok"] = True
                    result["action"] = action_name
                    self.send_json(HTTPStatus.OK, result)
                    return
                if action_name == "vacuum":
                    result = self.store.vacuum(purge_ephemeral=True)
                    result["ok"] = True
                    result["action"] = action_name
                    self.send_json(HTTPStatus.OK, result)
                    return

            if path == "/admin/api/actions" or path == "/admin/api/action":
                self.send_json(HTTPStatus.OK, {
                    "ok": True,
                    "actions": [
                        "purge-expired", "clear-pending", "dedupe-pending",
                        "slim-archive", "prune-archive", "vacuum",
                    ],
                })
                return

            if path == "/admin/api/size":
                size = self.store.table_byte_estimates()
                if BLOB_STORE is not None:
                    size.update(BLOB_STORE.stats())
                self.send_json(HTTPStatus.OK, size)
                return

            if path == "/admin/api/media":
                if BLOB_STORE is None:
                    self.send_json(HTTPStatus.OK, {"total": 0, "items": []})
                    return
                limit = int((qs.get("limit") or ["60"])[0])
                offset = int((qs.get("offset") or ["0"])[0])
                self.send_json(HTTPStatus.OK, BLOB_STORE.list_blobs(limit=limit, offset=offset))
                return

            if path.startswith("/admin/api/media/") and self.command == "GET":
                if BLOB_STORE is None:
                    self.send_error_json(HTTPStatus.NOT_FOUND, "not_found")
                    return
                sha = path.rsplit("/", 1)[-1].lower().strip()
                if not re.fullmatch(r"[a-f0-9]{64}", sha):
                    self.send_error_json(HTTPStatus.BAD_REQUEST, "invalid_sha256")
                    return
                data = BLOB_STORE.get(sha)
                if data is None:
                    self.send_error_json(HTTPStatus.NOT_FOUND, "blob_not_found")
                    return
                meta = BLOB_STORE.meta(sha) or {}
                mime = meta.get("mimeType") or "application/octet-stream"
                if not str(mime).startswith("image/"):
                    # still allow download
                    mime = mime or "application/octet-stream"
                self.send_response(HTTPStatus.OK)
                self.send_header("Content-Type", mime)
                self.send_header("Content-Length", str(len(data)))
                self.send_header("Cache-Control", "private, max-age=3600")
                self.end_headers()
                self.wfile.write(data)
                return

            LOG.warning("admin not_found path=%s cmd=%s", path, self.command)
            self.send_json(HTTPStatus.NOT_FOUND, {
                "error": "not_found",
                "path": path,
                "command": self.command,
                "hint": "Update relay/server.py and restart the service",
                "actions": [
                    "/admin/api/actions/dedupe-pending",
                    "/admin/api/actions/slim-archive",
                    "/admin/api/actions/clear-pending",
                    "/admin/api/actions/purge-expired",
                    "/admin/api/actions/vacuum",
                    "/admin/api/actions/purge-ephemeral",
                ],
            })
        except ValueError as exc:
            self.send_error_json(HTTPStatus.BAD_REQUEST, str(exc))
        except Exception as exp:  # noqa: BLE001
            LOG.exception("admin handler error path=%s", getattr(parsed, "path", "?"))
            with STATS_LOCK:
                STATS["errors"] += 1
            self.send_error_json(HTTPStatus.INTERNAL_SERVER_ERROR, "admin_error:" + type(exp).__name__)

    def do_GET(self) -> None:  # noqa: N802
        parsed = urlsplit(self.path)
        # --- Admin panel (dashboard / DB / logs) ---
        if parsed.path == "/admin" or parsed.path.startswith("/admin/"):
            self.handle_admin(parsed)
            return
        if "/blobs/" in parsed.path and parsed.path.startswith("/v1/mailboxes/"):
            self.handle_blob_api(parsed)
            return
        # --- WebSocket push channel (path 3: persistent connection) ---
        if parsed.path == "/v1/push":
            self.handle_websocket_push(parsed)
            return
        if parsed.path == "/v1/backup":
            self.handle_backup_get()
            return
        if parsed.path == "/health":
            try:
                snap = self.store.stats_snapshot()
            except (sqlite3.Error, OSError):
                # A transient storage/path/permission issue should produce a clear
                # degraded health response rather than an uncaught request traceback.
                self.send_json(HTTPStatus.SERVICE_UNAVAILABLE, {
                    "service": "ourspace-relay",
                    "status": "degraded",
                    "error": "database_unavailable",
                })
                return
            with STATS_LOCK:
                counters = dict(STATS)
            with DDNS_LOCK:
                ddns = dict(DDNS_STATUS)
            body = {
                "service": "ourspace-relay",
                "status": "ok",
                "protocol": 3,
                "version": 3,
                "uptimeSec": int(time.monotonic() - START_MONO),
                "startedAt": START_MS,
                "pendingMessages": snap["pendingMessages"],
                "activeMailboxes": snap["activeMailboxes"],
                "oldestPendingAt": snap["oldestPendingAt"],
                "archivedMessages": snap["archivedMessages"],
                "counters": counters,
                "ddns": ddns,
                "activeMailboxPrefixes": sorted(m[:12] for m in ACTIVE_MAILBOXES),
                "householdMode": HOUSEHOLD_TOKEN is not None,
                "householdMailboxPrefix": (HOUSEHOLD_MAILBOX[:12] if HOUSEHOLD_MAILBOX else None),
                "pairingHint": (
                    "OK_single_pair" if len(ACTIVE_MAILBOXES) <= 1
                    else "WARNING_multiple_mailboxes_means_phones_not_sharing_same_pairing_secret"
                ),
                "features": ["durable-mailbox", "permanent-archive", "encrypted-household-backup", "ack", "long-poll", "websocket-push", "fcm-wake", "health-v2", "ddns", "pin-pairing", "admin-panel", "admin-message-flow", "device-action-logs", "binary-blobs"],
                "wsConnections": ws_hub.HUB.count(),
                "fcmConfigured": fcm_server_key() is not None,
            }
            self.send_json(HTTPStatus.OK, body)
            return
        route = self.authorized_route(parsed.path)
        if route is None:
            return
        mailbox, direction, resource = route
        if resource != "messages":
            self.send_error_json(HTTPStatus.NOT_FOUND, "not_found")
            return
        query = parse_qs(parsed.query, keep_blank_values=False)
        try:
            limit = max(1, min(MAX_FETCH, int(query.get("limit", ["20"])[0])))
        except ValueError:
            self.send_error_json(HTTPStatus.BAD_REQUEST, "invalid_limit")
            return
        wait_raw = query.get("wait", ["0"])[0]
        try:
            wait_sec = max(0.0, min(MAX_LONG_POLL_SEC, float(wait_raw)))
        except ValueError:
            wait_sec = 0.0
        messages = self.store.receive(mailbox, direction, limit)
        if not messages and wait_sec > 0:
            woke = wait_for_mail(
                mailbox,
                direction,
                wait_sec,
                lambda: self.store.has_pending(mailbox, direction),
            )
            if woke:
                with STATS_LOCK:
                    STATS["long_poll_wake"] += 1
            messages = self.store.receive(mailbox, direction, limit)
        if messages:
            actor = getattr(self, "_relay_actor", self._device_actor(mailbox, direction, resource))
            try:
                self.store.record_received(mailbox, direction, messages, actor)
            except Exception:  # noqa: BLE001 — audit telemetry must never block relay delivery
                LOG.exception("device_receive_audit_failed mailbox=%s dir=%s", mailbox[:12], direction)
            _touch_device_presence(mailbox, actor, action="receive", channel="http")
        # Include the relay's wall clock so Android can validate envelope TTL against
        # the same clock that accepted/stored it, not a potentially skewed handset clock.
        self.send_json(HTTPStatus.OK, {
            "messages": messages,
            "serverTimeMs": int(time.time() * 1000),
        })

    def do_PUT(self) -> None:  # noqa: N802
        parsed = urlsplit(self.path)
        if "/blobs/" in parsed.path and parsed.path.startswith("/v1/mailboxes/"):
            self.handle_blob_api(parsed)
            return
        self.send_error_json(HTTPStatus.METHOD_NOT_ALLOWED, "method_not_allowed")

    def do_POST(self) -> None:  # noqa: N802
        parsed = urlsplit(self.path)
        if parsed.path.startswith("/admin/"):
            self.handle_admin(parsed)
            return
        if parsed.path.endswith("/push-tokens") or parsed.path.endswith("/push-tokens/"):
            self.handle_push_token_register(parsed)
            return
        if parsed.path.endswith("/push-tokens/delete"):
            self.handle_push_token_delete(parsed)
            return
        if parsed.path == "/v1/backup":
            self.handle_backup_post()
            return
        if parsed.path in ("/pairing/host-pin", "/pairing/verify-pin"):
            self.handle_pairing_pin(parsed.path)
            return
        route = self.authorized_route(parsed.path)
        if route is None:
            return
        mailbox, direction, resource = route
        try:
            payload = self.read_json()
            if resource == "messages":
                message = validate_message(payload)
                created = self.store.publish(mailbox, direction, message)
                actor = getattr(self, "_relay_actor", self._device_actor(mailbox, direction, resource))
                event_details = self.store._event_message_details(message.get("envelope"))
                event_details["envelopeBytes"] = len(
                    json.dumps(message.get("envelope") or {}, separators=(",", ":"))
                )
                self._record_device_event(
                    mailbox, actor, "publish", direction, message["messageId"],
                    self.store._event_message_type(message.get("envelope")),
                    "stored" if created else "duplicate", event_details,
                )
                self.send_json(
                    HTTPStatus.CREATED if created else HTTPStatus.OK,
                    {"messageId": message["messageId"], "stored": created},
                )
            elif resource == "acknowledgements":
                ids = validate_acknowledgements(payload)
                actor = getattr(self, "_relay_actor", self._device_actor(mailbox, direction, resource))
                deleted = self.store.acknowledge(mailbox, direction, ids, actor=actor)
                _touch_device_presence(mailbox, actor, action="ack", channel="http")
                self.send_json(HTTPStatus.OK, {"acknowledged": deleted})
            else:
                self.send_error_json(HTTPStatus.NOT_FOUND, "not_found")
        except OverflowError:
            with STATS_LOCK:
                STATS["errors"] += 1
            actor = getattr(self, "_relay_actor", self._device_actor(mailbox, direction, resource))
            self._record_device_event(mailbox, actor, "publish_error", direction, result="mailbox_full")
            self.send_error_json(HTTPStatus.TOO_MANY_REQUESTS, "mailbox_full")
        except ValueError as exc:
            with STATS_LOCK:
                STATS["errors"] += 1
            actor = getattr(self, "_relay_actor", self._device_actor(mailbox, direction, resource))
            self._record_device_event(mailbox, actor, "request_error", direction, result=str(exc)[:120])
            self.send_error_json(HTTPStatus.BAD_REQUEST, str(exc))
        except Exception as exc:
            with STATS_LOCK:
                STATS["errors"] += 1
            LOG.exception("request_failed")
            actor = getattr(self, "_relay_actor", self._device_actor(mailbox, direction, resource))
            self._record_device_event(mailbox, actor, "request_error", direction, result=type(exc).__name__)
            self.send_error_json(HTTPStatus.INTERNAL_SERVER_ERROR, "internal_error")

    def handle_pairing_pin(self, path: str) -> None:
        """Register/verify the first-run four-digit PIN for the private household."""
        global HOST_PIN_HASH, HOST_PIN_EXPIRES_AT
        authorization = self.headers.get("Authorization", "")
        token = authorization[7:] if authorization.startswith("Bearer ") else ""
        if not HOUSEHOLD_TOKEN or not hmac.compare_digest(token, HOUSEHOLD_TOKEN):
            self.send_error_json(HTTPStatus.UNAUTHORIZED, "unauthorized")
            return
        if HOUSEHOLD_MAILBOX and not self.limiter.allow(HOUSEHOLD_MAILBOX):
            self.send_error_json(HTTPStatus.TOO_MANY_REQUESTS, "rate_limited")
            return
        mailbox = HOUSEHOLD_MAILBOX or mailbox_for_token(token)
        actor = self._device_actor(mailbox, "", "pairing_pin")
        self._relay_actor = actor
        _touch_device_presence(mailbox, actor, channel="http")

        client_ip = self.client_address[0] if self.client_address else "unknown"
        now = time.monotonic()
        if path.endswith("/verify-pin"):
            with PIN_ATTEMPTS_LOCK:
                attempts = PIN_ATTEMPTS[client_ip]
                cutoff = now - 300.0
                while attempts and attempts[0] <= cutoff:
                    attempts.popleft()
                if len(attempts) >= 8:
                    self.send_error_json(HTTPStatus.TOO_MANY_REQUESTS, "too_many_pin_attempts")
                    return
                attempts.append(now)

        try:
            payload = self.read_json()
            pin = str(payload.get("pin") or "")
            if len(pin) != 4 or not pin.isascii() or not pin.isdigit():
                raise ValueError("pin_must_be_four_digits")
            pin_hash = hashlib.sha256(pin.encode("ascii")).hexdigest()
            if path.endswith("/host-pin"):
                with HOST_PIN_LOCK:
                    HOST_PIN_HASH = pin_hash
                    HOST_PIN_EXPIRES_AT = time.monotonic() + 600.0
                self._record_device_event(mailbox, actor, "pairing_host_pin_register", result="registered")
                self.send_json(HTTPStatus.OK, {"registered": True, "expiresInSec": 600})
                LOG.info("host pairing PIN registered (value redacted)")
                return

            with HOST_PIN_LOCK:
                valid = (
                    HOST_PIN_HASH is not None
                    and time.monotonic() < HOST_PIN_EXPIRES_AT
                    and hmac.compare_digest(HOST_PIN_HASH, pin_hash)
                )
            if not valid:
                self._record_device_event(mailbox, actor, "pairing_pin_verify", result="invalid_or_expired")
                self.send_error_json(HTTPStatus.FORBIDDEN, "invalid_or_expired_pin")
                return
            self._record_device_event(mailbox, actor, "pairing_pin_verify", result="valid")
            self.send_json(HTTPStatus.OK, {"valid": True})
        except ValueError as exc:
            self.send_error_json(HTTPStatus.BAD_REQUEST, str(exc))
        except Exception:
            LOG.exception("pairing_pin_request_failed")
            self.send_error_json(HTTPStatus.INTERNAL_SERVER_ERROR, "internal_error")

    def authorized_route(self, path: str) -> tuple[str, str, str] | None:
        match = ROUTE_RE.fullmatch(path)
        if match is None:
            self.send_error_json(HTTPStatus.NOT_FOUND, "not_found")
            return None
        mailbox, direction, resource = match.group(1), match.group(2), match.group(3)
        authorization = self.headers.get("Authorization", "")
        if not authorization.startswith("Bearer "):
            with STATS_LOCK:
                STATS["unauthorized"] += 1
            self.send_error_json(HTTPStatus.UNAUTHORIZED, "unauthorized")
            return None
        token = authorization[7:]
        if not TOKEN_RE.fullmatch(token):
            with STATS_LOCK:
                STATS["unauthorized"] += 1
            self.send_error_json(HTTPStatus.UNAUTHORIZED, "unauthorized")
            return None
        # Single-household mode: only the server token is accepted; path mailbox must match it.
        if HOUSEHOLD_TOKEN is not None and HOUSEHOLD_MAILBOX is not None:
            if not hmac.compare_digest(token, HOUSEHOLD_TOKEN):
                with STATS_LOCK:
                    STATS["unauthorized"] += 1
                self.send_error_json(HTTPStatus.UNAUTHORIZED, "unauthorized")
                return None
            if not hmac.compare_digest(mailbox, HOUSEHOLD_MAILBOX):
                with STATS_LOCK:
                    STATS["unauthorized"] += 1
                self.send_error_json(HTTPStatus.UNAUTHORIZED, "wrong_mailbox")
                return None
        elif not hmac.compare_digest(mailbox_for_token(token), mailbox):
            with STATS_LOCK:
                STATS["unauthorized"] += 1
            self.send_error_json(HTTPStatus.UNAUTHORIZED, "unauthorized")
            return None
        if not self.limiter.allow(mailbox):
            self.send_error_json(HTTPStatus.TOO_MANY_REQUESTS, "rate_limited")
            return None
        self._relay_actor = self._device_actor(mailbox, direction, resource)
        _touch_device_presence(mailbox, self._relay_actor, channel="http")
        if _device_presence_log_due(mailbox, self._relay_actor):
            self.store.record_device_event(mailbox, self._relay_actor, "http_presence", result="active")
        return mailbox, direction, resource

    def read_json(self) -> dict:
        raw_length = self.headers.get("Content-Length")
        if raw_length is None:
            raise ValueError("content_length_required")
        length = int(raw_length)
        if length < 2 or length > MAX_BODY:
            raise ValueError("invalid_body_size")
        raw = self.rfile.read(length)
        if len(raw) != length:
            raise ValueError("incomplete_body")
        value = json.loads(raw.decode("utf-8"))
        if not isinstance(value, dict):
            raise ValueError("json_object_required")
        return value

    def send_error_json(self, status: HTTPStatus, code: str) -> None:
        self.send_json(status, {"error": code})

    def send_json(self, status: HTTPStatus, payload: dict) -> None:
        body = json.dumps(payload, separators=(",", ":"), ensure_ascii=True).encode("utf-8")
        if len(body) > MAX_RESPONSE:
            status = HTTPStatus.INTERNAL_SERVER_ERROR
            body = b'{"error":"response_too_large"}'
        try:
            self.send_response(status.value)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            self.send_header("X-Content-Type-Options", "nosniff")
            # Android HttpURLConnection + ThreadingHTTPServer: avoid keep-alive half-closes.
            self.send_header("Connection", "close")
            self.end_headers()
            self.wfile.write(body)
        except CLIENT_GONE:
            # Client closed long-poll / switched network. Server keeps running.
            LOG.debug("client disconnected while sending to %s", self.client_address)
        except OSError as exc:
            # errno 104 (ECONNRESET), 32 (EPIPE) on some platforms
            if getattr(exc, "errno", None) in (32, 104, 54, 10053, 10054):
                LOG.debug("socket gone while sending to %s: %s", self.client_address, exc)
            else:
                raise

    def handle(self) -> None:
        """Swallow benign disconnects so ThreadingHTTPServer does not print a traceback."""
        try:
            super().handle()
        except CLIENT_GONE:
            LOG.debug("client disconnected during handle %s", self.client_address)
        except OSError as exc:
            if getattr(exc, "errno", None) in (32, 104, 54, 10053, 10054):
                LOG.debug("socket error during handle %s: %s", self.client_address, exc)
            else:
                raise

    def finish(self) -> None:
        try:
            super().finish()
        except CLIENT_GONE:
            pass
        except OSError:
            pass


def validate_message(payload: dict) -> dict:
    required = {"messageId", "correlationId", "createdAt", "expiresAt", "envelope"}
    if set(payload) != required:
        raise ValueError("invalid_message_fields")
    message_id = payload["messageId"]
    correlation_id = payload["correlationId"]
    created_at = payload["createdAt"]
    expires_at = payload["expiresAt"]
    envelope = payload["envelope"]
    if not isinstance(message_id, str) or not ID_RE.fullmatch(message_id):
        raise ValueError("invalid_message_id")
    if correlation_id is not None and (
        not isinstance(correlation_id, str) or not ID_RE.fullmatch(correlation_id)
    ):
        raise ValueError("invalid_correlation_id")
    if not isinstance(created_at, int) or isinstance(created_at, bool):
        raise ValueError("invalid_created_at")
    if not isinstance(expires_at, int) or isinstance(expires_at, bool):
        raise ValueError("invalid_expires_at")
    now_ms = int(time.time() * 1000)
    if created_at < now_ms - MAX_TTL_MS or created_at > now_ms + MAX_CLOCK_SKEW_MS:
        raise ValueError("invalid_created_at")
    if expires_at <= now_ms or expires_at < created_at or expires_at > created_at + MAX_TTL_MS:
        raise ValueError("invalid_expires_at")
    if not isinstance(envelope, dict):
        raise ValueError("invalid_envelope")
    envelope_size = len(json.dumps(envelope, separators=(",", ":"), ensure_ascii=True).encode("utf-8"))
    if envelope_size > MAX_BODY:
        raise ValueError("envelope_too_large")
    return payload


def validate_acknowledgements(payload: dict) -> list[str]:
    if set(payload) != {"messageIds"} or not isinstance(payload["messageIds"], list):
        raise ValueError("invalid_acknowledgements")
    ids = payload["messageIds"]
    if len(ids) > MAX_ACK:
        raise ValueError("too_many_acknowledgements")
    if any(not isinstance(item, str) or not ID_RE.fullmatch(item) for item in ids):
        raise ValueError("invalid_message_id")
    return list(dict.fromkeys(ids))


class DdnsUpdater(threading.Thread):
    """Built-in Dynamic DNS client for DNSLab / DynDNS-compatible providers.

    Config file relay-data/ddns.json examples:

    A) DNSLab (username + password from panel — same as modem):
      {
        "enabled": true,
        "hostname": "ourspace.iddns.ir",
        "username": "YOUR_DNSLAB_USERNAME",
        "password": "YOUR_DNSLAB_PASSWORD",
        "interval_minutes": 60
      }

    B) Full update URL (DuckDNS / token links):
      {
        "enabled": true,
        "hostname": "ourspace.iddns.ir",
        "update_url": "https://...",
        "interval_minutes": 60
      }
    """

    daemon = True

    def __init__(
        self,
        update_url: str = "",
        hostname: str = "",
        username: str = "",
        password: str = "",
        server: str = "",
        interval_sec: int = 3600,
    ) -> None:
        super().__init__(name="OurSpaceDdns")
        self.update_url = (update_url or "").strip()
        self.hostname = (hostname or "").strip()
        self.username = (username or "").strip()
        self.password = (password or "").strip()
        self.server = (server or "dnslab.link").strip()
        self.interval_sec = max(300, int(interval_sec))
        self._stop = threading.Event()
        with DDNS_LOCK:
            DDNS_STATUS.update(
                {
                    "enabled": True,
                    "hostname": self.hostname,
                    "intervalSec": self.interval_sec,
                    "lastMessage": "starting",
                }
            )

    def stop(self) -> None:
        self._stop.set()

    def run(self) -> None:
        delay = 5
        while not self._stop.is_set():
            try:
                self._update_once()
            except Exception as exc:  # noqa: BLE001
                LOG.warning("ddns update failed: %s", exc)
                with DDNS_LOCK:
                    DDNS_STATUS["lastOk"] = False
                    DDNS_STATUS["lastAt"] = int(time.time() * 1000)
                    DDNS_STATUS["lastMessage"] = str(exc)[:200]
            if self._stop.wait(delay):
                break
            delay = self.interval_sec

    def _public_ip(self) -> str:
        for url in (
            "https://api.ipify.org",
            "https://ifconfig.me/ip",
            "https://icanhazip.com",
        ):
            try:
                with urlopen(Request(url, headers={"User-Agent": "OurSpaceRelay/2"}), timeout=10) as resp:
                    ip = resp.read().decode("utf-8").strip()
                    if ip and len(ip) < 64:
                        return ip
            except Exception:
                continue
        return ""

    def _candidate_targets(self, ip: str) -> list[tuple[str, dict]]:
        """List of (url, headers). Auth goes in Header so passwords with @ work."""
        targets: list[tuple[str, dict]] = []
        headers_base = {"User-Agent": "OurSpaceRelay-DDNS/2"}

        if self.update_url:
            url = self.update_url
            if "{ip}" in url and ip:
                url = url.replace("{ip}", quote(ip))
            if "{hostname}" in url and self.hostname:
                url = url.replace("{hostname}", quote(self.hostname))
            targets.append((url, dict(headers_base)))
            return targets

        if not (self.username and self.password and self.hostname):
            raise RuntimeError("ddns needs update_url or username+password+hostname")

        token = base64.b64encode(f"{self.username}:{self.password}".encode("utf-8")).decode("ascii")
        auth_headers = {**headers_base, "Authorization": f"Basic {token}"}
        host_q = quote(self.hostname, safe="")
        ip_q = quote(ip, safe="") if ip else ""
        query = f"hostname={host_q}" + (f"&myip={ip_q}" if ip_q else "")
        servers = []
        for s in (self.server, "dnslab.link", "www.dnslab.link", "api.dnslab.link"):
            if s and s not in servers:
                servers.append(s)
        paths = [f"/nic/update?{query}", f"/v1/update?{query}", f"/update?{query}"]
        seen = set()
        for srv in servers:
            for path in paths:
                for scheme in ("https", "http"):
                    u = f"{scheme}://{srv}{path}"
                    if u not in seen:
                        seen.add(u)
                        targets.append((u, dict(auth_headers)))
        return targets

    def _update_once(self) -> None:
        ip = self._public_ip()
        last_error = ""
        for url, headers in self._candidate_targets(ip):
            try:
                req = Request(url, headers=headers)
                with urlopen(req, timeout=20) as resp:
                    body = resp.read().decode("utf-8", errors="replace")[:300]
                    code = getattr(resp, "status", 200)
                low = body.lower().strip()
                # Reject HTML login/SPA pages (false positives on dnslab.link/nic/update).
                if low.startswith("<!doctype") or low.startswith("<html") or "<html" in low[:200]:
                    ok = False
                else:
                    # DynDNS tokens, DNSLab "true", or short plain OK bodies.
                    tokens = ("good", "nochg", "updated", "success", "ok", "true")
                    bad = ("badauth", "unauthorized", "abuse", "911", "nohost", "notfqdn", "false", "fail")
                    has_good = any(
                        low == t or low.startswith(t + " ") or low.startswith(t + "\n") or f"\n{t}" in low
                        for t in tokens
                    ) or (len(low) < 40 and ("ok" in low or low == "true") and "<" not in low)
                    has_bad = any(b in low for b in bad) and low not in ("true", "ok", "good", "nochg")
                    ok = code in (200, 201) and has_good and not has_bad
                with DDNS_LOCK:
                    DDNS_STATUS.update(
                        {
                            "lastOk": ok,
                            "lastAt": int(time.time() * 1000),
                            "lastMessage": body or f"HTTP {code}",
                            "lastIp": ip,
                        }
                    )
                if ok:
                    LOG.info(
                        "ddns ok hostname=%s ip=%s via=%s body=%s",
                        self.hostname or "-",
                        ip or "-",
                        url.split("?")[0][:80],
                        body[:80],
                    )
                    return
                last_error = body or f"HTTP {code}"
                LOG.warning("ddns try failed via=%s body=%s", url.split("?")[0][:80], body[:120])
            except Exception as exc:  # noqa: BLE001
                last_error = str(exc)
                LOG.warning("ddns try error via=%s err=%s", url.split("?")[0][:80], exc)
        raise RuntimeError(last_error or "all ddns endpoints failed")



def load_ddns_config(path: str) -> dict:
    if not path or not os.path.isfile(path):
        return {}
    try:
        with open(path, "r", encoding="utf-8") as fh:
            data = json.load(fh)
        return data if isinstance(data, dict) else {}
    except Exception as exc:  # noqa: BLE001
        LOG.warning("ddns config read failed: %s", exc)
        return {}



def load_or_create_household_token(path: str) -> tuple[str, str]:
    """Use the same preconfigured shared token as all OurSpace Android clients.

    The token is intentionally fixed to the Android app default. Existing random
    household.json values are replaced so server and phone cannot silently land in
    different mailboxes.
    """
    os.makedirs(os.path.dirname(os.path.abspath(path)) or ".", exist_ok=True)
    token = DEFAULT_HOUSEHOLD_TOKEN

    stored_token = None
    if os.path.isfile(path):
        try:
            with open(path, "r", encoding="utf-8") as fh:
                data = json.load(fh)
            stored_token = str(data.get("token") or "").strip()
        except Exception as exc:  # noqa: BLE001
            LOG.warning("household token read failed: %s", exc)

    if stored_token != token:
        with open(path, "w", encoding="utf-8") as fh:
            json.dump({"token": token, "note": "Must match RelayConfig.DEFAULT_ACCESS_TOKEN in the OurSpace Android app"}, fh, indent=2)
        LOG.info("synchronized household token file with the configured app token: %s", path)

    return token, mailbox_for_token(token)


def setup_logging(log_dir: str) -> None:
    os.makedirs(log_dir, exist_ok=True)
    path = os.path.join(log_dir, "relay.log")
    handler = RotatingFileHandler(path, maxBytes=2_000_000, backupCount=3, encoding="utf-8")
    handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(message)s"))
    root = logging.getLogger()
    root.setLevel(logging.INFO)
    root.handlers.clear()
    root.addHandler(handler)
    console = logging.StreamHandler(sys.stdout)
    console.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(message)s"))
    root.addHandler(console)
    try:
        admin_ui.install_memory_log_handler()
    except Exception as exc:  # noqa: BLE001
        LOG.warning("admin memory log handler failed: %s", exc)
    # Keep path for admin log tail
    global RELAY_LOG_PATH
    RELAY_LOG_PATH = path



class QuietThreadingHTTPServer(ThreadingHTTPServer):
    """Keep serving forever; do not dump stack traces for mobile disconnects."""

    daemon_threads = True  # do not block shutdown on idle long-poll threads

    def handle_error(self, request, client_address) -> None:  # noqa: ANN001
        exc = sys.exc_info()[1]
        if isinstance(exc, CLIENT_GONE):
            LOG.debug("client gone %s: %s", client_address, exc)
            return
        if isinstance(exc, OSError) and getattr(exc, "errno", None) in (32, 104, 54, 10053, 10054):
            LOG.debug("client socket error %s: %s", client_address, exc)
            return
        # Real errors still go to the log with traceback
        LOG.exception("request_handler_error client=%s", client_address)



def main() -> None:
    parser = argparse.ArgumentParser(description="OurSpace personal relay v2 (+ built-in DDNS)")
    parser.add_argument("--host", default=os.environ.get("OURSPACE_RELAY_HOST", "0.0.0.0"))
    parser.add_argument("--port", type=int, default=int(os.environ.get("OURSPACE_RELAY_PORT", "8787")))
    configured_database = os.environ.get("OURSPACE_RELAY_DATABASE")
    if configured_database:
        default_database = configured_database
    else:
        script_database = os.path.join(
            os.path.dirname(os.path.abspath(__file__)), "relay-data", "relay.sqlite3"
        )
        # Preserve a pre-existing database from the old cwd-relative default when
        # the server is first upgraded from a different launch directory.
        cwd_database = os.path.abspath(os.path.join("relay-data", "relay.sqlite3"))
        default_database = (
            cwd_database
            if os.path.isfile(cwd_database) and not os.path.isfile(script_database)
            else script_database
        )
    parser.add_argument("--database", default=default_database)
    parser.add_argument(
        "--log-dir",
        default=os.environ.get("OURSPACE_RELAY_LOG", "relay-data/logs"),
    )
    parser.add_argument(
        "--ddns-config",
        default=os.environ.get("OURSPACE_DDNS_CONFIG", "relay-data/ddns.json"),
        help="Path to ddns.json (built-in Dynamic DNS)",
    )
    parser.add_argument("--ddns-url", default=os.environ.get("OURSPACE_DDNS_URL", ""), help="Override DDNS update URL")
    parser.add_argument("--ddns-hostname", default=os.environ.get("OURSPACE_DDNS_HOSTNAME", ""), help="Hostname label")
    parser.add_argument(
        "--ddns-interval",
        type=int,
        default=int(os.environ.get("OURSPACE_DDNS_INTERVAL", "0") or "0"),
        help="DDNS interval in minutes (default 60 from config)",
    )
    args = parser.parse_args()
    setup_logging(args.log_dir)

    global HOUSEHOLD_TOKEN, HOUSEHOLD_MAILBOX
    household_path = os.environ.get("OURSPACE_HOUSEHOLD", "relay-data/household.json")
    if hasattr(args, "household") is False:
        pass
    HOUSEHOLD_TOKEN, HOUSEHOLD_MAILBOX = load_or_create_household_token(household_path)
    LOG.info("HOUSEHOLD single-mailbox mode mailbox=%s…", HOUSEHOLD_MAILBOX[:12])
    print("=" * 60, flush=True)
    print("  کلید مشترک خانه (همین را در هر دو گوشی وارد کن):", flush=True)
    print(f"  {HOUSEHOLD_TOKEN}", flush=True)
    print(f"  mailbox: {HOUSEHOLD_MAILBOX[:16]}…", flush=True)
    print("=" * 60, flush=True)

    ddns_cfg = load_ddns_config(args.ddns_config)
    update_url = (args.ddns_url or ddns_cfg.get("update_url") or "").strip()
    hostname = (args.ddns_hostname or ddns_cfg.get("hostname") or "").strip()
    username = str(ddns_cfg.get("username") or os.environ.get("OURSPACE_DDNS_USER", "")).strip()
    password = str(ddns_cfg.get("password") or os.environ.get("OURSPACE_DDNS_PASS", "")).strip()
    server = str(ddns_cfg.get("server") or "dnslab.link").strip()
    enabled = bool(ddns_cfg.get("enabled", bool(update_url) or bool(username and password and hostname)))
    interval_min = args.ddns_interval or int(ddns_cfg.get("interval_minutes") or 60)
    ddns_thread: DdnsUpdater | None = None
    if enabled and (update_url or (username and password and hostname)):
        ddns_thread = DdnsUpdater(
            update_url=update_url,
            hostname=hostname,
            username=username,
            password=password,
            server=server,
            interval_sec=interval_min * 60,
        )
        ddns_thread.start()
        LOG.info("DDNS enabled hostname=%s every %s min", hostname or "-", interval_min)
        print(f"DDNS: enabled for {hostname or 'provider'} every {interval_min} minutes", flush=True)
    else:
        LOG.info("DDNS disabled (set relay-data/ddns.json with username/password or update_url)")

    server = QuietThreadingHTTPServer((args.host, args.port), RelayHandler)
    # Longer than MAX_LONG_POLL_SEC so idle long-polls are not killed mid-wait.
    server.timeout = MAX_LONG_POLL_SEC + 15
    server.store = RelayStore(args.database)  # type: ignore[attr-defined]
    global BLOB_STORE
    blob_root = os.path.join(os.path.dirname(os.path.abspath(args.database)), "blobs")
    BLOB_STORE = blob_store_mod.BlobStore(blob_root)
    server.blob_store = BLOB_STORE  # type: ignore[attr-defined]
    LOG.info("blob store root=%s", blob_root)
    try:
        # Never delete history on startup. Compact fat Base64 archive rows, then VACUUM if useful.
        slim = server.store.slim_existing_archive()
        LOG.info("startup archive slim: %s", slim)
        if slim.get("updated", 0) > 0 or slim.get("savedChars", 0) > 1_000_000:
            vac = server.store.vacuum()
            LOG.info("startup vacuum after slim: %s", vac)
    except Exception as exc:  # noqa: BLE001
        LOG.warning("startup archive slim failed: %s", exc)
    try:
        snap = server.store.stats_snapshot()
        pending = int(snap.get("pendingMessages") or 0)
        if pending > 500:
            deduped = server.store.dedupe_pending()
            LOG.warning("startup queue dedupe pending=%s result=%s", pending, deduped)
            # Do not trim unacknowledged relay messages at startup. A large pending
            # queue is a recovery/back-pressure condition, not permission to discard data.
            snap2 = server.store.stats_snapshot()
            pending2 = int(snap2.get("pendingMessages") or 0)
            if pending2 >= MAX_MESSAGES_PER_MAILBOX * 0.9:
                LOG.warning(
                    "startup queue near capacity pending=%s; preserving all unacknowledged messages",
                    pending2,
                )
    except Exception as exc:  # noqa: BLE001
        LOG.warning("startup queue heal failed: %s", exc)
    LOG.info("SQLite database path=%s", server.store.path)
    fcm_wake_mailbox._store = server.store  # type: ignore[attr-defined]
    if fcm_server_key():
        LOG.info("FCM data-only wake enabled")
    else:
        LOG.info("FCM wake disabled (set FCM_SERVER_KEY to enable)")
    server.limiter = RateLimiter()  # type: ignore[attr-defined]
    LOG.info("OurSpace relay v2 listening on %s:%s", args.host, args.port)
    print(f"OurSpace relay v2 listening on {args.host}:{args.port}; Ctrl+C to stop", flush=True)
    try:
        server.serve_forever(poll_interval=0.5)
    except KeyboardInterrupt:
        pass
    finally:
        if ddns_thread is not None:
            ddns_thread.stop()
        server.server_close()
        LOG.info("relay stopped")


if __name__ == "__main__":
    main()
