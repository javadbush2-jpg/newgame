package com.ourspace.app.core.sync

import com.ourspace.app.core.database.OurSpaceDatabase
import com.ourspace.app.core.pairing.PairingStore
import com.ourspace.app.core.preferences.AppPreferences
import com.ourspace.app.core.relay.RelayInternetSync
import java.io.IOException
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

/**
 * Only transport: user-hosted personal relay (HTTP mailbox).
 * All phones share one household access token → one mailbox.
 */
class SyncClient(
    private val database: OurSpaceDatabase,
    private val pairingStore: PairingStore,
    private val preferences: AppPreferences
) {
    enum class Transport { RELAY }

    data class Result(
        val receivedItems: Int,
        val sentItems: Int,
        val acknowledgedItems: Int,
        val transport: Transport = Transport.RELAY
    )

    suspend fun syncNow(): Result = globalSyncMutex.withLock {
        val relay = preferences.currentRelayConfig()
        if (!relay.isUsable) {
            throw IOException("سرور شخصی یا کلید مشترک خانه تنظیم نشده است.")
        }
        RelayInternetSync.exchange(
            accessToken = relay.accessToken,
            endpoint = relay.endpoint,
            database = database,
            deviceRole = preferences.currentRole()?.persistedName
        )
    }

    companion object {
        private val globalSyncMutex = Mutex()

        internal fun humanizeSyncError(error: Throwable): String = when (error) {
            is java.net.SocketTimeoutException -> "پاسخ سرور شخصی در زمان مجاز دریافت نشد."
            is java.net.UnknownHostException -> "آدرس سرور شخصی پیدا نشد (DDNS یا اینترنت را بررسی کنید)."
            is java.net.ConnectException -> "اتصال به سرور شخصی برقرار نشد (سرور روشن است؟ پورت باز است؟)."
            else -> error.message?.takeIf { it.isNotBlank() } ?: "همگام‌سازی ناموفق بود."
        }
    }
}
