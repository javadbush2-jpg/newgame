package com.ourspace.app.core.relay

import com.ourspace.app.core.security.DeviceIdentityManager
import java.net.HttpURLConnection

/** Adds stable, non-secret device metadata to Relay requests for admin presence/audit. */
internal object RelayDeviceHeaders {
    private val deviceIdPattern = Regex("^[a-f0-9]{24}$")

    fun currentDeviceId(): String? = runCatching {
        DeviceIdentityManager().getOrCreateIdentity().deviceId
    }.getOrNull()?.takeIf(deviceIdPattern::matches)

    fun validDeviceId(value: String?): String? = value?.takeIf(deviceIdPattern::matches)

    fun validRole(value: String?): String? = value?.trim()?.lowercase()
        ?.takeIf { it == "host" || it == "companion" }

    fun apply(connection: HttpURLConnection, deviceId: String?, role: String?) {
        validDeviceId(deviceId)?.let {
            connection.setRequestProperty("X-OurSpace-Device-Id", it)
        }
        validRole(role)?.let {
            connection.setRequestProperty("X-OurSpace-Device-Role", it)
        }
    }
}
