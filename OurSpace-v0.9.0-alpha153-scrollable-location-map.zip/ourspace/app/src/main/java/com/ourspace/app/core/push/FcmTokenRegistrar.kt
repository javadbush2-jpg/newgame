package com.ourspace.app.core.push

import android.content.Context
import android.util.Log
import com.ourspace.app.core.preferences.AppPreferences
import com.ourspace.app.core.relay.RelayClient
import com.ourspace.app.core.relay.RelayCredentials
import com.ourspace.app.core.webrtc.ConnectionDiagnostics
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/**
 * Registers FCM token with the personal relay when Firebase is available.
 * If google-services.json is still a placeholder, this no-ops — WebSocket wake remains active.
 */
object FcmTokenRegistrar {
    private const val TAG = "OurSpaceFCM"
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    fun refreshAndUpload(context: Context) {
        scope.launch {
            runCatching {
                val token = fetchTokenOrNull()
                if (token.isNullOrBlank()) {
                    Log.i(TAG, "FCM unavailable or not configured — using WebSocket wake only")
                    return@launch
                }
                upload(context, token)
            }.onFailure {
                Log.w(TAG, "FCM skipped: ${it.message}")
            }
        }
    }

    fun onNewToken(context: Context, token: String) {
        scope.launch {
            runCatching { upload(context, token) }
                .onFailure { Log.w(TAG, "FCM upload failed: ${it.message}") }
        }
    }

    private fun fetchTokenOrNull(): String? {
        return try {
            val firebaseMessaging = Class.forName("com.google.firebase.messaging.FirebaseMessaging")
            val instance = firebaseMessaging.getMethod("getInstance").invoke(null)
            val task = firebaseMessaging.getMethod("getToken").invoke(instance)
            // com.google.android.gms.tasks.Tasks.await(task)
            val tasksClass = Class.forName("com.google.android.gms.tasks.Tasks")
            val result = tasksClass.getMethod("await", Class.forName("com.google.android.gms.tasks.Task"))
                .invoke(null, task) as? String
            result?.takeIf { it.isNotBlank() && !it.contains("REPLACE", ignoreCase = true) }
        } catch (error: Throwable) {
            Log.i(TAG, "Firebase not ready: ${error.javaClass.simpleName}")
            null
        }
    }

    private suspend fun upload(context: Context, token: String) {
        val preferences = AppPreferences(context)
        val config = preferences.currentRelayConfig()
        if (!config.isUsable) return
        val credentials = RelayCredentials.fromAccessToken(config.accessToken)
        val role = preferences.currentRole()?.persistedName
        RelayClient(config.endpoint, credentials, deviceRole = role).registerPushToken(token, platform = "android")
        ConnectionDiagnostics.log("توکن FCM روی سرور ثبت شد")
        Log.i(TAG, "FCM token uploaded")
    }
}
