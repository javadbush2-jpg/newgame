#!/usr/bin/env python3
"""OurSpace Relay Admin Panel helpers — dashboard, database browser, live logs."""

from __future__ import annotations

import json
import logging
import os
import sqlite3
import threading
import time
from collections import deque
from pathlib import Path
from typing import Any

LOG = logging.getLogger("ourspace.relay.admin")

_LOG_BUFFER: deque[str] = deque(maxlen=2_000)
_LOG_LOCK = threading.Lock()

ADMIN_TABLES = (
    "relay_messages",
    "relay_archive",
    "push_tokens",
    "household_backups",
)

_HTML_PATH = Path(__file__).resolve().parent / "admin.html"


class MemoryLogHandler(logging.Handler):
    def emit(self, record: logging.LogRecord) -> None:
        try:
            line = self.format(record)
        except Exception:  # noqa: BLE001
            line = record.getMessage()
        with _LOG_LOCK:
            _LOG_BUFFER.append(line)


def install_memory_log_handler() -> None:
    root = logging.getLogger()
    for h in root.handlers:
        if isinstance(h, MemoryLogHandler):
            return
    handler = MemoryLogHandler()
    handler.setLevel(logging.INFO)
    handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(message)s"))
    root.addHandler(handler)


def recent_logs(limit: int = 200, level: str = "", log_file: str = "") -> list[str]:
    limit = max(1, min(int(limit), 1_000))
    level = (level or "").upper().strip()
    with _LOG_LOCK:
        lines = list(_LOG_BUFFER)
    if len(lines) < 20 and log_file:
        lines = tail_log_file(log_file, limit) or lines
    if level:
        lines = [ln for ln in lines if f" {level} " in ln]
    return lines[-limit:]


def tail_log_file(path: str, limit: int = 200) -> list[str]:
    try:
        if not path or not os.path.isfile(path):
            return []
        with open(path, "r", encoding="utf-8", errors="replace") as fh:
            fh.seek(0, os.SEEK_END)
            size = fh.tell()
            fh.seek(max(0, size - 256_000))
            data = fh.read()
        lines = [ln for ln in data.splitlines() if ln.strip()]
        return lines[-max(1, min(limit, 1_000)) :]
    except OSError:
        return []


def admin_html_bytes() -> bytes:
    if _HTML_PATH.is_file():
        return _HTML_PATH.read_bytes()
    return b"<h1>admin.html missing</h1>"


def db_table_stats(store) -> dict[str, Any]:
    rows: list[dict[str, Any]] = []
    with store.transaction() as database:
        for name in ADMIN_TABLES:
            try:
                count = database.execute(f"SELECT COUNT(*) FROM {name}").fetchone()[0]
            except sqlite3.Error:
                count = -1
            rows.append({"name": name, "count": int(count)})
        try:
            page_count = database.execute("PRAGMA page_count").fetchone()[0]
            page_size = database.execute("PRAGMA page_size").fetchone()[0]
            db_bytes = int(page_count) * int(page_size)
        except sqlite3.Error:
            db_bytes = 0
    path = getattr(store, "path", "")
    file_bytes = 0
    try:
        if path and os.path.isfile(path):
            file_bytes = os.path.getsize(path)
    except OSError:
        pass
    return {
        "tables": rows,
        "dbPath": path,
        "pageBytes": db_bytes,
        "fileBytes": file_bytes,
    }


def db_browse(
    store,
    table: str,
    limit: int = 50,
    offset: int = 0,
    mailbox: str = "",
    direction: str = "",
    q: str = "",
) -> dict[str, Any]:
    if table not in ADMIN_TABLES:
        raise ValueError("unknown_table")
    limit = max(1, min(int(limit), 200))
    offset = max(0, int(offset))
    mailbox = (mailbox or "").strip()
    direction = (direction or "").strip()
    q = (q or "").strip()

    where: list[str] = []
    args: list[Any] = []
    if table in ("relay_messages", "relay_archive") and mailbox:
        where.append("mailbox_id LIKE ?")
        args.append(f"{mailbox}%")
    if table in ("relay_messages", "relay_archive") and direction in ("to-host", "to-companion"):
        where.append("direction = ?")
        args.append(direction)
    if table in ("relay_messages", "relay_archive") and q:
        where.append("(message_id LIKE ? OR envelope_json LIKE ?)")
        args.extend([f"%{q}%", f"%{q}%"])
    if table == "push_tokens" and mailbox:
        where.append("mailbox_id LIKE ?")
        args.append(f"{mailbox}%")
    if table == "household_backups" and mailbox:
        where.append("mailbox_id LIKE ?")
        args.append(f"{mailbox}%")

    clause = (" WHERE " + " AND ".join(where)) if where else ""
    order = {
        "relay_messages": "created_at DESC",
        "relay_archive": "archive_id DESC",
        "push_tokens": "updated_at DESC",
        "household_backups": "updated_at DESC",
    }[table]

    with store.transaction() as database:
        total = database.execute(f"SELECT COUNT(*) FROM {table}{clause}", args).fetchone()[0]
        if table == "relay_messages":
            sql = f"""
                SELECT mailbox_id, direction, message_id, correlation_id, created_at, expires_at,
                       length(envelope_json) AS envelope_bytes,
                       substr(envelope_json, 1, 240) AS envelope_preview
                FROM relay_messages{clause}
                ORDER BY {order} LIMIT ? OFFSET ?
            """
        elif table == "relay_archive":
            sql = f"""
                SELECT archive_id, mailbox_id, direction, message_id, correlation_id, created_at, expires_at,
                       length(envelope_json) AS envelope_bytes,
                       substr(envelope_json, 1, 240) AS envelope_preview
                FROM relay_archive{clause}
                ORDER BY {order} LIMIT ? OFFSET ?
            """
        elif table == "push_tokens":
            sql = f"""
                SELECT mailbox_id, substr(token, 1, 16) || '…' AS token_prefix, platform, updated_at
                FROM push_tokens{clause}
                ORDER BY {order} LIMIT ? OFFSET ?
            """
        else:
            sql = f"""
                SELECT mailbox_id, updated_at, length(backup_json) AS backup_bytes
                FROM household_backups{clause}
                ORDER BY {order} LIMIT ? OFFSET ?
            """
        cur = database.execute(sql, [*args, limit, offset])
        columns = [d[0] for d in cur.description]
        items = [dict(zip(columns, row)) for row in cur.fetchall()]

    for item in items:
        mid = item.get("mailbox_id")
        if isinstance(mid, str) and len(mid) > 16:
            item["mailbox_prefix"] = mid[:12]
    return {
        "table": table,
        "total": int(total),
        "limit": limit,
        "offset": offset,
        "columns": columns,
        "items": items,
    }


def db_message_detail(store, table: str, message_id: str, mailbox: str = "") -> dict[str, Any] | None:
    if table not in ("relay_messages", "relay_archive"):
        raise ValueError("unsupported_table")
    message_id = (message_id or "").strip()
    if not message_id:
        return None
    with store.transaction() as database:
        if table == "relay_messages":
            sql = """
                SELECT mailbox_id, direction, message_id, correlation_id, created_at, expires_at, envelope_json
                FROM relay_messages WHERE message_id=?
            """
            args: list[Any] = [message_id]
            if mailbox:
                sql += " AND mailbox_id LIKE ?"
                args.append(f"{mailbox}%")
            sql += " LIMIT 1"
            row = database.execute(sql, args).fetchone()
            if not row:
                return None
            envelope = json.loads(row[6])
            return {
                "table": table,
                "mailbox_id": row[0],
                "mailbox_prefix": row[0][:12],
                "direction": row[1],
                "message_id": row[2],
                "correlation_id": row[3],
                "created_at": row[4],
                "expires_at": row[5],
                "envelope_bytes": len(row[6].encode("utf-8")),
                "envelope": _safe_envelope_view(envelope),
            }
        sql = """
            SELECT archive_id, mailbox_id, direction, message_id, correlation_id, created_at, expires_at, envelope_json
            FROM relay_archive WHERE message_id=?
        """
        args = [message_id]
        if mailbox:
            sql += " AND mailbox_id LIKE ?"
            args.append(f"{mailbox}%")
        sql += " ORDER BY archive_id DESC LIMIT 1"
        row = database.execute(sql, args).fetchone()
        if not row:
            return None
        envelope = json.loads(row[7])
        return {
            "table": table,
            "archive_id": row[0],
            "mailbox_id": row[1],
            "mailbox_prefix": row[1][:12],
            "direction": row[2],
            "message_id": row[3],
            "correlation_id": row[4],
            "created_at": row[5],
            "expires_at": row[6],
            "envelope_bytes": len(row[7].encode("utf-8")),
            "envelope": _safe_envelope_view(envelope),
        }


def _safe_envelope_view(envelope: dict) -> dict:
    view: dict[str, Any] = {"type": envelope.get("type"), "keys": sorted(envelope.keys())}
    for key in ("requestId", "sentAt", "correlationId"):
        if key in envelope:
            view[key] = envelope[key]
    delta = envelope.get("delta")
    if isinstance(delta, dict):
        changes = delta.get("changes")
        acks = delta.get("acknowledgedChanges") or delta.get("acknowledgements")
        view["delta"] = {
            "protocol": delta.get("protocol"),
            "schema": delta.get("schema"),
            "changesCount": len(changes) if isinstance(changes, list) else 0,
            "ackCount": len(acks) if isinstance(acks, list) else 0,
            "changeEntityTypes": _entity_type_histogram(changes) if isinstance(changes, list) else {},
        }
    raw = json.dumps(envelope, ensure_ascii=False, separators=(",", ":"))
    view["rawPreview"] = raw[:8_000] + ("…" if len(raw) > 8_000 else "")
    view["rawBytes"] = len(raw.encode("utf-8"))
    return view


def _entity_type_histogram(changes: list) -> dict[str, int]:
    hist: dict[str, int] = {}
    for item in changes:
        if not isinstance(item, dict):
            continue
        et = str(item.get("entityType") or "?")
        hist[et] = hist.get(et, 0) + 1
    return hist


def db_direction_breakdown(store) -> list[dict[str, Any]]:
    now_ms = int(time.time() * 1000)
    with store.transaction() as database:
        rows = database.execute(
            """
            SELECT direction, COUNT(*) AS cnt, MIN(created_at) AS oldest, MAX(created_at) AS newest
            FROM relay_messages
            WHERE expires_at > ?
            GROUP BY direction
            """,
            (now_ms,),
        ).fetchall()
    return [
        {"direction": r[0], "count": int(r[1]), "oldestAt": r[2], "newestAt": r[3]}
        for r in rows
    ]


def purge_expired(store) -> int:
    now_ms = int(time.time() * 1000)
    with store.transaction() as database:
        cur = database.execute("DELETE FROM relay_messages WHERE expires_at <= ?", (now_ms,))
        return int(cur.rowcount or 0)


def clear_pending(store, mailbox: str = "", direction: str = "") -> int:
    where = ["1=1"]
    args: list[Any] = []
    if mailbox:
        where.append("mailbox_id LIKE ?")
        args.append(f"{mailbox}%")
    if direction in ("to-host", "to-companion"):
        where.append("direction = ?")
        args.append(direction)
    sql = f"DELETE FROM relay_messages WHERE {' AND '.join(where)}"
    with store.transaction() as database:
        cur = database.execute(sql, args)
        return int(cur.rowcount or 0)
