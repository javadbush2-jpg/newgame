# اصلاح خطاهای کامپایل — alpha147

- پارامترهای `telegramBotToken` و `onSetTelegramBotToken` از فراخوانی `RelationshipScreen` برداشته شدند و به فراخوانی `SettingsScreen` منتقل شدند؛ فقط `SettingsScreen` این پارامترها را می‌پذیرد.
- import مربوط به `androidx.compose.runtime.setValue` اضافه شد تا متغیر `tokenDraft` در `remember { mutableStateOf(...) }` بتواند با `by` مقداردهی و تغییر کند.
- importهای لازم Compose برای فیلد توکن و دکمه‌ها در نسخه قبلی موجود بودند.
- این دو اصلاح مستقیماً خطاهای گزارش‌شده در `MainShell.kt` و `SettingsScreen.kt` را هدف می‌گیرند.
