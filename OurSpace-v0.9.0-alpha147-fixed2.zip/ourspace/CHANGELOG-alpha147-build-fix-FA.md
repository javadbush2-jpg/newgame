# اصلاح خطاهای کامپایل — alpha147

- انتقال پارامترهای `telegramBotToken` و `onSetTelegramBotToken` از فراخوانی `RelationshipScreen` به فراخوانی `SettingsScreen`.
- افزودن importهای Compose موردنیاز برای `Button`، `OutlinedTextField`، `remember` و `mutableStateOf`.
- جایگزینی آیکون ناموجود `EmojiEmotions` با آیکون `Share` که در همین فایل import شده است.
- این اصلاحات برای رفع خطاهای کامپایل گزارش‌شده انجام شده‌اند؛ ساخت کامل APK باید روی محیط توسعه با Gradle اجرا و تأیید شود.
