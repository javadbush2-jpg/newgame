package com.ourspace.app.core.webrtc

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/** Lightweight in-app sync health telemetry for the personal relay server. */
object ConnectionDiagnostics {
    enum class ConnectionState {
        DISCONNECTED, CONNECTING, CONNECTED, DEGRADED, RECONNECTING
    }

    data class Health(
        val state: ConnectionState = ConnectionState.DISCONNECTED,
        val lastSentAt: Long = 0L,
        val lastReceivedAt: Long = 0L,
        val lastAckAt: Long = 0L,
        val lastActivityAt: Long = 0L,
        val sentCount: Long = 0L,
        val receivedCount: Long = 0L,
        val ackCount: Long = 0L,
        val failedCount: Long = 0L,
        val lastLatencyMs: Long = -1L,
        val pushConnected: Boolean = false
    )

    private val _lines = MutableStateFlow<List<String>>(emptyList())
    val lines: StateFlow<List<String>> = _lines
    private val _health = MutableStateFlow(Health())
    val health: StateFlow<Health> = _health
    private val clock = SimpleDateFormat("HH:mm:ss", Locale.US)
    private val sentAtByMessage = LinkedHashMap<String, Long>()

    fun setState(state: ConnectionState) {
        _health.value = _health.value.copy(state = state)
    }

    fun setPushConnected(connected: Boolean) {
        val current = _health.value
        // اگر کانال فوری وصل شد، وضعیت قطع‌شده قدیمی را نگه ندار
        val nextState = when {
            connected && current.state != ConnectionState.CONNECTED -> ConnectionState.CONNECTED
            else -> current.state
        }
        _health.value = current.copy(pushConnected = connected, state = nextState)
    }

    fun touchActivity() {
        val now = System.currentTimeMillis()
        val current = _health.value
        // ترافیک واقعی (ارسال/دریافت) یعنی سرور در دسترس است — وضعیت UI را هم‌راستا کن
        val nextState = when (current.state) {
            ConnectionState.DISCONNECTED,
            ConnectionState.CONNECTING,
            ConnectionState.RECONNECTING,
            ConnectionState.DEGRADED -> ConnectionState.CONNECTED
            ConnectionState.CONNECTED -> ConnectionState.CONNECTED
        }
        _health.value = current.copy(lastActivityAt = now, state = nextState)
    }

    fun statusLabelFa(h: Health = _health.value): String {
        // بعد از ری‌استارت، اگر تازه ترافیک موفق بوده ولی state هنوز به‌روز نشده،
        // برچسب «قطع» نشان نده.
        val recentActivity = listOf(h.lastActivityAt, h.lastReceivedAt, h.lastSentAt, h.lastAckAt)
            .maxOrNull()
            ?.let { System.currentTimeMillis() - it < 120_000L } == true
        val effective = when {
            h.state == ConnectionState.CONNECTED -> ConnectionState.CONNECTED
            h.pushConnected -> ConnectionState.CONNECTED
            recentActivity && h.state != ConnectionState.CONNECTING -> ConnectionState.CONNECTED
            else -> h.state
        }
        return when (effective) {
            ConnectionState.CONNECTED ->
                if (h.pushConnected) "متصل • کانال فوری" else "متصل به سرور شخصی"
            ConnectionState.CONNECTING -> "در حال اتصال…"
            ConnectionState.RECONNECTING -> "در حال اتصال مجدد…"
            ConnectionState.DEGRADED -> "اتصال ناپایدار"
            ConnectionState.DISCONNECTED -> "سرور در دسترس نیست"
        }
    }

    fun detailLabelFa(h: Health = _health.value): String {
        val activity = listOf(h.lastActivityAt, h.lastReceivedAt, h.lastSentAt, h.lastAckAt).maxOrNull() ?: 0L
        val ago = if (activity > 0L) "آخرین فعالیت ${formatRelativeFa(activity)}" else "هنوز همگام‌سازی نشده"
        val queue = if (h.failedCount > 0) " • خطا: ${h.failedCount}" else ""
        val lat = if (h.lastLatencyMs >= 0) " • تأخیر ${h.lastLatencyMs}ms" else ""
        return ago + queue + lat
    }

    private fun formatRelativeFa(at: Long): String {
        val sec = ((System.currentTimeMillis() - at) / 1000L).coerceAtLeast(0)
        return when {
            sec < 15 -> "همین الان"
            sec < 60 -> "${sec} ثانیه پیش"
            sec < 3600 -> "${sec / 60} دقیقه پیش"
            sec < 86400 -> "${sec / 3600} ساعت پیش"
            else -> clock.format(Date(at))
        }
    }

    @Synchronized
    fun sent(messageId: String? = null) {
        val now = System.currentTimeMillis()
        messageId?.let { sentAtByMessage[it] = now }
        trimIds(now)
        val current = _health.value
        _health.value = current.copy(
            lastSentAt = now,
            lastActivityAt = now,
            sentCount = current.sentCount + 1,
            state = if (current.state != ConnectionState.CONNECTED) ConnectionState.CONNECTED else current.state
        )
    }

    @Synchronized
    fun received(messageId: String? = null) {
        val now = System.currentTimeMillis()
        val current = _health.value
        val latency = messageId?.let { sentAtByMessage.remove(it)?.let { stamp -> now - stamp } }
            ?: current.lastLatencyMs
        _health.value = current.copy(
            lastReceivedAt = now,
            lastActivityAt = now,
            receivedCount = current.receivedCount + 1,
            lastLatencyMs = latency,
            state = if (current.state != ConnectionState.CONNECTED) ConnectionState.CONNECTED else current.state
        )
    }

    fun ack(messageId: String? = null) {
        val now = System.currentTimeMillis()
        val current = _health.value
        val latency = messageId?.let { sentAtByMessage.remove(it)?.let { stamp -> now - stamp } }
            ?: current.lastLatencyMs
        _health.value = current.copy(
            lastAckAt = now,
            lastActivityAt = now,
            ackCount = current.ackCount + 1,
            lastLatencyMs = latency,
            state = if (current.state != ConnectionState.CONNECTED) ConnectionState.CONNECTED else current.state
        )
    }

    fun failed() {
        _health.value = _health.value.copy(failedCount = _health.value.failedCount + 1)
    }

    @Synchronized
    fun log(message: String) {
        val line = "${clock.format(Date())} $message"
        _lines.value = (_lines.value + line).takeLast(80)
    }

    fun clear() {
        _lines.value = emptyList()
        _health.value = Health()
        synchronized(this) { sentAtByMessage.clear() }
    }

    private fun trimIds(now: Long) {
        val iterator = sentAtByMessage.entries.iterator()
        while (iterator.hasNext()) {
            if (now - iterator.next().value > 120_000L) iterator.remove()
        }
        while (sentAtByMessage.size > 200) {
            val first = sentAtByMessage.keys.firstOrNull() ?: break
            sentAtByMessage.remove(first)
        }
    }
}
