package com.ourspace.app.core.relay

import com.ourspace.app.core.database.OurSpaceDatabase
import com.ourspace.app.core.sync.IncrementalSyncCodec
import com.ourspace.app.core.sync.SyncClient
import java.util.UUID
import kotlinx.coroutines.delay
import kotlinx.coroutines.withTimeout
import org.json.JSONObject

/**
 * HTTP mailbox exchange against the user-hosted Linux relay (personal relay only).
 * Companion publishes an incremental request to to-host; host poller answers on to-companion.
 */
object RelayInternetSync {
    private const val WAIT_MS = 45_000L
    private const val POLL_MS = 350L

    suspend fun exchange(
        accessToken: String,
        endpoint: String,
        database: OurSpaceDatabase
    ): SyncClient.Result {
        val credentials = RelayCredentials.fromAccessToken(accessToken)
        val relay = RelayClient(endpoint, credentials)
        val codec = IncrementalSyncCodec(database)
        val prepared = codec.prepareRequest()
        val requestId = UUID.randomUUID().toString()
        val outboundMessageId = UUID.randomUUID().toString().replace("-", "") + "req"
        // Ensure opaque id length stays within relay limits.
        val messageId = outboundMessageId.take(32).padEnd(16, '0')
        val request = JSONObject()
            .put("type", "incremental_exchange")
            .put("requestId", requestId)
            .put("sentAt", System.currentTimeMillis())
            .put("delta", prepared.payload)

        relay.publish(
            direction = RelayDirection.TO_HOST,
            envelope = request,
            correlationId = null,
            messageId = messageId
        )

        return withTimeout(WAIT_MS) {
            while (true) {
                val inbox = relay.receive(RelayDirection.TO_COMPANION, limit = 20, waitSeconds = 3)
                val match = inbox.firstOrNull { message ->
                    message.correlationId == messageId ||
                        message.envelope.optString("requestId") == requestId
                }
                if (match != null) {
                    val envelope = match.envelope
                    if (envelope.optBoolean("error")) {
                        throw IllegalStateException(
                            envelope.optString("message", "خطای همگام‌سازی از سرور شخصی")
                        )
                    }
                    val delta = envelope.optJSONObject("delta")
                        ?: throw IllegalStateException("پاسخ سرور شخصی بدون delta است")
                    val applied = codec.applyCompanionResponse(
                        response = delta,
                        sentAcknowledgementIds = prepared.sentAcknowledgementIds
                    )
                    relay.acknowledge(RelayDirection.TO_COMPANION, listOf(match.messageId))
                    return@withTimeout SyncClient.Result(
                        receivedItems = applied.receivedChanges,
                        sentItems = prepared.sentChangeCount,
                        acknowledgedItems = applied.acknowledgedLocalChanges,
                        transport = SyncClient.Transport.RELAY
                    )
                }
                delay(POLL_MS)
            }
            @Suppress("UNREACHABLE_CODE")
            error("unreachable")
        }
    }
}
