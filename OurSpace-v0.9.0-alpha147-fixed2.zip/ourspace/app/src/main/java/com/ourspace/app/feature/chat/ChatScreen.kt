package com.ourspace.app.feature.chat

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.gestures.scrollBy
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.automirrored.outlined.Send
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.EmojiEmotions
import androidx.compose.material.icons.outlined.AttachFile
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.MoreVert
import androidx.compose.material3.AlertDialog
import com.ourspace.app.ui.design.OSConfirmDialog
import com.ourspace.app.ui.design.OSFormDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.runtime.snapshotFlow
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch
import androidx.compose.ui.Alignment
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ourspace.app.core.database.AttachmentEntity

import com.airbnb.lottie.compose.LottieAnimation
import com.airbnb.lottie.compose.LottieCompositionSpec
import com.airbnb.lottie.compose.LottieConstants
import com.airbnb.lottie.compose.rememberLottieComposition
import com.ourspace.app.core.database.TelegramStickerEntity
import com.ourspace.app.core.database.TelegramStickerPackEntity
import com.ourspace.app.core.telegram.TelegramStickerClient
import java.util.zip.GZIPInputStream
import java.io.ByteArrayInputStream
import com.ourspace.app.core.database.MessageEntity
import com.ourspace.app.core.time.PersianDateFormatter
import com.ourspace.app.ui.AppViewModel
import com.ourspace.app.core.webrtc.ConnectionDiagnostics
import com.ourspace.app.core.webrtc.WebRtcSession
import androidx.compose.runtime.collectAsState

@Composable
fun ChatScreen(
    ownDeviceId: String,
    isPaired: Boolean,
    messages: List<MessageEntity>,
    attachments: List<AttachmentEntity>,
    syncState: AppViewModel.SyncState,
    attachmentAction: AppViewModel.AttachmentActionState,
    chatAction: AppViewModel.ChatActionState = AppViewModel.ChatActionState(),
    peerTyping: Boolean = false,
    pendingSendIds: Set<String> = emptySet(),
    onSend: suspend (String, String?) -> Boolean,
    onSendAttachment: (String, String?) -> Unit,
    onSaveAttachment: (String, String) -> Unit,
    onEdit: (MessageEntity, String) -> Unit,
    onDelete: (MessageEntity) -> Unit,
    onReact: (MessageEntity, String) -> Unit,
    onMarkVisibleRead: (List<String>) -> Unit = {},
    onTyping: (Boolean) -> Unit = {},
    onStampDeliveries: () -> Unit = {},
    onSearchMessages: suspend (String) -> List<MessageEntity> = { emptyList() },
    onFindMessage: suspend (String) -> MessageEntity? = { null },
    onLoadOlder: suspend (MessageEntity) -> Int,
    onLoadAttachment: suspend (String) -> AttachmentEntity? = { null },
    onSync: () -> Unit,
    telegramStickerPacks: List<TelegramStickerPackEntity> = emptyList(),
    stickerImportAction: AppViewModel.StickerImportActionState = AppViewModel.StickerImportActionState(),
    onImportTelegramPack: (String) -> Unit = {},
    onDeleteTelegramPack: (String) -> Unit = {},
    onLoadTelegramStickers: suspend (String) -> List<TelegramStickerEntity> = { emptyList() },
    onSendTelegramSticker: (String, String?) -> Unit = { _, _ -> }
) {
    if (!isPaired) {
        ChatLockedState()
        return
    }

    LaunchedEffect(messages.size) {
        onStampDeliveries()
    }

    val listState = rememberLazyListState()
    val chatScope = rememberCoroutineScope()
    var pendingScrollToId by remember { mutableStateOf<String?>(null) }
    var highlightMessageId by remember { mutableStateOf<String?>(null) }
    var draft by remember { mutableStateOf("") }
    var searchQuery by remember { mutableStateOf("") }
    var searchResults by remember { mutableStateOf<List<MessageEntity>?>(null) }
    var searchFailed by remember { mutableStateOf(false) }
    var showDeleteConfirmation by remember { mutableStateOf(false) }
    var pendingDeleteMessage by remember { mutableStateOf<MessageEntity?>(null) }
    var isSearching by remember { mutableStateOf(false) }
    var showSearch by remember { mutableStateOf(false) }
    val messageMap = remember(messages, searchResults) { (messages + searchResults.orEmpty()).associateBy { it.id } }
    var replyTo by remember { mutableStateOf<MessageEntity?>(null) }
    var selected by remember { mutableStateOf<MessageEntity?>(null) }
    var editing by remember { mutableStateOf<MessageEntity?>(null) }
    var selectedAttachment by remember { mutableStateOf<AttachmentEntity?>(null) }
    var pendingExport by remember { mutableStateOf<AttachmentEntity?>(null) }
    var resolvedQuotes by remember { mutableStateOf<Map<String, MessageEntity>>(emptyMap()) }
    val loadedMessageIds = remember(messages, searchResults) {
        (messages + searchResults.orEmpty()).mapTo(HashSet()) { it.id }
    }
    val attachmentsByMessage = remember(attachments, loadedMessageIds) {
        // Only index attachments for currently loaded/search-result messages; do not build a
        // second in-memory map for unrelated memories or older, unloaded chat pages.
        attachments.asSequence()
            .mapNotNull { attachment ->
                val messageId = attachment.messageId
                if (messageId != null && messageId in loadedMessageIds) messageId to attachment else null
            }
            .groupBy(keySelector = { it.first }, valueTransform = { it.second })
    }
    val attachmentPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri?.let {
            onSendAttachment(it.toString(), replyTo?.id)
            replyTo = null
        }
    }
    val attachmentSaver = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("*/*")
    ) { uri ->
        val attachment = pendingExport
        if (uri != null && attachment != null) onSaveAttachment(attachment.id, uri.toString())
        pendingExport = null
    }

    val visibleMessages = if (searchQuery.isBlank()) messages else searchResults.orEmpty()

    // لمس پیش‌نمایش ریپلای → اسکرول به پیام اصلی (در صورت نیاز با بارگذاری تاریخچهٔ قدیمی‌تر)
    LaunchedEffect(pendingScrollToId, visibleMessages.map { it.id }) {
        val targetId = pendingScrollToId ?: return@LaunchedEffect
        val index = visibleMessages.indexOfFirst { it.id == targetId }
        if (index >= 0) {
            listState.animateScrollToItem(index)
            highlightMessageId = targetId
            delay(1_400L)
            if (highlightMessageId == targetId) highlightMessageId = null
            pendingScrollToId = null
            return@LaunchedEffect
        }
        if (searchQuery.isNotBlank() || visibleMessages.isEmpty()) {
            pendingScrollToId = null
            return@LaunchedEffect
        }
        val added = onLoadOlder(visibleMessages.first())
        if (added <= 0) {
            pendingScrollToId = null
        }
    }

    LaunchedEffect(searchQuery) {
        val query = searchQuery.trim()
        if (query.isBlank()) {
            searchResults = null
            searchFailed = false
            isSearching = false
        } else {
            searchResults = emptyList()
            searchFailed = false
            isSearching = true
            delay(250)
            try {
                searchResults = onSearchMessages(query)
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (_: Exception) {
                searchFailed = true
            } finally {
                isSearching = false
            }
        }
    }
    LaunchedEffect(searchQuery, searchResults) {
        val results = searchResults
        if (searchQuery.isNotBlank() && !results.isNullOrEmpty()) {
            withFrameNanos { }
            // The list may have been cleared while waiting for the next frame.
            val itemCount = listState.layoutInfo.totalItemsCount
            if (itemCount > 0) {
                listState.scrollToItem(results.lastIndex.coerceIn(0, itemCount - 1))
            }
        }
    }
    LaunchedEffect(messages, searchResults) {
        val known = (messages + searchResults.orEmpty()).associateBy { it.id }
        val missingReplyIds = (messages + searchResults.orEmpty())
            .mapNotNull { it.replyToId }
            .distinct()
            .filter { it !in known && it !in resolvedQuotes }
        var resolved = resolvedQuotes
        for (id in missingReplyIds) {
            try {
                val found = onFindMessage(id)
                if (found != null && !found.isDeleted) resolved = resolved + (id to found)
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (_: Exception) {
                // Keep the conversation usable if a reply target cannot be loaded right now.
            }
        }
        resolvedQuotes = resolved
    }
    // Read receipts are only written for incoming messages that are actually visible.
    LaunchedEffect(listState, visibleMessages, ownDeviceId) {
        snapshotFlow { listState.layoutInfo.visibleItemsInfo.mapNotNull { it.key as? String } }
            .collect { visibleIds ->
                val ids = visibleIds.toSet()
                val unreadVisible = visibleMessages.asSequence()
                    .filter { it.id in ids && it.senderDeviceId != ownDeviceId && it.readAt == null }
                    .map { it.id }.toList()
                if (unreadVisible.isNotEmpty()) onMarkVisibleRead(unreadVisible)
            }
    }
    // Latest page is initially shown at the bottom. History loading is only triggered by
    // an actual user scroll to the top, never by the initial empty/top layout pass.
    var initialBottomDone by remember { mutableStateOf(false) }
    var lastRequestedOldestId by remember { mutableStateOf<String?>(null) }
    var isNearBottom by remember { mutableStateOf(true) }
    var unseenNewMessages by remember { mutableStateOf(0) }
    val lastVisibleId = visibleMessages.lastOrNull()?.id

    LaunchedEffect(lastVisibleId, searchQuery) {
        if (visibleMessages.isNotEmpty() && searchQuery.isBlank()) {
            if (!initialBottomDone) {
                withFrameNanos { }
                listState.scrollToItem(visibleMessages.lastIndex)
                initialBottomDone = true
                isNearBottom = true
                unseenNewMessages = 0
            } else if (lastVisibleId != null) {
                if (isNearBottom) {
                    listState.animateScrollToItem(visibleMessages.lastIndex)
                    unseenNewMessages = 0
                } else {
                    unseenNewMessages += 1
                }
            }
        }
    }

    LaunchedEffect(listState, visibleMessages.size, searchQuery, initialBottomDone) {
        snapshotFlow {
            val info = listState.layoutInfo
            val lastVisible = info.visibleItemsInfo.lastOrNull()?.index ?: -1
            val total = info.totalItemsCount
            val atBottom = total > 0 && lastVisible >= total - 2
            Triple(listState.firstVisibleItemIndex, listState.firstVisibleItemScrollOffset, atBottom)
        }.collect { (index, offset, atBottom) ->
            isNearBottom = atBottom
            if (initialBottomDone && searchQuery.isBlank() && listState.isScrollInProgress && index == 0 && visibleMessages.isNotEmpty()) {
                val oldest = visibleMessages.first()
                if (oldest.id != lastRequestedOldestId) {
                    lastRequestedOldestId = oldest.id
                    val added = onLoadOlder(oldest)
                    if (added > 0) {
                        withFrameNanos { }
                        listState.scrollToItem(added, offset)
                    }
                }
            }
        }
    }

    CompositionLocalProvider(LocalContentColor provides MaterialTheme.colorScheme.onSurface) {
    Column(
        // edge-to-edge: پنجره خودش با کیبورد جمع نمی‌شود؛ imePadding باکس تایپ را بالا می‌آورد.
        // نوار پایین در MainShell هنگام باز بودن کیبورد مخفی می‌شود تا فاصله اضافه نماند.
        Modifier
            .fillMaxSize()
            .imePadding()
    ) {
        val connectionHealth by ConnectionDiagnostics.health.collectAsState()
        val connectionLabel = remember(connectionHealth, peerTyping) {
            val base = ConnectionDiagnostics.statusLabelFa(connectionHealth)
            val webrtc = if (WebRtcSession.isOpen()) " · لینک مستقیم" else ""
            base + webrtc
        }
        // نوار وضعیت اتصال + همگام‌سازی و جست‌وجو
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 10.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                connectionLabel,
                style = MaterialTheme.typography.labelSmall,
                color = when (connectionHealth.state) {
                    ConnectionDiagnostics.ConnectionState.CONNECTED -> MaterialTheme.colorScheme.primary
                    ConnectionDiagnostics.ConnectionState.DEGRADED,
                    ConnectionDiagnostics.ConnectionState.RECONNECTING -> MaterialTheme.colorScheme.tertiary
                    else -> MaterialTheme.colorScheme.onSurfaceVariant
                },
                modifier = Modifier.weight(1f)
            )
            TextButton(onClick = onSync, contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)) {
                Text(
                    when {
                        syncState.isSyncing -> "همگام…"
                        else -> "همگام‌سازی"
                    },
                    style = MaterialTheme.typography.labelMedium
                )
            }
            TextButton(
                onClick = { showSearch = !showSearch; if (!showSearch) searchQuery = "" },
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
            ) {
                Text(if (showSearch) "بستن" else "جست‌وجو", style = MaterialTheme.typography.labelMedium)
            }
        }
        if (showSearch) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it.take(120) },
                modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 4.dp),
                singleLine = true,
                label = { Text("جست‌وجوی متن پیام‌ها") },
                placeholder = { Text("عبارت را بنویسید…") }
            )
        }
        if (messages.isEmpty()) {
            EmptyChat(modifier = Modifier.weight(1f))
        } else if (visibleMessages.isEmpty()) {
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                Text(
                    when {
                        searchFailed -> "جست‌وجو انجام نشد؛ دوباره تلاش کنید."
                        searchQuery.isNotBlank() && isSearching -> "در حال جست‌وجو…"
                        else -> "نتیجه‌ای برای این جست‌وجو نیست"
                    },
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        } else {
            Box(Modifier.weight(1f).fillMaxWidth()) {
            LazyColumn(
                state = listState,
                modifier = Modifier.fillMaxSize(),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(
                    start = 14.dp,
                    end = 14.dp,
                    top = 8.dp,
                    bottom = 12.dp
                ),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                itemsIndexed(visibleMessages, key = { _, message -> message.id }) { index, message ->
                    val currentDate = PersianDateFormatter.formatDate(message.createdAt)
                    val previousDate = visibleMessages.getOrNull(index - 1)?.let { PersianDateFormatter.formatDate(it.createdAt) }
                    if (index == 0 || currentDate != previousDate) {
                        Text(
                            currentDate,
                            modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    MessageBubble(
                        message = message,
                        quoted = message.replyToId?.let { messageMap[it] ?: resolvedQuotes[it] },
                        attachments = attachmentsByMessage[message.id].orEmpty(),
                        onLoadAttachment = onLoadAttachment,
                        isOwn = message.senderDeviceId == ownDeviceId,
                        isSending = message.id in pendingSendIds,
                        isHighlighted = message.id == highlightMessageId,
                        onClick = { selected = message },
                        onQuotedClick = message.replyToId?.let { replyId ->
                            { pendingScrollToId = replyId }
                        },
                        onAttachmentClick = { selectedAttachment = it }
                    )
                }
            }
            if (unseenNewMessages > 0 && !isNearBottom && searchQuery.isBlank()) {
                TextButton(
                    onClick = {
                        chatScope.launch { listState.animateScrollToItem((visibleMessages.size - 1).coerceAtLeast(0)) }
                        unseenNewMessages = 0
                        isNearBottom = true
                    },
                    modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 6.dp)
                ) { Text("پیام جدید: $unseenNewMessages") }
            }
            }
        }
        ChatComposer(
            draft = draft,
            replyTo = replyTo,
            onDraftChange = { draft = it.take(5_000) },
            attachmentAction = attachmentAction,
            chatAction = chatAction,
            peerTyping = peerTyping,
            onTyping = onTyping,
            onAttach = { attachmentPicker.launch("*/*") },
            onCancelReply = { replyTo = null },
            onSend = {
                if (draft.isNotBlank() && !chatAction.isSending) {
                    val outgoingText = draft
                    val replyId = replyTo?.id
                    chatScope.launch {
                        if (onSend(outgoingText, replyId)) {
                            draft = ""
                            replyTo = null
                        }
                    }
                }
            },
            onSendText = { text ->
                if (text.isNotBlank() && !chatAction.isSending) {
                    val replyId = replyTo?.id
                    chatScope.launch {
                        if (onSend(text.take(5_000), replyId)) {
                            draft = ""
                            replyTo = null
                        }
                    }
                }
            },
            telegramStickerPacks = telegramStickerPacks,
            stickerImportAction = stickerImportAction,
            onImportTelegramPack = onImportTelegramPack,
            onDeleteTelegramPack = onDeleteTelegramPack,
            onLoadTelegramStickers = onLoadTelegramStickers,
            onSendTelegramSticker = { id -> onSendTelegramSticker(id, replyTo?.id) },

        )
    }

    } // CompositionLocalProvider

    selectedAttachment?.let { attachment ->
        AttachmentDetailsDialog(
            attachment = attachment,
            onLoadAttachment = onLoadAttachment,
            isSaving = attachmentAction.isLoading,
            onDismiss = { selectedAttachment = null },
            onSaveCopy = {
                pendingExport = attachment
                selectedAttachment = null
                attachmentSaver.launch(attachment.fileName.replace('/', '_').replace('\\', '_'))
            }
        )
    }

    selected?.let { message ->
        MessageActionsDialog(
            message = message,
            isOwn = message.senderDeviceId == ownDeviceId,
            onDismiss = { selected = null },
            onReply = {
                replyTo = message
                selected = null
            },
            onReact = { reaction ->
                onReact(message, reaction)
                selected = null
            },
            onEdit = {
                editing = message
                selected = null
            },
            onDelete = {
                pendingDeleteMessage = message
                selected = null
                showDeleteConfirmation = true
            }
        )
    }


    if (showDeleteConfirmation) {
        OSConfirmDialog(
            title = "حذف پیام؟",
            message = "این پیام و پیوست‌های وابسته به آن از گفت‌وگو حذف می‌شوند. پس از همگام‌سازی، حذف به گوشی مقابل نیز منتقل خواهد شد.",
            confirmLabel = "حذف",
            dismissLabel = "انصراف",
            destructive = true,
            emoji = "💬",
            onConfirm = {
                pendingDeleteMessage?.let(onDelete)
                pendingDeleteMessage = null
                showDeleteConfirmation = false
            },
            onDismiss = { showDeleteConfirmation = false; pendingDeleteMessage = null }
        )
    }

    editing?.let { message ->
        EditMessageDialog(
            initialText = message.text,
            onDismiss = { editing = null },
            onSave = { newText ->
                onEdit(message, newText)
                editing = null
            }
        )
    }
}

@Composable
private fun MessageBubble(
    message: MessageEntity,
    quoted: MessageEntity?,
    attachments: List<AttachmentEntity>,
    onLoadAttachment: suspend (String) -> AttachmentEntity?,
    isOwn: Boolean,
    isSending: Boolean = false,
    isHighlighted: Boolean = false,
    onClick: () -> Unit,
    onQuotedClick: (() -> Unit)? = null,
    onAttachmentClick: (AttachmentEntity) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (isOwn) Arrangement.Start else Arrangement.End
    ) {
        Card(
            modifier = Modifier
                .widthIn(max = 320.dp)
                .clickable(onClick = onClick),
            shape = if (isOwn) {
                RoundedCornerShape(topStart = 10.dp, topEnd = 24.dp, bottomEnd = 24.dp, bottomStart = 24.dp)
            } else {
                RoundedCornerShape(topStart = 24.dp, topEnd = 10.dp, bottomEnd = 24.dp, bottomStart = 24.dp)
            },
            colors = CardDefaults.cardColors(
                containerColor = when {
                    isHighlighted -> MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.95f)
                    isOwn -> MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.92f)
                    else -> MaterialTheme.colorScheme.surfaceContainerHigh
                }
            ),
            elevation = CardDefaults.cardElevation(defaultElevation = if (isHighlighted) 2.dp else 0.dp)
        ) {
            Column(Modifier.padding(horizontal = 14.dp, vertical = 10.dp)) {
                if (message.replyToId != null) {
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(MaterialTheme.colorScheme.surfaceContainerLowest.copy(alpha = .75f))
                            .then(
                                if (onQuotedClick != null) {
                                    Modifier.clickable(onClick = onQuotedClick)
                                } else {
                                    Modifier
                                }
                            )
                            .padding(8.dp)
                    ) {
                        Column {
                            Text(
                                "پاسخ به",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.primary,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                quoted?.text?.ifBlank { "پیوست" } ?: "پیام اصلی حذف شده یا در دسترس نیست",
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis,
                                style = MaterialTheme.typography.bodySmall,
                                fontStyle = FontStyle.Italic,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                    Spacer(Modifier.size(7.dp))
                }
                attachments.forEach { attachment ->
                    AttachmentPreview(attachment, onLoadAttachment = onLoadAttachment, onClick = { onAttachmentClick(attachment) })
                    if (message.text.isNotBlank()) Spacer(Modifier.size(7.dp))
                }
                if (message.text.isNotBlank()) {
                    val shareCard = ChatShareCard.parse(message.text)
                    val onlyTgSticker = attachments.isNotEmpty() && attachments.all {
                        it.mimeType == TelegramStickerClient.MIME_TGS ||
                            (it.mimeType == "image/webp" && it.fileName.startsWith("tg_"))
                    } && isStickerOnlyMessage(message.text)
                    if (shareCard != null) {
                        ShareCardContent(shareCard)
                    } else if (!onlyTgSticker) {
                        val stickerLike = isStickerOnlyMessage(message.text)
                        Text(
                            message.text,
                            style = if (stickerLike) {
                                MaterialTheme.typography.displaySmall.copy(fontSize = 44.sp, lineHeight = 52.sp)
                            } else {
                                MaterialTheme.typography.bodyLarge
                            },
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
                Row(
                    modifier = Modifier.padding(top = 5.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (message.editedAt != null) {
                        Text("ویرایش‌شده • ", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Text(
                        PersianDateFormatter.formatTime(message.createdAt),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    if (isOwn) {
                        val (statusText, statusColor) = when {
                            isSending -> "  …" to MaterialTheme.colorScheme.onSurfaceVariant
                            message.readAt != null -> "  ✓✓" to MaterialTheme.colorScheme.primary
                            message.deliveredAt != null -> "  ✓✓" to MaterialTheme.colorScheme.onSurfaceVariant
                            else -> "  ✓" to MaterialTheme.colorScheme.onSurfaceVariant
                        }
                        Text(
                            statusText,
                            style = MaterialTheme.typography.labelSmall,
                            color = statusColor
                        )
                    }
                }
                val reactions = listOfNotNull(message.reaction, message.reaction2)
                if (reactions.isNotEmpty()) {
                    Row(
                        modifier = Modifier.padding(top = 4.dp).clip(CircleShape)
                            .background(MaterialTheme.colorScheme.surface).padding(horizontal = 8.dp, vertical = 3.dp),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        reactions.forEach { reaction -> Text(reaction) }
                    }
                }
            }
        }
    }
}

@Composable
private fun AttachmentPreview(
    attachment: AttachmentEntity,
    onLoadAttachment: suspend (String) -> AttachmentEntity?,
    onClick: () -> Unit
) {
    val isTgs = attachment.mimeType == TelegramStickerClient.MIME_TGS
    val isStickerFile = isTgs || (
        attachment.mimeType == "image/webp" && attachment.fileName.startsWith("tg_")
    )

    if (isTgs) {
        val lottieJson by produceState<String?>(initialValue = null, attachment.id, attachment.sha256) {
            val full = onLoadAttachment(attachment.id)
            val bytes = full?.content
            value = if (bytes != null && bytes.isNotEmpty()) {
                withContext(Dispatchers.Default) {
                    runCatching {
                        GZIPInputStream(ByteArrayInputStream(bytes)).use { it.readBytes() }.decodeToString()
                    }.getOrNull()
                }
            } else null
        }
        val json = lottieJson
        if (json != null) {
            val composition by rememberLottieComposition(LottieCompositionSpec.JsonString(json))
            LottieAnimation(
                composition = composition,
                iterations = LottieConstants.IterateForever,
                modifier = Modifier
                    .size(180.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .clickable(onClick = onClick)
            )
        } else {
            Text("🎬 استیکر انیمیشنی", style = MaterialTheme.typography.bodyMedium)
        }
        return
    }

    val preview by produceState<Bitmap?>(initialValue = null, attachment.id, attachment.sha256) {
        value = if (attachment.mimeType.startsWith("image/")) {
            val full = onLoadAttachment(attachment.id)
            val bytes = full?.content
            if (bytes != null && bytes.isNotEmpty()) {
                withContext(Dispatchers.Default) { decodeAttachmentPreview(bytes) }
            } else null
        } else null
    }
    val previewBitmap = preview
    if (previewBitmap != null) {
        Column {
            Image(
                bitmap = previewBitmap.asImageBitmap(),
                contentDescription = attachment.fileName,
                contentScale = if (isStickerFile) ContentScale.Fit else ContentScale.Crop,
                modifier = if (isStickerFile) {
                    Modifier.size(180.dp).clip(RoundedCornerShape(16.dp)).clickable(onClick = onClick)
                } else {
                    Modifier.fillMaxWidth().widthIn(max = 280.dp).aspectRatio(4f / 3f)
                        .clip(RoundedCornerShape(14.dp)).clickable(onClick = onClick)
                }
            )
            if (!isStickerFile) {
                Text(
                    "${attachment.fileName} • ${formatAttachmentSize(attachment.sizeBytes)}",
                    style = MaterialTheme.typography.labelSmall,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(top = 5.dp)
                )
            }
        }
    } else {
        Row(
            modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).clickable(onClick = onClick)
                .background(MaterialTheme.colorScheme.surface.copy(alpha = .7f)).padding(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Outlined.AttachFile, null, modifier = Modifier.size(30.dp))
            Column(Modifier.weight(1f).padding(start = 9.dp)) {
                Text(attachment.fileName, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Bold)
                Text(
                    "${formatAttachmentSize(attachment.sizeBytes)} • ${attachment.mimeType}",
                    style = MaterialTheme.typography.labelSmall,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

private fun decodeAttachmentPreview(bytes: ByteArray): Bitmap? = runCatching {
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
    var sample = 1
    while (bounds.outWidth / sample > 1_024 || bounds.outHeight / sample > 1_024) sample *= 2
    BitmapFactory.decodeByteArray(
        bytes,
        0,
        bytes.size,
        BitmapFactory.Options().apply { inSampleSize = sample.coerceAtLeast(1) }
    )
}.getOrNull()

private fun isTelegramStickerMime(mime: String): Boolean =
    mime == TelegramStickerClient.MIME_TGS || mime == "image/webp"

private fun isStickerOnlyMessage(text: String): Boolean {
    val t = text.trim()
    if (t.isEmpty() || t.length > 16) return false
    val cps = t.codePoints().toArray()
    if (cps.size > 8) return false
    return cps.all { cp ->
        cp in 0x1F300..0x1FAFF ||
            cp in 0x2600..0x27BF ||
            cp in 0x1F600..0x1F64F ||
            cp in 0x1F680..0x1F6FF ||
            cp in 0xFE00..0xFE0F ||
            cp == 0x200D ||
            cp == 0x2764 ||
            cp == 0x2665
    }
}

private fun formatAttachmentSize(bytes: Long): String {
    val value = when {
        bytes >= 1024 * 1024 -> "${bytes / (1024 * 1024)} مگابایت"
        bytes >= 1024 -> "${bytes / 1024} کیلوبایت"
        else -> "$bytes بایت"
    }
    return PersianDateFormatter.toPersianDigits(value)
}

@Composable
private fun AttachmentDetailsDialog(
    attachment: AttachmentEntity,
    onLoadAttachment: suspend (String) -> AttachmentEntity?,
    isSaving: Boolean,
    onDismiss: () -> Unit,
    onSaveCopy: () -> Unit
) {
    var showFullscreen by remember(attachment.id) { mutableStateOf(false) }
    val preview by produceState<Bitmap?>(initialValue = null, attachment.id, attachment.sha256) {
        value = if (attachment.mimeType.startsWith("image/")) {
            val full = onLoadAttachment(attachment.id)
            val bytes = full?.content
            if (bytes != null && bytes.isNotEmpty()) {
                withContext(Dispatchers.Default) { decodeAttachmentPreview(bytes) }
            } else null
        } else null
    }
    OSFormDialog(
        title = attachment.fileName,
        emoji = "📎",
        onDismiss = onDismiss,
        onConfirm = onSaveCopy,
        confirmLabel = "ذخیره نسخه",
        confirmEnabled = !isSaving,
        dismissLabel = "بستن"
    ) {

                val previewBitmap = preview
                if (previewBitmap != null) {
                    Image(
                        bitmap = previewBitmap.asImageBitmap(),
                        contentDescription = attachment.fileName,
                        contentScale = ContentScale.Fit,
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 260.dp, max = 480.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .clickable { showFullscreen = true }
                    )
                    Text(
                        "برای نمایش کامل لمس کنید",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                } else {
                    Box(
                        Modifier.fillMaxWidth().background(
                            MaterialTheme.colorScheme.surfaceVariant,
                            RoundedCornerShape(16.dp)
                        ).padding(22.dp),
                        contentAlignment = Alignment.Center
                    ) { Icon(Icons.Outlined.AttachFile, null, modifier = Modifier.size(48.dp)) }
                }
                Text("حجم: ${formatAttachmentSize(attachment.sizeBytes)}")
                Text(
                    "نوع: ${attachment.mimeType}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    "پیش از ذخیره، اندازه و اثر انگشت SHA-256 دوباره بررسی می‌شود.",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.primary
                )
    }
    if (showFullscreen && preview != null) {
        ChatFullscreenImageViewer(
            bitmap = preview!!,
            fileName = attachment.fileName,
            onDismiss = { showFullscreen = false }
        )
    }
}

@Composable
private fun ChatFullscreenImageViewer(
    bitmap: Bitmap,
    fileName: String,
    onDismiss: () -> Unit
) {
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(
            usePlatformDefaultWidth = false,
            decorFitsSystemWindows = true,
            dismissOnBackPress = true,
            dismissOnClickOutside = false
        )
    ) {
        Box(
            Modifier
                .fillMaxSize()
                .background(Color.Black)
        ) {
            Image(
                bitmap = bitmap.asImageBitmap(),
                contentDescription = fileName,
                contentScale = ContentScale.Fit,
                modifier = Modifier
                    .fillMaxSize()
                    .padding(top = 56.dp, bottom = 24.dp)
                    .clickable(onClick = onDismiss)
            )
            Row(
                Modifier
                    .fillMaxWidth()
                    .background(Color.Black.copy(alpha = 0.55f))
                    .padding(horizontal = 4.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onDismiss) {
                    Icon(
                        Icons.AutoMirrored.Outlined.ArrowBack,
                        contentDescription = "بازگشت",
                        tint = Color.White
                    )
                }
                Text(
                    fileName,
                    color = Color.White,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}

@Composable
private fun ChatComposer(
    draft: String,
    replyTo: MessageEntity?,
    attachmentAction: AppViewModel.AttachmentActionState,
    chatAction: AppViewModel.ChatActionState,
    peerTyping: Boolean = false,
    onDraftChange: (String) -> Unit,
    onTyping: (Boolean) -> Unit = {},
    onAttach: () -> Unit,
    onCancelReply: () -> Unit,
    onSend: () -> Unit,
    onSendText: (String) -> Unit = {},
    telegramStickerPacks: List<TelegramStickerPackEntity> = emptyList(),
    stickerImportAction: AppViewModel.StickerImportActionState = AppViewModel.StickerImportActionState(),
    onImportTelegramPack: (String) -> Unit = {},
    onDeleteTelegramPack: (String) -> Unit = {},
    onLoadTelegramStickers: suspend (String) -> List<TelegramStickerEntity> = { emptyList() },
    onSendTelegramSticker: (String) -> Unit = {}
) {
    var showStickers by remember { mutableStateOf(false) }

    // Typing presence: notify peer while drafting; auto-clear after idle.
    LaunchedEffect(draft) {
        if (draft.isBlank()) {
            onTyping(false)
        } else {
            onTyping(true)
            kotlinx.coroutines.delay(1_600)
            onTyping(false)
        }
    }
    DisposableEffect(Unit) {
        onDispose { onTyping(false) }
    }
    val stickerPacks = remember { StickerCatalog.packs }

    Column(
        Modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.96f))
            .padding(horizontal = 10.dp, vertical = 4.dp)
    ) {
        if (replyTo != null) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.10f))
                    .padding(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    Icons.AutoMirrored.Outlined.ArrowBack,
                    null,
                    modifier = Modifier.size(18.dp),
                    tint = MaterialTheme.colorScheme.primary
                )
                Text(
                    replyTo.text.ifBlank { "پیوست" },
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f).padding(horizontal = 8.dp),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurface
                )
                IconButton(onClick = onCancelReply, modifier = Modifier.size(28.dp)) {
                    Icon(Icons.Outlined.Close, "لغو پاسخ", modifier = Modifier.size(17.dp))
                }
            }
            Spacer(Modifier.size(8.dp))
        }
        attachmentAction.message?.let {
            Text(
                it,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(bottom = 4.dp)
            )
        }
        attachmentAction.error?.let {
            Text(
                it,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.error,
                modifier = Modifier.padding(bottom = 4.dp)
            )
        }
        chatAction.message?.let {
            Text(it, style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(bottom = 4.dp))
        }
        chatAction.error?.let {
            Text(it, style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(bottom = 4.dp))
        }

        if (peerTyping) {
            Text(
                "در حال نوشتن…",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(bottom = 6.dp, start = 4.dp)
            )
        }

        // Telegram-like order (forced LTR): [sticker] [text field] [attach] [send]
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            Row(
                verticalAlignment = Alignment.Bottom,
                modifier = Modifier.fillMaxWidth()
            ) {
                IconButton(
                    onClick = { showStickers = !showStickers },
                    modifier = Modifier
                        .size(46.dp)
                        .background(
                            if (showStickers) MaterialTheme.colorScheme.primary.copy(alpha = 0.16f)
                            else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.75f),
                            CircleShape
                        )
                ) {
                    Icon(
                        Icons.Outlined.EmojiEmotions,
                        contentDescription = "استیکر و شکلک",
                        tint = if (showStickers) MaterialTheme.colorScheme.primary
                        else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Spacer(Modifier.size(6.dp))
                OutlinedTextField(
                    value = draft,
                    onValueChange = onDraftChange,
                    modifier = Modifier.weight(1f),
                    placeholder = { Text("پیام بنویسید…") },
                    maxLines = 5,
                    shape = RoundedCornerShape(26.dp)
                )
                Spacer(Modifier.size(6.dp))
                // Attachment sits left of Send — Telegram style
                IconButton(
                    onClick = {
                        showStickers = false
                        onAttach()
                    },
                    enabled = !attachmentAction.isLoading,
                    modifier = Modifier
                        .size(46.dp)
                        .background(
                            MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.75f),
                            CircleShape
                        )
                ) {
                    Icon(
                        Icons.Outlined.AttachFile,
                        contentDescription = "پیوست فایل یا تصویر",
                        tint = MaterialTheme.colorScheme.primary
                    )
                }
                Spacer(Modifier.size(4.dp))
                IconButton(
                    onClick = {
                        showStickers = false
                        onSend()
                    },
                    enabled = draft.isNotBlank() && !chatAction.isSending,
                    modifier = Modifier
                        .size(50.dp)
                        .background(
                            if (draft.isNotBlank()) MaterialTheme.colorScheme.primary
                            else MaterialTheme.colorScheme.surfaceVariant,
                            CircleShape
                        )
                ) {
                    Icon(
                        Icons.AutoMirrored.Outlined.Send,
                        contentDescription = "ارسال",
                        tint = if (draft.isNotBlank()) MaterialTheme.colorScheme.onPrimary
                        else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        if (showStickers) {
            Spacer(Modifier.size(10.dp))
            StickerPickerPanel(
                emojiPacks = stickerPacks,
                telegramPacks = telegramStickerPacks,
                stickerImportAction = stickerImportAction,
                onPickEmoji = { sticker ->
                    onSendText(sticker)
                    showStickers = false
                },
                onInsertEmoji = { emoji ->
                    onDraftChange(draft + emoji)
                },
                onImportTelegramPack = onImportTelegramPack,
                onDeleteTelegramPack = onDeleteTelegramPack,
                onLoadTelegramStickers = onLoadTelegramStickers,
                onSendTelegramSticker = { id ->
                    onSendTelegramSticker(id)
                    showStickers = false
                }
            )
        }
    }
}


@Composable
private fun ShareCardContent(card: ChatShareCard.Card) {
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.55f))
            .padding(10.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Text(
            "${card.type.emoji} ${card.type.label}",
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.primary,
            fontWeight = FontWeight.SemiBold
        )
        Text(
            card.title,
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface
        )
        card.subtitle?.takeIf { it.isNotBlank() }?.let {
            Text(
                it,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

/** Curated sticker / emoji packs for the private couple chat (no network). */
private object StickerCatalog {
    data class Pack(val title: String, val items: List<String>)

    val packs: List<Pack> = listOf(
        Pack(
            "عاشقانه",
            listOf(
                "❤️", "💕", "💖", "💗", "💓", "💞", "💘", "💝", "😍", "🥰",
                "😘", "💋", "🌹", "🌷", "💍", "🤍", "💌", "🔥"
            )
        ),
        Pack(
            "احساس",
            listOf(
                "😊", "😂", "🥺", "😢", "😅", "🤗", "😌", "😎", "🤔", "😴",
                "🤤", "😏", "😇", "🤩", "😤", "🤦", "🙌", "👍"
            )
        ),
        Pack(
            "روزمره",
            listOf(
                "☕", "🍰", "🍕", "🏠", "🌙", "☀️", "🌧️", "🌸", "🎵", "📱",
                "✈️", "🎁", "🎂", "🐶", "🐱", "✨", "⭐", "🌟"
            )
        ),
        Pack(
            "استیکر",
            listOf(
                "🫶", "🙈", "🙉", "🙊", "🐱‍👤", "🐼", "🦋", "🍀", "🌈", "🍑",
                "🍓", "🥂", "🧸", "💤", "🫡", "🫠", "😈", "👻"
            )
        )
    )
}

@Composable
private fun StickerPickerPanel(
    emojiPacks: List<StickerCatalog.Pack>,
    telegramPacks: List<TelegramStickerPackEntity>,
    stickerImportAction: AppViewModel.StickerImportActionState,
    onPickEmoji: (String) -> Unit,
    onInsertEmoji: (String) -> Unit,
    onImportTelegramPack: (String) -> Unit,
    onDeleteTelegramPack: (String) -> Unit,
    onLoadTelegramStickers: suspend (String) -> List<TelegramStickerEntity>,
    onSendTelegramSticker: (String) -> Unit
) {
    var tab by remember { mutableStateOf(0) } // 0=emoji 1=telegram
    var packIndex by remember { mutableStateOf(0) }
    var importDraft by remember { mutableStateOf("") }
    var selectedTgPack by remember { mutableStateOf(telegramPacks.firstOrNull()?.name) }
    var tgStickers by remember { mutableStateOf<List<TelegramStickerEntity>>(emptyList()) }

    LaunchedEffect(selectedTgPack, telegramPacks) {
        val name = selectedTgPack
        tgStickers = if (name.isNullOrBlank()) emptyList() else onLoadTelegramStickers(name)
    }

    Column(
        Modifier
            .fillMaxWidth()
            .height(280.dp)
            .clip(RoundedCornerShape(20.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f))
            .padding(10.dp)
    ) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("ایموجی", "تلگرام").forEachIndexed { i, label ->
                val selected = tab == i
                Text(
                    text = label,
                    modifier = Modifier
                        .clip(RoundedCornerShape(14.dp))
                        .background(
                            if (selected) MaterialTheme.colorScheme.primary.copy(alpha = 0.18f)
                            else MaterialTheme.colorScheme.surface.copy(alpha = 0.7f)
                        )
                        .clickable { tab = i }
                        .padding(horizontal = 14.dp, vertical = 8.dp),
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                    color = if (selected) MaterialTheme.colorScheme.primary
                    else MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        Spacer(Modifier.size(8.dp))

        if (tab == 0) {
            val pack = emojiPacks.getOrElse(packIndex) { emojiPacks.first() }
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                items(emojiPacks.size) { index ->
                    val selected = index == packIndex
                    Text(
                        text = emojiPacks[index].title,
                        modifier = Modifier
                            .clip(RoundedCornerShape(14.dp))
                            .background(
                                if (selected) MaterialTheme.colorScheme.primary.copy(alpha = 0.18f)
                                else MaterialTheme.colorScheme.surface.copy(alpha = 0.7f)
                            )
                            .clickable { packIndex = index }
                            .padding(horizontal = 12.dp, vertical = 6.dp),
                        style = MaterialTheme.typography.labelMedium,
                        color = if (selected) MaterialTheme.colorScheme.primary
                        else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            Spacer(Modifier.size(6.dp))
            Text(
                "لمس کوتاه = ارسال  ·  لمس بلند = اضافه به متن",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            LazyColumn(verticalArrangement = Arrangement.spacedBy(4.dp), modifier = Modifier.fillMaxWidth().weight(1f)) {
                val rows = pack.items.chunked(6)
                items(rows.size) { rowIndex ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                        rows[rowIndex].forEach { sticker ->
                            Text(
                                text = sticker,
                                fontSize = 28.sp,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(12.dp))
                                    .pointerInput(sticker) {
                                        detectTapGestures(
                                            onTap = { onPickEmoji(sticker) },
                                            onLongPress = { onInsertEmoji(sticker) }
                                        )
                                    }
                                    .padding(8.dp)
                            )
                        }
                    }
                }
            }
        } else {
            // Telegram import + packs
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                OutlinedTextField(
                    value = importDraft,
                    onValueChange = { importDraft = it },
                    modifier = Modifier.weight(1f),
                    placeholder = { Text("لینک یا نام پک…") },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    enabled = !stickerImportAction.isLoading
                )
                Spacer(Modifier.size(6.dp))
                Button(
                    onClick = {
                        val v = importDraft.trim()
                        if (v.isNotEmpty()) onImportTelegramPack(v)
                    },
                    enabled = importDraft.isNotBlank() && !stickerImportAction.isLoading
                ) {
                    Text(if (stickerImportAction.isLoading) "…" else "ورود")
                }
            }
            stickerImportAction.message?.let {
                Text(it, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
            }
            stickerImportAction.error?.let {
                Text(it, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.error)
            }
            if (telegramPacks.isNotEmpty()) {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth().padding(top = 6.dp)) {
                    items(telegramPacks.size) { index ->
                        val p = telegramPacks[index]
                        val selected = p.name == selectedTgPack
                        Text(
                            text = p.title,
                            modifier = Modifier
                                .clip(RoundedCornerShape(14.dp))
                                .background(
                                    if (selected) MaterialTheme.colorScheme.primary.copy(alpha = 0.18f)
                                    else MaterialTheme.colorScheme.surface.copy(alpha = 0.7f)
                                )
                                .clickable { selectedTgPack = p.name }
                                .padding(horizontal = 12.dp, vertical = 6.dp),
                            style = MaterialTheme.typography.labelMedium,
                            color = if (selected) MaterialTheme.colorScheme.primary
                            else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            } else {
                Text(
                    "هنوز پکی وارد نشده. لینک مثل t.me/addstickers/Cats را بچسبان.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 8.dp)
                )
            }
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(4.dp),
                modifier = Modifier.fillMaxWidth().weight(1f).padding(top = 6.dp)
            ) {
                val rows = tgStickers.chunked(5)
                items(rows.size) { rowIndex ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                        rows[rowIndex].forEach { st ->
                            TelegramStickerThumb(
                                sticker = st,
                                onClick = { onSendTelegramSticker(st.id) }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun TelegramStickerThumb(
    sticker: TelegramStickerEntity,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .size(56.dp)
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(2.dp),
        contentAlignment = Alignment.Center
    ) {
        if (sticker.isAnimated || sticker.mimeType == TelegramStickerClient.MIME_TGS) {
            val jsonBytes = remember(sticker.id) {
                runCatching {
                    GZIPInputStream(ByteArrayInputStream(sticker.content)).use { it.readBytes() }
                }.getOrNull()
            }
            if (jsonBytes != null) {
                val composition by rememberLottieComposition(
                    LottieCompositionSpec.JsonString(jsonBytes.decodeToString())
                )
                LottieAnimation(
                    composition = composition,
                    iterations = LottieConstants.IterateForever,
                    modifier = Modifier.fillMaxSize()
                )
            } else {
                Text(sticker.emoji, fontSize = 28.sp)
            }
        } else {
            val bitmap = remember(sticker.id) {
                runCatching {
                    android.graphics.BitmapFactory.decodeByteArray(sticker.content, 0, sticker.content.size)
                }.getOrNull()
            }
            if (bitmap != null) {
                androidx.compose.foundation.Image(
                    bitmap = bitmap.asImageBitmap(),
                    contentDescription = sticker.emoji,
                    modifier = Modifier.fillMaxSize()
                )
            } else {
                Text(sticker.emoji, fontSize = 28.sp)
            }
        }
    }
}


@Composable
private fun MessageActionsDialog(
    message: MessageEntity,
    isOwn: Boolean,
    onDismiss: () -> Unit,
    onReply: () -> Unit,
    onReact: (String) -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    OSFormDialog(
        title = "گزینه‌های پیام",
        emoji = "💬",
        onDismiss = onDismiss,
        onConfirm = onDismiss,
        confirmLabel = "بستن",
        showDismissButton = false
    ) {

                Text(message.text.ifBlank { "پیام دارای پیوست" }, maxLines = 3, overflow = TextOverflow.Ellipsis)
                HorizontalDivider(Modifier.padding(vertical = 12.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    listOf("❤️", "👍", "😂", "👏").forEach { reaction ->
                        Text(
                            reaction,
                            modifier = Modifier.clip(CircleShape).clickable { onReact(reaction) }.padding(10.dp)
                        )
                    }
                }
                TextButton(onClick = onReply, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.AutoMirrored.Outlined.ArrowBack, null)
                    Text("پاسخ به پیام", modifier = Modifier.padding(start = 8.dp))
                }
                if (isOwn) {
                    if (message.text.isNotBlank()) {
                        TextButton(onClick = onEdit, modifier = Modifier.fillMaxWidth()) {
                            Icon(Icons.Outlined.Edit, null)
                            Text("ویرایش", modifier = Modifier.padding(start = 8.dp))
                        }
                    }
                    TextButton(onClick = onDelete, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Outlined.Delete, null, tint = MaterialTheme.colorScheme.error)
                        Text("حذف", color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(start = 8.dp))
                    }
                }
    }
}

@Composable
private fun EditMessageDialog(
    initialText: String,
    onDismiss: () -> Unit,
    onSave: (String) -> Unit
) {
    var value by remember(initialText) { mutableStateOf(initialText) }
    OSFormDialog(
        title = "ویرایش پیام",
        emoji = "✏️",
        onDismiss = onDismiss,
        onConfirm = { onSave(value) },
        confirmLabel = "ذخیره",
        confirmEnabled = value.isNotBlank()
    ) {
        OutlinedTextField(
            value = value,
            onValueChange = { value = it.take(5_000) },
            modifier = Modifier.fillMaxWidth(),
            maxLines = 5
        )
    }
}

@Composable
private fun EmptyChat(modifier: Modifier = Modifier) {
    Column(
        modifier.fillMaxSize().padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            Modifier.size(104.dp).background(
                brush = androidx.compose.ui.graphics.Brush.linearGradient(
                    listOf(
                        MaterialTheme.colorScheme.primaryContainer,
                        MaterialTheme.colorScheme.tertiaryContainer
                    )
                ),
                shape = CircleShape
            ),
            contentAlignment = Alignment.Center
        ) {
            Text("💬", style = MaterialTheme.typography.displaySmall)
        }
        Text(
            "اولین پیام را بفرستید",
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Black,
            modifier = Modifier.padding(top = 20.dp)
        )
        Text(
            "این گفتگو فقط بین دو دستگاه مورد اعتماد همگام می‌شود — رمزنگاری‌شده و خصوصی.",
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            style = MaterialTheme.typography.bodyMedium,
            modifier = Modifier.padding(top = 8.dp)
        )
    }
}

@Composable
private fun ChatLockedState() {
    Column(
        Modifier.fillMaxSize().padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(Icons.Outlined.Lock, null, modifier = Modifier.size(68.dp), tint = MaterialTheme.colorScheme.primary)
        Text("ابتدا دو گوشی را متصل کنید", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Black, modifier = Modifier.padding(top = 18.dp))
        Text("بعد از تأیید جفت‌سازی، گفتگوی خصوصی فعال می‌شود.", color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
