package com.ourspace.app.feature.games

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp

private enum class TwoPlayerGame(val label: String) {
    TIC_TAC_TOE("دوز"),
    CONNECT_FOUR("چهار در یک خط"),
    ROCK_PAPER_SCISSORS("سنگ، کاغذ، قیچی")
}

@Composable
fun GamesScreen() {
    var selectedGame by remember { mutableStateOf(TwoPlayerGame.TIC_TAC_TOE) }

    Column(Modifier.fillMaxSize()) {
        Column(Modifier.padding(horizontal = 16.dp, vertical = 10.dp)) {
            Text("بازی‌ها", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Black)
            Text(
                "چند بازی دونفرهٔ نوبتی برای بازی روی یک گوشی",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(top = 2.dp)
            )
            Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(top = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                TwoPlayerGame.values().forEach { game ->
                    FilterChip(
                        selected = selectedGame == game,
                        onClick = { selectedGame = game },
                        label = { Text(game.label, maxLines = 1) }
                    )
                }
            }
        }
        when (selectedGame) {
            TwoPlayerGame.TIC_TAC_TOE -> TicTacToeGame(Modifier.weight(1f).fillMaxWidth())
            TwoPlayerGame.CONNECT_FOUR -> ConnectFourGame(Modifier.weight(1f).fillMaxWidth())
            TwoPlayerGame.ROCK_PAPER_SCISSORS -> RockPaperScissorsGame(Modifier.weight(1f).fillMaxWidth())
        }
    }
}

@Composable
private fun TicTacToeGame(modifier: Modifier = Modifier) {
    var board by remember { mutableStateOf(List(9) { 0 }) }
    var currentPlayer by remember { mutableIntStateOf(1) }
    val winner = remember(board) { ticTacToeWinner(board) }
    val isDraw = winner == 0 && board.none { it == 0 }

    LazyColumn(
        modifier = modifier,
        contentPadding = PaddingValues(horizontal = 18.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            GameStatusCard(
                title = when {
                    winner != 0 -> "بازیکن ${winnerFa(winner)} برنده شد!"
                    isDraw -> "بازی مساوی شد"
                    else -> "نوبت بازیکن ${winnerFa(currentPlayer)}"
                },
                subtitle = "سه خانهٔ پشت‌سرهم را افقی، عمودی یا مورب پر کنید."
            )
        }
        item {
            Card(
                Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(28.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow)
            ) {
                Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    repeat(3) { rowIndex ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            repeat(3) { columnIndex ->
                                val index = rowIndex * 3 + columnIndex
                                val player = board[index]
                                Box(
                                    Modifier
                                        .weight(1f)
                                        .aspectRatio(1f)
                                        .clip(RoundedCornerShape(18.dp))
                                        .background(MaterialTheme.colorScheme.surfaceContainerHigh)
                                        .clickable(enabled = player == 0 && winner == 0 && !isDraw) {
                                            board = board.toMutableList().also { it[index] = currentPlayer }
                                            currentPlayer = if (currentPlayer == 1) 2 else 1
                                        },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        when (player) {
                                            1 -> "×"
                                            2 -> "○"
                                            else -> ""
                                        },
                                        style = MaterialTheme.typography.displayMedium,
                                        fontWeight = FontWeight.Black,
                                        color = if (player == 1) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.tertiary
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
                Button(onClick = { board = List(9) { 0 }; currentPlayer = 1 }) { Text("شروع دوباره") }
            }
        }
    }
}

@Composable
private fun ConnectFourGame(modifier: Modifier = Modifier) {
    val rowCount = 6
    val columnCount = 7
    var board by remember { mutableStateOf(List(rowCount * columnCount) { 0 }) }
    var currentPlayer by remember { mutableIntStateOf(1) }
    var winner by remember { mutableIntStateOf(0) } // 0 active, -1 draw, 1 or 2 winner

    fun dropDisc(column: Int) {
        if (winner != 0) return
        val row = (rowCount - 1 downTo 0).firstOrNull { board[it * columnCount + column] == 0 } ?: return
        val updated = board.toMutableList()
        updated[row * columnCount + column] = currentPlayer
        board = updated
        when {
            hasConnectFour(updated, row, column, currentPlayer, rowCount, columnCount) -> winner = currentPlayer
            updated.none { it == 0 } -> winner = -1
            else -> currentPlayer = if (currentPlayer == 1) 2 else 1
        }
    }

    LazyColumn(
        modifier = modifier,
        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            GameStatusCard(
                title = when (winner) {
                    1, 2 -> "بازیکن ${winnerFa(winner)} برنده شد!"
                    -1 -> "بازی مساوی شد"
                    else -> "نوبت بازیکن ${winnerFa(currentPlayer)}"
                },
                subtitle = "روی یکی از خانه‌های ستون بزنید تا مهره در آن ستون بیفتد."
            )
        }
        item {
            Card(
                Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.55f))
            ) {
                Column(Modifier.fillMaxWidth().padding(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    repeat(rowCount) { row ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            repeat(columnCount) { column ->
                                val player = board[row * columnCount + column]
                                Box(
                                    Modifier
                                        .weight(1f)
                                        .aspectRatio(1f)
                                        .clip(CircleShape)
                                        .background(
                                            when (player) {
                                                1 -> MaterialTheme.colorScheme.primary
                                                2 -> MaterialTheme.colorScheme.tertiary
                                                else -> MaterialTheme.colorScheme.surfaceContainerHighest
                                            }
                                        )
                                        .clickable(enabled = winner == 0 && board[column] == 0) { dropDisc(column) },
                                    contentAlignment = Alignment.Center
                                ) {
                                }
                            }
                        }
                    }
                }
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
                Button(onClick = { board = List(rowCount * columnCount) { 0 }; currentPlayer = 1; winner = 0 }) {
                    Text("شروع دوباره")
                }
            }
        }
    }
}

private enum class HandChoice(val title: String, val symbol: String) {
    ROCK("سنگ", "✊"),
    PAPER("کاغذ", "✋"),
    SCISSORS("قیچی", "✌️")
}

@Composable
private fun RockPaperScissorsGame(modifier: Modifier = Modifier) {
    var firstChoice by remember { mutableStateOf<HandChoice?>(null) }
    var secondChoice by remember { mutableStateOf<HandChoice?>(null) }
    var firstScore by remember { mutableIntStateOf(0) }
    var secondScore by remember { mutableIntStateOf(0) }

    fun choose(choice: HandChoice) {
        if (secondChoice != null) return
        val first = firstChoice
        if (first == null) {
            firstChoice = choice
        } else {
            secondChoice = choice
            when (handWinner(first, choice)) {
                1 -> firstScore++
                2 -> secondScore++
            }
        }
    }

    val roundResult = if (firstChoice != null && secondChoice != null) {
        handWinner(firstChoice!!, secondChoice!!)
    } else null

    LazyColumn(
        modifier = modifier,
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            GameStatusCard(
                title = when {
                    roundResult == null && firstChoice == null -> "نوبت بازیکن اول"
                    roundResult == null -> "نوبت بازیکن دوم؛ گوشی را بدهید"
                    roundResult == 0 -> "این دور مساوی شد"
                    else -> "بازیکن ${winnerFa(roundResult)} این دور را برد"
                },
                subtitle = "انتخاب بازیکن اول تا زمان انتخاب نفر دوم پنهان می‌ماند."
            )
        }
        item {
            Card(
                Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(26.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow)
            ) {
                Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                        ScorePill("بازیکن اول", firstScore)
                        ScorePill("بازیکن دوم", secondScore)
                    }
                    if (roundResult != null) {
                        Text(
                            "بازیکن اول: ${firstChoice!!.symbol}  ·  بازیکن دوم: ${secondChoice!!.symbol}",
                            modifier = Modifier.fillMaxWidth(),
                            textAlign = TextAlign.Center,
                            fontWeight = FontWeight.Bold
                        )
                    } else if (firstChoice != null) {
                        Text(
                            "انتخاب نفر اول ثبت شد. گوشی را به بازیکن دوم بدهید.",
                            modifier = Modifier.fillMaxWidth(),
                            textAlign = TextAlign.Center,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Row(
                        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        HandChoice.values().forEach { choice ->
                            OutlinedButton(onClick = { choose(choice) }, enabled = secondChoice == null) {
                                Text("${choice.symbol} ${choice.title}")
                            }
                        }
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
                        if (roundResult != null) {
                            TextButton(onClick = { firstChoice = null; secondChoice = null }) { Text("دور بعدی") }
                        }
                        TextButton(onClick = {
                            firstChoice = null
                            secondChoice = null
                            firstScore = 0
                            secondScore = 0
                        }) { Text("شروع دوباره از صفر") }
                    }
                }
            }
        }
    }
}

@Composable
private fun GameStatusCard(title: String, subtitle: String) {
    Card(
        Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.68f))
    ) {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Black)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun ScorePill(label: String, score: Int) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(score.toString(), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Black, color = MaterialTheme.colorScheme.primary)
    }
}

private fun winnerFa(player: Int): String = if (player == 1) "اول" else "دوم"

private fun ticTacToeWinner(board: List<Int>): Int {
    val lines = listOf(
        listOf(0, 1, 2), listOf(3, 4, 5), listOf(6, 7, 8),
        listOf(0, 3, 6), listOf(1, 4, 7), listOf(2, 5, 8),
        listOf(0, 4, 8), listOf(2, 4, 6)
    )
    return lines.firstNotNullOfOrNull { line ->
        val player = board[line.first()]
        player.takeIf { it != 0 && line.all { cell -> board[cell] == player } }
    } ?: 0
}

private fun hasConnectFour(board: List<Int>, row: Int, column: Int, player: Int, rows: Int, columns: Int): Boolean {
    fun countDirection(rowStep: Int, columnStep: Int, sign: Int): Int {
        var r = row + rowStep * sign
        var c = column + columnStep * sign
        var count = 0
        while (r in 0 until rows && c in 0 until columns && board[r * columns + c] == player) {
            count++
            r += rowStep * sign
            c += columnStep * sign
        }
        return count
    }
    val directions = listOf(0 to 1, 1 to 0, 1 to 1, 1 to -1)
    return directions.any { (rowStep, columnStep) ->
        1 + countDirection(rowStep, columnStep, 1) + countDirection(rowStep, columnStep, -1) >= 4
    }
}

private fun handWinner(first: HandChoice, second: HandChoice): Int = when {
    first == second -> 0
    first == HandChoice.ROCK && second == HandChoice.SCISSORS -> 1
    first == HandChoice.PAPER && second == HandChoice.ROCK -> 1
    first == HandChoice.SCISSORS && second == HandChoice.PAPER -> 1
    else -> 2
}
