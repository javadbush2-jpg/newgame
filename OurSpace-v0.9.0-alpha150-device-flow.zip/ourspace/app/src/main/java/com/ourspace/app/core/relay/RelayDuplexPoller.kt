package com.ourspace.app.core.relay

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.util.Log
import android.os.SystemClock
import com.ourspace.app.core.database.OurSpaceDatabase
import com.ourspace.app.core.attachment.AttachmentChunkAssembler
import com.ourspace.app.core.attachment.AttachmentIntegrity
import android.util.Base64
import com.ourspace.app.core.preferences.AppPreferences
import com.ourspace.app.core.security.DeviceIdentityManager
import com.ourspace.app.core.sync.HostSyncExchangeProcessor
import com.ourspace.app.core.sync.IncrementalSyncCodec
import com.ourspace.app.core.sync.SyncSnapshotCodec
import com.ourspace.app.core.webrtc.ConnectionDiagnostics
import com.ourspace.app.core.webrtc.WebRtcSession
import com.ourspace.app.core.push.FcmTokenRegistrar
import com.ourspace.app.model.DeviceRole
import java.io.IOException
import java.security.MessageDigest
import java.util.UUID
import java.util.concurrent.atomic.AtomicReference
import kotlin.math.min
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import org.json.JSONObject

/**
 * Low-latency, durable relay transport for both devices.
 *
 * Design goals:
 * - WebSocket /v1/push wakes the phone the moment the relay accepts new mail (path 3);
 * - long-poll remains as a safety net when the WebSocket is down;
 * - a Room change observer wakes the sender immediately, so phone -> server does not wait for
 *   a polling interval;
 * - the old WorkManager/periodic sync remains only as a recovery mechanism;
 * - changes are claimed before transmission and are removed only after durable relay publish;
 * - binary attachments use integrity-checked chunks so chat, timeline and album images replicate.
 */
class RelayDuplexPoller(context: Context) {
    private data class PendingTypingSignal(
        val isTyping: Boolean,
        val sentAt: Long,
        val queuedAtElapsedMs: Long
    )

    private val appContext = context.applicationContext
    private val preferences = AppPreferences(appContext)
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val wake = Channel<Unit>(Channel.CONFLATED)
    private val pendingTyping = AtomicReference<PendingTypingSignal?>(null)
    private val networkLost = Channel<Unit>(Channel.CONFLATED)
    private val networkRestored = Channel<Unit>(Channel.CONFLATED)
    @Volatile private var partnerLocationRefreshRequested = false
    @Volatile private var networkCallback: ConnectivityManager.NetworkCallback? = null
    private var job: Job? = null

    @Volatile var lastSuccessAt: Long = 0L
        private set
    @Volatile var lastError: String? = null
        private set
    @Volatile var serverReachable: Boolean = false
        private set

    @Synchronized
    fun start() {
        if (job?.isActive == true) return
        ConnectionDiagnostics.setState(ConnectionDiagnostics.ConnectionState.CONNECTING)
        registerNetworkCallback()
        job = scope.launch { loop() }
    }

    @Synchronized
    fun stop() {
        ConnectionDiagnostics.setPushConnected(false)
        // قطع سرویس را «قطع کامل سرور» نشان نده؛ ممکن است بلافاصله دوباره استارت شود
        ConnectionDiagnostics.setState(ConnectionDiagnostics.ConnectionState.RECONNECTING)
        job?.cancel()
        job = null
        val manager = appContext.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
        networkCallback?.let { callback -> runCatching { manager?.unregisterNetworkCallback(callback) } }
        networkCallback = null
    }

    /** Network callbacks cut through long-poll waits after Wi-Fi/mobile connectivity changes. */
    private fun registerNetworkCallback() {
        if (networkCallback != null) return
        val manager = appContext.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
            ?: return
        val callback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                networkRestored.trySend(Unit)
                wake.trySend(Unit)
                ConnectionDiagnostics.log("شبکه در دسترس شد؛ همگام‌سازی فوری آغاز می‌شود")
            }

            override fun onLost(network: Network) {
                networkLost.trySend(Unit)
                ConnectionDiagnostics.setState(ConnectionDiagnostics.ConnectionState.RECONNECTING)
                ConnectionDiagnostics.log("شبکه قطع شد؛ اتصال سرور دوباره برقرار می‌شود")
            }
        }
        runCatching {
            manager.registerDefaultNetworkCallback(callback)
            networkCallback = callback
        }.onFailure { error ->
            Log.w(TAG, "Could not register network callback", error)
            ConnectionDiagnostics.log("تشخیص تغییر شبکه فعال نشد: ${error.javaClass.simpleName}")
        }
    }

    /** Wake the outbound side immediately. No periodic polling is required for local changes. */
    fun requestImmediateSync() {
        wake.trySend(Unit)
    }

    /** Queue the newest short-lived typing state and wake the relay sender. */
    fun requestTyping(
        isTyping: Boolean,
        sentAt: Long,
        queuedAtElapsedMs: Long = SystemClock.elapsedRealtime()
    ) {
        if (sentAt <= 0L) return
        pendingTyping.set(PendingTypingSignal(isTyping, sentAt, queuedAtElapsedMs))
        wake.trySend(Unit)
    }

    /** Ask the peer device to obtain a fresh GPS fix and return it through normal sync. */
    fun requestPartnerLocationRefresh() {
        partnerLocationRefreshRequested = true
        wake.trySend(Unit)
    }

    private suspend fun loop() {
        var failures = 0
        while (currentCoroutineContext().isActive) {
            try {
                val role = preferences.currentRole()
                val config = preferences.currentRelayConfig()
                if (role == null || !config.isUsable) {
                    // بعد از ری‌استارت ممکن است نقش/تنظیمات لحظه‌ای هنوز آماده نباشد
                    ConnectionDiagnostics.setState(ConnectionDiagnostics.ConnectionState.CONNECTING)
                    delay(1_500L)
                    continue
                }

                val accessToken = config.accessToken.trim()
                if (accessToken.isBlank()) {
                    ConnectionDiagnostics.setState(ConnectionDiagnostics.ConnectionState.CONNECTING)
                    lastError = "کلید مشترک خانه تنظیم نشده"
                    delay(1_500L)
                    continue
                }

                val credentials = RelayCredentials.fromAccessToken(accessToken)
                val relay = RelayClient(config.endpoint, credentials)
                Log.i(TAG, "relay mailbox=${credentials.mailboxId.take(12)} role=$role (household)")
                ConnectionDiagnostics.setState(ConnectionDiagnostics.ConnectionState.CONNECTING)

                // Health is a connection bootstrap check only. The old implementation called
                // /health before every short poll, adding avoidable latency and traffic.
                val health = relay.healthReport()
                serverReachable = health.ok
                if (!health.ok) {
                    val detail = health.raw.ifBlank { "بدون پاسخ" }.take(160)
                    throw IllegalStateException(
                        "سرور شخصی در دسترس نیست — ${config.endpoint} — $detail"
                    )
                }
                ConnectionDiagnostics.setState(ConnectionDiagnostics.ConnectionState.CONNECTING)
                FcmTokenRegistrar.refreshAndUpload(appContext)
                ConnectionDiagnostics.log(
                    "سرور پاسخ‌گوست؛ دریافت احراز‌شدهٔ صندوق در حال بررسی است | صندوق ${credentials.mailboxId.take(12)}… | pending=${health.pendingMessages}"
                )

                // The session contains two concurrent lanes:
                // 1) a long-poll receiver for immediate server -> phone delivery;
                // 2) a Room-driven sender for immediate phone -> server delivery.
                runConnectedSession(role, relay)
                failures = 0
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (error: Exception) {
                failures += 1
                lastError = error.message?.take(160)
                serverReachable = false
                ConnectionDiagnostics.setState(ConnectionDiagnostics.ConnectionState.RECONNECTING)
                ConnectionDiagnostics.log("اتصال سرور: ${error.message ?: error.javaClass.simpleName}")
                Log.w(TAG, "duplex session failed", error)
                // Cap retry sleep at 3.2s and interrupt it as soon as Android reports
                // that connectivity has returned. A stale network callback is harmless:
                // it only causes one early retry, never data loss.
                val wait = min(3_200L, 400L * (1L shl min(failures - 1, 3)))
                withTimeoutOrNull(wait) { networkRestored.receive() }
            }
        }
    }

    private suspend fun runConnectedSession(role: DeviceRole, relay: RelayClient) = coroutineScope {
        val database = OurSpaceDatabase.getInstance(appContext)
        val deviceId = DeviceIdentityManager().getOrCreateIdentity().deviceId
        val codec = IncrementalSyncCodec(database, deviceId)
        val processor = HostSyncExchangeProcessor(appContext)
        val attachmentAssembler = AttachmentChunkAssembler(appContext)
        val outboundWake = Channel<Unit>(Channel.CONFLATED)
        val inboundWake = Channel<Unit>(Channel.CONFLATED)
        val inboundDirection = if (role == DeviceRole.HOST) {
            RelayDirection.TO_HOST
        } else {
            RelayDirection.TO_COMPANION
        }
        val inboundMutex = Mutex()

        // Fast-path: apply peer deltas arriving over WebRTC without waiting for mailbox long-poll.
        WebRtcSession.setDeltaListener { envelope ->
            scope.launch {
                runCatching {
                    val type = envelope.optString("type")
                    when (type) {
                        "incremental_exchange" -> {
                            val response = processor.processMessage(envelope)
                            // مسیر سریع WebRTC + مسیر پایدار رله تا ACK گم نشود
                            WebRtcSession.sendRealtimeDelta(response)
                            runCatching {
                                relay.publish(
                                    direction = oppositeDirection(role),
                                    envelope = response,
                                    messageId = newRelayMessageId()
                                )
                            }.onFailure { err ->
                                Log.w(TAG, "WebRTC ACK relay publish failed: ${err.message}")
                            }
                            ConnectionDiagnostics.log("WebRTC: exchange اعمال شد؛ ACK روی کانال فوری و رله ارسال شد")
                            outboundWake.trySend(Unit)
                        }
                        "incremental_exchange_result" -> {
                            val delta = envelope.optJSONObject("delta")
                            if (delta != null) {
                                val sentAckIds = envelope.optJSONArray("acknowledgementIds")?.let { array ->
                                    buildList {
                                        for (index in 0 until array.length()) {
                                            val id = array.optString(index)
                                            if (id.isNotBlank()) add(id)
                                        }
                                    }
                                }.orEmpty()
                                val applied = codec.applyCompanionResponse(delta, sentAckIds)
                                ConnectionDiagnostics.log(
                                    "WebRTC result: +${applied.receivedChanges} / ACK ${applied.acknowledgedLocalChanges}"
                                )
                                // همیشه بیدار شو تا ACKهای باقی‌مانده و صف پیام‌ها خالی شوند
                                outboundWake.trySend(Unit)
                            }
                        }
                    }
                }.onFailure { error ->
                    Log.w(TAG, "WebRTC delta apply failed: ${error.message}")
                }
            }
        }
        // Keep FCM token fresh while the duplex session is alive (no-op if Firebase absent).
        FcmTokenRegistrar.refreshAndUpload(appContext)


        // A process/network interruption can leave durable outbox rows in SENDING.
        // The previous session is already gone at this point, so release them for an
        // immediate idempotent retry instead of leaving them displayed as awaiting ACK.
        val interrupted = database.syncChangeDao().sendingIds()
        if (interrupted.isNotEmpty()) {
            database.syncChangeDao().releaseAllSending(System.currentTimeMillis())
            ConnectionDiagnostics.log("${interrupted.size} تغییر نیمه‌تمام برای ارسال مجدد آزاد شد")
        }

        // If Android reports loss of the default network, fail this session instead of
        // leaving the inbound lane waiting for its old HTTP read timeout. Structured
        // concurrency then cancels both lanes and the outer loop reconnects with backoff.
        val networkMonitorJob = launch {
            networkLost.receive()
            throw IOException("اتصال شبکه تغییر کرد؛ تلاش مجدد برای اتصال سرور")
        }

        // External/manual wake requests and Room changes both reach the same sender lane.
        val bridgeJob = launch {
            while (isActive) {
                wake.receive()
                outboundWake.trySend(Unit)
                // Manual sync and network restoration should also drain the inbox now, rather
                // than waiting for the current long-poll or a WebSocket wake.
                inboundWake.trySend(Unit)
            }
        }

        // Room is the source of truth: as soon as a textual entity changes, wake transport.
        val pendingObserverJob = launch {
            database.syncChangeDao().observePendingOnlyCount().collect { count ->
                if (count > 0) outboundWake.trySend(Unit)
            }
        }
        val ackObserverJob = launch {
            database.syncAcknowledgementDao().observePendingCount().collect { count ->
                if (count > 0) outboundWake.trySend(Unit)
            }
        }

        // SENDING rows do not change the PENDING-count flow when their retry deadline
        // expires. Periodically wake the sender so timed-out changes are reclaimed even
        // when the user makes no new edits and the app stays open in the background.
        val retryTickerJob = launch {
            while (isActive) {
                delay(RETRY_TICK_MS)
                // آزادسازی ردیف‌های SENDING منقضی‌شده تا دوباره claim شوند
                runCatching {
                    val now = System.currentTimeMillis()
                    val stale = database.syncChangeDao().due(
                        now = now,
                        staleBefore = now - IncrementalSyncCodec.IN_FLIGHT_TIMEOUT_MS_PUBLIC,
                        limit = 1
                    )
                    if (stale.isNotEmpty()) outboundWake.trySend(Unit)
                    else outboundWake.trySend(Unit)
                }.onFailure {
                    outboundWake.trySend(Unit)
                }
            }
        }

        // Path 3: persistent WebSocket push — server wakes us the moment mail is published.
        // Message bodies still arrive only through the encrypted HTTP mailbox API.
        // inboundMutex serializes processing so WS-drain and long-poll never double-handle
        // the same envelope (which could publish duplicate exchange responses).
        val pushClient = run {
            val cfg = preferences.currentRelayConfig()
            RelayPushClient(cfg.endpoint, cfg.accessToken, this, deviceRole = role.persistedName)
        }
        // Subscribe before opening the socket. SharedFlow has no replay cache, so the old
        // connect-before-collect order could drop the initial hello/mail wake.
        val pushJob = launch(start = CoroutineStart.UNDISPATCHED) {
            try {
                pushClient.events.collect { event ->
                    when (event) {
                        is RelayPushClient.PushEvent.Connected -> {
                            ConnectionDiagnostics.setPushConnected(true)
                            ConnectionDiagnostics.touchActivity()
                            ConnectionDiagnostics.log("کانال فوری WebSocket فعال شد")
                            inboundWake.trySend(Unit)
                        }
                        is RelayPushClient.PushEvent.Mail -> {
                            ConnectionDiagnostics.touchActivity()
                            if (event.direction.isBlank() || event.direction == inboundDirection.wireName) {
                                inboundWake.trySend(Unit)
                            }
                        }
                        is RelayPushClient.PushEvent.Disconnected -> {
                            ConnectionDiagnostics.setPushConnected(false)
                            ConnectionDiagnostics.log("WebSocket قطع شد؛ در حال اتصال مجدد / long-poll پشتیبان")
                        }
                    }
                }
            } finally {
                pushClient.close()
            }
        }
        pushClient.connect()

        suspend fun drainInboundOnce() {
            inboundMutex.withLock {
                val messages = relay.receive(inboundDirection, limit = 50, waitSeconds = 0)
                ConnectionDiagnostics.inboxPollSucceeded(inboundDirection.wireName, messages.size)
                if (messages.isEmpty()) return
                ConnectionDiagnostics.log(
                    "پیام در صندوق دریافت شد | جهت ${inboundDirection.wireName} | تعداد ${messages.size}"
                )
                for (message in messages) {
                    processInboundMessage(role, relay, codec, processor, attachmentAssembler, message)
                }
                outboundWake.trySend(Unit)
                lastSuccessAt = System.currentTimeMillis()
                lastError = null
            }
        }

        // Instant drain lane driven by WebSocket mail signals (and hello).
        val pushDrainJob = launch {
            while (isActive) {
                inboundWake.receive()
                try {
                    drainInboundOnce()
                } catch (cancelled: CancellationException) {
                    throw cancelled
                } catch (error: Exception) {
                    ConnectionDiagnostics.failed()
                    ConnectionDiagnostics.log(
                        "دریافت فوری از صندوق ناموفق بود: ${error.message ?: error.javaClass.simpleName}"
                    )
                    Log.w(TAG, "push-drain: ${error.message}", error)
                }
            }
        }

        // Long-poll safety net (shorter when WS is down, longer when WS is healthy).
        val inboundJob = launch {
            while (isActive) {
                // Shorter poll when push is down or local outbox is non-empty; longer when idle + WS healthy.
                val pendingOutbox = runCatching {
                    database.syncChangeDao().due(
                        System.currentTimeMillis(),
                        System.currentTimeMillis() - IncrementalSyncCodec.IN_FLIGHT_TIMEOUT_MS_PUBLIC,
                        1
                    ).isNotEmpty()
                }.getOrDefault(false)
                val waitSeconds = when {
                    pendingOutbox -> 3
                    pushClient.isConnected -> 22
                    else -> 6
                }
                try {
                    // Peek with long-poll outside the mutex so we do not block push-drain.
                    val messages = relay.receive(inboundDirection, limit = 50, waitSeconds = waitSeconds)
                    if (messages.isEmpty()) {
                        ConnectionDiagnostics.inboxPollSucceeded(inboundDirection.wireName, 0)
                        continue
                    }
                    inboundMutex.withLock {
                        // Re-fetch under lock to avoid processing envelopes another lane ACKed.
                        val fresh = relay.receive(inboundDirection, limit = 50, waitSeconds = 0)
                        ConnectionDiagnostics.inboxPollSucceeded(inboundDirection.wireName, fresh.size)
                        if (fresh.isEmpty()) return@withLock
                        ConnectionDiagnostics.log(
                            "پیام در صندوق دریافت شد | جهت ${inboundDirection.wireName} | تعداد ${fresh.size}"
                        )
                        for (message in fresh) {
                            processInboundMessage(role, relay, codec, processor, attachmentAssembler, message)
                        }
                        outboundWake.trySend(Unit)
                        lastSuccessAt = System.currentTimeMillis()
                        lastError = null
                    }
                } catch (cancelled: CancellationException) {
                    throw cancelled
                } catch (error: Exception) {
                    ConnectionDiagnostics.failed()
                    ConnectionDiagnostics.log(
                        "خواندن صندوق ${inboundDirection.wireName} ناموفق بود: ${error.message ?: error.javaClass.simpleName}"
                    )
                    throw error
                }
            }
        }

        // پشتیبان کامل فقط دستی از تنظیمات گرفته می‌شود (backupNow روی گوشی میزبان).
        // پشتیبان‌گیری خودکار هر دقیقه حذف شد تا ترافیک و بار سرور کم باشد.

        val outboundJob = launch {
            // Flush anything already waiting as soon as the connection is established.
            outboundWake.trySend(Unit)
            while (isActive) {
                outboundWake.receive()
                // Drain all currently claimable work. Once claimed, rows become SENDING and
                // cannot spin; the peer ACK moves them to deleted/complete state.
                while (isActive) {
                    val didWork = flushOutbound(role, relay, codec, database)
                    if (!didWork) break
                }
                lastSuccessAt = System.currentTimeMillis()
                lastError = null
            }
        }

        // Structured concurrency: a failure in either transport lane cancels the sibling
        // immediately. This avoids the old sequential join() bug where a failed outbound
        // lane could remain hidden behind the forever-running inbound long-poll.
        try {
            kotlinx.coroutines.joinAll(inboundJob, outboundJob)
        } finally {
            WebRtcSession.setDeltaListener(null)
            pushClient.close()
            bridgeJob.cancel()
            networkMonitorJob.cancel()
            pendingObserverJob.cancel()
            ackObserverJob.cancel()
            retryTickerJob.cancel()
            pushJob.cancel()
            pushDrainJob.cancel()
            inboundJob.cancel()
            outboundJob.cancel()
        }
    }

    private suspend fun processInboundMessage(
        role: DeviceRole,
        relay: RelayClient,
        codec: IncrementalSyncCodec,
        processor: HostSyncExchangeProcessor,
        attachmentAssembler: AttachmentChunkAssembler,
        message: RelayMessage
    ) {
        val envelope = message.envelope
        val type = envelope.optString("type")
        try {
            when (type) {
                // A request from either phone is handled identically. The receiver applies the
                // sender's delta and returns its own current delta plus acknowledgements.
                "incremental_exchange" -> {
                    // Apply peer delta + build our response (includes acknowledgedChanges).
                    val response = processor.processMessage(envelope)
                    try {
                        relay.publish(
                            direction = oppositeDirection(role),
                            envelope = response,
                            correlationId = message.messageId,
                            messageId = newRelayMessageId()
                        )
                        ConnectionDiagnostics.sent()
                    } catch (publishError: Exception) {
                        // Changes already applied locally. Still ACK the inbound mailbox row
                        // so a full queue does not block forever; our own outbox will push later.
                        val msg = publishError.message.orEmpty()
                        if (msg.contains("429") || msg.contains("mailbox_full", ignoreCase = true)) {
                            ConnectionDiagnostics.log("پاسخ همگام‌سازی در صف سرور جا نشد؛ بعداً از outbox ارسال می‌شود")
                        } else {
                            throw publishError
                        }
                    }
                    ConnectionDiagnostics.received(message.messageId)
                }

                // Response to a request we previously sent. This is where SENDING -> ACKED
                // happens, so successful delivery is durable and retry-safe.
                "incremental_exchange_result" -> {
                    if (envelope.has("locationRefresh")) {
                        if (envelope.optBoolean("locationRefresh")) {
                            val refreshedLocation = envelope.optJSONObject("refreshedLocation")
                            if (refreshedLocation != null) {
                                val locationId = refreshedLocation.optString("id")
                                if (locationId.isNotBlank()) {
                                    SyncSnapshotCodec(OurSpaceDatabase.getInstance(appContext), appContext).mergeSnapshot(
                                        JSONObject()
                                            .put("schema", 6)
                                            .put("generatedAt", System.currentTimeMillis())
                                            .put("locationShares", org.json.JSONArray().put(refreshedLocation)),
                                        setOf("locationShares:$locationId")
                                    )
                                    ConnectionDiagnostics.log("موقعیت تازه گوشی مقابل دریافت و روی نقشه ثبت شد")
                                } else {
                                    ConnectionDiagnostics.log("گوشی مقابل موقعیت را تازه کرد، اما شناسه موقعیت معتبر نبود")
                                }
                            } else {
                                ConnectionDiagnostics.log("گوشی مقابل موقعیت را تازه کرد، اما مختصات در پاسخ نبود")
                            }
                        } else {
                            val reason = envelope.optString("locationRefreshError").takeIf { it.isNotBlank() && it != "null" }
                                ?: "گوشی مقابل نتوانست موقعیت را دریافت کند"
                            ConnectionDiagnostics.log("به‌روزرسانی موقعیت گوشی مقابل ناموفق بود: $reason")
                        }
                    }
                    val delta = envelope.optJSONObject("delta")
                    if (delta != null) {
                        val sentAckIds = envelope.optJSONArray("acknowledgementIds")?.let { array ->
                            buildList {
                                for (index in 0 until array.length()) add(array.getString(index))
                            }
                        }.orEmpty()
                        val identity = DeviceIdentityManager().getOrCreateIdentity()
                        val unreadBefore = OurSpaceDatabase.getInstance(appContext).messageDao().unreadCountOnce(identity.deviceId)
                        val applied = codec.applyCompanionResponse(delta, sentAckIds)
                        if (applied.receivedChanges > 0) {
                            runCatching { com.ourspace.app.core.reminder.HabitReminderScheduler.scheduleAll(appContext) }
                            runCatching {
                                com.ourspace.app.core.notification.OurSpaceNotificationCenter(appContext)
                                    .showRemoteChanges(applied.receivedChanges, listOf("اطلاعات مشترک"))
                            }
                        }
                        val unreadAfter = OurSpaceDatabase.getInstance(appContext).messageDao().unreadCountOnce(identity.deviceId)
                        if (unreadAfter > unreadBefore) {
                            runCatching {
                                com.ourspace.app.core.notification.OurSpaceNotificationCenter(appContext)
                                    .showNewMessages(unreadAfter - unreadBefore)
                            }
                        }
                        if (applied.receivedChanges > 0 || applied.acknowledgedLocalChanges > 0) {
                            ConnectionDiagnostics.received(message.messageId)
                        }
                    }
                }

                "attachment_tombstone" -> {
                    val deleted = envelope.getJSONObject("attachment")
                    codec.applyRealtimeAttachment(deleted, deleted.optString("changeId").takeIf { it.isNotBlank() })
                    ConnectionDiagnostics.received(message.messageId)
                }

                "attachment_blob" -> {
                    val attJson = envelope.getJSONObject("attachment")
                    val sha = attJson.optString("blobSha256").ifBlank { attJson.optString("sha256") }
                    require(sha.isNotBlank()) { "attachment_blob missing sha256" }
                    val bytes = relay.getBlob(sha)
                    require(bytes.isNotEmpty()) { "empty blob" }
                    require(AttachmentIntegrity.verify(bytes, bytes.size.toLong(), sha.lowercase())) {
                        "blob integrity mismatch"
                    }
                    val merged = JSONObject(attJson.toString())
                        .put(
                            "content",
                            android.util.Base64.encodeToString(
                                bytes,
                                android.util.Base64.URL_SAFE or android.util.Base64.NO_WRAP or android.util.Base64.NO_PADDING
                            )
                        )
                        .put("sizeBytes", bytes.size.toLong())
                        .put("sha256", sha.lowercase())
                    codec.applyRealtimeAttachment(
                        merged,
                        merged.optString("changeId").takeIf { it.isNotBlank() }
                    )
                    ConnectionDiagnostics.log("عکس باینری دریافت شد: ${merged.optString("fileName", "photo")}")
                    ConnectionDiagnostics.received(message.messageId)
                }

                "attachment_chunk" -> {
                    val chunk = envelope.getJSONObject("chunk")
                    val transferId = chunk.getString("transferId")
                    val completed = attachmentAssembler.accept(chunk)
                    if (completed != null) {
                        // Commit to Room before deleting staged bytes or acknowledging the final
                        // relay message. A missing parent can be resolved by a later sync message.
                        codec.applyRealtimeAttachment(
                            completed,
                            completed.optString("changeId").takeIf { it.isNotBlank() }
                        )
                        // End-to-end ACK: sender keeps its durable outbox row until this
                        // message returns through the relay. Publishing chunks alone is not
                        // proof that the receiver reconstructed and stored the file.
                        relay.publish(
                            direction = oppositeDirection(role),
                            envelope = JSONObject()
                                .put("type", "attachment_transfer_ack")
                                .put("transferId", transferId)
                                .put("changeId", completed.optString("changeId")),
                            messageId = stableResponseMessageId(transferId, "attachment-transfer-ack")
                        )
                        // Only discard staged chunks after the ACK itself is durably queued.
                        // If publishing the ACK fails, the relay retries the final chunk and
                        // the assembler can reconstruct the completed file again.
                        attachmentAssembler.complete(transferId)
                        ConnectionDiagnostics.log("تصویر دریافت و ذخیره شد: ${completed.optString("fileName", "attachment")}")
                    }
                    ConnectionDiagnostics.received(message.messageId)
                }

                "attachment_transfer_ack" -> {
                    val transferId = envelope.optString("transferId")
                    val changeId = envelope.optString("changeId")
                    if (transferId.isNotBlank() && changeId.isNotBlank()) {
                        // The peer only emits this after the assembled bytes pass SHA-256
                        // validation and the attachment has been committed to Room.
                        OurSpaceDatabase.getInstance(appContext).syncChangeDao()
                            .deleteAcknowledged(listOf(changeId))
                        ConnectionDiagnostics.log("تکمیل انتقال پیوست تأیید شد: ${transferId.take(12)}")
                    }
                }

                "location_refresh_request" -> {
                    val response = processor.processMessage(envelope)
                    relay.publish(
                        direction = oppositeDirection(role),
                        envelope = response,
                        correlationId = message.messageId,
                        messageId = newRelayMessageId()
                    )
                    ConnectionDiagnostics.received(message.messageId)
                    ConnectionDiagnostics.sent()
                }

                "typing_presence" -> {
                    WebRtcSession.receiveTyping(
                        isTyping = envelope.getBoolean("isTyping"),
                        sentAt = envelope.optLong("sentAt", message.createdAt)
                    )
                    ConnectionDiagnostics.received(message.messageId)
                }

                else -> {
                    // Keep compatibility with older alpha messages handled by the existing
                    // host processor. Unsupported messages are ACKed by the normal mailbox
                    // acknowledgement below rather than blocking the queue forever.
                    val response = runCatching { processor.processMessage(envelope) }.getOrNull()
                    if (response != null) {
                        relay.publish(
                            direction = oppositeDirection(role),
                            envelope = response,
                            correlationId = message.messageId,
                            messageId = newRelayMessageId()
                        )
                    }
                }
            }
            relay.acknowledge(inboundDirectionFor(role), listOf(message.messageId))
            ConnectionDiagnostics.ack()
        } catch (error: HostSyncExchangeProcessor.PairingRequiredException) {
            // Do not ACK a pairing-required message: it can be retried after pairing repair.
            throw error
        } catch (error: Exception) {
            // An attachment may race its parent message/memory over the relay. Keep the final
            // chunk unacknowledged and staged; later messages in the same batch can deliver the
            // parent, after which the relay retries this chunk and the database commit succeeds.
            val errorText = error.message.orEmpty()
            if (type == "attachment_chunk" &&
                (errorText.contains("Missing message parent", ignoreCase = true) ||
                 errorText.contains("Missing memory parent", ignoreCase = true))) {
                ConnectionDiagnostics.log("تصویر دریافت شد اما منتظر همگام‌سازی پیام/خاطره است؛ انتقال نگه داشته شد")
                delay(750L)
                return
            }
            // Malformed payloads should not poison the mailbox indefinitely. Transport errors
            // are rethrown so the message remains durable and is retried.
            if (error is org.json.JSONException || error is IllegalArgumentException) {
                relay.acknowledge(inboundDirectionFor(role), listOf(message.messageId))
                ConnectionDiagnostics.ack()
                ConnectionDiagnostics.log("پیام نامعتبر کنار گذاشته شد: ${error.message ?: "unknown"}")
            } else {
                throw error
            }
        }
    }

    private suspend fun flushOutbound(
        role: DeviceRole,
        relay: RelayClient,
        codec: IncrementalSyncCodec,
        database: OurSpaceDatabase
    ): Boolean {
        var didWork = false

        pendingTyping.getAndSet(null)?.let { signal ->
            val age = SystemClock.elapsedRealtime() - signal.queuedAtElapsedMs
            if (age in 0L..MAX_PENDING_TYPING_AGE_MS) {
                try {
                    relay.publish(
                        direction = oppositeDirection(role),
                        envelope = JSONObject()
                            .put("type", "typing_presence")
                            .put("isTyping", signal.isTyping)
                            .put("sentAt", signal.sentAt),
                        ttlMillis = TYPING_RELAY_TTL_MS
                    )
                    ConnectionDiagnostics.sent()
                    didWork = true
                } catch (cancelled: CancellationException) {
                    pendingTyping.compareAndSet(null, signal)
                    throw cancelled
                } catch (error: Exception) {
                    // A typing hint is best-effort, unlike durable sync data. Retain it for
                    // the next outbound retry tick unless a newer state has already arrived.
                    pendingTyping.compareAndSet(null, signal)
                    ConnectionDiagnostics.log(
                        "نشانگر تایپ موقتاً از Relay ارسال نشد: ${error.message ?: error.javaClass.simpleName}"
                    )
                }
            }
        }

        if (partnerLocationRefreshRequested) {
            partnerLocationRefreshRequested = false
            val requestId = UUID.randomUUID().toString().replace("-", "")
            relay.publish(
                direction = oppositeDirection(role),
                envelope = JSONObject()
                    .put("type", "location_refresh_request")
                    .put("requestId", requestId)
                    .put("sentAt", System.currentTimeMillis())
            )
            didWork = true
        }

        val push = codec.prepareRealtimePush()
        if (push != null) {
            val envelope = JSONObject()
                .put("type", "incremental_exchange")
                .put("requestId", UUID.randomUUID().toString().replace("-", ""))
                .put("sentAt", System.currentTimeMillis())
                .put("delta", push.payload)
                .put("acknowledgementIds", org.json.JSONArray(push.acknowledgementIds))
            // Fast path: peer receives delta over DataChannel immediately when online.
            val webrtcSent = WebRtcSession.sendRealtimeDelta(envelope)
            if (webrtcSent) {
                ConnectionDiagnostics.log("WebRTC fast-path: ${push.changeIds.size} تغییر ارسال شد")
                WebRtcSession.sendNudge()
            }
            try {
                // Durable path: always publish to personal relay so offline peer still receives.
                relay.publish(
                    direction = oppositeDirection(role),
                    envelope = envelope,
                    messageId = push.messageId
                )
                ConnectionDiagnostics.sent(push.messageId)
                didWork = true
            } catch (error: Exception) {
                val msg = error.message.orEmpty()
                // message_conflict / replace already on server, or transient full mailbox:
                // keep SENDING window; do not immediately unlock for another flood.
                if (msg.contains("message_conflict", ignoreCase = true) ||
                    msg.contains("409") ||
                    msg.contains("mailbox_full", ignoreCase = true) ||
                    msg.contains("429")
                ) {
                    ConnectionDiagnostics.log("ارسال همگام‌سازی موقتاً متوقف شد: ${msg.take(80)}")
                    didWork = true
                } else {
                    codec.markRealtimePushFailed(push.changeIds)
                    throw error
                }
            }
        }

        // Attachments are deliberately transported separately from JSON deltas. The relay
        // envelope limit and Base64 expansion make embedding a full photo unreliable.
        val now = System.currentTimeMillis()
        val due = database.syncChangeDao().due(now, now - ATTACHMENT_IN_FLIGHT_TIMEOUT_MS, 20)
        val attachmentChange = due.firstOrNull { it.entityType == "attachments" }
        if (attachmentChange != null) {
            val attachment = database.attachmentDao().findById(attachmentChange.entityId)
            if (attachment == null) {
                database.syncChangeDao().deleteAcknowledged(listOf(attachmentChange.changeId))
                didWork = true
            } else {
                val transferId = stableResponseMessageId("${attachment.id}:${attachmentChange.changeId}", "attachment-transfer")
                val messageId = stableResponseMessageId(attachmentChange.changeId, "attachment-start")
                database.syncChangeDao().markSending(
                    listOf(attachmentChange.changeId), now, messageId,
                    now + ATTACHMENT_IN_FLIGHT_TIMEOUT_MS
                )
                try {
                    val content = attachment.content
                    if (attachment.isDeleted) {
                        relay.publish(
                            direction = oppositeDirection(role),
                            envelope = JSONObject().put("type", "attachment_tombstone").put("attachment", JSONObject()
                                .put("id", attachment.id)
                                .put("messageId", attachment.messageId ?: JSONObject.NULL)
                                .put("memoryId", attachment.memoryId ?: JSONObject.NULL)
                                .put("fileName", attachment.fileName)
                                .put("mimeType", attachment.mimeType)
                                .put("sizeBytes", attachment.sizeBytes.coerceAtLeast(1L))
                                .put("sha256", attachment.sha256)
                                .put("content", "")
                                .put("createdByDeviceId", attachment.createdByDeviceId)
                                .put("deleted", true)
                                .put("createdAt", attachment.createdAt)
                                .put("updatedAt", attachment.updatedAt)
                                .put("changeId", attachmentChange.changeId)),
                            messageId = stableResponseMessageId(transferId, "attachment-tombstone")
                        )
                        database.syncChangeDao().deleteAcknowledged(listOf(attachmentChange.changeId))
                        didWork = true
                        return didWork
                    }
                    if (content.isEmpty() || content.size.toLong() != attachment.sizeBytes ||
                        !AttachmentIntegrity.verify(content, attachment.sizeBytes, attachment.sha256)) {
                        throw IllegalArgumentException("Attachment content failed local integrity check")
                    }
                    // Preferred path: one binary PUT + tiny metadata envelope (no Base64 / multi-chunk JSON).
                    val binaryOk = runCatching {
                        relay.putBlob(
                            sha256 = attachment.sha256,
                            content = content,
                            mimeType = attachment.mimeType,
                            fileName = attachment.fileName
                        )
                        relay.publish(
                            direction = oppositeDirection(role),
                            envelope = JSONObject()
                                .put("type", "attachment_blob")
                                .put(
                                    "attachment",
                                    JSONObject()
                                        .put("id", attachment.id)
                                        .put("messageId", attachment.messageId ?: JSONObject.NULL)
                                        .put("memoryId", attachment.memoryId ?: JSONObject.NULL)
                                        .put("fileName", attachment.fileName)
                                        .put("mimeType", attachment.mimeType)
                                        .put("sizeBytes", attachment.sizeBytes)
                                        .put("sha256", attachment.sha256)
                                        .put("content", "")
                                        .put("createdByDeviceId", attachment.createdByDeviceId)
                                        .put("deleted", attachment.isDeleted)
                                        .put("createdAt", attachment.createdAt)
                                        .put("updatedAt", attachment.updatedAt)
                                        .put("changeId", attachmentChange.changeId)
                                        .put("blobSha256", attachment.sha256)
                                ),
                            messageId = stableResponseMessageId(transferId, "attachment-blob")
                        )
                        true
                    }.getOrDefault(false)
                    if (binaryOk) {
                        database.syncChangeDao().deleteAcknowledged(listOf(attachmentChange.changeId))
                        didWork = true
                        ConnectionDiagnostics.log("عکس باینری ارسال شد: ${attachment.fileName}")
                        return didWork
                    }
                    val total = (content.size + AttachmentChunkAssembler.CHUNK_BYTES - 1) / AttachmentChunkAssembler.CHUNK_BYTES
                    require(total in 1..MAX_ATTACHMENT_CHUNKS) { "Attachment is too large for chunk transport" }
                    val metadata = JSONObject()
                        .put("id", attachment.id)
                        .put("messageId", attachment.messageId ?: JSONObject.NULL)
                        .put("memoryId", attachment.memoryId ?: JSONObject.NULL)
                        .put("fileName", attachment.fileName)
                        .put("mimeType", attachment.mimeType)
                        .put("sizeBytes", attachment.sizeBytes)
                        .put("sha256", attachment.sha256)
                        .put("content", "")
                        .put("createdByDeviceId", attachment.createdByDeviceId)
                        .put("deleted", attachment.isDeleted)
                        .put("createdAt", attachment.createdAt)
                        .put("updatedAt", attachment.updatedAt)
                        .put("changeId", attachmentChange.changeId)
                    for (index in 0 until total) {
                        val start = index * AttachmentChunkAssembler.CHUNK_BYTES
                        val end = min(content.size, start + AttachmentChunkAssembler.CHUNK_BYTES)
                        val chunkBytes = content.copyOfRange(start, end)
                        val chunk = JSONObject()
                            .put("transferId", transferId)
                            .put("index", index)
                            .put("total", total)
                            .put("attachment", metadata)
                            .put("data", Base64.encodeToString(chunkBytes, Base64.NO_WRAP))
                        val chunkId = stableResponseMessageId("$transferId:$index", "attachment-chunk")
                        relay.publish(
                            direction = oppositeDirection(role),
                            envelope = JSONObject().put("type", "attachment_chunk").put("chunk", chunk),
                            messageId = chunkId
                        )
                    }
                    // Keep the durable source row until the receiver confirms full assembly,
                    // SHA-256 validation and Room commit. A retry reuses stable chunk IDs so
                    // the relay deduplicates already-published chunks where possible.
                    database.syncChangeDao().markRetry(
                        listOf(attachmentChange.changeId), System.currentTimeMillis(),
                        System.currentTimeMillis() + ATTACHMENT_RETRY_MS
                    )
                    didWork = true
                    ConnectionDiagnostics.log("قطعه‌های تصویر ارسال شد؛ منتظر تأیید مقصد هستیم: ${attachment.fileName}")
                } catch (error: Exception) {
                    database.syncChangeDao().markRetry(
                        listOf(attachmentChange.changeId), System.currentTimeMillis(),
                        System.currentTimeMillis() + ATTACHMENT_RETRY_MS
                    )
                    throw error
                }
            }
        }
        return didWork
    }

    /** Responses may be rebuilt from newer database state when an inbound message is retried.
     * A fresh transport ID prevents a stale queued response from causing message_conflict.
     * Delta application remains idempotent because each change carries its own changeId/version.
     */
    private fun newRelayMessageId(): String = UUID.randomUUID().toString().replace("-", "")

    private fun stableResponseMessageId(requestMessageId: String, kind: String): String {
        val input = "$kind:$requestMessageId".toByteArray(Charsets.UTF_8)
        val digest = MessageDigest.getInstance("SHA-256").digest(input)
        return digest.take(16).joinToString("") { "%02x".format(it) }
    }

    private fun inboundDirectionFor(role: DeviceRole): RelayDirection =
        if (role == DeviceRole.HOST) RelayDirection.TO_HOST else RelayDirection.TO_COMPANION

    private fun oppositeDirection(role: DeviceRole): RelayDirection =
        if (role == DeviceRole.HOST) RelayDirection.TO_COMPANION else RelayDirection.TO_HOST

    companion object {
        private const val RETRY_TICK_MS = 2_000L
        private const val TAG = "OurSpaceRelayDuplex"
        private const val ATTACHMENT_IN_FLIGHT_TIMEOUT_MS = 10 * 60 * 1000L
        private const val ATTACHMENT_RETRY_MS = 15_000L
        private const val MAX_ATTACHMENT_CHUNKS = 1024
        private const val TYPING_RELAY_TTL_MS = 60_000L
        private const val MAX_PENDING_TYPING_AGE_MS = 15_000L
    }
}
